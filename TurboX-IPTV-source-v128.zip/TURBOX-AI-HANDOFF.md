# TurboX IPTV — ملف تسليم كامل للذكاء الاصطناعي التالي

## 1. الهدف

TurboX IPTV هو تطبيق مشغل IPTV أصلي مبني بـ React Native وExpo SDK 52، مخصص للموبايل وAndroid TV/Google TV/Fire TV وAOSP TV Boxes. التطبيق لا يحتوي على قنوات أو أفلام أو مسلسلات جاهزة؛ المستخدم يدخل مصادره الخاصة.

الهوية الحالية: TurboX IPTV، واجهة سينمائية داكنة CyberDark، ألوان أساسية سماوي/أزرق مع إبرازات وردية، دعم RTL للعربية وLTR للإنجليزية.

> لا تضف بيانات دخول أو قوائم IPTV حقيقية إلى المصدر أو السجل أو ملفات التسليم.

## 2. التقنيات

- React Native 0.76.5
- Expo SDK 52 / prebuild-bare workflow
- TypeScript/TSX
- Android Native Kotlin
- AndroidX Media3 موجود كمشغل Native تجريبي، والمسار المستقر الحالي للتشغيل يستخدم Expo AV
- AsyncStorage للإعدادات والمفضلة والتقدم والكاش الحالي
- Expo SQLite مع طبقة قاعدة بيانات مهيأة للهجرة والتخزين الكبير
- FlatList + React.memo + batched M3U parser
- Android TV focus engine + جسر أحداث D-Pad من MainActivity إلى React Native

## 3. شجرة الملفات المهمة

- `App.tsx`: التطبيق الرئيسي، التنقل، الواجهة، المصادر، الفلترة، المفضلة، المشاهدة، المشغل، EPG، التحكم الأبوي، البروفايلات.
- `android/app/src/main/java/com/streambox/iptv/MainActivity.kt`: تهيئة Android، الخروج من Touch Mode، طلب التركيز الأولي، تسجيل أزرار الريموت، إرسال `TurboXRemoteKey` إلى JS.
- `android/app/src/main/java/com/streambox/iptv/player/PlayerController.kt`: مشغل Media3/ExoPlayer Native، Buffer وHeaders وfailover.
- `android/app/src/main/java/com/streambox/iptv/player/TurboPlayerView.kt`: SurfaceView وواجهة المشغل وربط DPAD أثناء المشاهدة.
- `android/app/src/main/java/com/streambox/iptv/player/DPADKeyEventHandler.kt`: اختصارات الريموت داخل المشغل.
- `android/app/src/main/java/com/streambox/iptv/player/PlayerOverlay.kt`: HUD وم drawers المشغل.
- `android/app/src/main/java/com/streambox/iptv/player/TurboPlayerModule.kt`: Native module.
- `android/app/src/main/java/com/streambox/iptv/player/TurboPlayerPackage.kt`: تسجيل الحزمة Native.
- `android/app/src/main/java/com/streambox/iptv/player/TurboPlayerViewManager.kt`: تصدير TurboPlayerView إلى React Native.
- `src/storage/database.ts`: تهيئة SQLite والجداول.
- `src/playlists/m3uParser.ts`: تحليل M3U على دفعات لتفادي تجميد الواجهة.
- `assets/turbox-logo.png`: الشعار داخل الواجهة.
- `assets/turbo-iptv-icon.png`: أيقونة التطبيق.
- `android/app/src/main/AndroidManifest.xml`: TV feature، touchscreen optional، landscape وcleartext.
- `app.json`: إعداد Expo واسم التطبيق والحزمة والأيقونة.
- `package.json` و`package-lock.json`: الاعتمادات.

## 4. الميزات الموجودة

### المصادر

- Xtream Codes API: `player_api.php`
- Live TV
- Movies/VOD
- Series
- EPG عبر `get_short_epg`
- M3U/M3U8 URL
- ملف M3U محلي عبر Document Picker
- عدة Providers مع تبديل المصدر من Settings
- بروفايلات متعددة ومفضلة منفصلة لكل profile
- User-Agent وReferer وOrigin للطلبات
- تجربة HTTP وHTTPS عند الاتصال
- إعادة المحاولة للطلبات: 30 ثانية ثم 45 ثانية

### الواجهة

- Home
- Live TV
- Movies
- Series
- Settings
- Search
- Favorites
- Continue Watching
- Recently Added، آخر 7 أيام فقط عند وجود timestamp صحيح
- EPG
- Profiles
- Multi-view surface
- Connection Diagnostics
- Themes
- Arabic/English
- Parental PIN surface
- RTL/LTR
- Landscape orientation
- Sidebar للفئات محسوبة على 25% من عرض الشاشة في catalog

### Live TV

- تصنيفات خاصة بالمصدر
- بحث
- Now Playing تحت اسم القناة عند توفر EPG
- EPG لكل قناة
- مفضلة
- تشغيل عبر Expo AV

### Movies وSeries

- ملصقات وصور cover/cover_big/stream_icon
- تصنيفات خاصة بالمصدر
- بحث
- مفضلة
- Continue Watching
- Series details
- اختيار الموسم والحلقات عبر `get_series_info`
- تشغيل الحلقة

### الريموت

تم حل وصول أحداث الريموت إلى التطبيق في v80/v81:

- `MainActivity.dispatchKeyEvent` يسجل كل حدث ثم يستدعي `super.dispatchKeyEvent(event)`.
- `decorView` يصبح `focusableInTouchMode` ويطلب التركيز عند بداية التطبيق.
- أول عنصر قابل للتفاعل يحاول الحصول على التركيز بعد mount.
- عناصر القوائم تستخدم:

```tsx
<Pressable
  focusable={true}
  isTVSelectable={true}
  hasTVPreferredFocus={index === 0}
  onFocus={() => setIsFocused(true)}
  onBlur={() => setIsFocused(false)}
  onPress={onPlay}
>
```

- D-Pad Native يرسل حدث `TurboXRemoteKey` إلى JS.
- JS يحرك `tvFocusedIndex` وFlatList ويشغل العنصر عند OK.
- يوجد إطار سماوي وتوهج وتكبير بسيط للعنصر المحدد.
- `useTVEventHandler` أُزيل لأنه سبب `undefined is not a function` على بيئة Expo/RN الحالية.

### كود Native المهم

```kotlin
override fun dispatchKeyEvent(event: KeyEvent): Boolean {
  Log.d(
    "TV_REMOTE_DEBUG",
    "Key Pressed: ${KeyEvent.keyCodeToString(event.keyCode)} (${event.keyCode}), Action: ${event.action}, Repeat: ${event.repeatCount}"
  )
  if (event.action == KeyEvent.ACTION_DOWN) emitRemoteKey(event)
  return super.dispatchKeyEvent(event)
}
```

الأكواد المتوقعة:

- 19 Up
- 20 Down
- 21 Left
- 22 Right
- 23 Center/OK
- 66 Enter
- 4 Back

## 5. إدارة الحالة والتخزين

- `streambox.providers`: مصادر IPTV المحفوظة
- `streambox.activeProviderId`: المصدر الفعال
- `streambox.profile`: البروفايل الفعال
- `streambox.profiles`: قائمة البروفايلات
- `streambox.favorites.<providerId>.<profileName>`: المفضلة
- `streambox.watchProgress`: تقدم المشاهدة
- `streambox.theme`: الثيم
- `streambox.language`: اللغة
- `streambox.parentalPin`: PIN الرقابة الأبوية
- `streambox.deviceMode`: tv/mobile

لا توجد خدمة Backend أو API key. كل الاتصال بمصادر IPTV يتم مباشرة من الجهاز.

## 6. المشكلة التي ظهرت وتم التعامل معها

### رسالة تحميل المصدر

ظهرت رسالة:

`تعذر تحميل المصدر — تعذر الوصول إلى السيرفر (انتهت مهلة الطلب).`

تم في المصدر الحالي:

- رفع المهلة إلى 30 ثانية.
- Retry إضافي 45 ثانية.
- تجربة server candidates HTTP/HTTPS.
- Headers مناسبة.
- رسالة فشل أوضح.

إذا استمرت الرسالة، فالاحتمالات الأساسية: السيرفر متوقف، المنفذ مغلق، البيانات غير صحيحة، الاشتراك منتهي، أو لوحة Xtream تمنع طلبات الجهاز.

### الريموت

الريموت أصبح يصل للتطبيق، ثم تم إصلاح الإطار البصري بربط مؤشر القائمة مع React state بدل ref فقط. يجب اختبار ذلك على TV Box فعلي لأن أجهزة AOSP تختلف في نظام focus.

## 7. التشغيل محليًا

```bash
cd streambox-expo
npm install
npx expo start
```

Android dev build:

```bash
npx expo run:android
```

Export للتحقق من JavaScript:

```bash
npx expo export --platform android --output-dir /tmp/turbox-check
```

Release APK من مجلد المشروع:

```bash
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
export ANDROID_HOME=$HOME/android-sdk
export ANDROID_SDK_ROOT=$HOME/android-sdk
export PATH="$JAVA_HOME/bin:$ANDROID_HOME/platform-tools:$PATH"
./android/gradlew -p android assembleRelease --no-daemon --console=plain
```

الناتج:

`android/app/build/outputs/apk/release/app-release.apk`

## 8. تشخيص الريموت

بعد توصيل TV Box عبر ADB:

```bash
adb logcat -c
adb logcat -s TV_REMOTE_DEBUG
```

إذا ظهرت `KEYCODE_DPAD_*` فالريموت يصل إلى Activity. إذا لم تظهر أي سجلات فالمشكلة في الريموت/النظام/ADB أو الجهاز لا يرسل أزرار D-Pad كتلك الأكواد.

## 9. ملاحظات مهمة للذكاء الاصطناعي التالي

1. لا تعِد بناء التطبيق بـ Flutter؛ القرار الحالي هو الاستمرار على React Native/Expo.
2. لا تستخدم `useTVEventHandler` مباشرة من `react-native` في هذه النسخة؛ سبب خطأ runtime على الجهاز.
3. لا تستبدل `MainActivity.dispatchKeyEvent` بـ handler يستهلك كل الأزرار؛ يجب تسجيل الحدث ثم `super.dispatchKeyEvent(event)`.
4. لا تنشئ لاعبًا Native جديدًا لكل قناة؛ استخدم Player instance reuse.
5. لا تحفظ ملفات IPTV أو الفيديو في التخزين الخارجي؛ التخزين الحالي داخلي/AsyncStorage/SQLite.
6. لا تضع credentials حقيقية في source أو README أو debug logs.
7. المشغل المستقر الحالي Expo AV؛ Media3 Native موجود لكنه يحتاج اختبارًا دقيقًا قبل جعله المسار الأساسي.
8. يجب عدم إضافة أي قنوات أو محتوى فعلي إلى التطبيق؛ المستخدم يضيف مصادره.
9. لا تعتمد على نسخة `app.json` وحدها لمعرفة رقم APK؛ راجع أيضًا `android/app/build.gradle`.
10. اختبر 3 حالات: Android phone touch، Android TV remote، AOSP TV Box مع mouse فقط.

## 10. التسليم الحالي

- آخر APK: `TurboX-IPTV-release-v81.apk`
- APK SHA-256:

```text
13fb8eb39b00564f4d59f79c32e6ed83cc7484b346e954ee5f3dcc51bc0cae6f
```

- آخر تعديل فعلي في المصدر يشمل جسر `TurboXRemoteKey` وإصلاح الإطار البصري.

## 11. v82: شاشة الافتتاح وشاشة تسجيل الدخول

- `src/components/SplashScreen.tsx`: عرض افتتاحي متحرك (~5.7 ثانية) مع صوت `assets/sounds/turbox-intro.wav`. الضغط/OK يتخطاه.
- `src/components/TurboXLogo.tsx`: شعار TurboX مبني بـ Views فقط (بدون react-native-svg). يعمل متحركًا (مع `t`) أو ثابتًا.
- `src/components/LoginScreen.tsx`: شاشة تسجيل الدخول (الاسم/السيرفر/اسم المستخدم/كلمة المرور + اختيار ملف M3U).
- ترتيب الظهور في `App.tsx`: Splash ← اختيار Mobile/TV ← LoginScreen (عند عدم وجود مصادر، أو عند إضافة مصدر جديد من Settings).
- منطق الحفظ والاتصال لم يتغير: `saveProvider` و`pickM3uFile` كما هما.
- لم يُختبر على جهاز فعلي بعد: راجع حجم الخط والمسافات على Phone وTV Box.

## 12. v83: الواجهة الرئيسية الجديدة

- `src/components/HomeDashboard.tsx`: `HomeTopBar` (لوجو TurboX + الساعة + الشبكة + الإشعارات + الإعدادات) و`HomeBody` (ترحيب وحالة المصدر، 3 بطاقات Live/Movies/Series مع شريط تقدم، أزرار EPG/Multi-View/Account/Settings، ومتابعة المشاهدة).
- كل العناصر تدعم تركيز الريموت (إطار أحمر) واللمس.
- في `App.tsx` تم استبدال `dashboardTop` و`dashboardHome` القديمين بهذين المكونين؛ باقي الشاشات لم تتغير.
- الأنماط القديمة (`dashboardTile`, `dashboardAction`, ...) ما زالت موجودة ويمكن حذفها لاحقًا.
- لم يُبنَ APK في هذه الجلسة (لا يوجد Android SDK ولا اتصال بالإنترنت). البناء حسب القسم 7.

## 13. v84: الهوية الحمراء في كل الشاشات + ريموت TV Box

### الألوان
- `themeAccents.turbo = #e11d2e`، حلقة التركيز `#ff5a66`، الخلفية `#0b0b12`، الرمادي الأزرق تحول إلى رمادي محايد.
- Android: splash داكن (`colors.xml`)، أيقونة التطبيق وsplash logo جديدين (X + Play).

### الريموت (مهم)
- `src/tv/focus.tsx`: محرك تنقل مكاني (spatial navigation) بالـ JS يعمل فقط عندما `deviceMode === 'tv'`.
  - كل `Pressable` في التطبيق صار `TVPressable` (يسجل نفسه في المحرك). على TV يكون `focusable={false}` أصليًا حتى لا يتحرك الـ focus الأصلي مرتين.
  - أحداث `TurboXRemoteKey` (DPAD/OK) تحرك التركيز لأقرب عنصر في الاتجاه، وOK يستدعي `onPress` مباشرة.
  - التمرير التلقائي عبر `useTVScroller` + `TVScope` (outerScroll وsideScroll وgridScroll وقائمة "متابعة المشاهدة").
  - قوائم Live/Grid تعمل بـ `removeClippedSubviews={false}` على TV ليظل القياس صحيحًا.
- النوافذ (`Modal`) تستخدم focus أندرويد الأصلي (`TVModalLayer`)، وزر OK فيها يصل عبر `MainActivity.onKeyUp` ← حدث `TurboXRemoteKey` بـ `action = 1`.
- البحث على TV: الضغط على مربع البحث يفتح نافذة بها TextInput (`showSearch`).
- تم حذف معالج الريموت القديم الخاص بالكتالوج (index-based). `remoteFocused` صار دائمًا false.
- لم يُختبر على جهاز فعلي. للتشخيص: `adb logcat -s TV_REMOTE_DEBUG`.

## 14. v85: ريموت المشغّل + تخزين آمن + بانر TV + اختبار الاتصال

- **المشغّل (TV فقط):** `src/components/PlayerControls.tsx` + معالج في `App.tsx`: ◀ ▶ تقديم/تأخير 10 ثوانٍ (VOD)، ▲ ▼ تغيير القناة (Live)، OK/Play-Pause إيقاف وتشغيل، شريط معلومات يختفي بعد ثوانٍ. أزرار الفيديو الأصلية معطلة على TV. أحداث المشغّل تصل كـ `action = 1` من `MainActivity.onKeyUp` (النافذة المنبثقة تمرر key-up فقط).
- **تخزين آمن:** `src/storage/secureProviders.ts` يحفظ (server/username/password) في Android Keystore عبر `expo-secure-store`، وAsyncStorage يحتفظ بـ id والاسم فقط. الحسابات القديمة تُرحَّل تلقائيًا. **يلزم `npm install`** (تمت إضافة `expo-secure-store ~14.0.1`). ما زال `streambox.parentalPin` وكاش الكتالوج في AsyncStorage.
- **بانر Android TV:** `drawable-xhdpi/tv_banner.png` (640×360) و`android:banner` في `AndroidManifest.xml`.
- **اختبار الاتصال:** `src/network/testConnection.ts` + زر في `LoginScreen`. يفحص Xtream (الدخول، الحالة، تاريخ الانتهاء، الاتصالات) وM3U (صلاحية القائمة وعدد العناصر).
- الإصدار 1.6.0 (versionCode 56).

## 15. v86: حالة الحساب + Xtream + ريموت شاشة الاختيار + أرقام القنوات

- **حالة الحساب:** `AccountModal.tsx` (الحالة، تاريخ الانتهاء والأيام المتبقية، الاتصالات المستخدمة/المتاحة، نوع الحساب، تاريخ الإنشاء، المنطقة الزمنية) ويُفتح من زر ACCOUNT في الرئيسية أو من Settings ← Account Status أو من شريط التنبيه. البيانات من `network/accountInfo.ts` (تُملأ عند `connect()` ويمكن تحديثها بزر Refresh).
- **تنبيه الاشتراك:** شريط في الرئيسية عند بقاء ≤ 7 أيام أو انتهاء/تعطيل الحساب.
- **إضافة Xtream:** `LoginScreen` فيها تبويبان (Xtream Codes / M3U link-file). لصق رابط `get.php?username=..&password=..` يُفكَّك تلقائيًا إلى (سيرفر/مستخدم/كلمة مرور). `Provider.m3u` يحدد نوع المصدر، و`isM3u` يتعرف على `type=m3u`.
- **ريموت شاشة اختيار Mobile/TV:** ◀ ▶ تبديل، ▼ زر Continue، OK تأكيد (أحداث key-up من `MainActivity.onKeyUp`). أي زر في الريموت يتخطى شاشة الافتتاح.
- **المشغّل:** أرقام القنوات 0-9 (رقم Xtream `num` أو ترتيب القائمة)، `0` أو LAST للقناة السابقة، MENU/INFO يفتح VLC لاختيار الصوت والترجمة.
- **إصلاح:** `TurboPlayerModule` لم يكن مسجلًا في `TurboPlayerPackage` فكان زر VLC لا يعمل؛ سُجِّل الآن.
- **ملاحظة:** `expo-av` لا يوفر اختيار مسارات الصوت/الترجمة. الحل الكامل يحتاج تشغيل مشغّل Media3 الأصلي.

## 16. v87: اختيار المشغّل من الإعدادات

- Settings ← Player (`PlayerPicker.tsx`): المشغّل المدمج، VLC، MX Player، Just Player، أو اختيار في كل مرة (system chooser). يُحفظ في `streambox.playerEngine`.
- `launchPlayer()` في `App.tsx` يمر عليه كل تشغيل (قناة/فيلم/حلقة). إذا كان المشغّل الخارجي غير مثبت يظهر تنبيه ويعود للمشغّل المدمج.
- Native: `TurboPlayerModule.openExternalPlayer(url, title, packages, headers, promise)` (MX يستقبل الـ headers). تمت إضافة `<queries>` للحزم في `AndroidManifest.xml` لتعمل مع Android 11+.
- مع المشغّل الخارجي لا يتوفر تغيير القناة بالأرقام (هذه ميزة المشغّل المدمج).

## 17. v88: Settings → Automation

- `AutomationSettings.tsx` + `storage/automation.ts` (`streambox.automation`): تحديث القنوات/الأفلام/المسلسلات كل N يوم، وتحديث EPG كل N يوم (1/2/3/5/7/14/30)، مع SAVE CHANGES وBACK وزر Update now.
- `connect(provider, force)`: عمر الكاش = `catalogDays` عند التفعيل؛ عند الإيقاف يُستخدم الكاش دائمًا حتى Update now (إن لم يوجد كاش يُحمَّل من السيرفر).
- EPG "الآن يعرض": يُخزَّن في `streambox.epgCache.<providerId>` (20 برنامجًا لأول 60 قناة). عند التفعيل يتجدد بعد `epgDays` أو إذا لم يعد الكاش يغطي الوقت الحالي؛ عند الإيقاف يُستخدم المحفوظ فقط.
- التحديث يُفحص عند فتح التطبيق/الاتصال بالمصدر (لا يوجد مؤقت أثناء التشغيل حتى لا يقطع المشاهدة).

## 18. v89: صف الرئيسية + مؤقت النوم + إخفاء التصنيفات + ملفات بناء APK

- **الرئيسية:** صفان جديدان: "شاهدتها مؤخرًا" (`streambox.recentPlayed.<providerId>`، آخر 20 عنصرًا) و"المفضلة". تظهر الصفوف فقط عند وجود عناصر.
- **مؤقت النوم:** Settings ← Sleep Timer (15/30/45/60/90/120)، وفي المشغّل: الزر الأحمر على الريموت (KEYCODE_PROG_RED=183) يبدل 30/60/90/120/إيقاف، وزر القمر في الشريط العلوي على الموبايل. عند الانتهاء يُغلق المشغّل ويظهر تنبيه. لا يعمل مع المشغلات الخارجية.
- **إخفاء التصنيفات:** Settings ← Hidden Categories (`HiddenCategories.tsx`)، لكل Live/Movies/Series، محفوظة لكل مصدر في `streambox.hiddenCats.<providerId>`. التصنيف المخفي لا يظهر في القائمة الجانبية ولا في "All"، لكن المفضلة تظل ظاهرة.
- **بناء APK:** `.github/workflows/build-apk.yml` و`eas.json` و`build-apk.sh` و`BUILD-APK.md`.

## 19. v90: إصلاح ريموت نافذة "إضافة حساب IPTV"

- السبب: `LoginScreen` داخل `Modal` (نافذة منفصلة)، والـ focus الأصلي في النافذة لا يعمل على بعض TV Boxes، ومحرك JS كان يخدم الشاشات الرئيسية فقط.
- `src/tv/focus.tsx`: `TVEngineLayer` يجعل محرك JS يقود نافذة معيّنة (أحداث key-up من `MainActivity.onKeyUp`)، مع طبقة منفصلة لكل نافذة (`modal` id) ويُستعاد التركيز السابق عند الإغلاق. `TVTextInput`: ▲▼◀▶ تنقل، OK يفتح لوحة المفاتيح، والانتقال لعنصر آخر يغلق التحرير.
- `LoginScreen.tsx`: مغلّف بـ `TVEngineLayer` + `TVScope`/`useTVScroller` (تمرير تلقائي)، والحقول `TVTextInput`، والتركيز الأولي على أول حقل.
- لم يُختبر على جهاز فعلي. للتشخيص: `adb logcat -s TV_REMOTE_DEBUG`.
- نوافذ أخرى (Account/Player/Automation...) ما زالت على focus الأصلي؛ لتحويل أي منها لف محتواها بـ `<TVEngineLayer>`.

## 20. v91: ما تغيّر

1. **الريموت في كل النوافذ**: `Modal` في `src/components/TVModal.tsx` يلفّ المحتوى بـ `TVEngineLayer` افتراضيًا. الاستثناء `native` للـ Splash واختيار الجهاز والمشغّل. أُضيف `TVScrollView` و`TVFlatList` (تمرير تلقائي) و`TVTextInput` (OK يفتح لوحة المفاتيح).
2. **Media3**: خيار المشغّل `media3` (Settings → Player). `TurboPlayerView` يتحكم به JS بالكامل (source/headers/paused/seek/audioTrack/textTrack/resizeMode) ويرسل onStatus/onTracks/onError. زر MENU/INFO (أو أيقونة الفقاعة على الموبايل) يفتح `TrackMenu` لاختيار الصوت والترجمة. **لم يُترجم Kotlin على جهاز/Gradle بعد**.
3. **XMLTV** لمصادر M3U: `src/epg/xmltv.ts` يقرأ `url-tvg` من ترويسة القائمة (لا يدعم .gz).
4. **تخزين**: `cacheStore.ts` (SQLite) لكاش الكتالوج و EPG؛ كاش الكتالوج لم يكن يُحفظ أصلًا فصار يُحفظ. PIN في `securePin.ts` (Keystore) مع ترحيل تلقائي.
5. **تقسيم App.tsx** (2806 سطرًا → 6): `src/TurboXApp.tsx`, `styles.ts`, `types.ts`, `theme.ts`, `utils/media.ts`, `network/sources.ts`, `components/ListParts.tsx`, `AppErrorBoundary.tsx`. حُذفت 52 نمط غير مستخدم ومكوّنات ميتة. أُصلح متغيّر `storageDirectory` غير المعرّف.

## v92: Profiles = اشتراكات منفصلة + تعديل السيرفر عند الفشل + تحديث أسبوعي

- **Profile = اشتراك/سيرفر.** حُذف "IPTV Sources" و"Active Provider" من Settings. شاشة Settings → Profiles تعرض كل الاشتراكات المحفوظة (اختيار للتبديل، قلم للتعديل، سلة للحذف) وزر "إضافة Profile جديد" يفتح `LoginScreen` لسيرفر منفصل. `selectProfile/addProfile` وقائمة `streambox.profiles` أُزيلت؛ `profileName` بقي فقط كلاحقة لمفتاح المفضلة القديم (`streambox.favorites.<providerId>.<profileName>`).
- **فشل التحميل:** في `connect()` لا يظهر Alert؛ تُفتح شاشة السيرفر (`openEdit`) معبّأة ببيانات الـ Profile مع رسالة الخطأ في أعلاها وزر "حفظ وإعادة الاتصال". الحفظ يحافظ على نفس `id` ويمسح كاش الكتالوج/EPG لهذا الـ Profile ثم يعيد التحميل.
- **استثناء:** إذا فشل التحديث الأسبوعي وكان هناك كاش محفوظ (ولم يضغط المستخدم Update now) يُستخدم الكاش بصمت ويُعاد المحاولة عند الفتح التالي.
- **التحميل:** الكتالوج يُحمَّل أول مرة فقط ثم كل 7 أيام (`DEFAULT_AUTOMATION` = 7 أيام للكتالوج وEPG). قابل للتغيير من Settings → Automation.
- لم يُبنَ APK ولم يُختبر على جهاز (لا يوجد SDK/اتصال). فُحص الـ syntax فقط.

## v93: تحديث بالخلفية + آخر تحديث لكل Profile + حذف بـ ChoiceModal

- **تحديث الكتالوج بالخلفية:** إذا وُجد كاش منتهٍ (أو ضغط المستخدم تحديث) يُعرض الكاش فورًا ويُحمَّل الجديد خلفه؛ تظهر "جارٍ التحديث…" في شريط المصدر بالرئيسية (`refreshing`). لا يُنقل المستخدم لتبويب Live بعد انتهاء التحديث. أول تحميل (بلا كاش) و M3U ما زالا بشاشة تحميل كاملة.
- **حماية السباق:** `connectSeq` في `connect()`: أي اتصال أقدم يتوقف عن كتابة الحالة إذا فُتح Profile آخر أو حُذف الحالي أثناء التحديث.
- **Profiles:** تحت كل اسم "آخر تحديث: منذ …" (`streambox.lastUpdated.<providerId>` في AsyncStorage) وزر تحديث الآن لكل Profile.
- **الحذف:** عبر `ChoiceModal` (يعمل بالريموت) بدل `Alert`.
- لم يُبنَ/يُختبر على جهاز؛ فُحص syntax فقط.

## v94: أخطاء واضحة، كاش أخف، دليل برامج، تفاصيل فيلم، وضع أطفال، قوائم مفضلة، سجل

**لم يُبنَ APK ولم يُجرَّب على جهاز.** تم: فحص أنواع TypeScript (بدون React types) ومقارنته بالنسخة الأصلية، و24 اختبار وحدة للمنطق الصرف (`npm test`).

- **أخطاء واضحة** (`src/network/errors.ts`): `xtream()` يرمي `IptvError` بنوع (offline/timeout/unreachable/auth/expired/disabled/notfound/blocked/server/badresponse) ويظهر السبب والحل في شاشة السيرفر وفي "Connection Diagnostics".
- **كاش** (`src/storage/catalogCache.ts`): الكتالوج في 3 ملفات + meta تُكتب أخيرًا (يُقرأ الشكل القديم أيضًا). `slimMedia` يحذف الحقول الفارغة/غير المستخدمة. فشل تحميل قائمة واحدة لا يمسح النسخة المحفوظة، والرد الفارغ كليًا يُعامل كعطل سيرفر. البحث يستخدم `useDeferredValue`. **لم يُنفَّذ** التحميل الكسول لكل تصنيف/SQLite.
- **المشغّل:** `handlePlayFailure` موحّد: إعادة اتصال بنفس الرابط (مرتان للبث المباشر) ← روابط بديلة ← المحرك الآخر ← رسالة. مراقب توقف 25 ث للبث المباشر. **Media3 ما زال غير مُجرَّب ولم يُجعل الافتراضي.**
- **EPG:** عناوين/أوصاف Xtream تأتي base64 وكانت تُعرض خام: `decodeEpgText`. دليل زمني (`EpgTimeline`: 3 ساعات، ◀ ▶) من Settings ← TV Guide أو الرئيسية. Catch-up (`timeshiftUrl`) للقنوات ذات `tv_archive=1` عبر `get_simple_data_table` — **غير مُجرَّب على سيرفر حقيقي**.
- **تفاصيل الفيلم** (`MovieDetails`, `get_vod_info`)، **بدء التشغيل** (Home/Live/آخر قناة، `streambox.startup`)، **قوائم مفضلة متعددة** لكل Profile (القائمة الافتراضية تحتفظ بالمفتاح القديم)، **وضع أطفال** لكل Profile (`Provider.kid`: يخفي تصنيفات الكبار؛ مع PIN يلزم لدخول Settings/إدارة Profiles)، **سجل أخطاء** (`utils/logger.ts`، بدون بيانات دخول).
- **إصلاح:** parser الـ M3U كان يُسقط قناة كل ~1000 سطر عند حدود الدفعات (القوائم التي تبدأ بـ `#EXTM3U`).
- `playItem` أُعيدت هيكلته: `proceedItem` (مسلسل/فيلم/تشغيل) و`startPlayback`. بعد PIN، الأفلام صارت تُشغَّل بنفس الترويسات (كانت بلا ترويسات).
- **التقسيم:** ملفات جديدة بدل زيادة `TurboXApp.tsx`: ProfilesModal, MovieDetails, EpgTimeline, LogsModal, FavListsBar + utils/. لم تُستخرج hooks من `TurboXApp.tsx` (خطر بدون تشغيل).
- ترجمة: كل Alerts وإعدادات Settings الأساسية صارت `tx()`.

## v95: الكتالوج الكبير (نقطة 3)

- **تحميل الأفلام/المسلسلات عند الحاجة:** عند فتح التطبيق من كاش سليم يُقرأ جزء البث المباشر فقط (`readSnapshot(key, true)`) والأعداد من meta (`counts`). `hydrateHeavy()` يقرأ الباقي (`readHeavy`) أول مرة يحتاجه شيء: تبويب Movies/Series، الصفحة الرئيسية، نافذة المفضلة، التصنيفات المخفية، البحث، أو القوائم الخاصة (`__favorites__` …). المحاولة مربوطة بـ `connectSeq` وبمعرّف الـ Profile.
- **مهم:** عند تبديل Profile يُفرَّغ `movies/series` فورًا (وإلا تبقى قوائم Profile السابق). تحديث الشبكة يملأ الثلاثة ويعلّم `heavyLoaded=true`. لو فشل تنزيل قائمة والنسخة المحفوظة "خفيفة" تُقرأ القوائم المحفوظة أولًا قبل الكتابة، وإن تعذّر ذلك يُلغى الحفظ (لا تُكتب قائمة فارغة).
- **حسابات كانت تُعاد على 100 ألف عنصر بلا داعٍ:** `continueItems` (كانت تُعاد كل نبضة تقدّم أثناء المشاهدة) صارت للرئيسية فقط وبلا مشغّل؛ `filtered` لا يعتمد على `watchProgress` إلا في "continue"؛ `globalResults` تتوقف عند 20 نتيجة؛ `favoriteItems`/`allCategoryNames`/`itemsByKey`/`recentItems` تُحسب فقط عند الحاجة.
- **منطق التخزين** انتقل إلى `storage/catalogStore.ts` (مصنع `createSnapshotStore(io)` بلا اعتماديات RN) و`catalogCache.ts` يربطه بـ `cacheStore`. اختبارات: `__tests__/catalogStore.test.ts`.
- **غير مُنفَّذ:** استعلامات SQLite/ترقيم صفحات لكل تصنيف. بعد التحميل تبقى القوائم كاملة في الذاكرة، وتحديث الشبكة الأسبوعي ما زال يحمّل الثلاثة مؤقتًا. القياسات (Node على حاسوب، بيانات تجريبية 15k/60k/20k): قراءة كاملة 74ms/25MB، خفيفة 9ms/4MB، والباقي عند الطلب 63ms. أرقام الجهاز الحقيقي لم تُقَس.

## v96: أداء التلفاز

لم يُقَس على جهاز. الإجراءات مبنية على قراءة الكود، ولإثبات الأثر استعمل Settings → Logs (يظهر سطر `D-pad: …` كل 25 ضغطة).

- **الصفوف:** `MediaRow` صار `React.memo` (كان `MediaCard` فقط) والمعالجات ثابتة (`onRowFavorite/onRowPlay/onRowFocusIndex` عبر `rowActions` ref، وتستلم العنصر كمعامل). سابقًا كل setState في `TurboXApp` كان يعيد رسم كل الصفوف المعروضة. `favSet` بدل `favorites.includes`.
- **الصور:** صور الصفوف المباشرة بلا `resizeMethod="resize"` (كانت تُفكّ بحجمها الكامل) → أُضيفت مع `fadeDuration={0}`.
- **القوائم على TV:** `windowSize` 3 (كان 5/4)، `initialNumToRender` 10، `maxToRenderPerBatch` 6، و`scrollEventThrottle` 48. كل صف مُحمَّل = عقدة تركيز + صورة.
- **محرك الريموت (`tv/focus.tsx`):** (1) `warm()` يقيس مواقع العناصر غير المعروفة على دفعات من 6 وقت الخمول بعد أي تغيير تخطيط أو ظهور صفوف، فلا تدفع الضغطة التالية ثمن قياسها كلها. (2) أفضل 10 مرشحين للقياس الفعلي صارت 6. (3) `perfSink` يكتب متوسط/أقصى زمن الضغطة وعدد القياسات إلى السجل.
- إن بقي بطء: أرسل أسطر `D-pad:` من السجل؛ تفصل بين "قياس كثير" (عدد measures/move كبير) و"رسم ثقيل" (measures منخفض والزمن عالٍ).

## v97: تنقل الريموت (مسار سريع)

- **`fastMove` في `tv/focus.tsx`:** إذا كانت مواقع كل العناصر في الذاكرة (`rectCache`) يُختار الجار منها ويُتحقق من الهدف وحده بقياس واحد (مقارنة المراكز بفارق ≤3px). أثناء التمرير المتواصل (آخر تمرير <150ms) لا يوجد أي نداء قياس. أي شك (عنصر غير مقيس، حافة الشاشة، تغيّر تخطيط) ← المسار الكامل القديم. و`vpCache` يخزّن مستطيل منفذ كل scroller (يُمسح مع `invalidate()`).
- **المحاكاة** (`tools/tv-sim-*.js`، محرك حقيقي مع RN مُحاكى): نفس الأهداف في 70 حركة، وعدد نداءات القياس 513→71 (ضغط كل 200ms) و448→18 (ضغط مستمر 25ms). عند تغيير تخطيط لم يُبلَّغ به المحرك: لا فرق عن الحقيقة. المحاكاة بلا زمن حقيقي للجسر، فالتسارع على الجهاز غير مقيس.
- السجل (`D-pad: N moves (M fast) …`) يوضّح نسبة المسار السريع على الجهاز. بعد فتح شاشة جديدة يلزم ~0.4–1 ث ليمتلئ الكاش (`warm`)، والضغطات الأولى تستخدم المسار الكامل.

## v98: وضع أداء التلفاز (نجمة، إطار التركيز، الصور)

لم يُجرَّب على جهاز.

- **النجمة خارج التنقل على TV** (`ListParts`): كانت `TVPressable` ثانية داخل كل صف/بطاقة فتتضاعف العناصر المسجّلة. صارت أيقونة فقط، والإضافة للمفضلة بأزرار الريموت **MENU / INFO / الأصفر** على العنصر المحدد (`ALT_KEYS` في المحرك، `onAltPress` على `TVPressable`، يعمل في الشاشة الرئيسية وفي الحوارات). تلميح لمرة واحدة في رأس قائمة البث المباشر (`streambox.favHint`). **احتياط:** الإعدادات ← "نجمة المفضلة في قوائم التلفاز" (`streambox.tvStar`) تُعيدها هدف تنقل عادي لريموتات بلا هذه الأزرار (`StarFocusContext`).
- **إطار تركيز خفيف** (`lite`) للصفوف والبطاقات: حدّ + تظليل بلا ظل/ارتفاع/تكبير (مكلفة على GPU الضعيف). باقي الشاشات بلا تغيير.
- **الصور بعد هدوء التمرير** (`utils/scrollIdle.ts`، `useImagesReady`): على TV لا تُطلب صور الصفوف/البوسترات أثناء التمرير، وتُطلب بعد ~220ms من توقفه. 3 اختبارات وحدة.
- أُضيفت اختبارات: المجموع الآن 35. المحاكاة `tools/tv-sim-*.js` تعمل على الإخراج الجديد (`/tmp/tvbuild/tv/focus.js`) وتؤكد أن مفاتيح MENU/INFO/الأصفر تستدعي `alt` فقط لعنصر يملكه ولا تعارض OK.

## v99: تشخيص من سجل التلفاز الحقيقي (v98) وإصلاحاته

سجل الجهاز أظهر: شاشة 24 عنصر avg 31ms (جيد)؛ شاشة 272 عنصر avg 238ms/max 3.3s؛ شاشة أخرى avg 528ms/max 11.5s؛ وسطور `timeout 45s` لـ `get_short_epg` و`get_vod_info`.

- **السبب الأرجح للبطء (في الكود لا المحرك):** الشريط الجانبي كان يفلتر القائمة كاملة (41k فيلم) مرة لكل تصنيف مع كل render للتطبيق (O(تصنيفات × عناصر)). الآن `categoryCounts` (Map بمرور واحد، memo) + `CategoryRow` (React.memo، إطار lite). قياس على حاسوب: 54ms → 1.2ms لكل render (على التلفاز أبطأ بكثير؛ الربط بالثواني استنتاج لا قياس).
- **عاصفة طلبات البرامج:** `xtream()` كان يطبّق سياسة الدخول (http+https × محاولتين × 30/45ث) على كل نداء، فكل `get_short_epg` متعثّر يعلّق حتى ~150ث، ×60 قناة بالتوازي، ويُعاد عند كل زيارة لتبويب Live (لأن القائمة الفارغة كانت تُخزَّن فتُعتبر "منتهية"). الآن: `xtreamPlan.planAttempts` — طلبات `quick` (تفاصيل فيلم، برامج، مواسم): محاولة واحدة على العنوان الذي نجح سابقًا، مهلة 10ث (20ث للمواسم). `mapLimit` بحد 4 متوازية، وقاطع: 3 إخفاقات متتالية بلا أي نجاح ← إيقاف + تأجيل 10 دقائق (`epgBackoff`) ولا يُخزَّن دليل فارغ. تُذكر آخر عنوان ناجح لكل Profile.
- **الكاش:** القوائم تُحفظ/تُقرأ على دفعات 4000 عنصر مع `yield` بينها (قبلها `JSON.parse/stringify` لـ 25MB دفعة واحدة تُجمّد الـ JS لثوانٍ؛ "loaded 41231 movies on demand" استغرق ~8ث من بدء التطبيق). ملف الـ meta يُحذف أولًا ويُكتب أخيرًا فلا يُقرأ خليط قديم/جديد. تُقرأ الصيغ القديمة.
- **المحرك:** `warm` بدفعات 16 كل 8ms (كانت 6/24ms) لأن شاشة 272 عنصر كانت تحتاج ثوانٍ لملء الكاش؛ والمسار السريع يقيس بنفسه حتى 12 عنصرًا غير معروف بدل التخلّي مباشرة.
- اختبارات: 48 (كاش مجزأ، قاطع الطلبات، خطة المحاولات…). **لم يُجرَّب على الجهاز.**

## v100: فشل التشغيل على التلفاز فقط (الموبايل يعمل)

نفس الـ APK ونفس الروابط ونفس الترويسات على الجهازين ← الفرق في الجهاز (ترميز/نظام) أو الشبكة أو حد اتصالات الحساب. السبب الحقيقي لم يكن يظهر (رسالة ثابتة والخطأ يُهمَل).

- `handlePlayFailure(native, reason, detail)`: يلتقط نص خطأ ExoPlayer من expo-av (`onError(string)`) ومن عرض Media3 (`nativeEvent.message`)، ويسجّله في Settings → Logs (سطر `player …| <السبب>`؛ الروابط تُخفى بيانات الدخول منها).
- `network/playbackErrors.ts`: يصنّف السبب (HTTP 401/403/458/884 = رفض/حد اتصالات/حظر، 404، 5xx، شبكة، ترميز جهاز مثل HEVC/AC3، صيغة غير مدعومة، بطء بدء) ويعرض التشخيص بالعربي/الإنجليزي في نافذة الفشل مع سطر تقني قصير.
- **مراقب التعليق الذي أضفته في v94 كان قد يحوّل بطء بدء البث إلى "فشل":** صار 60ث قبل أول تشغيل (25ث فقط لو توقف البث بعد أن بدأ، `startedRef`).
- لا تغيير على اختيار المحرك الافتراضي (`builtin`). المحرك محفوظ لكل جهاز في `streambox.playerEngine` (قد يكون مضبوطًا على Media3 على التلفاز).
- اختبارات التصنيف: 5 جديدة.
