import { qrMatrix } from '../src/utils/qr';

describe('qr', () => {
  it('builds square matrices with the right version size', () => {
    expect(qrMatrix('http://10.0.0.5:8080/xyz').length).toBe(25); // version 2
    expect(qrMatrix('http://192.168.1.23:45678/a1b2c3d4').length).toBe(29); // version 3
  });
  it('has the three finder patterns', () => {
    const m = qrMatrix('http://10.0.0.5:8080/abc');
    const n = m.length;
    for (const [x, y] of [[0, 0], [n - 7, 0], [0, n - 7]]) {
      expect(m[y][x]).toBe(true);
      expect(m[y + 3][x + 3]).toBe(true);
      expect(m[y + 1][x + 1]).toBe(false);
    }
  });
  it('rejects text that does not fit', () => {
    expect(() => qrMatrix('x'.repeat(300))).toThrow();
  });
});
