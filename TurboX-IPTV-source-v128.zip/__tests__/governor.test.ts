import { createGovernor } from '../src/network/governor';

describe('governor', () => {
  it('pauses a kind of request after repeated failures, per provider', () => {
    let t = 1000;
    const g = createGovernor(() => t);
    expect(g.failure('a', 'epg').tripped).toBe(false);
    expect(g.failure('a', 'epg').tripped).toBe(false);
    const r = g.failure('a', 'epg');
    expect(r.tripped).toBe(true);
    expect(g.pausedUntil('a', 'epg')).toBe(1000 + 10 * 60_000);
    expect(g.pausedUntil('b', 'epg')).toBe(0); // other provider unaffected
    expect(g.pausedUntil('a', 'info')).toBe(0); // other kind unaffected
    t += 10 * 60_000 + 1;
    expect(g.pausedUntil('a', 'epg')).toBe(0); // pause over
  });
  it('doubles the pause when it keeps failing and resets on success', () => {
    let t = 0;
    const g = createGovernor(() => t);
    g.failure('a', 'info'); const first = g.failure('a', 'info');
    expect(first.until).toBe(45_000);
    t = 46_000;
    g.failure('a', 'info'); const second = g.failure('a', 'info');
    expect(second.until - t).toBe(90_000);
    g.success('a', 'info');
    t += 1;
    g.failure('a', 'info'); const third = g.failure('a', 'info');
    expect(third.until - t).toBe(45_000);
  });
  it('spaces requests out', () => {
    const t = 5000;
    const g = createGovernor(() => t);
    expect(g.paceDelay('a', 'epg', 250)).toBe(0);
    expect(g.paceDelay('a', 'epg', 250)).toBe(250);
    expect(g.paceDelay('a', 'epg', 250)).toBe(500);
  });
});
