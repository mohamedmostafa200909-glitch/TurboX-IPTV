import { normalizeText, buildIndex, searchIndex } from '../src/utils/search';

describe('search', () => {
  it('normalises Arabic forms and punctuation', () => {
    expect(normalizeText('أَحمد، الـعَرَبِيّة')).toBe(normalizeText('احمد العربيه'));
    expect(normalizeText('Dark (2017) 4K')).toBe('dark 2017 4k');
  });
  it('ranks prefix matches first and needs every word', () => {
    const items = ['The Dark Knight', 'Dark', 'Dark Waters', 'Knight Rider'].map(name => ({ name }));
    const idx = buildIndex(items, x => x.name);
    expect(searchIndex(idx, 'dark').map(x => x.name)).toEqual(['Dark', 'Dark Waters', 'The Dark Knight']);
    expect(searchIndex(idx, 'dark knight').map(x => x.name)).toEqual(['The Dark Knight']);
    expect(searchIndex(idx, '')).toEqual([]);
  });
  it('matches Arabic regardless of alef/taa marbuta spelling', () => {
    const idx = buildIndex(['الأنسة فرح', 'مسرح مصر'], x => x);
    expect(searchIndex(idx, 'انسه')).toEqual(['الأنسة فرح']);
  });
  it('respects the limit', () => {
    const idx = buildIndex(Array.from({ length: 50 }, (_, i) => `movie ${i}`), x => x);
    expect(searchIndex(idx, 'movie', 5).length).toBe(5);
  });
});
