import { createSnapshotStore, KV } from '../src/storage/catalogStore';

const memory = () => {
  const map = new Map<string, string>();
  const io: KV = { get: async k => map.get(k) ?? null, set: async (k, v) => { map.set(k, v); }, remove: async k => { map.delete(k); } };
  return { map, io };
};
const items = (n: number, kind: string) => Array.from({ length: n }, (_, i) => ({ name: `${kind}${i}`, stream_id: i, kind })) as any[];
const snap = (savedAt = 1000) => ({ savedAt, expiresAt: '2027', channels: items(3, 'live'), movies: items(5, 'movie'), series: items(2, 'series') });

describe('catalogue snapshot store', () => {
  it('round-trips a full snapshot', async () => {
    const { io } = memory();
    const store = createSnapshotStore(io);
    await store.writeSnapshot('k', snap());
    const out = await store.readSnapshot('k');
    expect(out!.channels.length).toBe(3);
    expect(out!.movies.length).toBe(5);
    expect(out!.series.length).toBe(2);
    expect(out!.heavy).toBe(true);
  });

  it('light read leaves movies/series on disk and reports their counts', async () => {
    const { io } = memory();
    const store = createSnapshotStore(io);
    await store.writeSnapshot('k', snap());
    const light = await store.readSnapshot('k', true);
    expect(light!.heavy).toBe(false);
    expect(light!.channels.length).toBe(3);
    expect(light!.movies.length).toBe(0);
    expect(light!.series.length).toBe(0);
    expect(light!.counts).toEqual({ live: 3, movies: 5, series: 2 });
    expect(light!.savedAt).toBe(1000);
  });

  it('loads the left-out lists on demand', async () => {
    const { io } = memory();
    const store = createSnapshotStore(io);
    await store.writeSnapshot('k', snap());
    const heavy = await store.readHeavy('k');
    expect(heavy!.movies.length).toBe(5);
    expect(heavy!.series.length).toBe(2);
  });

  it('light read of an old single-record snapshot returns everything', async () => {
    const { io, map } = memory();
    map.set('k', JSON.stringify({ savedAt: 5, channels: items(1, 'live'), movies: items(2, 'movie'), series: items(3, 'series') }));
    const out = await createSnapshotStore(io).readSnapshot('k', true);
    expect(out!.heavy).toBe(true);
    expect(out!.movies.length).toBe(2);
  });

  it('light read of a split snapshot without counts falls back to a full read', async () => {
    const { io, map } = memory();
    const store = createSnapshotStore(io);
    await store.writeSnapshot('k', snap());
    const meta = JSON.parse(map.get('k')!);
    delete meta.counts;
    map.set('k', JSON.stringify(meta));
    const out = await store.readSnapshot('k', true);
    expect(out!.heavy).toBe(true);
    expect(out!.movies.length).toBe(5);
  });

  it('ignores a snapshot whose write was interrupted (no meta record)', async () => {
    const { io, map } = memory();
    const store = createSnapshotStore(io);
    await store.writeSnapshot('k', snap());
    map.delete('k');
    expect(await store.readSnapshot('k')).toBeNull();
  });

  it('treats a missing list as no snapshot, and heavy as null', async () => {
    const { io, map } = memory();
    const store = createSnapshotStore(io);
    await store.writeSnapshot('k', snap());
    map.delete('k.series.0');
    expect(await store.readSnapshot('k')).toBeNull();
    expect(await store.readHeavy('k')).toBeNull();
    expect((await store.readSnapshot('k', true))!.heavy).toBe(false); // live part is intact
  });

  it('remove deletes every part', async () => {
    const { io, map } = memory();
    const store = createSnapshotStore(io);
    await store.writeSnapshot('k', snap());
    await store.removeSnapshot('k');
    expect(map.size).toBe(0);
  });
});

describe('catalogue snapshot store: chunks and old formats', () => {
  const small = (io: KV) => createSnapshotStore(io, { chunkSize: 2 });
  it('splits lists into chunks and reads them back in order', async () => {
    const { io, map } = memory();
    const store = small(io);
    await store.writeSnapshot('k', snap()); // 3 live / 5 movies / 2 series with chunkSize 2
    expect(map.has('k.live.1')).toBe(true);
    expect(map.has('k.movies.2')).toBe(true);
    expect(map.has('k.live')).toBe(false);
    const out = await store.readSnapshot('k');
    expect(out!.movies.map((m: any) => m.name)).toEqual(['movie0', 'movie1', 'movie2', 'movie3', 'movie4']);
    expect(out!.channels.length).toBe(3);
  });
  it('a missing chunk makes the snapshot unusable', async () => {
    const { io, map } = memory();
    const store = small(io);
    await store.writeSnapshot('k', snap());
    map.delete('k.movies.1');
    expect(await store.readSnapshot('k')).toBeNull();
    expect(await store.readHeavy('k')).toBeNull();
  });
  it('yields between chunks so the UI stays responsive', async () => {
    const { io } = memory();
    let yields = 0;
    const store = createSnapshotStore(io, { chunkSize: 2, yieldFn: async () => { yields++; } });
    await store.writeSnapshot('k', snap());
    const afterWrite = yields;
    await store.readHeavy('k');
    expect(afterWrite).toBe(6); // 2 live + 3 movies + 1 series chunks... (3/2=2, 5/2=3, 2/2=1)
    expect(yields - afterWrite).toBe(4); // movies 3 + series 1
  });
  it('removes chunks left over from a previous, larger snapshot', async () => {
    const { io, map } = memory();
    const store = small(io);
    await store.writeSnapshot('k', { ...snap(), movies: items(9, 'movie') }); // 5 movie chunks
    await store.writeSnapshot('k', snap()); // 3 movie chunks
    expect(map.has('k.movies.2')).toBe(true);
    expect(map.has('k.movies.3')).toBe(false);
    expect(map.has('k.movies.4')).toBe(false);
  });
  it('an interrupted write leaves NO valid snapshot (never a mix of old and new)', async () => {
    const { io, map } = memory();
    const store = small(io);
    await store.writeSnapshot('k', snap());
    let calls = 0;
    const flaky: KV = { ...io, set: async (k, v) => { if (++calls === 4) throw new Error('app killed'); return io.set(k, v); } };
    let failed = false;
    try { await createSnapshotStore(flaky, { chunkSize: 2 }).writeSnapshot('k', { ...snap(2000), movies: items(7, 'new') }); } catch { failed = true; }
    expect(failed).toBe(true);
    expect(await store.readSnapshot('k')).toBeNull();
    expect(map.has('k')).toBe(false);
  });
  it('reads the previous one-key-per-list format', async () => {
    const { io, map } = memory();
    map.set('k', JSON.stringify({ split: true, savedAt: 9, counts: { live: 3, movies: 5, series: 2 } }));
    map.set('k.live', JSON.stringify(items(3, 'live')));
    map.set('k.movies', JSON.stringify(items(5, 'movie')));
    map.set('k.series', JSON.stringify(items(2, 'series')));
    const store = small(io);
    const light = await store.readSnapshot('k', true);
    expect(light!.heavy).toBe(false);
    expect(light!.channels.length).toBe(3);
    const heavy = await store.readHeavy('k');
    expect(heavy!.movies.length).toBe(5);
  });
  it('remove deletes every chunk', async () => {
    const { io, map } = memory();
    const store = small(io);
    await store.writeSnapshot('k', snap());
    await store.removeSnapshot('k');
    expect(map.size).toBe(0);
  });
});
