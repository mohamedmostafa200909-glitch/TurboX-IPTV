import { compareVersions } from '../src/network/updateCheck';

describe('compareVersions', () => {
  it('compares numeric parts', () => {
    expect(compareVersions('1.8.0', '1.7.0')).toBeGreaterThan(0);
    expect(compareVersions('1.7.0', '1.8.0')).toBeLessThan(0);
    expect(compareVersions('1.7.0', '1.7.0')).toBe(0);
  });
  it('handles a "v" prefix and different lengths', () => {
    expect(compareVersions('v2.0', '1.9.9')).toBeGreaterThan(0);
    expect(compareVersions('1.7', '1.7.1')).toBeLessThan(0);
  });
  it('ignores trailing pre-release text for the numeric compare', () => {
    expect(compareVersions('1.8.0-beta', '1.7.0')).toBeGreaterThan(0);
  });
});
