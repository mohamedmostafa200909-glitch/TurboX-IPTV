import { thumbUrl } from '../src/utils/thumb';

describe('thumbUrl', () => {
  it('shrinks TMDB originals and large sizes', () => {
    expect(thumbUrl('https://image.tmdb.org/t/p/original/abc.jpg')).toBe('https://image.tmdb.org/t/p/w342/abc.jpg');
    expect(thumbUrl('http://image.tmdb.org/t/p/w780/abc.jpg')).toBe('http://image.tmdb.org/t/p/w342/abc.jpg');
    expect(thumbUrl('https://image.tmdb.org/t/p/w500/abc.jpg', 185)).toBe('https://image.tmdb.org/t/p/w185/abc.jpg');
  });
  it('never upscales and leaves other hosts alone', () => {
    expect(thumbUrl('https://image.tmdb.org/t/p/w185/abc.jpg')).toBe('https://image.tmdb.org/t/p/w185/abc.jpg');
    expect(thumbUrl('https://cdn.example.com/p/original/abc.jpg')).toBe('https://cdn.example.com/p/original/abc.jpg');
    expect(thumbUrl('')).toBe('');
  });
});
