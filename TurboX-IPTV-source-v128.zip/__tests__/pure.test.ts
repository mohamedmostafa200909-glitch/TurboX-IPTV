import { parseXtreamUrl } from '../src/network/testConnection';
import { parseM3uChunk, parseM3uText } from '../src/playlists/m3uParser';
import { IptvError, describeError, kindFromHttp, kindFromPayload, kindFromFetchError } from '../src/network/errors';
import { isAdultCategory } from '../src/utils/adult';
import { isCacheFresh, slimMedia } from '../src/utils/catalog';
import { decodeEpgText } from '../src/utils/epgText';
import { timeshiftUrl } from '../src/utils/timeshift';
import { redact } from '../src/utils/sanitize';
import { pushLog, formatLogs, MAX_LOGS } from '../src/utils/logFormat';
import { normalizeLists, favItemsKey, DEFAULT_LIST_ID } from '../src/utils/favLists';
import { parseStartup, parseLastLive, lastLiveValue } from '../src/utils/startup';
import { isM3u, serverCandidates, channelKey } from '../src/utils/media';

describe('parseXtreamUrl', () => {
  it('splits a get.php link', () => {
    expect(parseXtreamUrl('http://host.tv:8080/get.php?username=u1&password=p%401&type=m3u')).toEqual({ server: 'http://host.tv:8080', username: 'u1', password: 'p@1' });
  });
  it('rejects other links', () => {
    expect(parseXtreamUrl('http://host.tv/list.m3u')).toBeNull();
    expect(parseXtreamUrl('http://host.tv/get.php?username=u')).toBeNull();
  });
});

describe('M3U parser', () => {
  const sample = (n: number) => '#EXTM3U\n' + Array.from({ length: n }, (_, i) => `#EXTINF:-1 tvg-id="c${i}" group-title="G",Channel ${i}\nhttp://x/${i}.ts`).join('\n');
  it('parses attributes', () => {
    const [a] = parseM3uChunk(`#EXTM3U\n#EXTINF:-1 tvg-id="a" tvg-logo="l.png" group-title="News",Ch A\nhttp://x/a.ts`.split('\n'));
    expect(a).toMatchObject({ name: 'Ch A', group: 'News', logo: 'l.png', tvgId: 'a', url: 'http://x/a.ts' });
  });
  it('does not lose a channel at a batch boundary', async () => {
    let got = 0;
    const total = await parseM3uText(sample(2500), b => { got += b.length; }, 50);
    expect(total).toBe(2500);
    expect(got).toBe(2500);
  });
  it('keeps pairs that have extra # lines between them', async () => {
    const txt = '#EXTINF:-1,A\n#EXTVLCOPT:x=y\nhttp://x/a\n#EXTINF:-1,B\nhttp://x/b';
    expect(await parseM3uText(txt, undefined, 1)).toBe(2);
  });
});

describe('error classification', () => {
  it('maps http statuses', () => {
    expect(kindFromHttp(401)).toBe('auth');
    expect(kindFromHttp(403)).toBe('blocked');
    expect(kindFromHttp(404)).toBe('notfound');
    expect(kindFromHttp(502)).toBe('server');
  });
  it('reads Xtream account state', () => {
    expect(kindFromPayload({ user_info: { auth: 0, status: 'Expired' } })).toBe('expired');
    expect(kindFromPayload({ user_info: { auth: 0, status: 'Banned' } })).toBe('disabled');
    expect(kindFromPayload({ user_info: { auth: 0 } })).toBe('auth');
    expect(kindFromPayload({ user_info: { auth: 1, status: 'Active' } })).toBeNull();
  });
  it('distinguishes timeout / not-json / unreachable', () => {
    expect(kindFromFetchError({ name: 'AbortError' }, false)).toBe('timeout');
    expect(kindFromFetchError(new SyntaxError('x'), false)).toBe('badresponse');
    expect(kindFromFetchError(new TypeError('Network request failed'), false)).toBe('unreachable');
  });
  it('blames the device when it is offline', () => {
    expect(describeError(new IptvError('unreachable'), false, true).kind).toBe('offline');
    expect(describeError(new IptvError('auth'), true, true).kind).toBe('auth');
    expect(describeError(new IptvError('timeout', 'after 30s'), true).text).toContain('after 30s');
  });
});

describe('kid filter', () => {
  it('flags adult categories', () => {
    ['XXX Movies', 'Adults 18+', '+18 Live', 'افلام اباحية', 'للكبار فقط', 'Porn HD'].forEach(n => expect(isAdultCategory(n)).toBe(true));
  });
  it('keeps normal categories', () => {
    ['Sussex News', 'Kids', 'أفلام عربية', 'Sports 1080', 'Essex TV', undefined].forEach(n => expect(isAdultCategory(n as any)).toBe(false));
  });
});

describe('catalogue cache', () => {
  const day = 86400000;
  it('is fresh inside the window and stale after it', () => {
    expect(isCacheFresh(1000, 1000 + 6 * day, true, 7)).toBe(true);
    expect(isCacheFresh(1000, 1000 + 8 * day, true, 7)).toBe(false);
  });
  it('never expires when auto-update is off', () => {
    expect(isCacheFresh(0, 999 * day, false, 7)).toBe(true);
  });
  it('slims items without touching used fields', () => {
    const out: any = slimMedia({ name: 'A', stream_id: 5, stream_icon: '', custom_sid: 'x', thumbnail: 't', category_name: 'N', tv_archive: 1, epg_channel_id: null });
    expect(out).toEqual({ name: 'A', stream_id: 5, category_name: 'N', tv_archive: 1 });
  });
});

describe('Xtream EPG text', () => {
  it('decodes base64 UTF-8 (Latin and Arabic)', () => {
    expect(decodeEpgText('TmV3cyBhdCBUZW4=')).toBe('News at Ten');
    expect(decodeEpgText('2KfZhNij2K7YqNin2LE=')).toBe('الأخبار');
  });
  it('leaves normal text alone', () => {
    expect(decodeEpgText('News at Ten')).toBe('News at Ten');
    expect(decodeEpgText('الأخبار')).toBe('الأخبار');
    expect(decodeEpgText('Test')).toBe('Test');
    expect(decodeEpgText('')).toBe('');
  });
});

describe('catch-up url', () => {
  it('uses the server-time string from the EPG', () => {
    expect(timeshiftUrl('http://h:80/', 'u', 'p w', 90, '2026-10-26 21:05:00', 123)).toBe('http://h:80/timeshift/u/p%20w/90/2026-10-26:21-05/123.ts');
  });
  it('rejects bad input', () => {
    expect(timeshiftUrl('http://h', 'u', 'p', 0, '2026-10-26 21:05:00', 1)).toBeNull();
    expect(timeshiftUrl('http://h', 'u', 'p', 30, 'garbage', 1)).toBeNull();
  });
});

describe('redact', () => {
  it('hides credentials in query strings and stream paths', () => {
    expect(redact('GET http://h/player_api.php?username=bob&password=secret&action=x')).not.toMatch(/bob|secret/);
    expect(redact('http://h:80/live/bob/secret/123.ts')).toBe('http://h:80/live/***/***/123.ts');
    expect(redact('http://h/timeshift/bob/secret/90/2026-10-26:21-05/1.ts')).not.toMatch(/bob|secret/);
  });
});

describe('logs', () => {
  it('keeps only the newest entries and redacts', () => {
    let l: any[] = [];
    for (let i = 0; i < MAX_LOGS + 20; i++) l = pushLog(l, 'info', 't', `m${i} password=abc`, i);
    expect(l.length).toBe(MAX_LOGS);
    expect(l[0].msg).toContain('m20');
    expect(formatLogs(l)).not.toContain('abc');
  });
});

describe('favourite lists', () => {
  it('always has the default list first', () => {
    expect(normalizeLists(undefined, 'Fav')).toEqual([{ id: DEFAULT_LIST_ID, name: 'Fav' }]);
    expect(normalizeLists([{ id: 'x', name: 'News' }], 'Fav').map(l => l.id)).toEqual([DEFAULT_LIST_ID, 'x']);
  });
  it('keeps the legacy key for the default list', () => {
    expect(favItemsKey('p1', DEFAULT_LIST_ID, 'Main')).toBe('streambox.favorites.p1.Main');
    expect(favItemsKey('p1', 'x', 'Main')).toBe('streambox.favlist.p1.x');
  });
});

describe('startup mode', () => {
  it('parses and round-trips', () => {
    expect(parseStartup('last')).toBe('last');
    expect(parseStartup('home')).toBe('home');
    expect(parseStartup('nonsense')).toBe('live');
    expect(parseStartup(null)).toBe('live');
    expect(parseLastLive(lastLiveValue('p1', 'a|b'))).toEqual({ providerId: 'p1', key: 'a|b' });
    expect(parseLastLive(null)).toBeNull();
  });
});

describe('media utils', () => {
  it('detects m3u and builds candidates', () => {
    expect(isM3u('http://x/get.php?username=a&password=b&type=m3u')).toBe(true);
    expect(isM3u('http://x:8080')).toBe(false);
    expect(serverCandidates('x.tv:8080')).toEqual(['http://x.tv:8080', 'https://x.tv:8080']);
    expect(channelKey({ name: 'n', stream_id: 7 })).toBe('7');
  });
});

import { createScrollIdle, IDLE_MS } from '../src/utils/scrollIdle';
import { planAttempts } from '../src/network/xtreamPlan';
import { mapLimit } from '../src/utils/mapLimit';
import { classifyPlaybackError, describePlaybackError } from '../src/network/playbackErrors';
describe('scroll idle (images wait for the list to calm down)', () => {
  const fake = () => {
    let t = 1000;
    const timers: Array<{ at: number; fn: () => void }> = [];
    const idle = createScrollIdle(() => t, (fn, ms) => { timers.push({ at: t + ms, fn }); });
    const advance = (ms: number) => { t += ms; for (const x of timers.filter(x => x.at <= t)) { timers.splice(timers.indexOf(x), 1); x.fn(); } };
    return { idle, advance, noteAt: () => idle.noteScroll() };
  };
  it('runs immediately when nothing is scrolling', () => {
    const { idle } = fake();
    let ran = 0;
    idle.onceIdle(() => { ran++; });
    expect(ran).toBe(1);
  });
  it('waits while scrolling and runs once after it stops', () => {
    const { idle, advance } = fake();
    let ran = 0;
    idle.noteScroll();
    idle.onceIdle(() => { ran++; });
    expect(ran).toBe(0);
    advance(100); idle.noteScroll(); // still scrolling
    advance(130); idle.noteScroll(); // and still scrolling
    advance(120);
    expect(ran).toBe(0); // the check fired, but the list moved 120ms ago: keep waiting
    advance(IDLE_MS + 80);
    expect(ran).toBe(1);
    advance(1000);
    expect(ran).toBe(1); // only once
  });
  it('can be cancelled (row unmounted before the list stopped)', () => {
    const { idle, advance } = fake();
    let ran = 0;
    idle.noteScroll();
    const cancel = idle.onceIdle(() => { ran++; });
    cancel();
    advance(2000);
    expect(ran).toBe(0);
  });
});

describe('xtream attempt plan', () => {
  const c = ['http://h:80', 'https://h:80'];
  it('login: both address variants, two attempts each', () => {
    expect(planAttempts(c, undefined, false)).toEqual([{ server: 'http://h:80', timeouts: [30000, 45000] }, { server: 'https://h:80', timeouts: [30000, 45000] }]);
  });
  it('tries the address that worked last time first', () => {
    expect(planAttempts(c, 'https://h:80', false).map(p => p.server)).toEqual(['https://h:80', 'http://h:80']);
    expect(planAttempts(c, 'http://other', false).map(p => p.server)).toEqual(c); // unknown address is ignored
  });
  it('quick calls: one attempt, one address, short timeout', () => {
    expect(planAttempts(c, undefined, true)).toEqual([{ server: 'http://h:80', timeouts: [10000] }]);
    expect(planAttempts(c, 'https://h:80', true, 20000)).toEqual([{ server: 'https://h:80', timeouts: [20000] }]);
  });
});

describe('mapLimit', () => {
  it('never runs more than `limit` at once and finishes everything', async () => {
    let running = 0, peak = 0, done = 0;
    await mapLimit(Array.from({ length: 20 }, (_, i) => i), 4, async () => {
      running++; peak = Math.max(peak, running);
      await new Promise(r => setTimeout(r, 5));
      running--; done++;
    });
    expect(peak).toBe(4);
    expect(done).toBe(20);
  });
  it('stops starting new work once told to (circuit breaker)', async () => {
    let started = 0, failures = 0;
    await mapLimit(Array.from({ length: 60 }, (_, i) => i), 4, async () => {
      started++;
      await new Promise(r => setTimeout(r, 2));
      failures++;
    }, () => failures >= 3);
    expect(started < 12).toBe(true); // 4 in flight + a few already started, nowhere near 60
  });
  it('handles an empty list', async () => {
    await mapLimit([], 4, async () => { throw new Error('never'); });
    expect(1).toBe(1);
  });
});

describe('playback error classification', () => {
  it('reads the HTTP status ExoPlayer reports', () => {
    expect(classifyPlaybackError('com.google.android.exoplayer2.upstream.HttpDataSource$InvalidResponseCodeException: Response code: 403')).toBe('http-auth');
    expect(classifyPlaybackError('Response code: 884')).toBe('http-auth');
    expect(classifyPlaybackError('Response code: 404')).toBe('http-notfound');
    expect(classifyPlaybackError('Response code: 502')).toBe('http-server');
  });
  it('recognises network problems', () => {
    expect(classifyPlaybackError('java.net.UnknownHostException: no address')).toBe('network');
    expect(classifyPlaybackError('Unable to connect to http://h:80/live/u/p/1.ts')).toBe('network');
    expect(classifyPlaybackError('SocketTimeoutException: timeout')).toBe('network');
  });
  it('recognises codec limits of the device', () => {
    expect(classifyPlaybackError('MediaCodecRenderer$DecoderInitializationException: Decoder init failed: OMX.google.hevc.decoder, Format(null, null, video/hevc')).toBe('codec');
    expect(classifyPlaybackError('NO_EXCEEDS_CAPABILITIES audio/eac3')).toBe('codec');
  });
  it('recognises unsupported formats and slow starts', () => {
    expect(classifyPlaybackError('UnrecognizedInputFormatException: None of the available extractors')).toBe('format');
    expect(classifyPlaybackError('stalled: no data for 60s')).toBe('stalled');
    expect(classifyPlaybackError('')).toBe('unknown');
  });
  it('never leaks stream URLs into the message and keeps a short technical hint', () => {
    const d = describePlaybackError('Unable to connect to http://h:80/live/bob/secret/1.ts (host down)', false);
    expect(d.kind).toBe('network');
    expect(d.text).not.toContain('http://');
    expect(d.text).not.toContain('secret');
    expect(d.text).toContain('host down');
  });
});
