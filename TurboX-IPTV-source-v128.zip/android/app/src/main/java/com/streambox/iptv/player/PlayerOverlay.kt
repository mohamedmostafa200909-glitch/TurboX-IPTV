package com.streambox.iptv.player

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** HUD overlay: auto-hides after 4 seconds and exposes left/right quick drawers. */
class PlayerOverlay(context: Context) : FrameLayout(context) {
  companion object { const val HUD_AUTO_HIDE_MS = 4_000L }
  private val hud = panel("TurboX IPTV  •  LIVE")
  private val leftDrawer = panel("القنوات السريعة\n↑ ↓ للتبديل\nOK للتشغيل")
  private val rightDrawer = panel("الإعدادات السريعة\nالصوت  •  الترجمة\nنسبة العرض")
  private var hideRunnable: Runnable? = null

  init {
    setWillNotDraw(false)
    addView(hud, edgeParams(Gravity.TOP or Gravity.CENTER_HORIZONTAL, 16, 16, 16, 0))
    addView(leftDrawer, edgeParams(Gravity.START or Gravity.CENTER_VERTICAL, 0, 0, 0, 0))
    addView(rightDrawer, edgeParams(Gravity.END or Gravity.CENTER_VERTICAL, 0, 0, 0, 0))
    leftDrawer.visibility = GONE; rightDrawer.visibility = GONE
    isFocusable = true; isFocusableInTouchMode = true
    setOnKeyListener { _, keyCode, event ->
      if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
      when (keyCode) {
        KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { toggleHud(); true }
        KeyEvent.KEYCODE_DPAD_LEFT -> { showLeftDrawer(); true }
        KeyEvent.KEYCODE_DPAD_RIGHT -> { showRightDrawer(); true }
        KeyEvent.KEYCODE_BACK -> { if (hud.visibility == VISIBLE || leftDrawer.visibility == VISIBLE || rightDrawer.visibility == VISIBLE) { hideAll(); true } else false }
        else -> false
      }
    }
  }

  fun toggleHud() { hud.visibility = if (hud.visibility == VISIBLE) GONE else VISIBLE; if (hud.visibility == VISIBLE) scheduleHide() }
  fun showHud() { hud.visibility = VISIBLE; leftDrawer.visibility = GONE; rightDrawer.visibility = GONE; scheduleHide() }
  fun showLeftDrawer() { hud.visibility = VISIBLE; leftDrawer.visibility = VISIBLE; rightDrawer.visibility = GONE; scheduleHide() }
  fun showRightDrawer() { hud.visibility = VISIBLE; rightDrawer.visibility = VISIBLE; leftDrawer.visibility = GONE; scheduleHide() }
  fun isOverlayVisible(): Boolean = hud.visibility == VISIBLE || leftDrawer.visibility == VISIBLE || rightDrawer.visibility == VISIBLE
  fun hideAll() { hud.visibility = GONE; leftDrawer.visibility = GONE; rightDrawer.visibility = GONE; hideRunnable?.let(::removeCallbacks) }

  private fun scheduleHide() { hideRunnable?.let(::removeCallbacks); hideRunnable = Runnable { hud.visibility = GONE; leftDrawer.visibility = GONE; rightDrawer.visibility = GONE }; postDelayed(hideRunnable!!, HUD_AUTO_HIDE_MS) }
  private fun panel(text: String) = TextView(context).apply { this.text = text; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER; setPadding(24, 18, 24, 18); background = GradientDrawable().apply { setColor(Color.argb(225, 7, 11, 18)); setStroke(2, Color.rgb(34, 230, 244)); cornerRadius = 18f } }
  private fun edgeParams(gravity: Int, l: Int, t: Int, r: Int, b: Int) = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, gravity).apply { setMargins(l, t, r, b) }
}
