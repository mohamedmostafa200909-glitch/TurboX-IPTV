package com.streambox.iptv.player

import com.facebook.react.bridge.ReadableMap
import com.facebook.react.uimanager.SimpleViewManager
import com.facebook.react.uimanager.ThemedReactContext
import com.facebook.react.uimanager.annotations.ReactProp

class TurboPlayerViewManager : SimpleViewManager<TurboPlayerView>() {
  override fun getName() = "TurboPlayerView"
  override fun createViewInstance(reactContext: ThemedReactContext) = TurboPlayerView(reactContext)

  @ReactProp(name = "source")
  fun setSource(view: TurboPlayerView, source: String?) { view.setSourceProp(source) }

  @ReactProp(name = "fallbackSource")
  fun setFallbackSource(view: TurboPlayerView, source: String?) { view.setFallbackProp(source) }

  @ReactProp(name = "live", defaultBoolean = false)
  fun setLive(view: TurboPlayerView, live: Boolean) { view.setLiveProp(live) }

  @ReactProp(name = "headers")
  fun setHeaders(view: TurboPlayerView, headers: ReadableMap?) {
    val out = HashMap<String, String>()
    if (headers != null) {
      val it = headers.keySetIterator()
      while (it.hasNextKey()) { val k = it.nextKey(); headers.getString(k)?.let { v -> out[k] = v } }
    }
    view.setHeadersProp(out)
  }

  @ReactProp(name = "paused", defaultBoolean = false)
  fun setPaused(view: TurboPlayerView, paused: Boolean) { view.setPausedProp(paused) }

  /** mini preview: no sound */
  @ReactProp(name = "muted", defaultBoolean = false)
  fun setMuted(view: TurboPlayerView, muted: Boolean) { view.setMutedProp(muted) }

  /** { to: <ms>, n: <nonce> } - a new nonce triggers a seek. */
  @ReactProp(name = "seek")
  fun setSeek(view: TurboPlayerView, seek: ReadableMap?) {
    if (seek != null && seek.hasKey("to") && seek.hasKey("n")) view.setSeekProp(seek.getDouble("to").toLong(), seek.getInt("n"))
  }

  @ReactProp(name = "audioTrack")
  fun setAudioTrack(view: TurboPlayerView, id: String?) { view.setAudioTrackProp(id) }

  @ReactProp(name = "textTrack")
  fun setTextTrack(view: TurboPlayerView, id: String?) { view.setTextTrackProp(id) }

  @ReactProp(name = "resizeMode")
  fun setResizeMode(view: TurboPlayerView, mode: String?) { view.setResizeModeProp(mode) }

  override fun onAfterUpdateTransaction(view: TurboPlayerView) {
    super.onAfterUpdateTransaction(view)
    view.applyPending()
  }

  override fun getExportedCustomDirectEventTypeConstants(): Map<String, Any> {
    val events = HashMap<String, Any>()
    super.getExportedCustomDirectEventTypeConstants()?.let { events.putAll(it) }
    events["topTurboStatus"] = mapOf("registrationName" to "onStatus")
    events["topTurboTracks"] = mapOf("registrationName" to "onTracks")
    events["topTurboError"] = mapOf("registrationName" to "onError")
    return events
  }

  override fun onDropViewInstance(view: TurboPlayerView) { view.dispose(); super.onDropViewInstance(view) }
}
