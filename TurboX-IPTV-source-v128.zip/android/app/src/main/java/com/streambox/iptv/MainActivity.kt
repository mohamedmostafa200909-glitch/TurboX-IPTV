package com.streambox.iptv

import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import com.facebook.react.ReactActivity
import com.facebook.react.bridge.Arguments
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.facebook.react.ReactActivityDelegate
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint.fabricEnabled
import com.facebook.react.defaults.DefaultReactActivityDelegate
import expo.modules.ReactActivityDelegateWrapper

class MainActivity : ReactActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    // Set the theme before onCreate for Expo splash-screen compatibility.
    setTheme(R.style.AppTheme)
    super.onCreate(null)

    // Keep the display awake while IPTV playback is active.
    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

    // AOSP TV boxes can start React Native in touch-navigation mode. Give the
    // window a temporary focusable target so Android leaves touch mode and
    // starts dispatching DPAD events through the normal focus engine.
    window.decorView.post {
      window.decorView.isFocusable = true
      window.decorView.isFocusableInTouchMode = true
      window.decorView.requestFocus()
      window.decorView.postDelayed({
        if (currentFocus == null || currentFocus === window.decorView) {
          requestInitialTvFocus(window.decorView)
        }
      }, 350)
    }
  }

  /**
   * Find the first real interactive child after React Native has mounted.
   * We intentionally do not focus the root view: doing that can trap focus
   * above Pressable cards and prevent normal D-Pad navigation.
   */
  private fun requestInitialTvFocus(view: View): Boolean {
    if (
      view !== window.decorView &&
      view.visibility == View.VISIBLE &&
      view.isEnabled &&
      view.isFocusable
    ) {
      return view.requestFocus()
    }

    if (view is ViewGroup) {
      for (index in 0 until view.childCount) {
        if (requestInitialTvFocus(view.getChildAt(index))) return true
      }
    }

    return false
  }

  override fun onWindowFocusChanged(hasFocus: Boolean) {
    super.onWindowFocusChanged(hasFocus)

    if (hasFocus) {
      window.decorView.postDelayed({
        // A remote key naturally exits touch navigation mode. This fallback
        // only selects a child when Android has not selected anything yet.
        if (currentFocus == null || currentFocus === window.decorView) {
          requestInitialTvFocus(window.decorView)
        }
      }, 300)
    }
  }

  /**
   * Never manually consume DPAD arrows or call focusSearch here.
   * Android's native focus engine forwards the event to React Native.
   */
  private fun emitRemoteKey(event: KeyEvent) {
    val reactContext = reactInstanceManager.currentReactContext ?: return
    val payload = Arguments.createMap().apply {
      putInt("keyCode", event.keyCode)
      putInt("action", event.action)
      putInt("repeatCount", event.repeatCount)
    }
    reactContext
      .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
      .emit("TurboXRemoteKey", payload)
  }

  override fun dispatchKeyEvent(event: KeyEvent): Boolean {
    Log.d(
      "TV_REMOTE_DEBUG",
      "Key Pressed: ${KeyEvent.keyCodeToString(event.keyCode)} (${event.keyCode}), Action: ${event.action}, Repeat: ${event.repeatCount}"
    )
    if (event.action == KeyEvent.ACTION_DOWN) emitRemoteKey(event)
    return super.dispatchKeyEvent(event)
  }

  /**
   * React Native Modals (player, dialogs) are separate windows: their dialog forwards only
   * key-UP events to the activity. Forward OK, D-Pad, media and channel keys here so controls
   * inside modals and the video player can be driven by the remote. JS de-duplicates:
   * main-screen navigation listens to action = 0, modals/player listen to action = 1.
   */
  override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
    when (keyCode) {
      KeyEvent.KEYCODE_DPAD_CENTER,
      KeyEvent.KEYCODE_ENTER,
      KeyEvent.KEYCODE_NUMPAD_ENTER,
      KeyEvent.KEYCODE_DPAD_UP,
      KeyEvent.KEYCODE_DPAD_DOWN,
      KeyEvent.KEYCODE_DPAD_LEFT,
      KeyEvent.KEYCODE_DPAD_RIGHT,
      KeyEvent.KEYCODE_MEDIA_PLAY,
      KeyEvent.KEYCODE_MEDIA_PAUSE,
      KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
      KeyEvent.KEYCODE_MEDIA_REWIND,
      KeyEvent.KEYCODE_MEDIA_FAST_FORWARD,
      KeyEvent.KEYCODE_CHANNEL_UP,
      KeyEvent.KEYCODE_CHANNEL_DOWN,
      KeyEvent.KEYCODE_LAST_CHANNEL,
      KeyEvent.KEYCODE_MENU,
      KeyEvent.KEYCODE_INFO,
      KeyEvent.KEYCODE_PROG_RED,
      KeyEvent.KEYCODE_PROG_GREEN,
      KeyEvent.KEYCODE_PROG_YELLOW,
      KeyEvent.KEYCODE_PROG_BLUE,
      KeyEvent.KEYCODE_MEDIA_STOP,
      KeyEvent.KEYCODE_MEDIA_NEXT,
      KeyEvent.KEYCODE_MEDIA_PREVIOUS,
      KeyEvent.KEYCODE_PAGE_UP,
      KeyEvent.KEYCODE_PAGE_DOWN,
      KeyEvent.KEYCODE_BUTTON_A,
      KeyEvent.KEYCODE_CAPTIONS,
      KeyEvent.KEYCODE_MEDIA_AUDIO_TRACK,
      in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9,
      in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 -> emitRemoteKey(event)
    }
    return super.onKeyUp(keyCode, event)
  }

  override fun getMainComponentName(): String = "main"

  override fun createReactActivityDelegate(): ReactActivityDelegate {
    return ReactActivityDelegateWrapper(
      this,
      BuildConfig.IS_NEW_ARCHITECTURE_ENABLED,
      object : DefaultReactActivityDelegate(
        this,
        mainComponentName,
        fabricEnabled
      ) {}
    )
  }

  override fun invokeDefaultOnBackPressed() {
    if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R) {
      if (!moveTaskToBack(false)) {
        super.invokeDefaultOnBackPressed()
      }
      return
    }
    super.invokeDefaultOnBackPressed()
  }
}
