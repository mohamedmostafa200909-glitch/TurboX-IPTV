package com.streambox.iptv.player

import android.content.Context
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.SurfaceView
import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.exoplayer.DefaultRenderersFactory
import java.util.Locale
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.AspectRatioFrameLayout

/** TurboX dual-engine player. ExoPlayer is primary; libVLC is activated on codec/decoding failure. */
class PlayerController(private val context: Context, private val surface: SurfaceView) {
  enum class Engine { EXOPLAYER, EXTERNAL_VLC }
  enum class AspectRatio { RATIO_16_9, RATIO_4_3, ZOOM_CROP, STRETCH }

  companion object {
    const val FAILOVER_BUFFERING_MS = 3_000
    const val AUDIO_DELAY_MIN_MS = -5_000
    const val AUDIO_DELAY_MAX_MS = 5_000
  }

  // Buffer profile: "fast" (default) favours quick channel zapping; "stable" trades start-up speed for fewer
  // stalls on weak connections. Read once here, when this player (and its ExoPlayer instance) is created — Settings
  // sets TurboPlayerModule.bufferProfile, so a change there takes effect from the next channel/video you open, not
  // on one that is already playing (ExoPlayer's buffer sizing cannot be changed on a running instance).
  private val stableProfile = TurboPlayerModule.bufferProfile == "stable"
  private val minBufferMs = if (stableProfile) 6_000 else 2_000
  private val maxBufferMs = if (stableProfile) 20_000 else 8_000
  private val bufferForPlaybackMs = if (stableProfile) 2_500 else 500
  private val bufferForPlaybackAfterRebufferMs = if (stableProfile) 5_000 else 1_500

  private val mainHandler = Handler(Looper.getMainLooper())
  private val trackSelector = DefaultTrackSelector(context).apply {
    // Media Tunneling: hands decoded video straight to the display pipeline on supporting devices/codecs, cutting
    // latency and CPU use. Falls back silently where the device/codec combination does not support it — ExoPlayer
    // only tunnels when it safely can. Same "effective on next open" caveat as the buffer profile above.
    if (TurboPlayerModule.tunnelingEnabled) parameters = buildUponParameters().setTunnelingEnabled(true).build()
  }
  private val loadControl = DefaultLoadControl.Builder()
    .setBufferDurationsMs(minBufferMs, maxBufferMs, bufferForPlaybackMs, bufferForPlaybackAfterRebufferMs)
    .setPrioritizeTimeOverSizeThresholds(true)
    .setBackBuffer(0, false)
    .build()
  private val connectionPool = ConnectionPool(8, 5, java.util.concurrent.TimeUnit.MINUTES)
  private val okHttpClient = OkHttpClient.Builder()
    .connectionPool(connectionPool)
    .retryOnConnectionFailure(true)
    .build()
  private val httpFactory = OkHttpDataSource.Factory(okHttpClient)
    .setUserAgent("TurboX IPTV/1.0 (Android; Media3)")
    .setDefaultRequestProperties(mapOf(
      "Accept" to "*/*",
      "Connection" to "keep-alive",
      "X-TurboX-Player" to "Media3"
    ))
  private val dataSourceFactory = DefaultDataSource.Factory(context, httpFactory)
  private val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)
  // One ExoPlayer instance is reused for every channel switch in this native view.
  private val exo: ExoPlayer = ExoPlayer.Builder(context)
    .setRenderersFactory(DefaultRenderersFactory(context).setEnableDecoderFallback(true))
    .setTrackSelector(trackSelector)
    .setLoadControl(loadControl)
    .setMediaSourceFactory(mediaSourceFactory)
    .build()
  private var currentUrl: String? = null
  private var fallbackUrl: String? = null
  private var isLive = false
  private var engine = Engine.EXOPLAYER
  private var audioDelayMs = 0
  private var failoverAttempted = false
  private var bufferingSince = 0L
  private var listener: Listener? = null

  interface Listener {
    fun onEngineChanged(engine: Engine)
    fun onBufferingFailover(url: String?)
    fun onPlaybackError(error: String)
  }

  init {
    exo.setVideoSurfaceView(surface) // SurfaceView, not TextureView.
    exo.addListener(object : Player.Listener {
      override fun onPlayerError(error: PlaybackException) {
        if (isCodecOrDecoderError(error)) switchToVlc() else failoverOrReport(error.message ?: "Playback error")
      }
      override fun onPlaybackStateChanged(state: Int) {
        if (state == Player.STATE_BUFFERING) {
          if (bufferingSince == 0L) bufferingSince = System.currentTimeMillis()
          scheduleFailoverCheck()
        } else bufferingSince = 0L
      }
    })
  }

  fun setListener(listener: Listener?) { this.listener = listener }

  /** The reused ExoPlayer instance (view code attaches listeners / reads status from it). */
  val player: ExoPlayer get() = exo

  /** Per-request HTTP headers (User-Agent / Referer / Origin ...) from JS. Call before prepare(). */
  fun setHeaders(headers: Map<String, String>) {
    val props = mutableMapOf("Accept" to "*/*", "Connection" to "keep-alive", "X-TurboX-Player" to "Media3")
    headers.forEach { (k, v) -> if (k.equals("User-Agent", ignoreCase = true)) httpFactory.setUserAgent(v) else props[k] = v }
    httpFactory.setDefaultRequestProperties(props)
  }

  data class TrackInfo(val id: String, val label: String, val language: String, val selected: Boolean)

  /** Audio (C.TRACK_TYPE_AUDIO) or text/subtitle (C.TRACK_TYPE_TEXT) tracks of the current media. */
  fun listTracks(type: Int): List<TrackInfo> {
    val out = ArrayList<TrackInfo>()
    val groups = exo.currentTracks.groups
    for (gi in 0 until groups.size) {
      val g: Tracks.Group = groups[gi]
      if (g.type != type) continue
      for (ti in 0 until g.length) {
        if (!g.isTrackSupported(ti)) continue
        val f = g.getTrackFormat(ti)
        val lang = f.language ?: ""
        val name = f.label
          ?: if (lang.isNotEmpty() && lang != "und") Locale(lang).displayLanguage.ifBlank { lang } else "Track ${out.size + 1}"
        val extra = if (type == C.TRACK_TYPE_AUDIO && f.channelCount > 0) " (${f.channelCount}ch)" else ""
        out.add(TrackInfo("$gi:$ti", name + extra, lang, g.isTrackSelected(ti)))
      }
    }
    return out
  }

  /** id = "group:track" from listTracks(), or "off" to disable that track type (subtitles). */
  fun selectTrack(type: Int, id: String) {
    val builder = exo.trackSelectionParameters.buildUpon()
    if (id == "off") {
      builder.setTrackTypeDisabled(type, true)
    } else {
      val parts = id.split(":")
      val gi = parts.getOrNull(0)?.toIntOrNull() ?: return
      val ti = parts.getOrNull(1)?.toIntOrNull() ?: return
      val groups = exo.currentTracks.groups
      if (gi < 0 || gi >= groups.size) return
      builder.setTrackTypeDisabled(type, false)
        .setOverrideForType(TrackSelectionOverride(groups[gi].mediaTrackGroup, ti))
    }
    exo.trackSelectionParameters = builder.build()
  }

  fun seekTo(positionMs: Long) { exo.seekTo(positionMs) }
  fun setPaused(paused: Boolean) { exo.playWhenReady = !paused }

  fun prepare(primaryUrl: String, secondaryUrl: String? = null, live: Boolean = false) {
    currentUrl = primaryUrl
    fallbackUrl = secondaryUrl
    isLive = live
    failoverAttempted = false
    engine = Engine.EXOPLAYER
    exo.setVideoSurfaceView(surface)
    exo.stop()
    // Reuse the same ExoPlayer instance; replacing the item avoids player churn/OOM.
    exo.setMediaItem(MediaItem.Builder().setUri(primaryUrl).build())
    exo.prepare()
    exo.playWhenReady = true
    listener?.onEngineChanged(engine)
  }

  fun setAudioDelayMs(value: Int) {
    audioDelayMs = value.coerceIn(AUDIO_DELAY_MIN_MS, AUDIO_DELAY_MAX_MS)
    // Kept as a public synchronization API. Audio renderer integrations can consume this offset.
    exo.setPlaybackParameters(exo.playbackParameters)
  }

  fun getAudioDelayMs(): Int = audioDelayMs

  fun setAspectRatio(aspect: AspectRatio, resizeView: AspectRatioFrameLayout?) {
    resizeView?.resizeMode = when (aspect) {
      AspectRatio.RATIO_16_9 -> AspectRatioFrameLayout.RESIZE_MODE_FIT
      AspectRatio.RATIO_4_3 -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
      AspectRatio.ZOOM_CROP -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
      AspectRatio.STRETCH -> AspectRatioFrameLayout.RESIZE_MODE_FILL
    }
  }

  fun seekToNext() { exo.seekToNextMediaItem() }
  fun seekToPrevious() { exo.seekToPreviousMediaItem() }
  fun togglePlayPause() { if (exo.isPlaying) exo.pause() else exo.play() }
  fun release() { exo.release(); mainHandler.removeCallbacksAndMessages(null) }
  fun currentEngine(): Engine = engine

  private fun scheduleFailoverCheck() {
    mainHandler.postDelayed({
      if (engine == Engine.EXOPLAYER && isLive && bufferingSince > 0L && System.currentTimeMillis() - bufferingSince >= FAILOVER_BUFFERING_MS) {
        failoverOrReport("Live stream buffering exceeded ${FAILOVER_BUFFERING_MS}ms")
      }
    }, FAILOVER_BUFFERING_MS.toLong())
  }

  private fun failoverOrReport(message: String) {
    if (!failoverAttempted && !fallbackUrl.isNullOrBlank()) {
      failoverAttempted = true
      listener?.onBufferingFailover(fallbackUrl)
      prepare(fallbackUrl!!, null, isLive)
    } else listener?.onPlaybackError(message)
  }

  private fun isCodecOrDecoderError(error: PlaybackException): Boolean {
    return error.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
      error.errorCode == PlaybackException.ERROR_CODE_DECODING_FAILED ||
      error.errorCode == PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED
  }

  private fun switchToVlc() {
    val url = currentUrl ?: return
    try {
      val intent = Intent(Intent.ACTION_VIEW).apply {
        setPackage("org.videolan.vlc")
        setDataAndType(android.net.Uri.parse(url), "video/*")
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      context.startActivity(intent)
      engine = Engine.EXTERNAL_VLC
      listener?.onEngineChanged(engine)
    } catch (_: ActivityNotFoundException) {
      listener?.onPlaybackError("VLC is not installed. Install VLC for Android to use external fallback.")
    } catch (e: Exception) {
      listener?.onPlaybackError("Could not open external VLC: ${e.message}")
    }
  }

}
