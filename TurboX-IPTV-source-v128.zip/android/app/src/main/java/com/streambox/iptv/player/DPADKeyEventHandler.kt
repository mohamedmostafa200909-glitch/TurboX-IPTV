package com.streambox.iptv.player

import android.view.KeyEvent

/** Remote-control bindings for Android TV and D-pad devices. */
class DPADKeyEventHandler(
  private val overlay: PlayerOverlay,
  private val callbacks: Callbacks
) {
  interface Callbacks {
    fun onNextChannel()
    fun onPreviousChannel()
    fun onBackToEpg()
  }

  

  fun onKeyEvent(event: KeyEvent): Boolean {
    if (event.action != KeyEvent.ACTION_DOWN) return false
    return when (event.keyCode) {
      KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { overlay.toggleHud(); true }
      KeyEvent.KEYCODE_DPAD_UP -> { callbacks.onNextChannel(); true }
      KeyEvent.KEYCODE_DPAD_DOWN -> { callbacks.onPreviousChannel(); true }
      KeyEvent.KEYCODE_DPAD_LEFT -> { overlay.showLeftDrawer(); true }
      KeyEvent.KEYCODE_DPAD_RIGHT -> { overlay.showRightDrawer(); true }
      KeyEvent.KEYCODE_BACK -> {
        if (overlay.isOverlayVisible()) overlay.hideAll() else callbacks.onBackToEpg()
        true
      }
      else -> false
    }
  }
}
