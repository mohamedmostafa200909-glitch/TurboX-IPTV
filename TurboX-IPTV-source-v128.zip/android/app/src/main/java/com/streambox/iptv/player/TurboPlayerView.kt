package com.streambox.iptv.player

import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.SurfaceView
import android.widget.FrameLayout
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.text.CueGroup
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.SubtitleView
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.WritableMap
import com.facebook.react.uimanager.ThemedReactContext
import com.facebook.react.uimanager.UIManagerHelper

/**
 * Media3 player surface driven entirely by props from JS (no native HUD / key handling):
 * source, headers, live, paused, seek, audioTrack, textTrack, resizeMode.
 * Emits onStatus (1 Hz), onTracks (audio/subtitle lists) and onError.
 */
class TurboPlayerView(private val ctx: ThemedReactContext) : FrameLayout(ctx) {
  private val frame = AspectRatioFrameLayout(ctx)
  private val surface = SurfaceView(ctx)
  private val subtitles = SubtitleView(ctx)
  private val controller = PlayerController(ctx, surface)
  private val main = Handler(Looper.getMainLooper())

  // pending props, applied together in applyPending() (ViewManager.onAfterUpdateTransaction)
  private var source: String? = null
  private var fallback: String? = null
  private var live = false
  private var headers: Map<String, String> = emptyMap()
  private var paused = false
  private var muted = false
  private var appliedMuted: Boolean? = null
  private var seekTo = 0L
  private var seekNonce = -1
  private var audioTrack: String? = null
  private var textTrack: String? = null
  private var resizeMode = "contain"

  private var preparedKey: String? = null
  private var appliedPaused: Boolean? = null
  private var appliedSeekNonce = -1
  private var appliedAudio: String? = null
  private var appliedText: String? = null

  private val ticker = object : Runnable {
    override fun run() {
      emitStatus()
      main.postDelayed(this, 1000)
    }
  }

  // declared before init{}: addView() below calls requestLayout(), which uses it
  private val measureAndLayout = Runnable {
    measure(MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY))
    layout(left, top, right, bottom)
  }

  init {
    setBackgroundColor(Color.BLACK)
    frame.addView(surface, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
    addView(frame, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, Gravity.CENTER))
    subtitles.setUserDefaultStyle()
    subtitles.setUserDefaultTextSize()
    addView(subtitles, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

    controller.setListener(object : PlayerController.Listener {
      override fun onEngineChanged(engine: PlayerController.Engine) {}
      override fun onBufferingFailover(url: String?) {}
      override fun onPlaybackError(error: String) {
        val m = Arguments.createMap(); m.putString("message", error); emit("topTurboError", m)
      }
    })
    controller.player.addListener(object : Player.Listener {
      override fun onTracksChanged(tracks: Tracks) { emitTracks() }
      override fun onCues(cueGroup: CueGroup) { subtitles.setCues(cueGroup.cues) }
      override fun onVideoSizeChanged(videoSize: VideoSize) {
        frame.setAspectRatio(if (videoSize.height == 0) 0f else videoSize.width * videoSize.pixelWidthHeightRatio / videoSize.height)
      }
    })
  }

  // ---- props -------------------------------------------------------------------------------
  fun setSourceProp(v: String?) { source = v }
  fun setFallbackProp(v: String?) { fallback = v }
  fun setLiveProp(v: Boolean) { live = v }
  fun setHeadersProp(v: Map<String, String>) { headers = v }
  fun setPausedProp(v: Boolean) { paused = v }
  fun setMutedProp(v: Boolean) { muted = v }
  fun setSeekProp(to: Long, nonce: Int) { seekTo = to; seekNonce = nonce }
  fun setAudioTrackProp(v: String?) { audioTrack = v }
  fun setTextTrackProp(v: String?) { textTrack = v }
  fun setResizeModeProp(v: String?) { resizeMode = v ?: "contain" }

  fun applyPending() {
    frame.resizeMode = when (resizeMode) {
      "cover" -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
      "stretch" -> AspectRatioFrameLayout.RESIZE_MODE_FILL
      else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
    }
    val src = source
    if (!src.isNullOrBlank()) {
      val key = "$src|$live|${headers.hashCode()}"
      if (key != preparedKey) {
        preparedKey = key
        controller.setHeaders(headers)
        appliedAudio = null; appliedText = null; appliedPaused = null
        controller.prepare(src, fallback, live)
      }
    }
    if (appliedPaused != paused) { appliedPaused = paused; controller.setPaused(paused) }
    if (appliedMuted != muted) { appliedMuted = muted; controller.player.volume = if (muted) 0f else 1f }
    if (seekNonce != appliedSeekNonce) { appliedSeekNonce = seekNonce; if (seekNonce >= 0) controller.seekTo(seekTo) }
    val a = audioTrack
    if (a != null && a != appliedAudio) { appliedAudio = a; controller.selectTrack(C.TRACK_TYPE_AUDIO, a) }
    val t = textTrack
    if (t != null && t != appliedText) { appliedText = t; controller.selectTrack(C.TRACK_TYPE_TEXT, t) }
  }

  // ---- events ------------------------------------------------------------------------------
  private fun emit(name: String, data: WritableMap) {
    if (id == NO_ID) return
    val dispatcher = UIManagerHelper.getEventDispatcherForReactTag(ctx, id) ?: return
    dispatcher.dispatchEvent(TurboPlayerEvent(UIManagerHelper.getSurfaceId(ctx), id, name, data))
  }

  private fun emitStatus() {
    val p = controller.player
    val m = Arguments.createMap()
    val dur = p.duration
    m.putDouble("positionMs", p.currentPosition.toDouble())
    m.putDouble("durationMs", if (dur == C.TIME_UNSET) 0.0 else dur.toDouble())
    val buffering = p.playbackState == Player.STATE_BUFFERING
    m.putBoolean("buffering", buffering)
    m.putBoolean("playing", p.isPlaying || (p.playWhenReady && buffering))
    emit("topTurboStatus", m)
  }

  private fun emitTracks() {
    fun toArray(type: Int) = Arguments.createArray().also { arr ->
      controller.listTracks(type).forEach { t ->
        val o = Arguments.createMap()
        o.putString("id", t.id); o.putString("label", t.label); o.putString("language", t.language); o.putBoolean("selected", t.selected)
        arr.pushMap(o)
      }
    }
    val m = Arguments.createMap()
    m.putArray("audio", toArray(C.TRACK_TYPE_AUDIO))
    m.putArray("text", toArray(C.TRACK_TYPE_TEXT))
    val textDisabled = controller.player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
    m.putBoolean("textOff", textDisabled || controller.listTracks(C.TRACK_TYPE_TEXT).none { it.selected })
    emit("topTurboTracks", m)
  }

  // ---- lifecycle ---------------------------------------------------------------------------
  override fun onAttachedToWindow() { super.onAttachedToWindow(); main.removeCallbacks(ticker); main.postDelayed(ticker, 1000) }
  override fun onDetachedFromWindow() { main.removeCallbacks(ticker); super.onDetachedFromWindow() }
  fun dispose() { main.removeCallbacksAndMessages(null); controller.release() }

  // React Native does not re-run layout for children added natively: do it ourselves.
  override fun requestLayout() {
    super.requestLayout()
    post(measureAndLayout)
  }
}
