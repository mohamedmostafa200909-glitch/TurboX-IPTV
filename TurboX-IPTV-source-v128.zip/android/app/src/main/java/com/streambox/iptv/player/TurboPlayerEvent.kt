package com.streambox.iptv.player

import com.facebook.react.bridge.WritableMap
import com.facebook.react.uimanager.events.Event

/** Direct event sent from the native player view to JS (onStatus / onTracks / onError). */
class TurboPlayerEvent(
  surfaceId: Int,
  viewId: Int,
  private val name: String,
  private val payload: WritableMap
) : Event<TurboPlayerEvent>(surfaceId, viewId) {
  override fun getEventName(): String = name
  override fun getEventData(): WritableMap? = payload
}
