package com.streambox.iptv.player

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.ReadableArray
import com.facebook.react.modules.core.DeviceEventManagerModule
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URLDecoder
import java.security.SecureRandom
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.URL
import java.net.HttpURLConnection

class TurboPlayerModule(private val reactContext: ReactApplicationContext) : ReactContextBaseJavaModule(reactContext) {
  override fun getName() = "TurboPlayerModule"

  companion object {
    // Read once per player (PlayerController init), not live-switchable on an already-open stream — see the
    // comments there. Settings calls setBufferProfile/setTunnelingEnabled; it takes effect next time a channel or
    // video is opened.
    @Volatile var bufferProfile: String = "fast" // "fast" | "stable"
    @Volatile var tunnelingEnabled: Boolean = false
  }

  // ---------------------------------------------------------------------------------------------
  // Read-only text server: shows a snapshot of text (the error log, or a provider-check report) as a page the
  // phone can open and copy from, on the same pattern as the pairing server above but GET-only and much simpler —
  // no form, no saved credentials, nothing is ever written back to the TV. Used by LogsModal and
  // ProviderCheckModal instead of asking the person to photograph the TV screen.
  // ---------------------------------------------------------------------------------------------
  private var textServer: ServerSocket? = null

  private fun stopTextServerInternal() {
    try { textServer?.close() } catch (_: Exception) { }
    textServer = null
  }

  private fun textPage(title: String, body: String): String {
    val style = "body{font-family:-apple-system,sans-serif;background:#0b0b12;color:#fff;margin:0;padding:16px}" +
      "h2{margin:0 0 14px;font-size:18px}" +
      "pre{white-space:pre-wrap;word-break:break-word;background:#16161f;border:1px solid #2a2a36;border-radius:10px;" +
      "padding:14px;font-size:13px;line-height:1.5;direction:ltr;text-align:left}" +
      "button{position:sticky;top:10px;margin-bottom:12px;padding:12px 18px;border:0;border-radius:10px;" +
      "background:#e11d2e;color:#fff;font-size:15px;font-weight:700}"
    val safeBody = htmlEscape(body)
    val script = "<script>function cp(){var t=document.getElementById('t');" +
      "if(navigator.clipboard){navigator.clipboard.writeText(t.innerText);}else{" +
      "var r=document.createRange();r.selectNode(t);var s=window.getSelection();s.removeAllRanges();s.addRange(r);" +
      "document.execCommand('copy');s.removeAllRanges();}" +
      "var b=document.getElementById('b');b.innerText='Copied';setTimeout(function(){b.innerText='Copy';},1500);}</script>"
    return "<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">" +
      "<title>${htmlEscape(title)}</title><style>$style</style></head><body>" +
      "<h2>${htmlEscape(title)}</h2><button id="b" onclick="cp()">Copy</button><pre id="t">$safeBody</pre>$script</body></html>"
  }

  private fun handleTextRequest(socket: Socket, token: String, title: String, body: String) {
    socket.soTimeout = 5000
    val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
    val requestLine = reader.readLine() ?: return
    val parts = requestLine.split(" ")
    if (parts.size < 2) return
    val path = parts[1].substringBefore("?")
    if (path == "/$token") respond(socket, 200, "OK", textPage(title, body))
    else respond(socket, 404, "Not Found", "<!doctype html><meta charset="utf-8"><body style="font-family:sans-serif">404</body>")
  }

  /** Resolves "http://ip:port/token" showing `text` read-only, or null when there is no LAN address. */
  @ReactMethod
  fun startTextServer(text: String, title: String, promise: Promise) {
    try {
      stopTextServerInternal()
      val ip = localIpv4()
      if (ip == null) { promise.resolve(null); return }
      val ss = ServerSocket(0)
      ss.soTimeout = 1000
      textServer = ss
      val alphabet = "abcdefghjkmnpqrstuvwxyz23456789"
      val rnd = SecureRandom()
      val token = (1..8).map { alphabet[rnd.nextInt(alphabet.length)] }.joinToString("")
      val deadline = System.currentTimeMillis() + 10 * 60 * 1000
      val thread = Thread {
        while (!ss.isClosed && System.currentTimeMillis() < deadline) {
          try {
            val client = ss.accept()
            try { handleTextRequest(client, token, title, text) } catch (_: Exception) { } finally { try { client.close() } catch (_: Exception) { } }
          } catch (_: SocketTimeoutException) {
            // loop again to re-check the deadline
          } catch (_: Exception) {
            break
          }
        }
        try { ss.close() } catch (_: Exception) { }
      }
      thread.isDaemon = true
      thread.start()
      promise.resolve("http://$ip:${ss.localPort}/$token")
    } catch (_: Exception) {
      promise.resolve(null)
    }
  }

  @ReactMethod
  fun stopTextServer() {
    stopTextServerInternal()
  }

  // ---------------------------------------------------------------------------------------------
  // Settings transfer between two TVs on the same network: device A serves its backup JSON raw (for
  // fetch() on device B to consume directly — not a human-readable page), device B's person types the short
  // address shown on A using the on-screen keyboard, since a TV has no camera to scan A's QR itself. Same
  // ServerSocket/token/10-minute-timeout pattern as the servers above, kept separate so export/import and
  // logs/pairing never collide.
  // ---------------------------------------------------------------------------------------------
  private var jsonServer: ServerSocket? = null

  private fun stopJsonServerInternal() {
    try { jsonServer?.close() } catch (_: Exception) { }
    jsonServer = null
  }

  private fun handleJsonRequest(socket: Socket, token: String, json: String) {
    socket.soTimeout = 5000
    val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
    val requestLine = reader.readLine() ?: return
    val parts = requestLine.split(" ")
    if (parts.size < 2) return
    val path = parts[1].substringBefore("?")
    if (path == "/$token") {
      val bytes = json.toByteArray(Charsets.UTF_8)
      val header = "HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
" +
        "Access-Control-Allow-Origin: *
Content-Length: ${bytes.size}
Cache-Control: no-store
Connection: close

"
      val out = socket.getOutputStream()
      out.write(header.toByteArray(Charsets.UTF_8))
      out.write(bytes)
      out.flush()
    } else {
      respond(socket, 404, "Not Found", "")
    }
  }

  /** Resolves "http://ip:port/token", serving `json` raw at that one path, or null with no LAN address. */
  @ReactMethod
  fun startSettingsServer(json: String, promise: Promise) {
    try {
      stopJsonServerInternal()
      val ip = localIpv4()
      if (ip == null) { promise.resolve(null); return }
      val ss = ServerSocket(0)
      ss.soTimeout = 1000
      jsonServer = ss
      val alphabet = "abcdefghjkmnpqrstuvwxyz23456789"
      val rnd = SecureRandom()
      val token = (1..6).map { alphabet[rnd.nextInt(alphabet.length)] }.joinToString("")
      val deadline = System.currentTimeMillis() + 10 * 60 * 1000
      val thread = Thread {
        while (!ss.isClosed && System.currentTimeMillis() < deadline) {
          try {
            val client = ss.accept()
            try { handleJsonRequest(client, token, json) } catch (_: Exception) { } finally { try { client.close() } catch (_: Exception) { } }
          } catch (_: SocketTimeoutException) {
          } catch (_: Exception) {
            break
          }
        }
        try { ss.close() } catch (_: Exception) { }
      }
      thread.isDaemon = true
      thread.start()
      promise.resolve("http://$ip:${ss.localPort}/$token")
    } catch (_: Exception) {
      promise.resolve(null)
    }
  }

  @ReactMethod
  fun stopSettingsServer() {
    stopJsonServerInternal()
  }

  // ---------------------------------------------------------------------------------------------
  // DLNA/UPnP casting — EXPERIMENTAL. This is a from-scratch, minimal UPnP AVTransport client (SSDP discovery +
  // a hand-built SOAP SetAVTransportURI/Play call) with no proper UPnP library and no device to test against here.
  // Real DLNA renderers vary a lot in how strict they are about the SOAP envelope; some reject requests this
  // simple client sends. It also cannot set custom headers (User-Agent etc.) on the renderer's own request to the
  // stream, so a provider that requires one will fail here even though it plays fine on the TV itself.
  // ---------------------------------------------------------------------------------------------
  private val LOCATION_RE = Regex("(?i)LOCATION:\s*(\S+)")
  private val FRIENDLY_RE = Regex("(?is)<friendlyName>(.*?)</friendlyName>")
  private val CONTROL_URL_RE = Regex(
    "(?is)<service>(?:(?!</service>).)*?<serviceType>urn:schemas-upnp-org:service:AVTransport:1</serviceType>(?:(?!</service>).)*?<controlURL>(.*?)</controlURL>(?:(?!</service>).)*?</service>"
  )

  private fun httpGetText(url: String, timeoutMs: Int = 4000): String? = try {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = timeoutMs
    c.readTimeout = timeoutMs
    c.requestMethod = "GET"
    val text = c.inputStream.bufferedReader(Charsets.UTF_8).readText()
    c.disconnect()
    text
  } catch (_: Exception) { null }

  /** Finds DLNA media renderers on the local network for ~2.5s (SSDP M-SEARCH, UDP multicast). */
  @ReactMethod
  fun discoverDlnaRenderers(promise: Promise) {
    Thread {
      val found = Arguments.createArray()
      val seen = HashSet<String>()
      try {
        val socket = DatagramSocket()
        socket.soTimeout = 500
        val group = InetAddress.getByName("239.255.255.250")
        val msg = ("M-SEARCH * HTTP/1.1
HOST: 239.255.255.250:1900
MAN: "ssdp:discover"
MX: 2
" +
          "ST: urn:schemas-upnp-org:device:MediaRenderer:1

").toByteArray(Charsets.UTF_8)
        socket.send(DatagramPacket(msg, msg.size, group, 1900))
        val deadline = System.currentTimeMillis() + 2500
        val buf = ByteArray(2048)
        while (System.currentTimeMillis() < deadline) {
          try {
            val packet = DatagramPacket(buf, buf.size)
            socket.receive(packet)
            val reply = String(packet.data, 0, packet.length, Charsets.UTF_8)
            val location = LOCATION_RE.find(reply)?.groupValues?.get(1)?.trim() ?: continue
            if (!seen.add(location)) continue
            val desc = httpGetText(location) ?: continue
            if (!desc.contains("AVTransport")) continue
            val name = FRIENDLY_RE.find(desc)?.groupValues?.get(1)?.trim()?.ifBlank { null } ?: location
            val item = Arguments.createMap()
            item.putString("name", name)
            item.putString("location", location)
            found.pushMap(item)
          } catch (_: Exception) {
            // one bad reply should not stop the search
          }
        }
        socket.close()
      } catch (_: Exception) { }
      promise.resolve(found)
    }.start()
  }

  /** Sends SetAVTransportURI + Play to the renderer at `location` (one of discoverDlnaRenderers' results). */
  @ReactMethod
  fun castToDlna(location: String, streamUrl: String, title: String, promise: Promise) {
    Thread {
      try {
        val desc = httpGetText(location)
        val controlPath = desc?.let { CONTROL_URL_RE.find(it)?.groupValues?.get(1) }
        if (controlPath == null) { promise.resolve(false); return@Thread }
        val base = URL(location)
        val controlUrl = if (controlPath.startsWith("http")) controlPath else URL(base, controlPath).toString()
        val escapedStream = streamUrl.replace("&", "&amp;")
        val metaTitle = title.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        val didl = "&lt;DIDL-Lite xmlns="urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/" " +
          "xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:upnp="urn:schemas-upnp-org:metadata-1-0/upnp/"&gt;" +
          "&lt;item id="0" parentID="0" restricted="1"&gt;&lt;dc:title&gt;$metaTitle&lt;/dc:title&gt;" +
          "&lt;upnp:class&gt;object.item.videoItem&lt;/upnp:class&gt;&lt;/item&gt;&lt;/DIDL-Lite&gt;"
        fun soap(action: String, body: String): Boolean {
          val envelope = "<?xml version="1.0"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" " +
            "s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body>" +
            "<u:$action xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">$body</u:$action></s:Body></s:Envelope>"
          return try {
            val c = URL(controlUrl).openConnection() as HttpURLConnection
            c.connectTimeout = 5000
            c.readTimeout = 5000
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "text/xml; charset="utf-8"")
            c.setRequestProperty("SOAPACTION", ""urn:schemas-upnp-org:service:AVTransport:1#$action"")
            c.outputStream.use { it.write(envelope.toByteArray(Charsets.UTF_8)) }
            val ok = c.responseCode in 200..299
            c.disconnect()
            ok
          } catch (_: Exception) { false }
        }
        val setUri = soap("SetAVTransportURI", "<InstanceID>0</InstanceID><CurrentURI>$escapedStream</CurrentURI><CurrentURIMetaData>$didl</CurrentURIMetaData>")
        val play = if (setUri) soap("Play", "<InstanceID>0</InstanceID><Speed>1</Speed>") else false
        promise.resolve(setUri && play)
      } catch (_: Exception) {
        promise.resolve(false)
      }
    }.start()
  }

  /** "fast" (default, quick channel zapping) or "stable" (fewer stalls on weak connections). */
  @ReactMethod
  fun setBufferProfile(profile: String) {
    bufferProfile = if (profile == "stable") "stable" else "fast"
  }

  @ReactMethod
  fun setTunnelingEnabled(enabled: Boolean) {
    tunnelingEnabled = enabled
  }

  /**
   * true when this device has an app that can pick a file (system DocumentsUI or a file manager).
   * Many TV boxes have none: launching the picker there throws ActivityNotFoundException inside
   * the native picker and kills the whole app, so JS checks this first.
   */
  @ReactMethod
  fun canPickFile(promise: Promise) {
    try {
      val pm = reactContext.packageManager
      val open = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
      val get = Intent(Intent.ACTION_GET_CONTENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
      promise.resolve(open.resolveActivity(pm) != null || get.resolveActivity(pm) != null)
    } catch (e: Exception) {
      promise.resolve(false)
    }
  }

  /**
   * Open a stream in an external player. `packages` is a comma separated list tried in order
   * (empty = system chooser). `headers` is a flat [key, value, key, value...] array (used by MX Player).
   * Resolves true when an app was launched, false otherwise so JS can fall back to the built-in player.
   */
  @ReactMethod
  fun openExternalPlayer(url: String, title: String, packages: String, headers: ReadableArray, promise: Promise) {
    try {
      val pkgs = packages.split(",").map { it.trim() }.filter { it.isNotEmpty() }
      val hdr = ArrayList<String>()
      for (i in 0 until headers.size()) hdr.add(headers.getString(i) ?: "")
      fun build(pkg: String?): Intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(Uri.parse(url), "video/*")
        putExtra("title", title)
        if (hdr.isNotEmpty()) putExtra("headers", hdr.toTypedArray())
        if (pkg != null) setPackage(pkg)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      if (pkgs.isEmpty()) {
        val chooser = Intent.createChooser(build(null), title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        reactContext.startActivity(chooser)
        promise.resolve(true)
        return
      }
      for (pkg in pkgs) {
        try {
          reactContext.startActivity(build(pkg))
          promise.resolve(true)
          return
        } catch (_: ActivityNotFoundException) {
          // try the next package
        }
      }
      promise.resolve(false)
    } catch (_: Exception) {
      promise.resolve(false)
    }
  }

  @ReactMethod
  fun openExternalVlc(url: String) {
    try {
      val intent = Intent(Intent.ACTION_VIEW).apply {
        setPackage("org.videolan.vlc")
        setDataAndType(Uri.parse(url), "video/*")
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      reactContext.startActivity(intent)
    } catch (_: ActivityNotFoundException) {
      reactContext.currentActivity?.runOnUiThread {
        android.widget.Toast.makeText(reactContext, "VLC غير مثبت على الجهاز", android.widget.Toast.LENGTH_LONG).show()
      }
    } catch (_: Exception) {
      reactContext.currentActivity?.runOnUiThread {
        android.widget.Toast.makeText(reactContext, "تعذر فتح VLC الخارجي", android.widget.Toast.LENGTH_LONG).show()
      }
    }
  }

  // ---------------------------------------------------------------------------------------------
  // Phone pairing: a tiny HTTP server on the TV's LAN address. The TV shows a QR code with
  // http://<ip>:<port>/<token>; the phone opens it, fills in the provider details and posts them
  // back, and JS receives them as the "TurboPairData" event. Runs only while the pairing screen is
  // open (stopPairServer) and stops by itself after 10 minutes. Requests without the token get 404.
  // ---------------------------------------------------------------------------------------------
  private var pairServer: ServerSocket? = null

  private fun localIpv4(): String? {
    try {
      var fallback: String? = null
      val ifaces = NetworkInterface.getNetworkInterfaces() ?: return null
      for (ni in ifaces) {
        if (!ni.isUp || ni.isLoopback) continue
        for (addr in ni.inetAddresses) {
          if (addr is Inet4Address && !addr.isLoopbackAddress && addr.isSiteLocalAddress) {
            val name = ni.name ?: ""
            if (name.startsWith("wlan") || name.startsWith("eth")) return addr.hostAddress
            if (fallback == null) fallback = addr.hostAddress
          }
        }
      }
      return fallback
    } catch (_: Exception) {
      return null
    }
  }

  private fun stopPairInternal() {
    try { pairServer?.close() } catch (_: Exception) { }
    pairServer = null
  }

  private fun htmlEscape(v: String): String =
    v.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

  private fun pairPage(token: String, done: Boolean): String {
    val style = "body{font-family:sans-serif;background:#0b0b12;color:#fff;margin:0;padding:20px;max-width:480px;margin:auto}" +
      "h2{margin:8px 0 18px}label{display:block;margin:14px 0 6px;color:#9a9ab0;font-size:14px}" +
      "input{width:100%;box-sizing:border-box;padding:14px;border-radius:10px;border:1px solid #333;background:#16161f;color:#fff;font-size:17px}" +
      "button{width:100%;margin-top:22px;padding:15px;border:0;border-radius:12px;background:#e11d2e;color:#fff;font-size:18px;font-weight:700}" +
      ".ok{background:#12301f;border:1px solid #1f6b3d;padding:16px;border-radius:12px;margin-bottom:16px}"
    val head = "<!doctype html><html dir=\"rtl\" lang=\"ar\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>TurboX</title><style>$style</style></head><body>"
    val banner = if (done) "<div class=\"ok\">&#10003; تم الإرسال. تابع على التلفزيون.</div>" else ""
    val form = "<h2>TurboX IPTV</h2>$banner<form method=\"post\" action=\"/$token/save\" autocomplete=\"off\">" +
      "<label>اسم المصدر</label><input name=\"name\" placeholder=\"قائمتي\">" +
      "<label>السيرفر (Xtream) أو رابط M3U</label><input name=\"server\" inputmode=\"url\" autocapitalize=\"none\" placeholder=\"http://example.com:8080\">" +
      "<label>اسم المستخدم</label><input name=\"username\" autocapitalize=\"none\" autocomplete=\"off\">" +
      "<label>كلمة المرور</label><input name=\"password\" type=\"password\" autocomplete=\"off\">" +
      "<button type=\"submit\">إرسال إلى التلفزيون</button></form></body></html>"
    return head + form
  }

  private fun respond(socket: Socket, code: Int, status: String, html: String) {
    val bytes = html.toByteArray(Charsets.UTF_8)
    val header = "HTTP/1.1 $code $status\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: ${bytes.size}\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n"
    val out = socket.getOutputStream()
    out.write(header.toByteArray(Charsets.UTF_8))
    out.write(bytes)
    out.flush()
  }

  private fun handlePair(socket: Socket, token: String) {
    socket.soTimeout = 5000
    val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
    val requestLine = reader.readLine() ?: return
    val parts = requestLine.split(" ")
    if (parts.size < 2) return
    val method = parts[0]
    val path = parts[1].substringBefore("?")
    var contentLength = 0
    while (true) {
      val line = reader.readLine() ?: break
      if (line.isEmpty()) break
      if (line.lowercase().startsWith("content-length:")) contentLength = line.substringAfter(":").trim().toIntOrNull() ?: 0
    }
    if (path == "/$token" && method == "GET") {
      respond(socket, 200, "OK", pairPage(token, false))
    } else if (path == "/$token/save" && method == "POST" && contentLength in 1..4096) {
      val buf = CharArray(contentLength)
      var read = 0
      while (read < contentLength) {
        val n = reader.read(buf, read, contentLength - read)
        if (n < 0) break
        read += n
      }
      val fields = HashMap<String, String>()
      for (pair in String(buf, 0, read).split("&")) {
        val k = pair.substringBefore("=")
        val v = pair.substringAfter("=", "")
        fields[URLDecoder.decode(k, "UTF-8")] = URLDecoder.decode(v, "UTF-8").trim()
      }
      val map = Arguments.createMap()
      for (key in listOf("name", "server", "username", "password")) map.putString(key, fields[key] ?: "")
      reactContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java).emit("TurboPairData", map)
      respond(socket, 200, "OK", pairPage(token, true))
    } else {
      respond(socket, 404, "Not Found", "<!doctype html><meta charset=\"utf-8\"><body style=\"font-family:sans-serif\">404</body>")
    }
  }

  /** Resolves "http://ip:port/token" for the QR code, or null when there is no LAN address. */
  @ReactMethod
  fun startPairServer(promise: Promise) {
    try {
      stopPairInternal()
      val ip = localIpv4()
      if (ip == null) { promise.resolve(null); return }
      val ss = ServerSocket(0)
      ss.soTimeout = 1000
      pairServer = ss
      val alphabet = "abcdefghjkmnpqrstuvwxyz23456789"
      val rnd = SecureRandom()
      val token = (1..8).map { alphabet[rnd.nextInt(alphabet.length)] }.joinToString("")
      val deadline = System.currentTimeMillis() + 10 * 60 * 1000
      val thread = Thread {
        while (!ss.isClosed && System.currentTimeMillis() < deadline) {
          try {
            val client = ss.accept()
            try { handlePair(client, token) } catch (_: Exception) { } finally { try { client.close() } catch (_: Exception) { } }
          } catch (_: SocketTimeoutException) {
            // loop again to re-check the deadline
          } catch (_: Exception) {
            break
          }
        }
        try { ss.close() } catch (_: Exception) { }
      }
      thread.isDaemon = true
      thread.start()
      promise.resolve("http://$ip:${ss.localPort}/$token")
    } catch (_: Exception) {
      promise.resolve(null)
    }
  }

  @ReactMethod
  fun stopPairServer() {
    stopPairInternal()
  }

  // required by NativeEventEmitter consumers; JS uses DeviceEventEmitter so these are no-ops
  @ReactMethod
  fun addListener(eventName: String) { }

  @ReactMethod
  fun removeListeners(count: Int) { }
}
