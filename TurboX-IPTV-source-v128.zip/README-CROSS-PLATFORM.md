# StreamBox IPTV — Cross-platform source

React Native + Expo IPTV media player for user-owned IPTV sources. The app does not ship channels or copyrighted media.

## Supported source types

- Xtream Codes API: server URL, username, password.
- Remote M3U/M3U8 URL.
- Local M3U file selected through the system document picker.
- Multiple saved providers and profile-specific favorites.

## Main sections

- Live TV: source-specific categories, search, favorites, player and EPG entry point.
- Movies: source-specific category folders, full returned VOD list, search and playback.
- Series: source-specific category folders, seasons/episodes through `get_series_info`, search and playback.
- EPG: seven-day UI surface, ready for XMLTV data from a provider.

## Local database

`src/storage/database.ts` initializes `streambox.db` with SQLite WAL mode and these tables:

- `preferences`
- `providers`
- `favorites`
- `watch_progress`

The existing UI remains backward compatible with AsyncStorage while the SQLite layer provides the durable storage API for migration and large-library caching.

## Large playlists

`src/playlists/m3uParser.ts` parses M3U text in batches and yields to the React event loop between batches. This prevents a 10,000+ item playlist from blocking the UI during parsing. Production deployments should persist parsed items to SQLite and render virtualized lists.

## Run

```bash
npm install
npx expo start
```

- Android: `npx expo run:android`
- iOS: `npx expo run:ios` (requires macOS/Xcode)
- Web: `npx expo start --web`

## Native player capabilities

Android uses Expo AV backed by the native Android player. iOS uses the native iOS player when built with Xcode. PiP, background playback, hardware decoder behavior, subtitle tracks, and aspect-ratio controls must be verified and configured per platform build; they are not guaranteed by the browser target.

## TV compatibility

The app has a TV layout mode with larger spacing and controls. Android TV/Google TV/Fire TV support requires a TV-compatible native build and D-pad focus testing. Web/Smart TV browsers use the web target and cannot expose native ExoPlayer/AVPlayer APIs.

## Security and legal scope

Credentials are user-provided. Do not hard-code provider credentials, distribute playlists, or include third-party streams. For production, use OS secure storage for passwords instead of plain local preferences and consider encrypting the SQLite database.
