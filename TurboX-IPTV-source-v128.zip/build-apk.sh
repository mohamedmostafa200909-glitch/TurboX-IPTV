#!/usr/bin/env bash
# بناء APK محليًا. المتطلبات: Node 20+، JDK 21، Android SDK (ANDROID_HOME).
set -euo pipefail
npm install --no-audit --no-fund
chmod +x android/gradlew
./android/gradlew -p android assembleRelease --no-daemon --console=plain
echo
echo "تم البناء: android/app/build/outputs/apk/release/app-release.apk"
