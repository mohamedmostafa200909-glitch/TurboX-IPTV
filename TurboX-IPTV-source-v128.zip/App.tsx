import AppErrorBoundary from './src/components/AppErrorBoundary';
import TurboXApp from './src/TurboXApp';

export default function App() {
  return <AppErrorBoundary><TurboXApp /></AppErrorBoundary>;
}
