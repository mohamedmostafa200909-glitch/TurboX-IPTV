import { StyleSheet } from 'react-native';
import { bg, card } from './theme';

export const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: bg
  },
  app: {
    flex: 1,
    backgroundColor: bg
  },
  header: {
    height: 70,
    paddingHorizontal: 18,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 9,
    borderBottomWidth: 1,
    borderBottomColor: '#24262f'
  },
  logo: {
    width: 36,
    height: 36,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center'
  },
  logoSub: {
    fontSize: 7,
    color: '#777985',
    letterSpacing: 1
  },
  headerBack: {
    width: 42,
    height: 42,
    alignItems: 'center',
    justifyContent: 'center'
  },
  headerTitleBox: {
    flex: 1,
    alignItems: 'center'
  },
  headerTitle: {
    color: '#fff',
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: 1
  },
  headerUser: {
    marginLeft: 'auto',
    width: 32,
    height: 32,
    borderRadius: 18,
    backgroundColor: '#b86670',
    alignItems: 'center',
    justifyContent: 'center'
  },
  avatarText: {
    fontWeight: '800',
    color: '#25181a'
  },
  content: {
    flex: 1,
    paddingHorizontal: 18
  },
  tvContent: {
    paddingHorizontal: 32
  },
  primary: {
    borderRadius: 8,
    paddingHorizontal: 17,
    paddingVertical: 12,
    alignSelf: 'flex-start',
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center'
  },
  primaryText: {
    color: '#28191a',
    fontWeight: '800',
    fontSize: 12
  },
  sectionTitle: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 14
  },
  title: {
    color: '#f1efed',
    fontSize: 20,
    fontWeight: '800'
  },
  action: {
    fontSize: 11
  },
  provider: {
    backgroundColor: card,
    borderColor: '#2b2d36',
    borderWidth: 1,
    borderRadius: 10,
    padding: 11,
    marginBottom: 9,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 10
  },
  providerIcon: {
    width: 38,
    height: 38,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center'
  },
  channelName: {
    color: '#eeeae6',
    fontSize: 12,
    fontWeight: '700',
    textAlign: 'right'
  },
  channelSub: {
    color: '#858691',
    fontSize: 10,
    marginTop: 3,
    textAlign: 'right'
  },
  connected: {
    paddingHorizontal: 8,
    paddingVertical: 5,
    borderRadius: 9
  },
  epgButton: {
    alignSelf: 'flex-end',
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 6,
    borderWidth: 1,
    borderColor: '#343640',
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 7,
    marginBottom: 10
  },
  epgRow: {
    backgroundColor: card,
    borderRadius: 8,
    padding: 10,
    marginBottom: 6,
    flexDirection: 'row-reverse',
    gap: 10
  },
  epgTime: {
    color: '#888',
    fontSize: 10,
    width: 45
  },
  epgProgram: {
    color: '#eee',
    fontSize: 11,
    flex: 1,
    textAlign: 'right'
  },
  input: {
    flex: 1,
    color: '#eee',
    fontSize: 12,
    textAlign: 'right'
  },
  channel: {
    backgroundColor: card,
    borderColor: '#292b34',
    borderWidth: 1,
    borderRadius: 10,
    padding: 11,
    marginBottom: 9,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 10
  },
  channelLogo: {
    width: 45,
    height: 45,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden'
  },
  channelLogoImg: {
    width: 45,
    height: 45
  },
  empty: {
    padding: 32,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#343640',
    borderStyle: 'dashed',
    alignItems: 'center',
    marginTop: 8
  },
  emptyText: {
    color: '#aaa',
    fontSize: 13,
    marginVertical: 8
  },
  setting: {
    backgroundColor: card,
    borderRadius: 10,
    padding: 14,
    marginBottom: 9,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 12
  },
  settingsLabel: {
    color: '#9a9ba5',
    fontSize: 12,
    textAlign: 'right',
    marginTop: 15,
    marginBottom: 10
  },
  themeRow: {
    flexDirection: 'row-reverse',
    gap: 14,
    marginBottom: 18
  },
  episodeRow: {
    backgroundColor: card,
    borderRadius: 9,
    padding: 12,
    marginBottom: 7,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 10
  },
  episodeText: {
    color: '#eee',
    fontSize: 12,
    flex: 1,
    textAlign: 'right'
  },
  episodeDuration: {
    color: '#918ea7',
    fontSize: 10
  },
  seriesDetailScreen: {
    flex: 1,
    backgroundColor: '#0b0b12'
  },
  seriesDetailTop: {
    height: 72,
    paddingHorizontal: 22,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: '#27272d'
  },
  seriesDetailTitle: {
    color: '#fff',
    fontSize: 21,
    fontWeight: '800',
    flex: 1,
    textAlign: 'center'
  },
  seriesDetailBody: {
    padding: 24,
    paddingBottom: 50
  },
  seriesInfoRow: {
    flexDirection: 'row',
    gap: 24
  },
  seriesDetailPoster: {
    width: 190,
    height: 280,
    borderRadius: 8,
    backgroundColor: '#1f1e23',
    alignItems: 'center',
    justifyContent: 'center',
    resizeMode: 'contain'
  },
  seriesMeta: {
    flex: 1,
    justifyContent: 'space-around'
  },
  seriesMetaLine: {
    color: '#eee',
    fontSize: 17
  },
  seriesMetaLabel: {
    fontWeight: '800'
  },
  seriesPlot: {
    color: '#b8b9c6',
    fontSize: 14,
    lineHeight: 22,
    marginTop: 10
  },
  seriesActionRow: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 22
  },
  seriesAction: {
    minHeight: 52,
    paddingHorizontal: 20,
    borderRadius: 8,
    backgroundColor: '#242530',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8
  },
  seriesActionText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '700'
  },
  seasonPicker: {
    marginBottom: 16
  },
  seasonChip: {
    paddingHorizontal: 18,
    paddingVertical: 11,
    borderRadius: 7,
    backgroundColor: '#242530',
    marginRight: 9
  },
  seasonChipText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '700'
  },
  episodesTitle: {
    color: '#fff',
    fontSize: 19,
    fontWeight: '800',
    marginBottom: 10
  },
  aboutText: {
    color: '#c5c5ca',
    fontSize: 13,
    lineHeight: 23,
    textAlign: 'right',
    marginTop: 12
  },
  themeDot: {
    width: 34,
    height: 34,
    borderRadius: 18,
    borderWidth: 3
  },
  bottom: {
    height: 72,
    borderTopWidth: 1,
    borderTopColor: '#292b34',
    backgroundColor: '#111218',
    flexDirection: 'row-reverse',
    justifyContent: 'space-around',
    alignItems: 'center'
  },
  modalBg: {
    flex: 1,
    backgroundColor: '#000b',
    justifyContent: 'flex-end'
  },
  modal: {
    backgroundColor: '#1a1b23',
    borderTopLeftRadius: 22,
    borderTopRightRadius: 22,
    padding: 24,
    paddingBottom: 34
  },
  close: {
    position: 'absolute',
    left: 18,
    top: 18
  },
  modalTitle: {
    color: '#f5f3ef',
    fontSize: 21,
    fontWeight: '800',
    marginTop: 15,
    textAlign: 'right'
  },
  modalSub: {
    color: '#92939d',
    fontSize: 11,
    marginTop: 4,
    marginBottom: 16,
    textAlign: 'right'
  },
  field: {
    backgroundColor: '#24252d',
    borderWidth: 1,
    borderColor: '#33353e',
    borderRadius: 9,
    color: '#eee',
    height: 45,
    paddingHorizontal: 13,
    marginBottom: 9,
    textAlign: 'right',
    fontSize: 12
  },
  choiceBg: {
    flex: 1,
    backgroundColor: '#000d',
    justifyContent: 'center',
    padding: 20
  },
  choiceCard: {
    backgroundColor: '#1a1b23',
    borderRadius: 20,
    padding: 22,
    alignItems: 'center'
  },
  choiceTitle: {
    color: '#f5f3ef',
    fontSize: 22,
    fontWeight: '800',
    marginTop: 14,
    textAlign: 'center'
  },
  choiceSub: {
    color: '#999aa4',
    fontSize: 12,
    textAlign: 'center',
    marginTop: 8,
    marginBottom: 20
  },
  modeRow: {
    flexDirection: 'row',
    gap: 10,
    width: '100%',
    marginBottom: 18
  },
  modeCard: {
    flex: 1,
    minHeight: 132,
    borderWidth: 1,
    borderColor: '#343640',
    borderRadius: 13,
    padding: 12,
    alignItems: 'center',
    justifyContent: 'center'
  },
  modeText: {
    color: '#eee',
    fontWeight: '800',
    fontSize: 15,
    marginTop: 7
  },
  modeSub: {
    color: '#888995',
    fontSize: 9,
    textAlign: 'center',
    marginTop: 5
  },
  multiViewScreen: {
    flex: 1,
    backgroundColor: '#0b0b12'
  },
  multiHeader: {
    position: 'absolute',
    top: 18,
    left: 16,
    right: 16,
    zIndex: 5,
    height: 48,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  multiGrid: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    padding: 6,
    gap: 6
  },
  multiCell: {
    width: '49%',
    height: '49%',
    backgroundColor: '#000',
    borderWidth: 1,
    borderColor: '#35343d',
    borderRadius: 6,
    overflow: 'hidden'
  },
  multiVideo: {
    width: '100%',
    height: '100%'
  },
  multiTitle: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    color: '#fff',
    backgroundColor: '#000b',
    fontSize: 10,
    padding: 5,
    textAlign: 'right'
  },
  multiNote: {
    color: '#a8a9b8',
    fontSize: 11,
    textAlign: 'center',
    paddingHorizontal: 24,
    paddingTop: 72,
    paddingBottom: 8
  },
  multiPicker: {
    flex: 1,
    marginTop: 0,
    paddingHorizontal: 15
  },
  multiPickerRow: {
    minHeight: 54,
    borderWidth: 1,
    borderColor: '#373640',
    borderRadius: 9,
    marginBottom: 8,
    padding: 12,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 10
  },
  playerScreen: {
    flex: 1,
    backgroundColor: '#000'
  },
  playerTop: {
    position: 'absolute',
    top: 18,
    left: 16,
    right: 16,
    zIndex: 5,
    height: 54,
    paddingHorizontal: 4,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  playerTitle: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '700',
    flex: 1,
    textAlign: 'right',
    marginRight: 10
  },
  playerStatus: {
    color: '#d6d8df',
    fontSize: 9
  },
  playerOverlayText: {
    flex: 1,
    marginLeft: 12,
    backgroundColor: '#0008',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 8
  },
  video: {
    flex: 1,
    width: '100%',
    height: '100%',
    backgroundColor: '#000'
  },
  epgEmpty: {
    padding: 28,
    alignItems: 'center',
    justifyContent: 'center'
  },
  epgSearch: {
    height: 40,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#343640',
    backgroundColor: '#24252d',
    flexDirection: 'row-reverse',
    alignItems: 'center',
    paddingHorizontal: 10,
    gap: 7,
    marginBottom: 10
  },
  tileGlow: {
    position: 'absolute',
    top: 22,
    width: 190,
    height: 190,
    borderRadius: 95,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center'
  },
  tileLabel: {
    fontSize: 31,
    fontWeight: '900',
    letterSpacing: 1,
    textShadowColor: '#0b0b12',
    textShadowRadius: 8
  },
  catalogLoadingOverlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    backgroundColor: '#000b',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 20
  },
  catalogLoadingCard: {
    width: 330,
    borderRadius: 16,
    backgroundColor: '#1a1d25',
    padding: 24,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#8a1520'
  },
  catalogLoadingTitle: {
    color: '#fff',
    fontSize: 17,
    fontWeight: '800',
    marginTop: 14,
    textAlign: 'center'
  },
  catalogLoadingSub: {
    color: '#a8a9b8',
    fontSize: 11,
    marginTop: 8,
    textAlign: 'center'
  },
  outerScroll: {
    flex: 1
  },
  catalogHost: {
    flex: 1
  },
  catalogContent: {
    paddingHorizontal: 0
  },
  catalogScreen: {
    flex: 1,
    flexDirection: 'row',
    minHeight: 560,
    backgroundColor: '#050608',
    marginHorizontal: 0
  },
  catalogSide: {
    width: 300,
    backgroundColor: '#050608',
    paddingTop: 8,
    borderRightWidth: 1,
    borderRightColor: '#16191e'
  },
  catalogBrand: {
    height: 76,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    paddingHorizontal: 12
  },
  catalogBrandText: {
    color: '#fff',
    fontSize: 21,
    fontWeight: '800'
  },
  catalogSideSearch: {
    height: 53,
    marginHorizontal: 10,
    backgroundColor: '#1c1c1f',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    gap: 9
  },
  catalogSearchInput: {
    flex: 1,
    color: '#fff',
    fontSize: 14,
    textAlign: 'left'
  },
  catalogQuick: {
    height: 63,
    borderBottomWidth: 1,
    borderBottomColor: '#1b1d22',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    gap: 10
  },
  catalogQuickText: {
    color: '#f4f4f4',
    fontSize: 15,
    flex: 1
  },
  catalogQuickCount: {
    color: '#fff',
    fontSize: 15
  },
  catalogCategories: {
    flex: 1
  },
  catalogCategory: {
    minHeight: 52,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  catalogCategoryText: {
    color: '#f4f4f4',
    fontSize: 15,
    flex: 1
  },
  catalogCategoryCount: {
    color: '#d7d7d7',
    fontSize: 14
  },
  catalogMain: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 10
  },
  catalogHeader: {
    height: 66,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  catalogTitle: {
    color: '#fff',
    fontSize: 25,
    fontWeight: '800',
    textTransform: 'uppercase'
  },
  catalogHeaderActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 24
  },
  posterGrid: {
    paddingBottom: 26,
    paddingTop: 4
  },
  posterRow: {
    gap: 14,
    alignItems: 'flex-start',
    marginBottom: 12
  },
  mediaCard: {
    width: 150,
    marginBottom: 15
  },
  mediaPoster: {
    height: 215,
    borderRadius: 4,
    backgroundColor: '#1f1f24',
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative'
  },
  mediaPosterImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain',
    backgroundColor: '#16161a'
  },
  mediaBadge: {
    position: 'absolute',
    bottom: 6,
    left: 6,
    backgroundColor: '#000b',
    paddingHorizontal: 5,
    paddingVertical: 2
  },
  mediaBadgeText: {
    color: '#fff',
    fontSize: 8,
    fontWeight: '800'
  },
  mediaStar: {
    position: 'absolute',
    top: 6,
    right: 6,
    width: 29,
    height: 29,
    borderRadius: 15,
    backgroundColor: '#0009',
    alignItems: 'center',
    justifyContent: 'center'
  },
  mediaCardTitle: {
    color: '#f4f4f4',
    fontSize: 12,
    fontWeight: '700',
    marginTop: 6,
    textAlign: 'right'
  },
  mediaCardMeta: {
    color: '#9c9fa8',
    fontSize: 10,
    marginTop: 2,
    textAlign: 'right'
  }
});
