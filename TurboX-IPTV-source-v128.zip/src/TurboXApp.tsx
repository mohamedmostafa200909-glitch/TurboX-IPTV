import { useCallback, useDeferredValue, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Alert, BackHandler, FlatList, Image, InteractionManager, Linking, Platform, SafeAreaView, Share, ScrollView, StatusBar, Text, TextInput, View, useWindowDimensions, NativeModules, DeviceEventEmitter, I18nManager} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';
import { ResizeMode, Video } from 'expo-av';
import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system';
import NetInfo from '@react-native-community/netinfo';
import { initializeDatabase } from './storage/database';
import { fetchXmltv, normName, parseXmltv, Listing as XmltvListing } from './epg/xmltv';
import { deleteSecret, persistProviders, restoreProviders } from './storage/secureProviders';
import { cacheGet, cacheRemove, cacheSet } from './storage/cacheStore';
import { readHeavy, readSnapshot, removeSnapshot, writeSnapshot, Snapshot, Counts } from './storage/catalogCache';
import { IptvError, describeError, kindFromHttp, kindFromPayload } from './network/errors';
import { describePlaybackError } from './network/playbackErrors';
import { logError, logInfo, logWarn, installGlobalErrorLogging } from './utils/logger';
import { isCacheFresh, slimList } from './utils/catalog';
import { DEFAULT_LIST_ID, FavList, favItemsKey, favListsKey, normalizeLists } from './utils/favLists';
import { LAST_LIVE_KEY, STARTUP_KEY, StartupMode, lastLiveValue, parseLastLive, parseStartup } from './utils/startup';
import { isAdultCategory } from './utils/adult';
import { timeshiftUrl } from './utils/timeshift';
import { mapLimit } from './utils/mapLimit';
import { formatLogs, LogEntry } from './utils/logFormat';
import { clearLogs, getLogs } from './utils/logger';
import ProfilesModal from './components/ProfilesModal';
import MovieDetails from './components/MovieDetails';
import EpgTimeline, { Prog } from './components/EpgTimeline';
import LogsModal from './components/LogsModal';
import FavListsBar from './components/FavListsBar';

const hhmm = (sec: number) => { const d = new Date(sec * 1000); return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
import { decodeEpgText } from './utils/epgText';
import { loadPin, savePin } from './storage/securePin';
import PlayerControls, { PlayerButtonId } from './components/PlayerControls';
import { ChannelPanel, AutoNextCard, ErrorCard } from './components/PlayerOverlays';
import SearchOverlay from './components/SearchOverlay';
import Screensaver, { ScreensaverMinutes } from './components/Screensaver';
import ProviderCheckModal from './components/ProviderCheckModal';
import TextServerModal from './components/TextServerModal';
import BackupModal, { BACKUP_VERSION } from './components/BackupModal';
import CastModal from './components/CastModal';
import { checkForUpdate, UpdateInfo } from './network/updateCheck';
import appJson from '../app.json';
import { createGovernor } from './network/governor';
import { uaFor } from './network/userAgent';
import LiveTVScreen, { LiveCat } from './components/LiveTVScreen';
import VodScreen from './components/VodScreen';
import TrackMenu, { TrackRow } from './components/TrackMenu';
import AccountModal from './components/AccountModal';
import PlayerPicker, { PLAYER_OPTIONS, PlayerEngine } from './components/PlayerPicker';
import AutomationSettings from './components/AutomationSettings';
import ChoiceModal from './components/ChoiceModal';
import RemoteGuide from './components/RemoteGuide';
import HiddenCategories, { CatTab } from './components/HiddenCategories';
import { Automation, DEFAULT_AUTOMATION, loadAutomation, saveAutomation } from './storage/automation';
import { AccountInfo, accountInfoFromPayload, fetchAccountInfo, m3uAccountInfo } from './network/accountInfo';
import SplashScreen from './components/SplashScreen';
import LoginScreen from './components/LoginScreen';
import { HomeTopBar, HomeBody, HomeRowData } from './components/HomeDashboard';
import { TVPressable as Pressable, TVModeContext, TVScope, TVScrollView, TVTextInput, tvEngine, useTVScroller } from './tv/focus';
import type { Provider, Media, ThemeName } from './types';
import { bg, card, themeAccents } from './theme';
import { mediaId, channelKey, normalizeServer, isM3u, isM3uProvider, serverCandidates } from './utils/media';
import { xtream, loadM3u } from './network/sources';
import { NativeTurboPlayerView } from './native/turboPlayer';
import { Modal } from './components/TVModal';
import { SectionTitle, MediaRow, MediaCard, Empty, Setting, StarFocusContext, CategoryRow } from './components/ListParts';
import { styles } from './styles';

const SCREENSAVER_LABELS: Record<ScreensaverMinutes, [string, string]> = {
  0: ['متوقفة', 'Off'],
  5: ['بعد 5 دقائق', 'After 5 minutes'],
  10: ['بعد 10 دقائق', 'After 10 minutes'],
  30: ['بعد 30 دقيقة', 'After 30 minutes'],
};
/** 2-letter prefixes matched against ExoPlayer's raw (often 3-letter) track language via startsWith. */
const LANG_PREF_OPTIONS: Array<{ id: string; label: [string, string] }> = [
  { id: '', label: ['بدون تفضيل (يدوي)', 'No preference (manual)'] },
  { id: 'ar', label: ['العربية', 'Arabic'] },
  { id: 'en', label: ['الإنجليزية', 'English'] },
  { id: 'fr', label: ['الفرنسية', 'French'] },
  { id: 'es', label: ['الإسبانية', 'Spanish'] },
  { id: 'tr', label: ['التركية', 'Turkish'] },
];
const SUB_PREF_OPTIONS: Array<{ id: string; label: [string, string] }> = [
  { id: '', label: ['بدون تفضيل (يدوي)', 'No preference (manual)'] },
  { id: 'off', label: ['إيقاف تلقائي', 'Auto-off'] },
  { id: 'ar', label: ['العربية', 'Arabic'] },
  { id: 'en', label: ['الإنجليزية', 'English'] },
  { id: 'fr', label: ['الفرنسية', 'French'] },
  { id: 'es', label: ['الإسبانية', 'Spanish'] },
];
const THEME_LABELS: Record<ThemeName, [string, string]> = {
  turbo: ['توربو (أحمر)', 'Turbo (red)'],
  ember: ['إمبر (وردي)', 'Ember (pink)'],
  ocean: ['أوشن (أزرق)', 'Ocean (blue)'],
  violet: ['فيوليت (بنفسجي)', 'Violet (purple)'],
  green: ['أخضر', 'Green'],
};

/** moment the JS bundle started running: startup timings in the logs are relative to it */
const APP_T0 = Date.now();
/** shared by every guide/details request: pauses a provider kind that keeps failing (see network/governor.ts) */
const gov = createGovernor();
const sleepMs = (ms: number) => new Promise<void>(resolve => setTimeout(resolve, ms));
export default function TurboXApp() {
  const {
    width: screenWidth,
    height: screenHeight
  } = useWindowDimensions();
  const [deviceMode, setDeviceMode] = useState<'tv' | 'mobile' | null>(null);
  const [splashDone, setSplashDone] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const videoRef = useRef<Video>(null);
  const [storageDirectory, setStorageDirectory] = useState<string | null>(null); // was used but never declared
  // XMLTV guide for M3U sources: guide URL per provider (from the playlist header) and programmes per channel key.
  const xmltvUrls = useRef<Record<string, string | null>>({});
  const xmltvData = useRef<Record<string, XmltvListing[]>>({});
  const [overlayOn, setOverlayOn] = useState(false);
  const overlayTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const flashTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const playStatus = useRef({pos: 0, dur: 0, playing: true});
  const [playClock, setPlayClock] = useState({pos: 0, dur: 0, playing: true});
  const [seekFlash, setSeekFlash] = useState<string | null>(null);
  // YouTube-style player controls: focus 0 = scrubber, 1..n = button row; scrubTo = pending (uncommitted) seek target
  const [ctl, setCtlState] = useState<{focus: number; scrubTo: number | null}>({focus: 0, scrubTo: null});
  const ctlRef = useRef({focus: 0, scrubTo: null as number | null, count: 0, last: 0});
  const overlayRef = useRef(false);
  const scrubTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  // next-episode countdown, playback error card, live channel side panel, live guide (now/next)
  const [autoNext, setAutoNext] = useState<{ep: any; title: string; left: number} | null>(null);
  const autoNextRef = useRef<{ep: any; title: string; left: number} | null>(null);
  autoNextRef.current = autoNext;
  const endedFor = useRef('');
  // Small saved list of the movies/series the home screen shows (recent, favourites, continue watching), so opening
  // the app does not have to load the whole movie/series catalogue. undefined = still loading, null = not saved yet.
  const [homeSummary, setHomeSummary] = useState<Media[] | null | undefined>(undefined);
  // live preview inside the TV channel list (Settings can turn it off: it holds one stream connection while browsing)
  const [livePreview, setLivePreview] = useState(true);
  useEffect(() => { AsyncStorage.getItem('streambox.livePreview').then(v => { if (v === '0') setLivePreview(false); }).catch(() => undefined); }, []);
  function toggleLivePreview() {
    setLivePreview(v => { AsyncStorage.setItem('streambox.livePreview', v ? '0' : '1').catch(() => undefined); return !v; });
  }
  // Buffer profile and media tunneling: native-level playback settings. A change applies to the NEXT channel/video
  // you open, not to one already playing — see PlayerController.kt for why (ExoPlayer cannot change these live).
  const [bufferProfile, setBufferProfileState] = useState<'fast' | 'stable'>('fast');
  const [tunneling, setTunnelingState] = useState(false);
  useEffect(() => {
    AsyncStorage.multiGet(['streambox.bufferProfile', 'streambox.tunneling']).then(entries => {
      const map = Object.fromEntries(entries);
      const profile = map['streambox.bufferProfile'] === 'stable' ? 'stable' : 'fast';
      const tun = map['streambox.tunneling'] === '1';
      setBufferProfileState(profile);
      setTunnelingState(tun);
      NativeModules.TurboPlayerModule?.setBufferProfile?.(profile);
      NativeModules.TurboPlayerModule?.setTunnelingEnabled?.(tun);
    }).catch(() => undefined);
  }, []);
  function toggleBufferProfile() {
    setBufferProfileState(v => {
      const next = v === 'fast' ? 'stable' : 'fast';
      AsyncStorage.setItem('streambox.bufferProfile', next).catch(() => undefined);
      NativeModules.TurboPlayerModule?.setBufferProfile?.(next);
      return next;
    });
  }
  function toggleTunneling() {
    setTunnelingState(v => {
      const next = !v;
      AsyncStorage.setItem('streambox.tunneling', next ? '1' : '0').catch(() => undefined);
      NativeModules.TurboPlayerModule?.setTunnelingEnabled?.(next);
      return next;
    });
  }
  // Screensaver (OLED burn-in protection) and preferred audio/subtitle language — all persisted, all TV settings.
  const [screensaverMin, setScreensaverMin] = useState<ScreensaverMinutes>(10);
  const [showScreensaverPicker, setShowScreensaverPicker] = useState(false);
  const [audioPref, setAudioPref] = useState('');
  const [subPref, setSubPref] = useState('');
  const [showAudioPref, setShowAudioPref] = useState(false);
  const [showSubPref, setShowSubPref] = useState(false);
  useEffect(() => {
    AsyncStorage.multiGet(['streambox.screensaverMin', 'streambox.audioPref', 'streambox.subPref']).then(entries => {
      const map = Object.fromEntries(entries);
      const sm = Number(map['streambox.screensaverMin']);
      if ([0, 5, 10, 30].includes(sm)) setScreensaverMin(sm as ScreensaverMinutes);
      setAudioPref(map['streambox.audioPref'] || '');
      setSubPref(map['streambox.subPref'] || '');
    }).catch(() => undefined);
  }, []);
  function chooseScreensaver(min: ScreensaverMinutes) {
    setScreensaverMin(min);
    setShowScreensaverPicker(false);
    AsyncStorage.setItem('streambox.screensaverMin', String(min)).catch(() => undefined);
  }
  function chooseAudioPref(id: string) {
    setAudioPref(id);
    setShowAudioPref(false);
    AsyncStorage.setItem('streambox.audioPref', id).catch(() => undefined);
  }
  function chooseSubPref(id: string) {
    setSubPref(id);
    setShowSubPref(false);
    AsyncStorage.setItem('streambox.subPref', id).catch(() => undefined);
  }
  // Provider check + "view on phone" (logs and the check report share one modal)
  const [showProviderCheck, setShowProviderCheck] = useState(false);
  const [phoneText, setPhoneText] = useState<{title: string; text: string} | null>(null);
  function openLogsOnPhone() {
    const header = `TurboX | ${Platform.OS} ${Platform.Version} | ${deviceMode || ''} | profiles ${providers.length} | ${new Date().toISOString()}`;
    setPhoneText({title: tx('سجل الأخطاء', 'Logs'), text: formatLogs(logEntries, header)});
  }
  // Update check: at most once a day in the background, never interrupts — surfaced only as a Settings row.
  const APP_VERSION = String((appJson as any)?.expo?.version || '0.0.0');
  const [updateInfo, setUpdateInfo] = useState<UpdateInfo | null>(null);
  const [checkingUpdate, setCheckingUpdate] = useState(false);
  async function checkUpdateNow() {
    setCheckingUpdate(true);
    const info = await checkForUpdate(APP_VERSION);
    setUpdateInfo(info);
    setCheckingUpdate(false);
    AsyncStorage.setItem('streambox.lastUpdateCheck', String(Date.now())).catch(() => undefined);
  }
  useEffect(() => {
    AsyncStorage.getItem('streambox.lastUpdateCheck').then(v => {
      if (!v || Date.now() - Number(v) > 24 * 60 * 60 * 1000) checkUpdateNow();
    }).catch(() => undefined);
  }, []);
  // Settings transfer between TVs (providers + simple settings only — see BackupModal's own comment) + DLNA cast
  const [showBackup, setShowBackup] = useState(false);
  const [showCast, setShowCast] = useState(false);
  function buildBackupJson(): string {
    return JSON.stringify({
      turboxBackup: BACKUP_VERSION,
      providers, theme, language, livePreview, bufferProfile, tunneling, audioPref, subPref, screensaverMin,
    });
  }
  function applyBackup(data: any) {
    if (Array.isArray(data.providers) && data.providers.length) { setProviders(data.providers); persistProviders(data.providers); }
    if (data.theme) changeTheme(data.theme);
    if (data.language === 'ar' || data.language === 'en') { setLanguage(data.language); AsyncStorage.setItem('streambox.language', data.language).catch(() => undefined); }
    if (typeof data.livePreview === 'boolean') { setLivePreview(data.livePreview); AsyncStorage.setItem('streambox.livePreview', data.livePreview ? '1' : '0').catch(() => undefined); }
    if (data.bufferProfile === 'fast' || data.bufferProfile === 'stable') { setBufferProfileState(data.bufferProfile); AsyncStorage.setItem('streambox.bufferProfile', data.bufferProfile).catch(() => undefined); NativeModules.TurboPlayerModule?.setBufferProfile?.(data.bufferProfile); }
    if (typeof data.tunneling === 'boolean') { setTunnelingState(data.tunneling); AsyncStorage.setItem('streambox.tunneling', data.tunneling ? '1' : '0').catch(() => undefined); NativeModules.TurboPlayerModule?.setTunnelingEnabled?.(data.tunneling); }
    if (typeof data.audioPref === 'string') chooseAudioPref(data.audioPref);
    if (typeof data.subPref === 'string') chooseSubPref(data.subPref);
    if ([0, 5, 10, 30].includes(data.screensaverMin)) chooseScreensaver(data.screensaverMin);
  }
  // "continue from 35:05?" offer shown when a partly watched movie/episode starts
  const [resumeOffer, setResumeOffer] = useState<{pos: number; left: number} | null>(null);
  const resumeRef = useRef<{pos: number; left: number} | null>(null);
  resumeRef.current = resumeOffer;
  const resumeFor = useRef('');
  const [playError, setPlayError] = useState<{text: string; cursor: number} | null>(null);
  const errRef = useRef<{text: string; cursor: number} | null>(null);
  errRef.current = playError;
  const [chanPanel, setChanPanel] = useState({open: false, cursor: 0});
  const chanRef = useRef({open: false, cursor: 0, list: [] as Media[]});
  const chanTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [liveGuide, setLiveGuide] = useState<{key: string; list: Prog[]} | null>(null);
  function setCtl(patch: Partial<{focus: number; scrubTo: number | null}>) {
    ctlRef.current = {...ctlRef.current, ...patch};
    setCtlState({focus: ctlRef.current.focus, scrubTo: ctlRef.current.scrubTo});
  }
  const playerOpenedAt = useRef(0);
  const [accountInfo, setAccountInfo] = useState<AccountInfo | null>(null);
  const [showAccount, setShowAccount] = useState(false);
  const [playerEngine, setPlayerEngine] = useState<PlayerEngine>('builtin');
  // Media3 native player state
  type NativeTrack = {id: string; label: string; language: string; selected: boolean};
  const [nativeTracks, setNativeTracks] = useState<{audio: NativeTrack[]; text: NativeTrack[]; textOff: boolean}>({audio: [], text: [], textOff: true});
  const [nativePaused, setNativePaused] = useState(false);
  const [nativeSeek, setNativeSeek] = useState<{to: number; n: number} | undefined>(undefined);
  const nativeSeekN = useRef(0);
  const [audioSel, setAudioSel] = useState<string | undefined>(undefined);
  const [textSel, setTextSel] = useState<string | undefined>(undefined);
  const [showTracks, setShowTracks] = useState(false);
  const [trackCursor, setTrackCursor] = useState(0);
  const [showPlayerPicker, setShowPlayerPicker] = useState(false);
  const [showAutomation, setShowAutomation] = useState(false);
  const [hiddenCats, setHiddenCats] = useState<Record<CatTab, string[]>>({live: [], movies: [], series: []});
  const [showHidden, setShowHidden] = useState(false);
  const [recentKeys, setRecentKeys] = useState<string[]>([]);
  const [sleepEnd, setSleepEnd] = useState<number | null>(null);
  const [sleepMin, setSleepMin] = useState(0);
  const [sleepTick, setSleepTick] = useState(0);
  const [showSleep, setShowSleep] = useState(false);
  const [showThemes, setShowThemes] = useState(false);
  const [showExit, setShowExit] = useState(false);
  const [showRemoteGuide, setShowRemoteGuide] = useState(false);
  const [automation, setAutomation] = useState<Automation>(DEFAULT_AUTOMATION);
  const [epgTick, setEpgTick] = useState(0);
  const [accountLoading, setAccountLoading] = useState(false);
  const [accountError, setAccountError] = useState<string | null>(null);
  const [channelInput, setChannelInput] = useState('');
  const channelInputRef = useRef('');
  const channelTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const curLiveKey = useRef<string | null>(null);
  const prevLiveKey = useRef<string | null>(null);
  const [choiceOnContinue, setChoiceOnContinue] = useState(false);
  const choiceOnContinueRef = useRef(false);
  const choiceOpenedAt = useRef(0);
  const saveDeviceModeRef = useRef<() => void>(() => undefined);
  const outerScroll = useTVScroller('y');
  const sideScroll = useTVScroller('y');
  const gridScroll = useTVScroller('y');
  const compactDashboard = screenWidth < 1200;
  const homeCompact = screenHeight < 650;
  const fitScale = Math.max(0.72, Math.min(1, Math.min(screenWidth / 1280, screenHeight / 720)));
  const homeTopHeight = Math.max(58, Math.min(112, Math.round(screenHeight * 0.14 * fitScale)));
  const homeLogoWidth = Math.min(420, Math.round(screenWidth * 0.31 * fitScale));
  const homeLogoHeight = Math.max(48, Math.min(104, Math.round(screenHeight * 0.13 * fitScale)));
  const homeTileHeight = Math.max(128, Math.min(300, Math.round(screenHeight * (homeCompact ? 0.34 : 0.40) * fitScale)));
  const homeHorizontalPad = Math.max(14, Math.min(34, Math.round(screenWidth * 0.026 * fitScale)));
  const homeActionHeight = Math.max(44, Math.min(62, Math.round(62 * fitScale)));
  const homeActionGap = Math.max(7, Math.round(18 * fitScale));
  const catalogSideWidth = Math.max(1, Math.round(screenWidth * 0.25));
  const catalogColumns = deviceMode === 'tv' ? Math.max(5, Math.min(8, Math.floor((screenWidth - catalogSideWidth - 58) / 132))) : Math.max(2, Math.min(5, Math.floor((screenWidth - catalogSideWidth - 42) / 122)));
  const posterWidth = deviceMode === 'tv' ? Math.max(112, Math.floor((screenWidth - catalogSideWidth - 58 - (catalogColumns - 1) * 10) / catalogColumns)) : Math.max(100, Math.floor((screenWidth - catalogSideWidth - 42 - (catalogColumns - 1) * 8) / catalogColumns));
  const focusCatalogItem = (index: number) => {
    catalogListRef.current?.scrollToIndex({index, animated: true, viewPosition: 0.45});
  };
  // ONE stable function per action for every list row: rows are React.memo, so a state change in this big component
  // (EPG arriving, progress, buffering…) no longer re-renders every mounted row — the main cost on weak TV boxes.
  const rowActions = useRef({toggleFavorite, playItem, focusCatalogItem});
  rowActions.current = {toggleFavorite, playItem, focusCatalogItem};
  const onRowFavorite = useCallback((it: Media) => { rowActions.current.toggleFavorite(it); }, []);
  const onRowPlay = useCallback((it: Media) => { rowActions.current.playItem(it); }, []);
  const onRowFocusIndex = useCallback((i: number) => rowActions.current.focusCatalogItem(i), []);
  const [tab, setTab] = useState('home');
  const [catalogProgress, setCatalogProgress] = useState(0);
  const [catalogReady, setCatalogReady] = useState(false);
  const [catalogLoading, setCatalogLoading] = useState(false);
  const catalogListRef = useRef<FlatList<Media>>(null);
  const tvFocusIndex = useRef(0);
  const [tvFocusedIndex, setTvFocusedIndex] = useState(0);
  const [providers, setProviders] = useState<Provider[]>([]);
  const [activeProvider, setActiveProvider] = useState<Provider | null>(null);
  const [channelsAll, setChannels] = useState<Media[]>([]);
  const [moviesAll, setMovies] = useState<Media[]>([]);
  const [seriesAll, setSeries] = useState<Media[]>([]);
  // Kids profile: adult categories are removed everywhere (lists, search, home rows, guide)
  const kidMode = !!activeProvider?.kid;
  const channels = useMemo(() => kidMode ? channelsAll.filter(c => !isAdultCategory(c.category_name)) : channelsAll, [channelsAll, kidMode]);
  const movies = useMemo(() => kidMode ? moviesAll.filter(c => !isAdultCategory(c.category_name)) : moviesAll, [moviesAll, kidMode]);
  const series = useMemo(() => kidMode ? seriesAll.filter(c => !isAdultCategory(c.category_name)) : seriesAll, [seriesAll, kidMode]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [busy, setBusy] = useState(false);
  const [query, setQuery] = useState('');
  const [player, setPlayer] = useState<{
    title: string;
    url: string;
    mediaKey?: string;
    live?: boolean;
    headers?: Record<string, string>;
    fallbackUrls?: string[];
    native?: boolean; // Media3 native player (audio/subtitle tracks)
    allUrls?: string[];
    triedNative?: boolean;
    nonce?: number; // bumped to force a reload of the same URL
  } | null>(null);
  const [selectedSeries, setSelectedSeries] = useState<Media | null>(null);
  const [episodesBySeason, setEpisodesBySeason] = useState<Record<string, any[]>>({});
  const [showSeasons, setShowSeasons] = useState(false);
  const [selectedSeason, setSelectedSeason] = useState<string>('');
  const [subscriptionExpiry, setSubscriptionExpiry] = useState('غير محدد');
  const [language, setLanguage] = useState<'ar' | 'en'>('ar');
  const [parentalPin, setParentalPin] = useState('');
  const [pinDraft, setPinDraft] = useState('');
  const [verifyDraft, setVerifyDraft] = useState('');
  const [showLanguage, setShowLanguage] = useState(false);
  const [showParental, setShowParental] = useState(false);
  const [showAbout, setShowAbout] = useState(false);
  const [showVerify, setShowVerify] = useState(false);
  const [pendingMedia, setPendingMedia] = useState<Media | null>(null);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [theme, setTheme] = useState<ThemeName>('turbo');
  // profileName is only the legacy suffix of the favourites key (kept so old favourites still load);
  // a "profile" in the UI is now a saved server subscription (Provider).
  const [profileName, setProfileName] = useState('الرئيسية');
  const [showProfiles, setShowProfiles] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null); // provider being edited in the server screen
  const [loginError, setLoginError] = useState<{title: string; text: string} | null>(null);
  const [refreshing, setRefreshing] = useState(false); // background catalogue refresh (saved copy already shown)
  const [updatedAt, setUpdatedAt] = useState<Record<string, number>>({}); // last successful download per profile
  const [deleteTarget, setDeleteTarget] = useState<Provider | null>(null);
  const [favLists, setFavLists] = useState<FavList[]>([{id: DEFAULT_LIST_ID, name: 'المفضلة'}]);
  const [activeFavId, setActiveFavId] = useState(DEFAULT_LIST_ID);
  const [listDraft, setListDraft] = useState('');
  const [startupMode, setStartupMode] = useState<StartupMode>('live');
  const [showStartup, setShowStartup] = useState(false);
  const [resumeLast, setResumeLast] = useState(false); // play the last live channel once the catalogue is ready
  const [showLogs, setShowLogs] = useState(false);
  // Movies/series stay on disk until something needs them (most TV-box use is live TV only)
  const [starFocus, setStarFocus] = useState(false); // TV: make the list star a D-pad target again
  const [favHintSeen, setFavHintSeen] = useState(true); // TV: how to add favourites with the remote (shown until first used)
  const [heavyLoaded, setHeavyLoaded] = useState(true);
  const [catalogCounts, setCatalogCounts] = useState<Counts | null>(null);
  const heavyJob = useRef<{key: string; promise: Promise<void>} | null>(null);
  const [logEntries, setLogEntries] = useState<LogEntry[]>([]);
  const [showTimeline, setShowTimeline] = useState(false);
  const [selectedMovie, setSelectedMovie] = useState<Media | null>(null);
  const [movieInfo, setMovieInfo] = useState<any | null>(null);
  const [movieLoading, setMovieLoading] = useState(false);
  const [showMovie, setShowMovie] = useState(false);
  const [pendingAction, setPendingAction] = useState<(() => void) | null>(null); // runs after the Parental PIN is entered
  const guideCache = useRef<Record<string, Prog[]>>({});
  const epgBackoff = useRef<Record<string, number>>({}); // provider id → time until which guide requests are paused
  const onlineRef = useRef(true);
  const profileRef = useRef('الرئيسية'); // legacy favourites-key suffix (stored value, readable at app start)
  const langRef = useRef(false); // isEnglish, readable from callbacks that started before the language was loaded
  const connectSeq = useRef(0); // only the newest connect() may write state
  const [showEpg, setShowEpg] = useState(false);
  const [epgChannel, setEpgChannel] = useState<Media | null>(null);
  const [buffering, setBuffering] = useState(false);
  const [networkLabel, setNetworkLabel] = useState('Checking network…');
  const [watchProgress, setWatchProgress] = useState<Record<string, number>>({});
  const [epgPrograms, setEpgPrograms] = useState<any[]>([]);
  const [epgLoading, setEpgLoading] = useState(false);
  const [diagnosticLabel, setDiagnosticLabel] = useState('لم يتم الاختبار بعد');
  const [diagnosticBusy, setDiagnosticBusy] = useState(false);
  const [epgQuery, setEpgQuery] = useState('');
  const [nowPlaying, setNowPlaying] = useState<Record<string, string>>({});
  const [showMultiView, setShowMultiView] = useState(false);
  const [multiSelected, setMultiSelected] = useState<string[]>([]);
  const [showFavorites, setShowFavorites] = useState(false);
  const [aspectMode, setAspectMode] = useState<ResizeMode>(ResizeMode.CONTAIN);
  const [deviceDraft, setDeviceDraft] = useState<'tv' | 'mobile'>('mobile');
  const lastProgressSave = useRef(0);
  const accent = themeAccents[theme];
  const isEnglish = language === 'en';
  langRef.current = isEnglish;
  const tx = (ar: string, en: string) => isEnglish ? en : ar;
  const trackRows: TrackRow[] = useMemo(() => {
    const rows: TrackRow[] = [];
    nativeTracks.audio.forEach(t => rows.push({kind: 'audio', id: t.id, label: t.label, selected: audioSel ? audioSel === t.id : t.selected}));
    rows.push({kind: 'text', id: 'off', label: isEnglish ? 'Subtitles off' : 'بدون ترجمة', selected: textSel ? textSel === 'off' : nativeTracks.textOff});
    nativeTracks.text.forEach(t => rows.push({kind: 'text', id: t.id, label: t.label, selected: textSel ? textSel === t.id : !nativeTracks.textOff && t.selected}));
    return rows;
  }, [nativeTracks, audioSel, textSel, isEnglish]);
  const trackUi = useRef({show: false, rows: [] as TrackRow[], cursor: 0});
  trackUi.current = {show: showTracks, rows: trackRows, cursor: trackCursor};
  function chooseTrack(row: TrackRow) {
    if (row.kind === 'audio') setAudioSel(row.id); else setTextSel(row.id);
  }
  function toggleTrackMenu() {
    setTrackCursor(Math.max(0, trackUi.current.rows.findIndex(r => r.kind === 'audio' && r.selected)));
    setShowTracks(v => !v);
  }
  // Applies the preferred audio/subtitle language once per newly opened native stream, only if the viewer has not
  // already picked a track themselves this session (audioSel/textSel stay undefined until chooseTrack() is called).
  const langAppliedFor = useRef('');
  useEffect(() => {
    const tag = `${player?.url || ''}#${player?.nonce || 0}`;
    if (!player?.native || langAppliedFor.current === tag) return;
    if (!nativeTracks.audio.length && !nativeTracks.text.length) return; // tracks not reported yet
    langAppliedFor.current = tag;
    if (audioPref && audioSel === undefined) {
      const hit = nativeTracks.audio.find(t => t.language?.toLowerCase().startsWith(audioPref));
      if (hit) setAudioSel(hit.id);
    }
    if (subPref && textSel === undefined) {
      if (subPref === 'off') setTextSel('off');
      else { const hit = nativeTracks.text.find(t => t.language?.toLowerCase().startsWith(subPref)); if (hit) setTextSel(hit.id); }
    }
  }, [nativeTracks, player?.url, player?.nonce, player?.native, audioPref, subPref, audioSel, textSel]);
  const expiryAlert: {level: 'warn' | 'bad'; text: string} | null = accountInfo && accountInfo.kind === 'xtream'
    ? (accountInfo.expired || !accountInfo.active
        ? {level: 'bad', text: accountInfo.expired ? tx('انتهى اشتراكك. اضغط لعرض التفاصيل.', 'Your subscription has expired. Tap for details.') : tx(`حالة الحساب: ${accountInfo.status}. اضغط لعرض التفاصيل.`, `Account status: ${accountInfo.status}. Tap for details.`)}
        : accountInfo.daysLeft !== null && accountInfo.daysLeft <= 7
          ? {level: 'warn', text: tx(`ينتهي اشتراكك خلال ${accountInfo.daysLeft} يوم. اضغط للتفاصيل.`, `Your subscription ends in ${accountInfo.daysLeft} day(s). Tap for details.`)}
          : null)
    : null;
  const [form, setForm] = useState({
    name: 'مزودي الأول',
    server: '',
    username: '',
    password: '',
    userAgent: ''
  });
  useEffect(() => { guideCache.current = {}; }, [activeProvider?.id]);
  useEffect(() => {
    installGlobalErrorLogging();
    logInfo('app', 'started');
    tvEngine.perfSink = msg => logInfo('tv', msg);
    AsyncStorage.getItem('streambox.favHint').then(v => setFavHintSeen(v === '1')).catch(() => undefined);
    AsyncStorage.getItem('streambox.tvStar').then(v => setStarFocus(v === '1')).catch(() => undefined);
    initializeDatabase().catch(() => undefined);
    AsyncStorage.multiGet(['streambox.providers', 'streambox.theme', 'streambox.language', 'streambox.parentalPin', 'streambox.activeProviderId', 'streambox.profiles', 'streambox.profile', 'streambox.watchProgress', 'streambox.deviceMode']).then(async values => {
      const raw = values[0][1];
      const savedTheme = values[1][1] as ThemeName | null;
      if (raw) {
        const list = (await restoreProviders(raw)) as Provider[];
        setProviders(list);
        const savedId = values[4][1];
        const target = list.find(p => p.id === savedId) || list.find(p => !isM3uProvider(p));
        if (target) {
          setActiveProvider(target);
          const startup = parseStartup(await AsyncStorage.getItem(STARTUP_KEY));
          setStartupMode(startup);
          setTimeout(() => connect(target, false, {startup}), 0);
        }
      }
      if (savedTheme && themeAccents[savedTheme]) setTheme(savedTheme);
      if (values[2][1] === 'en') setLanguage('en');
      loadPin(values[3][1]).then(pin => { if (pin) setParentalPin(pin); }).catch(() => undefined);
      if (values[6][1]) { setProfileName(values[6][1]); profileRef.current = values[6][1]; }
      if (values[7][1]) setWatchProgress(JSON.parse(values[7][1]));
      if (values[8][1] === 'tv' || values[8][1] === 'mobile') setDeviceMode(values[8][1]);
    });
  }, []);
  useEffect(() => {
  }, []);
  useEffect(() => {
    const onBack = () => {
      if (player) {
        setPlayer(null);
        return true;
      }
      if (showSeasons) {
        setShowSeasons(false);
        return true;
      }
      if (selectedCategory !== 'All') {
        setSelectedCategory('All');
        setQuery('');
        return true;
      }
      if (tab !== 'home') {
        setTab('home');
        setQuery('');
        return true;
      }
      setShowExit(true);
      return true;
    };
    const subscription = BackHandler.addEventListener('hardwareBackPress', onBack);
    return () => subscription.remove();
  }, [player, showSeasons, selectedCategory, tab]);
  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener(state => {
      const details: any = state.details || {};
      const speed = details.downlink ? ` · ${Math.round(details.downlink)}Mbps` : '';
      onlineRef.current = state.isConnected !== false;
      setNetworkLabel(state.isConnected ? `${state.type === 'wifi' ? 'Wi‑Fi' : state.type}${speed}` : 'Offline');
    });
    return unsubscribe;
  }, []);
  const categorySource = tab === 'movies' ? movies : tab === 'series' ? series : channels;
  const recentItems = useMemo(() => {
    if (selectedCategory !== '__recent__') return [] as Media[]; // only the "recently added" list uses this
    const weekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
    return categorySource.filter(item => {
      const raw = item.added ?? item.added_at ?? item.created_at ?? item.last_modified;
      const value = Number(raw);
      if (!Number.isFinite(value) || value <= 0) return false;
      const timestamp = value < 100000000000 ? value * 1000 : value;
      return timestamp >= weekAgo && timestamp <= Date.now();
    });
  }, [categorySource, selectedCategory]);
  const hiddenNow = hiddenCats[tab === 'movies' ? 'movies' : tab === 'series' ? 'series' : 'live'];
  const categories = useMemo(() => ['All', ...Array.from(new Set(categorySource.map(c => c.category_name || 'عام'))).filter(name => !hiddenNow.includes(name))], [categorySource, hiddenNow]);
  // one pass over the list instead of one filter() per category per render (that was O(categories × items), seconds on a TV box)
  const categoryCounts = useMemo(() => {
    const m = new Map<string, number>();
    for (const item of categorySource) {
      const k = item.category_name || 'عام';
      m.set(k, (m.get(k) || 0) + 1);
    }
    return m;
  }, [categorySource]);
  const allCategoryNames = useMemo(() => {
    if (!showHidden) return {live: [], movies: [], series: []} as Record<CatTab, string[]>; // only the Hidden Categories screen reads this
    const uniq = (items: Media[]) => Array.from(new Set(items.map(c => c.category_name || 'عام'))).sort((a, b) => a.localeCompare(b));
    return {live: uniq(channels), movies: uniq(movies), series: uniq(series)};
  }, [showHidden, channels, movies, series]);
  const favSet = useMemo(() => new Set(favorites), [favorites]); // O(1) star lookup per row instead of scanning the array
  const deferredQuery = useDeferredValue(query);
  async function hydrateHeavy() {
    if (heavyLoaded || !activeProvider || isM3uProvider(activeProvider)) return;
    const key = `streambox.xtreamCache.${activeProvider.id}`;
    if (heavyJob.current?.key === key) return heavyJob.current.promise; // already loading for this profile
    const seq = connectSeq.current;
    const promise = (async () => {
      try {
        const heavyT = Date.now();
        const saved = await readHeavy(key);
        logInfo('startup', `movies/series read in ${Date.now() - heavyT}ms (+${Date.now() - APP_T0}ms since launch)`);
        if (seq !== connectSeq.current) return; // another profile/refresh took over meanwhile
        if (saved) { setMovies(saved.movies); setSeries(saved.series); }
        setHeavyLoaded(true); // even when unreadable: stop retrying, the next refresh rewrites it
        logInfo('catalog', `loaded ${saved?.movies.length ?? 0} movies / ${saved?.series.length ?? 0} series on demand`);
      } catch (err: any) {
        logWarn('catalog', `could not load movies/series: ${err?.message || err}`);
        if (seq === connectSeq.current) setHeavyLoaded(true);
      } finally {
        if (heavyJob.current?.key === key) heavyJob.current = null;
      }
    })();
    heavyJob.current = {key, promise};
    return promise;
  }
  useEffect(() => { if (catalogReady) logInfo('startup', `live catalog ready +${Date.now() - APP_T0}ms since launch`); }, [catalogReady]);
  useEffect(() => {
    setHomeSummary(undefined);
    if (!activeProvider) return;
    let off = false;
    cacheGet(`streambox.homeSummary.${activeProvider.id}`)
      .then(raw => { if (off) return; try { setHomeSummary(raw ? JSON.parse(raw) : null); } catch { setHomeSummary(null); } })
      .catch(() => { if (!off) setHomeSummary(null); });
    return () => { off = true; };
  }, [activeProvider?.id]);
  // what needs movies/series in memory: their tabs, the home rows, favourites, hidden categories, search, special lists
  const needHeavy = !heavyLoaded && catalogReady && (tab === 'movies' || tab === 'series' || (tab === 'home' && homeSummary === null) || showFavorites || showHidden || deferredQuery.trim().length > 0 || selectedCategory.startsWith('__'));
  useEffect(() => { if (needHeavy) hydrateHeavy(); }, [needHeavy, activeProvider?.id]);
  const heavyPending = !heavyLoaded && (tab === 'movies' || tab === 'series');
  const timelineChannels = useMemo(() => {
    if (!showTimeline) return [] as Media[];
    return tab === 'live' && selectedCategory !== 'All' && !selectedCategory.startsWith('__') ? channels.filter(c => (c.category_name || '???') === selectedCategory) : channels;
  }, [showTimeline, channels, tab, selectedCategory]);
  const filtered = useMemo(() => {
    let source = tab === 'movies' ? movies : tab === 'series' ? series : channels;
    if (selectedCategory === '__favorites__') source = source.filter(c => favorites.includes(channelKey(c)));
    if (selectedCategory === '__continue__') source = source.filter(c => (watchProgress[channelKey(c)] || 0) > 1 && (watchProgress[channelKey(c)] || 0) < 99);
    if (selectedCategory === '__recent__') source = recentItems;
    return source.filter(c => (c.name || '').toLowerCase().includes(deferredQuery.toLowerCase()) && (selectedCategory === 'All' ? !hiddenNow.includes(c.category_name || 'عام') : (selectedCategory === '__favorites__' || selectedCategory === '__continue__' || selectedCategory === '__recent__' || (c.category_name || 'عام') === selectedCategory)));
  }, [channels, movies, series, recentItems, tab, deferredQuery, selectedCategory, favorites, selectedCategory === '__continue__' ? watchProgress : null, hiddenNow]); // progress ticks must not re-filter 100k items while watching
  const globalResults = useMemo(() => {
    const q = deferredQuery.trim().toLowerCase();
    const out: Media[] = [];
    if (!q) return out;
    for (const list of [channels, movies, series]) {
      for (const c of list) {
        if ((c.name || '').toLowerCase().includes(q)) { out.push(c); if (out.length >= 20) return out; }
      }
    }
    return out;
  }, [channels, movies, series, deferredQuery]);
  useEffect(() => {
    tvEngine.start();
    loadAutomation().then(setAutomation).catch(() => undefined);
    AsyncStorage.getItem('streambox.playerEngine').then(v => {
      if (v && PLAYER_OPTIONS.some(o => o.id === v)) setPlayerEngine(v as PlayerEngine);
    }).catch(() => undefined);
  }, []);
  useEffect(() => {
    tvEngine.setEnabled(deviceMode === 'tv');
  }, [deviceMode]);
  useEffect(() => { tvEngine.invalidate(); }, [tab, selectedCategory, screenWidth, screenHeight, deviceMode, catalogReady, showSearch, showAccount]);
  // track ids belong to one media item: forget the choice when the stream changes or the player closes
  useEffect(() => {
    setAudioSel(undefined); setTextSel(undefined); setShowTracks(false);
    setNativeTracks({audio: [], text: [], textOff: true});
  }, [player?.url]);
  // Mobile / TV choice screen: ◀ ▶ switch card, ▼ goes to Continue, ▲ back, OK confirms
  useEffect(() => {
    if (!(splashDone && deviceMode === null)) return;
    choiceOpenedAt.current = Date.now();
    choiceOnContinueRef.current = false;
    setChoiceOnContinue(false);
    const sub = DeviceEventEmitter.addListener('TurboXRemoteKey', ({keyCode, action}: {keyCode: number; action: number}) => {
      if (action !== 1 || Date.now() - choiceOpenedAt.current < 600) return;
      const setCont = (v: boolean) => { choiceOnContinueRef.current = v; setChoiceOnContinue(v); };
      if (keyCode === 21 || keyCode === 22) { if (!choiceOnContinueRef.current) setDeviceDraft(d => d === 'tv' ? 'mobile' : 'tv'); }
      else if (keyCode === 20) setCont(true);
      else if (keyCode === 19) setCont(false);
      else if (keyCode === 23 || keyCode === 66 || keyCode === 160) { if (choiceOnContinueRef.current) saveDeviceModeRef.current(); else setCont(true); }
    });
    return () => sub.remove();
  }, [splashDone, deviceMode]);
  useEffect(() => {
    if (player) {
      playerOpenedAt.current = Date.now();
      playStatus.current = {pos: 0, dur: 0, playing: true};
      setPlayClock({pos: 0, dur: 0, playing: true});
      setNativePaused(false); setNativeSeek(undefined); setShowTracks(false);
      showOverlay(4500);
    } else {
      overlayRef.current = false;
      setOverlayOn(false);
      setSeekFlash(null);
      setCtl({focus: 0, scrubTo: null});
    }
  }, [player?.url, !!player]);
  async function refreshAccount() {
    const src = activeProvider;
    if (!src) return;
    if (isM3uProvider(src)) { setAccountInfo(m3uAccountInfo(src)); return; }
    setAccountLoading(true);
    setAccountError(null);
    try {
      setAccountInfo(await fetchAccountInfo(src));
    } catch (e: any) {
      setAccountError(tx('تعذر تحديث بيانات الحساب. تأكد من الاتصال.', 'Could not refresh the account. Check your connection.'));
    } finally {
      setAccountLoading(false);
    }
  }
  function openAccount() {
    setShowAccount(true);
    if (activeProvider && !isM3uProvider(activeProvider)) refreshAccount();
  }
  function liveList() {
    return (tab === 'live' ? filtered : channels).filter(item => item.kind === 'live' || !item.kind);
  }
  function zapPrev() {
    const key = prevLiveKey.current;
    const target = key ? (liveList().find(i => channelKey(i) === key) || channels.find(i => channelKey(i) === key)) : null;
    if (target) playItem(target); else flash('—');
  }
  function commitChannel() {
    const n = parseInt(channelInputRef.current, 10);
    channelInputRef.current = '';
    setChannelInput('');
    if (!n) return;
    const list = liveList();
    const target = list.find(item => Number((item as any).num) === n) || list[n - 1];
    if (target) playItem(target); else flash(`#${n} ✕`);
  }
  function enterDigit(d: number) {
    if (!player?.live) return;
    if (d === 0 && !channelInputRef.current) { zapPrev(); return; }
    const next = (channelInputRef.current + d).slice(0, 4);
    channelInputRef.current = next;
    setChannelInput(next);
    showOverlay(3000);
    if (channelTimer.current) clearTimeout(channelTimer.current);
    channelTimer.current = setTimeout(commitChannel, next.length >= 4 ? 200 : 1800);
  }
  // Settings → Startup → "Resume last channel": play it once the catalogue of that profile is on screen
  useEffect(() => {
    if (!resumeLast || !catalogReady || !channels.length || !activeProvider) return;
    setResumeLast(false);
    AsyncStorage.getItem(LAST_LIVE_KEY).then(v => {
      const last = parseLastLive(v);
      if (!last || last.providerId !== activeProvider.id) return;
      const item = channels.find(c => channelKey(c) === last.key);
      if (item) playItem(item);
    }).catch(() => undefined);
  }, [resumeLast, catalogReady, channels.length]);
  useEffect(() => {
    if (player?.live && player.mediaKey) {
      if (curLiveKey.current && curLiveKey.current !== player.mediaKey) prevLiveKey.current = curLiveKey.current;
      curLiveKey.current = player.mediaKey;
      if (activeProvider) AsyncStorage.setItem(LAST_LIVE_KEY, lastLiveValue(activeProvider.id, player.mediaKey)).catch(() => undefined);
    }
    if (!player) curLiveKey.current = null;
  }, [player?.mediaKey, !!player]);
  function showOverlay(ms = 4000) {
    overlayRef.current = true;
    setOverlayOn(true);
    if (overlayTimer.current) clearTimeout(overlayTimer.current);
    overlayTimer.current = setTimeout(() => { overlayRef.current = false; setOverlayOn(false); setCtl({focus: 0, scrubTo: null}); }, ms);
  }
  function hideOverlay() {
    if (overlayTimer.current) clearTimeout(overlayTimer.current);
    overlayRef.current = false;
    setOverlayOn(false);
    setCtl({focus: 0, scrubTo: null});
  }
  function getNextEpisode(): any | null {
    if (!player || player.live || !selectedSeries || !player.mediaKey) return null;
    const sid = mediaId(selectedSeries);
    const flat: any[] = [];
    for (const se of Object.keys(episodesBySeason).sort((a, b) => Number(a) - Number(b))) for (const ep of episodesBySeason[se] || []) flat.push(ep);
    const idx = flat.findIndex(ep => `${sid}-${ep.id}` === player.mediaKey);
    return idx >= 0 && idx < flat.length - 1 ? flat[idx + 1] : null;
  }
  function episodeLabel(ep: any) {
    const sn = ep?.season ? `S${ep.season} · ` : '';
    return `${sn}${ep?.title || `Episode ${ep?.episode_num || ''}`}`;
  }
  function playerButtons(): PlayerButtonId[] {
    return ['back10', 'play', 'fwd10', ...(getNextEpisode() ? ['next' as const] : []), ...(player?.native ? ['tracks' as const] : []), 'aspect', 'cast', 'sleep'];
  }
  // channel side panel
  function armPanelTimer() {
    if (chanTimer.current) clearTimeout(chanTimer.current);
    chanTimer.current = setTimeout(closePanel, 7000);
  }
  function setChan(patch: Partial<{open: boolean; cursor: number; list: Media[]}>) {
    chanRef.current = {...chanRef.current, ...patch};
    setChanPanel({open: chanRef.current.open, cursor: chanRef.current.cursor});
  }
  function closePanel() {
    if (chanTimer.current) { clearTimeout(chanTimer.current); chanTimer.current = null; }
    if (chanRef.current.open) setChan({open: false});
  }
  function openChanPanel() {
    const list = liveList();
    if (!list.length) { showOverlay(); return; }
    const idx = list.findIndex(i => channelKey(i) === player?.mediaKey);
    hideOverlay();
    setChan({open: true, cursor: Math.max(0, idx), list});
    armPanelTimer();
  }
  // playback error card actions (TV)
  function errorActions(): Array<{id: string; label: string}> {
    const a: Array<{id: string; label: string}> = [{id: 'retry', label: tx('إعادة المحاولة', 'Retry')}];
    if (player?.live) a.push({id: 'zapnext', label: tx('القناة التالية', 'Next channel')});
    else if (getNextEpisode()) a.push({id: 'nextep', label: tx('الحلقة التالية', 'Next episode')});
    a.push({id: 'vlc', label: tx('فتح عبر VLC', 'Open in VLC')}, {id: 'close', label: tx('إغلاق', 'Close')});
    return a;
  }
  function runErrorAction(id: string) {
    if (!player) return;
    if (id === 'retry') {
      retryRef.current = {n: 0, at: 0};
      setPlayError(null);
      setBuffering(true);
      setPlayer(cur => cur && ({...cur, url: cur.allUrls?.[0] || cur.url, fallbackUrls: cur.allUrls ? cur.allUrls.slice(1) : cur.fallbackUrls, nonce: (cur.nonce || 0) + 1}));
    } else if (id === 'zapnext') { setPlayError(null); zap(1); }
    else if (id === 'nextep') { const ep = getNextEpisode(); setPlayError(null); if (ep) playEpisode(ep); }
    else if (id === 'vlc') NativeModules.TurboPlayerModule?.openExternalVlc(player.url);
    else setPlayer(null);
  }
  function onPlayerBack() {
    if (showTracks) setShowTracks(false);
    else if (resumeRef.current) setResumeOffer(null);
    else if (autoNextRef.current) setAutoNext(null);
    else if (chanRef.current.open) closePanel();
    else setPlayer(null);
  }
  function commitScrub() {
    if (scrubTimer.current) { clearTimeout(scrubTimer.current); scrubTimer.current = null; }
    const t = ctlRef.current.scrubTo;
    setCtl({scrubTo: null});
    if (t == null) return;
    seekBy(t - playStatus.current.pos, true);
  }
  function flash(text: string) {
    setSeekFlash(text);
    if (flashTimer.current) clearTimeout(flashTimer.current);
    flashTimer.current = setTimeout(() => setSeekFlash(null), 900);
  }
  async function togglePause() {
    if (player?.native) {
      const willPause = playStatus.current.playing;
      setNativePaused(willPause);
      playStatus.current.playing = !willPause;
      setPlayClock(c => ({...c, playing: !willPause}));
      showOverlay(willPause ? 60000 : 2500);
      return;
    }
    const v = videoRef.current;
    if (!v) return;
    try {
      const st: any = await v.getStatusAsync();
      if (st?.isLoaded && st.isPlaying) { await v.pauseAsync(); playStatus.current.playing = false; setPlayClock(c => ({...c, playing: false})); showOverlay(60000); }
      else { await v.playAsync(); playStatus.current.playing = true; setPlayClock(c => ({...c, playing: true})); showOverlay(2500); }
    } catch {/* ignore */}
  }
  async function seekBy(deltaMs: number, silent = false) {
    if (player?.native) {
      if (player.live) { showOverlay(); return; }
      const dur = playStatus.current.dur;
      const target = Math.max(0, Math.min(dur ? dur - 1000 : Infinity, playStatus.current.pos + deltaMs));
      nativeSeekN.current += 1;
      setNativeSeek({to: target, n: nativeSeekN.current});
      playStatus.current.pos = target;
      setPlayClock(c => ({...c, pos: target}));
      if (!silent) flash(`${deltaMs > 0 ? '+' : '−'}${Math.abs(deltaMs / 1000)}s`);
      showOverlay();
      return;
    }
    const v = videoRef.current;
    if (!v || !player || player.live) { showOverlay(); return; }
    try {
      const st: any = await v.getStatusAsync();
      if (!st?.isLoaded) return;
      const dur = st.durationMillis || 0;
      const target = Math.max(0, Math.min(dur ? dur - 1000 : Infinity, (st.positionMillis || 0) + deltaMs));
      await v.setPositionAsync(target);
      playStatus.current.pos = target;
      setPlayClock(c => ({...c, pos: target}));
      if (!silent) flash(`${deltaMs > 0 ? '+' : '−'}${Math.abs(deltaMs / 1000)}s`);
      showOverlay();
    } catch {/* ignore */}
  }
  function zap(delta: number) {
    if (!player?.live) { showOverlay(); return; }
    const list = (tab === 'live' ? filtered : channels).filter(item => item.kind === 'live' || !item.kind);
    if (!list.length) return;
    const idx = list.findIndex(item => channelKey(item) === player.mediaKey);
    const next = list[((idx < 0 ? 0 : idx) + delta + list.length) % list.length];
    if (next) playItem(next);
  }
  useEffect(() => {
    if (!player || deviceMode !== 'tv') return;
    const sub = DeviceEventEmitter.addListener('TurboXRemoteKey', ({keyCode, action}: {keyCode: number; action: number}) => {
      // The player is a Modal window: its keys reach us as key-UP events from MainActivity.onKeyUp.
      if (action !== 1) return;
      if (Date.now() - playerOpenedAt.current < 700) return; // ignore the OK-release that opened the player
      const ui = trackUi.current;
      if (ui.show) { // audio / subtitle menu owns the remote while it is open
        if (keyCode === 19) setTrackCursor(c => Math.max(0, c - 1));
        else if (keyCode === 20) setTrackCursor(c => Math.min(ui.rows.length - 1, c + 1));
        else if (keyCode === 23 || keyCode === 66 || keyCode === 160) { const r = ui.rows[ui.cursor]; if (r) chooseTrack(r); }
        else if (keyCode === 82 || keyCode === 165) setShowTracks(false);
        return;
      }
      const okKey = keyCode === 23 || keyCode === 66 || keyCode === 160 || keyCode === 96;
      if (errRef.current) { // playback error card
        const acts = errorActions();
        const c = Math.min(errRef.current.cursor, acts.length - 1);
        if (keyCode === 21 || keyCode === 22) {
          const d = (keyCode === 22 ? 1 : -1) * (I18nManager.isRTL ? -1 : 1);
          setPlayError(e => e && {...e, cursor: Math.max(0, Math.min(acts.length - 1, c + d))});
        } else if (okKey) runErrorAction(acts[c].id);
        else if (keyCode === 86) setPlayer(null);
        return;
      }
      if (resumeRef.current) { // resume offer: OK = continue, any arrow = start over
        if (okKey) commitResume();
        else if ([19, 20, 21, 22].includes(keyCode)) setResumeOffer(null);
        else if (keyCode === 86) setPlayer(null);
        return;
      }
      if (autoNextRef.current) { // next-episode countdown: OK = play now, any arrow = cancel
        const a = autoNextRef.current;
        if (okKey) { setAutoNext(null); playEpisode(a.ep); }
        else if ([19, 20, 21, 22].includes(keyCode)) setAutoNext(null);
        else if (keyCode === 86) setPlayer(null);
        return;
      }
      if (player?.live && chanRef.current.open) { // channel side panel
        const cr = chanRef.current;
        if (keyCode === 19 || keyCode === 20) {
          setChan({cursor: Math.max(0, Math.min(cr.list.length - 1, cr.cursor + (keyCode === 20 ? 1 : -1)))});
          armPanelTimer();
        } else if (okKey) {
          const it = cr.list[cr.cursor];
          closePanel();
          if (it && channelKey(it) !== player.mediaKey) playItem(it);
        } else if (keyCode === 21 || keyCode === 22) closePanel();
        return;
      }
      if (player?.live && (keyCode === 21 || keyCode === 22)) { openChanPanel(); return; }
      // VOD: YouTube-style controls. Left/Right scrub (growing steps), Up/Down move between scrubber and buttons, OK activates.
      if (!player?.live && [19, 20, 21, 22, 23, 66, 160, 96].includes(keyCode)) {
        const btns = playerButtons();
        const playIdx = btns.indexOf('play') + 1;
        const visible = overlayRef.current || !playStatus.current.playing;
        const isOk = okKey;
        const flip = I18nManager.isRTL ? -1 : 1;
        const dir = keyCode === 22 ? 1 : keyCode === 21 ? -1 : 0; // +1 = key points visually right
        const keep = playStatus.current.playing ? 5000 : 60000;
        if (!visible) {
          if (isOk) { setCtl({focus: playIdx, scrubTo: null}); togglePause(); return; }
          if (keyCode === 19 || keyCode === 20) { setCtl({focus: keyCode === 20 ? playIdx : 0, scrubTo: null}); showOverlay(keep); return; }
          setCtl({focus: 0, scrubTo: null});
        }
        const c = ctlRef.current;
        const f = visible ? c.focus : 0;
        if (f === 0) { // scrubber
          if (dir !== 0) {
            const dur = playStatus.current.dur;
            if (!dur) { seekBy(keyCode === 22 ? 10000 : -10000); return; }
            const now = Date.now();
            const n = now - c.last < 700 ? c.count + 1 : 1;
            ctlRef.current = {...ctlRef.current, count: n, last: now};
            const step = n <= 3 ? 10000 : n <= 8 ? 30000 : 60000;
            const base = c.scrubTo != null ? c.scrubTo : playStatus.current.pos;
            const fwd = keyCode === 22 ? 1 : -1; // time direction follows the key, as before
            setCtl({focus: 0, scrubTo: Math.max(0, Math.min(dur - 1000, base + fwd * step))});
            showOverlay(keep);
            if (scrubTimer.current) clearTimeout(scrubTimer.current);
            scrubTimer.current = setTimeout(commitScrub, 900);
            return;
          }
          if (isOk) { if (c.scrubTo != null) commitScrub(); else togglePause(); return; }
          if (keyCode === 20) { if (c.scrubTo != null) commitScrub(); setCtl({focus: playIdx}); showOverlay(keep); return; }
          if (keyCode === 19) { if (c.scrubTo != null) commitScrub(); if (playStatus.current.playing) hideOverlay(); return; }
        } else { // button row
          if (dir !== 0) { setCtl({focus: Math.max(1, Math.min(btns.length, f + dir * flip))}); showOverlay(keep); return; }
          if (keyCode === 19) { setCtl({focus: 0}); showOverlay(keep); return; }
          if (keyCode === 20) { showOverlay(keep); return; }
          if (isOk) {
            const id = btns[f - 1];
            showOverlay(keep);
            if (id === 'back10') seekBy(-10000);
            else if (id === 'fwd10') seekBy(10000);
            else if (id === 'play') togglePause();
            else if (id === 'next') { const ep = getNextEpisode(); if (ep) playEpisode(ep); }
            else if (id === 'cast') setShowCast(true);
            else if (id === 'tracks') toggleTrackMenu();
            else if (id === 'aspect') setAspectMode(m => m === ResizeMode.CONTAIN ? ResizeMode.COVER : m === ResizeMode.COVER ? ResizeMode.STRETCH : ResizeMode.CONTAIN);
            else if (id === 'sleep') cycleSleep();
            return;
          }
        }
      }
      switch (keyCode) {
        case 21: case 89: seekBy(-10000); break;          // left / rewind
        case 22: case 90: seekBy(10000); break;           // right / fast-forward
        case 19: case 166: zap(1); break;                 // up / channel up
        case 20: case 167: zap(-1); break;                // down / channel down
        case 23: case 66: case 160: case 96: case 85: togglePause(); break; // OK / A button / play-pause
        case 126: case 127: togglePause(); break;
        case 86: setPlayer(null); break;                              // STOP: close the player
        case 87: case 92: if (player?.live) zap(1); else seekBy(30000); break;   // NEXT / PAGE UP
        case 88: case 93: if (player?.live) zap(-1); else seekBy(-30000); break; // PREVIOUS / PAGE DOWN
        case 175: case 222: case 186: if (player?.native) toggleTrackMenu(); break; // CAPTIONS / AUDIO / BLUE: audio + subtitles
        case 185: setAspectMode(m => m === ResizeMode.CONTAIN ? ResizeMode.COVER : m === ResizeMode.COVER ? ResizeMode.STRETCH : ResizeMode.CONTAIN); break; // YELLOW: picture size
        case 183: cycleSleep(); break;                                // RED: sleep timer
        case 229: zapPrev(); break;                                   // LAST channel
        case 82: case 165: if (player?.native) toggleTrackMenu(); else if (player?.url) NativeModules.TurboPlayerModule?.openExternalVlc(player.url); break; // MENU / INFO -> Media3 track menu, otherwise VLC
        default:
          if (keyCode >= 7 && keyCode <= 16) enterDigit(keyCode - 7);
          else if (keyCode >= 144 && keyCode <= 153) enterDigit(keyCode - 144);
          break;
      }
    });
    return () => sub.remove();
  }, [player, deviceMode, tab, filtered, channels]);
  const continueItems = useMemo(() => {
    if (tab !== 'home' || player) return [] as Media[]; // the progress value changes every few seconds while playing
    const out: Media[] = [];
    const extra = heavyLoaded ? [] : (homeSummary || []);
    for (const list of [channels, movies, series, extra]) {
      for (const item of list) {
        const progress = watchProgress[channelKey(item)] || 0;
        if (progress > 1 && progress < 99) { out.push(item); if (out.length >= 8) return out; }
      }
    }
    // partly watched episodes are saved as "<seriesId>-<episodeId>": surface their series (opens the seasons screen)
    const bySid = new Map<string, Media>();
    for (const it of series) bySid.set(String(mediaId(it)), it);
    for (const it of extra) if ((it as any).kind === 'series') bySid.set(String(mediaId(it)), it);
    for (const k of Object.keys(watchProgress)) {
      const v = watchProgress[k];
      if (!(v > 1 && v < 99) || !/^\d+-\d+$/.test(k)) continue;
      const it = bySid.get(k.slice(0, k.indexOf('-')));
      if (it && !out.includes(it)) { out.push(it); if (out.length >= 8) break; }
    }
    return out;
  }, [tab, !!player, channels, movies, series, watchProgress, homeSummary, heavyLoaded]);
  // keep the saved home summary current (only while the full catalogue is in memory; debounced, signature-based)
  const summarySig = useMemo(() => {
    const need = new Set<string>([...recentKeys, ...favorites]);
    for (const k of Object.keys(watchProgress)) { const v = watchProgress[k]; if (v > 1 && v < 99) need.add(k); }
    return Array.from(need).sort().join('|');
  }, [recentKeys, favorites, watchProgress]);
  useEffect(() => {
    if (!activeProvider || !heavyLoaded || !catalogReady || (!movies.length && !series.length)) return;
    const t = setTimeout(() => {
      const need = new Set<string>(summarySig ? summarySig.split('|') : []);
      const seriesIds = new Set<string>();
      need.forEach(k => { if (/^\d+-\d+$/.test(k)) seriesIds.add(k.slice(0, k.indexOf('-'))); });
      const items: Media[] = [];
      const seen = new Set<string>();
      for (const list of [movies, series]) {
        for (const item of list) {
          const key = channelKey(item);
          if ((need.has(key) || ((item as any).kind === 'series' && seriesIds.has(String(mediaId(item))))) && !seen.has(key)) {
            seen.add(key);
            items.push(item);
            if (items.length >= 80) break;
          }
        }
      }
      cacheSet(`streambox.homeSummary.${activeProvider.id}`, JSON.stringify(items)).catch(() => undefined);
    }, 3000);
    return () => clearTimeout(t);
  }, [summarySig, heavyLoaded, catalogReady, movies, series, activeProvider?.id]);
  async function pickM3uFile() {
    try {
      // No file manager on this device (common on TV boxes): opening the picker would crash the app.
      const canPick = await NativeModules.TurboPlayerModule?.canPickFile?.();
      if (canPick === false) {
        Alert.alert(
          tx('لا يوجد مدير ملفات', 'No file manager'),
          tx('هذا الجهاز لا يحتوي على تطبيق لاختيار الملفات، ولذلك لا يمكن اختيار ملف M3U. ثبّت مدير ملفات (مثل X-plore أو File Commander) أو الصق رابط M3U بدل الملف.', 'This device has no app to pick files, so an M3U file cannot be chosen. Install a file manager (e.g. X-plore or File Commander) or paste the M3U link instead.')
        );
        return;
      }
      // '*/*': many TV file managers do not know the m3u MIME types and would show nothing (or fail).
      const result = await DocumentPicker.getDocumentAsync({
        type: '*/*',
        copyToCacheDirectory: true,
        multiple: false
      });
      if (result.canceled || !result.assets?.[0]?.uri) return;
      const asset = result.assets[0];
      if (!/\.(m3u8?|txt)$/i.test(asset.name || '') && !/mpegurl|text/i.test(asset.mimeType || '')) {
        Alert.alert(tx('ملف غير مدعوم', 'Unsupported file'), tx('اختر ملف قائمة بصيغة .m3u أو .m3u8.', 'Pick a playlist file (.m3u or .m3u8).'));
        return;
      }
      setForm({
        ...form,
        name: asset.name?.replace(/\.[^.]+$/, '') || 'قائمة M3U محلية',
        server: asset.uri,
        username: '',
        password: ''
      });
    } catch (e: any) {
      // Many Android TV boxes ship without a file manager / documents UI.
      Alert.alert(
        tx('تعذر فتح مستعرض الملفات', 'Could not open the file browser'),
        tx('هذا الجهاز لا يحتوي على مدير ملفات. ثبّت تطبيق مدير ملفات (مثل X-plore أو File Commander) أو استخدم رابط M3U بدل الملف.', 'This device has no file manager. Install one (e.g. X-plore or File Commander) or use an M3U URL instead.')
      );
    }
  }
  async function requestStorageAccess() {
    try {
      await AsyncStorage.setItem('streambox.storageAccessAsked', '1');
      const result = await FileSystem.StorageAccessFramework.requestDirectoryPermissionsAsync();
      if (result.granted && result.directoryUri) {
        setStorageDirectory(result.directoryUri);
        await AsyncStorage.setItem('streambox.storageDirectory', result.directoryUri);
        Alert.alert(tx('تم اختيار مجلد التخزين', 'Storage folder selected'), tx('سيتم حفظ نسخة من بيانات Xtream على الجهاز لتسريع الفتح والعمل دون إعادة التحميل كل مرة.', 'A copy of the Xtream data will be kept on the device so the app opens faster without reloading each time.'));
      }
    } catch {/* بعض أجهزة TV لا تعرض منتقي المجلدات؛ سيستمر الكاش الداخلي */}
  }
  async function saveExternalCatalog(provider: Provider, snapshot: any) {
    const targetDirectory = storageDirectory || (await AsyncStorage.getItem('streambox.storageDirectory'));
    if (!targetDirectory) return;
    try {
      const name = `TurboX_${provider.id}_${Date.now()}.json`;
      const fileUri = await FileSystem.StorageAccessFramework.createFileAsync(targetDirectory, name, 'application/json');
      await FileSystem.writeAsStringAsync(fileUri, JSON.stringify(snapshot));
    } catch {/* الكاش الداخلي يظل مصدرًا احتياطيًا */}
  }
  function openAdd() {
    setForm({name: `Profile ${providers.length + 1}`, server: '', username: '', password: ''});
    setEditingId(null);
    setLoginError(null);
    setShowAdd(true);
  }
  /** Open the server screen filled with an existing profile so its server/login can be fixed. */
  function openEdit(provider: Provider, error?: {title: string; text: string}) {
    setForm({name: provider.name, server: provider.server, username: provider.username, password: provider.password, userAgent: provider.userAgent || ''});
    setEditingId(provider.id);
    setLoginError(error || null);
    setShowAdd(true);
  }
  function closeAdd() {
    setShowAdd(false);
    setEditingId(null);
    setLoginError(null);
  }
  async function saveProvider(forceM3u?: boolean) {
    const m3u = forceM3u === true || isM3u(form.server);
    if (!form.server || !m3u && (!form.username || !form.password)) return Alert.alert(tx('بيانات ناقصة', 'Missing details'), m3u ? tx('أدخل رابط M3U.', 'Enter the M3U link.') : tx('أدخل رابط السيرفر واسم المستخدم وكلمة المرور.', 'Enter the server address, username and password.'));
    const fields = {
      ...form,
      server: form.server.trim(),
      username: m3u ? '' : form.username,
      password: m3u ? '' : form.password,
      m3u: m3u || undefined
    };
    let item: Provider;
    let next: Provider[];
    if (editingId) {
      // same id: favourites, hidden categories etc. stay; the catalogue is reloaded from the new server
      item = {...(providers.find(p => p.id === editingId) || {}), ...fields, id: editingId} as Provider;
      next = providers.map(p => p.id === editingId ? item : p);
      await removeSnapshot(`streambox.xtreamCache.${editingId}`);
      await cacheRemove(`streambox.epgCache.${editingId}`);
      await cacheRemove(`streambox.xmltv.${editingId}`);
    } else {
      item = {id: Date.now().toString(), ...fields};
      next = [...providers, item];
    }
    setProviders(next);
    await persistProviders(next);
    closeAdd();
    connect(item, !!editingId);
  }
  function confirmDeleteProvider(p: Provider) {
    setShowProfiles(false);
    setDeleteTarget(p); // remote-friendly ChoiceModal instead of a native Alert
  }
  async function deleteProvider(p: Provider) {
    const next = providers.filter(x => x.id !== p.id);
    setProviders(next);
    await persistProviders(next);
    await deleteSecret(p.id);
    await removeSnapshot(`streambox.xtreamCache.${p.id}`);
    await cacheRemove(`streambox.epgCache.${p.id}`);
    await cacheRemove(`streambox.xmltv.${p.id}`);
    if (activeProvider?.id !== p.id) return;
    connectSeq.current += 1; // drop any refresh still running for the deleted profile
    setRefreshing(false);
    setChannels([]); setMovies([]); setSeries([]);
    setCatalogReady(false); setCatalogProgress(0);
    setActiveProvider(null);
    if (next.length) connect(next[0]);
    else {
      await AsyncStorage.removeItem('streambox.activeProviderId');
      setForm({name: 'Profile 1', server: '', username: '', password: ''});
    }
  }
  async function connect(provider: Provider, force = false, opts: {startup?: StartupMode} = {}) {
    const seq = ++connectSeq.current;
    // where to land once the catalogue is ready (a normal switch always opens Live TV; app start follows Settings → Startup)
    const land = () => {
      if (opts.startup === 'home') return;
      setTab('live');
      if (opts.startup === 'last') setResumeLast(true);
    };
    const stale = () => seq !== connectSeq.current; // another profile was opened meanwhile
    setRefreshing(false);
    setSelectedCategory('All');
    setQuery('');
    setCatalogProgress(3);
    setCatalogReady(false);
    setCatalogLoading(true);
    setBusy(true);
    setActiveProvider(provider);
    await AsyncStorage.setItem('streambox.activeProviderId', provider.id);
    let cached = false; // a catalogue snapshot is already on screen
    let prevSnap: Snapshot | null = null; // the saved copy, used to fill in a list that fails to download
    try {
      await loadFavorites(provider.id);
      setCatalogProgress(10);
      if (isM3uProvider(provider)) {
        setSubscriptionExpiry('غير محدد');
        setAccountInfo(m3uAccountInfo(provider));
        const {items: list, epgUrl} = await loadM3u(provider.server);
        if (stale()) return;
        xmltvUrls.current[provider.id] = epgUrl;
        markUpdated(provider.id);
        setChannels(list.map(x => ({
          ...x,
          sourceId: provider.id
        })));
        setMovies([]);
        setSeries([]);
        setHeavyLoaded(true); // nothing on disk to load for an M3U list
        setCatalogCounts(null);
        setCatalogProgress(100);
        setCatalogReady(true);
        land();
        return;
      }
      const cacheKey = `streambox.xtreamCache.${provider.id}`;
      const auto = await loadAutomation();
      try {
        const snapT = Date.now();
        const snapshot = await readSnapshot(cacheKey, true);
        logInfo('startup', `live snapshot read in ${Date.now() - snapT}ms (+${Date.now() - APP_T0}ms since launch)`);
        if (snapshot) {
          prevSnap = snapshot;
          setChannels(snapshot.channels);
          // movies/series of the PREVIOUS profile must never stay on screen: replace (or empty) them now
          setMovies(snapshot.movies);
          setSeries(snapshot.series);
          setHeavyLoaded(snapshot.heavy !== false);
          setCatalogCounts(snapshot.counts || null);
          if (snapshot.expiresAt) setSubscriptionExpiry(String(snapshot.expiresAt));
          setCatalogProgress(100);
          setCatalogReady(true);
          cached = true;
          if (snapshot.savedAt) setUpdatedAt(u => ({...u, [provider.id]: Number(snapshot.savedAt)}));
          if (!force && isCacheFresh(Number(snapshot.savedAt || 0), Date.now(), auto.catalogEnabled, auto.catalogDays)) {
            land();
            return;
          }
          setRefreshing(true); // show the saved copy now, refresh quietly behind it
          if (!force) land();
        }
      } catch (err) {
        logWarn('cache', `unreadable snapshot, ignoring: ${(err as any)?.message || err}`);
        await removeSnapshot(cacheKey);
      }
      setCatalogProgress(18);
      const info = await xtream<any>(provider);
      if (stale()) return;
      setCatalogProgress(28);
      const expiry = info?.user_info?.exp_date ? new Date(Number(info.user_info.exp_date) * 1000).toLocaleDateString('ar-EG') : 'غير محدد';
      setSubscriptionExpiry(expiry);
      setAccountInfo(accountInfoFromPayload(info, provider));
      const [live, vod, shows, liveCats, vodCats, seriesCats] = await Promise.all([xtream<Media[]>(provider, 'action=get_live_streams').catch(() => null), xtream<Media[]>(provider, 'action=get_vod_streams').catch(() => null), xtream<Media[]>(provider, 'action=get_series').catch(() => null), xtream<any[]>(provider, 'action=get_live_categories').catch(() => []), xtream<any[]>(provider, 'action=get_vod_categories').catch(() => []), xtream<any[]>(provider, 'action=get_series_categories').catch(() => [])]);
      if (stale()) return;
      setCatalogProgress(76);
      const catMap = (items: any[]) => Object.fromEntries((Array.isArray(items) ? items : []).map(x => [String(x.category_id), x.category_name]));
      const liveMap = catMap(liveCats as any[]),
        vodMap = catMap(vodCats as any[]),
        seriesMap = catMap(seriesCats as any[]);
      const liveItems = slimList((Array.isArray(live) ? live : []).map(x => ({
        ...x,
        sourceId: provider.id,
        category_name: x.category_name || liveMap[String((x as any).category_id)] || 'عام',
        kind: 'live' as const
      })));
      const movieItems = slimList((Array.isArray(vod) ? vod : []).map(x => ({
        ...x,
        sourceId: provider.id,
        category_name: x.category_name || vodMap[String((x as any).category_id)] || 'عام',
        kind: 'movie' as const
      })));
      const seriesItems = slimList((Array.isArray(shows) ? shows : []).map(x => ({
        ...x,
        stream_id: (x as any).stream_id ?? (x as any).series_id ?? (x as any).id,
        series_id: (x as any).series_id ?? (x as any).stream_id ?? (x as any).id,
        sourceId: provider.id,
        category_name: x.category_name || seriesMap[String((x as any).category_id)] || 'عام',
        kind: 'series' as const
      })));
      // a list that failed to download (null) must not wipe the saved one; an entirely empty reply is a server fault
      const failed = {live: live === null, vod: vod === null, shows: shows === null};
      if ((failed.vod || failed.shows) && prevSnap && prevSnap.heavy === false) {
        const saved = await readHeavy(cacheKey);
        if (!saved) throw new IptvError('server', 'saved lists unreadable'); // keep what is on screen rather than writing an empty list
        prevSnap = {...prevSnap, movies: saved.movies, series: saved.series, heavy: true};
      }
      const liveFinal = failed.live && prevSnap ? prevSnap.channels : liveItems;
      const movieFinal = failed.vod && prevSnap ? prevSnap.movies : movieItems;
      const seriesFinal = failed.shows && prevSnap ? prevSnap.series : seriesItems;
      if (!liveFinal.length && !movieFinal.length && !seriesFinal.length) throw new IptvError('server', 'empty catalogue');
      setCatalogProgress(88);
      setChannels(liveFinal);
      setMovies(movieFinal);
      setSeries(seriesFinal);
      setHeavyLoaded(true);
      setCatalogCounts({live: liveFinal.length, movies: movieFinal.length, series: seriesFinal.length});
      const safe = (items: Media[]) => items.map(({
        sourceServer,
        sourceUsername,
        sourcePassword,
        ...item
      }) => item);
      const snapshot: Snapshot = {
        savedAt: Date.now(),
        expiresAt: expiry,
        channels: safe(liveFinal),
        movies: safe(movieFinal),
        series: safe(seriesFinal)
      };
      writeSnapshot(cacheKey, snapshot).catch(err => logWarn('cache', `could not save catalogue: ${err?.message || err}`));
      logInfo('connect', `${provider.name}: loaded ${liveFinal.length} live / ${movieFinal.length} movies / ${seriesFinal.length} series${failed.live || failed.vod || failed.shows ? ' (some lists failed, kept saved copy)' : ''}`);
      markUpdated(provider.id, snapshot.savedAt);
      setCatalogProgress(100);
      setCatalogReady(true);
      if (!cached) land(); // a saved copy was already shown: don't pull the user away from where they are
    } catch (e: any) {
      if (stale()) return;
      if (cached && !force) {
        // the weekly refresh failed but the saved catalogue is fine: keep using it, retry on next open
        logWarn('connect', `${provider.name}: background refresh failed, using saved copy (${e?.kind || ''} ${e?.detail || e?.message || ''})`);
        return;
      }
      setChannels([]);
      setMovies([]);
      setSeries([]);
      setCatalogProgress(0);
      setCatalogReady(false);
      // bring the server screen back (filled in) so the server / login can be corrected
      const d = describeError(e, langRef.current, !onlineRef.current);
      logError('connect', `${provider.name}: ${d.kind} ${e?.detail || e?.message || ''}`);
      openEdit(provider, {title: d.title, text: d.text});
    } finally {
      if (!stale()) {
        setCatalogLoading(false);
        setBusy(false);
        setRefreshing(false);
      }
    }
  }
  function markUpdated(id: string, at = Date.now()) {
    setUpdatedAt(u => ({...u, [id]: at}));
    AsyncStorage.setItem(`streambox.lastUpdated.${id}`, String(at)).catch(() => undefined);
  }
  function ago(ts?: number) {
    if (!ts) return tx('لم يُحدَّث بعد', 'Not updated yet');
    const min = Math.max(0, Math.round((Date.now() - ts) / 60000));
    if (min < 2) return tx('آخر تحديث: الآن', 'Updated: just now');
    if (min < 60) return tx(`آخر تحديث: منذ ${min} دقيقة`, `Updated ${min} min ago`);
    const h = Math.round(min / 60);
    if (h < 24) return tx(`آخر تحديث: منذ ${h} ساعة`, `Updated ${h} h ago`);
    const d = Math.round(h / 24);
    return tx(`آخر تحديث: منذ ${d} يوم`, `Updated ${d} d ago`);
  }
  // read each profile's last-updated time whenever the Profiles screen opens
  useEffect(() => {
    if (!showProfiles) return;
    AsyncStorage.multiGet(providers.map(p => `streambox.lastUpdated.${p.id}`)).then(rows => {
      const next: Record<string, number> = {};
      rows.forEach(([k, v], i) => { if (v) next[providers[i].id] = Number(v); });
      setUpdatedAt(u => ({...next, ...u})); // values already in memory are the freshest
    }).catch(() => undefined);
  }, [showProfiles]);
  useEffect(() => {
    if (!activeProvider) return;
    let alive = true;
    AsyncStorage.multiGet([`streambox.hiddenCats.${activeProvider.id}`, `streambox.recentPlayed.${activeProvider.id}`]).then(values => {
      if (!alive) return;
      try { const h = values[0][1] ? JSON.parse(values[0][1] as string) : null; setHiddenCats({live: h?.live || [], movies: h?.movies || [], series: h?.series || []}); } catch { setHiddenCats({live: [], movies: [], series: []}); }
      try { setRecentKeys(values[1][1] ? JSON.parse(values[1][1] as string) : []); } catch { setRecentKeys([]); }
    }).catch(() => undefined);
    return () => { alive = false; };
  }, [activeProvider?.id]);
  async function saveHidden(next: Record<CatTab, string[]>) {
    setHiddenCats(next);
    if (activeProvider) await AsyncStorage.setItem(`streambox.hiddenCats.${activeProvider.id}`, JSON.stringify(next));
    if (selectedCategory !== 'All' && !selectedCategory.startsWith('__') && next[tab === 'movies' ? 'movies' : tab === 'series' ? 'series' : 'live'].includes(selectedCategory)) setSelectedCategory('All');
  }
  function toggleHidden(t: CatTab, name: string) {
    const cur = hiddenCats[t];
    saveHidden({...hiddenCats, [t]: cur.includes(name) ? cur.filter(x => x !== name) : [...cur, name]});
  }
  function recordRecent(key: string) {
    if (!activeProvider || !key) return;
    setRecentKeys(prev => {
      const next = [key, ...prev.filter(k => k !== key)].slice(0, 20);
      AsyncStorage.setItem(`streambox.recentPlayed.${activeProvider.id}`, JSON.stringify(next)).catch(() => undefined);
      return next;
    });
  }
  const itemsByKey = useMemo(() => {
    const map = new Map<string, Media>();
    if (tab !== 'home') return map; // only the home rows look items up by key
    [...channels, ...movies, ...series].forEach(item => map.set(channelKey(item), item));
    if (homeSummary) for (const item of homeSummary) { const k = channelKey(item); if (!map.has(k)) map.set(k, item); }
    return map;
  }, [tab, channels, movies, series, homeSummary]);
  const homeRows: HomeRowData[] = useMemo(() => {
    const toRow = (keys: string[]) => keys.map(k => itemsByKey.get(k)).filter(Boolean).slice(0, 20).map(item => ({
      key: channelKey(item as Media),
      name: (item as Media).name,
      icon: (item as Media).stream_icon || (item as Media).cover,
      onPress: () => playItem(item as Media)
    }));
    return [
      {id: 'recent', title: tx('شاهدتها مؤخرًا', 'Recently watched'), icon: 'time', items: toRow(recentKeys)},
      {id: 'fav', title: tx('المفضلة', 'Favorites'), icon: 'star', items: toRow([...favorites].reverse())}
    ];
  }, [itemsByKey, recentKeys, favorites, language]);

  // ---- Sleep timer
  function setSleepMinutes(min: number) {
    setSleepMin(min);
    setSleepEnd(min > 0 ? Date.now() + min * 60000 : null);
  }
  function cycleSleep() {
    const steps = [0, 30, 60, 90, 120];
    const next = steps[(Math.max(0, steps.indexOf(sleepMin)) + 1) % steps.length];
    setSleepMinutes(next);
    flash(next ? `🌙 ${next} ${tx('د', 'min')}` : `🌙 ${tx('إيقاف', 'Off')}`);
    showOverlay();
  }
  useEffect(() => {
    if (!sleepEnd) return;
    const timer = setTimeout(() => {
      setSleepEnd(null);
      setSleepMin(0);
      if (player) {
        setPlayer(null);
        Alert.alert(tx('مؤقت النوم', 'Sleep timer'), tx('تم إيقاف التشغيل.', 'Playback was stopped.'));
      }
    }, Math.max(0, sleepEnd - Date.now()));
    return () => clearTimeout(timer);
  }, [sleepEnd, !!player]);
  useEffect(() => {
    if (!sleepEnd || !player) return;
    const id = setInterval(() => setSleepTick(x => x + 1), 1000);
    return () => clearInterval(id);
  }, [sleepEnd, !!player]);
  const sleepLeft = (() => {
    if (!sleepEnd) return null;
    const sec = Math.max(0, Math.round((sleepEnd - Date.now()) / 1000));
    return `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}`;
  })();
  void sleepTick;

  async function loadFavorites(providerId: string) {
    const [rawLists, rawActive] = await Promise.all([AsyncStorage.getItem(favListsKey(providerId)), AsyncStorage.getItem(`streambox.favActive.${providerId}`)]);
    let stored: unknown = null;
    try { stored = rawLists ? JSON.parse(rawLists) : null; } catch { /* corrupt: start from the default list */ }
    const lists = normalizeLists(stored, 'المفضلة');
    const activeId = lists.some(l => l.id === rawActive) ? (rawActive as string) : DEFAULT_LIST_ID;
    const rawItems = await AsyncStorage.getItem(favItemsKey(providerId, activeId, profileRef.current));
    let items: string[] = [];
    try { items = rawItems ? JSON.parse(rawItems) : []; } catch { /* corrupt */ }
    setFavLists(lists);
    setActiveFavId(activeId);
    setFavorites(Array.isArray(items) ? items : []);
  }
  async function toggleFavorite(item: Media) {
    if (!activeProvider) return;
    if (!favHintSeen) { setFavHintSeen(true); AsyncStorage.setItem('streambox.favHint', '1').catch(() => undefined); }
    const key = channelKey(item);
    const next = favorites.includes(key) ? favorites.filter(x => x !== key) : [...favorites, key];
    setFavorites(next);
    await AsyncStorage.setItem(favItemsKey(activeProvider.id, activeFavId, profileRef.current), JSON.stringify(next));
  }
  async function selectFavList(id: string) {
    if (!activeProvider || id === activeFavId) return;
    setActiveFavId(id);
    await AsyncStorage.setItem(`streambox.favActive.${activeProvider.id}`, id);
    const raw = await AsyncStorage.getItem(favItemsKey(activeProvider.id, id, profileRef.current));
    try { setFavorites(raw ? JSON.parse(raw) : []); } catch { setFavorites([]); }
  }
  async function addFavList() {
    const name = listDraft.trim();
    if (!name || !activeProvider) return;
    const list = {id: Date.now().toString(), name};
    const next = [...favLists, list];
    setFavLists(next);
    setListDraft('');
    await AsyncStorage.setItem(favListsKey(activeProvider.id), JSON.stringify(next));
    await selectFavList(list.id);
  }
  async function deleteFavList(id: string) {
    if (!activeProvider || id === DEFAULT_LIST_ID) return;
    const next = favLists.filter(l => l.id !== id);
    setFavLists(next);
    await AsyncStorage.setItem(favListsKey(activeProvider.id), JSON.stringify(next));
    await AsyncStorage.removeItem(favItemsKey(activeProvider.id, id, profileRef.current));
    if (activeFavId === id) await selectFavList(DEFAULT_LIST_ID);
  }
  function providerForItem(item: Media) {
    if (item.sourceServer && item.sourceUsername && item.sourcePassword) return {
      id: item.sourceId || 'embedded',
      name: 'Xtream',
      server: item.sourceServer,
      username: item.sourceUsername,
      password: item.sourcePassword
    };
    const saved = item.sourceId && providers.find(p => p.id === item.sourceId && p.username && p.password);
    if (saved) return saved;
    if (activeProvider?.username && activeProvider.password) return activeProvider;
    return providers.find(p => p.username && p.password && !isM3uProvider(p)) || null;
  }
  function streamUrlCandidates(item: Media) {
    if (item.url) return [item.url];
    const source = providerForItem(item);
    if (!source || !mediaId(item)) return [];
    const folder = item.kind === 'movie' ? 'movie' : 'live';
    const exts = item.kind === 'movie'
      ? [...new Set([item.container_extension, 'mp4', 'mkv'].filter((x): x is string => !!x))]
      : [item.container_extension || 'ts'];
    const out: string[] = [];
    for (const ext of exts) {
      for (const base of serverCandidates(source.server)) out.push(`${base}/${folder}/${source.username}/${source.password}/${mediaId(item)}.${ext}`);
    }
    return out;
  }
  function streamUrl(item: Media) {
    return streamUrlCandidates(item)[0] || '';
  }
  function playbackHeaders(item: Media) {
    const source = providerForItem(item);
    const base = source ? normalizeServer(source.server) : '';
    return {
      'User-Agent': uaFor(source),
      'Accept': '*/*',
      ...(base ? {'Referer': `${base}/`, 'Origin': base} : {})
    };
  }
  async function openSeries(item: Media) {
    const source = providerForItem(item);
    const seriesId = mediaId(item);
    if (!seriesId) return Alert.alert(tx('غير متاح', 'Unavailable'), tx('هذا المسلسل لا يحتوي على رقم تعريف صالح من مزود Xtream.', 'This series has no valid Xtream ID.'));
    if (!source?.server || !source.username || !source.password) return Alert.alert(tx('غير متاح', 'Unavailable'), tx('أعد الاتصال بمصدر Xtream أولًا لتحميل المواسم.', 'Reconnect to the Xtream source first to load the seasons.'));
    const pausedUntil = gov.pausedUntil(source.id, 'info');
    if (pausedUntil) {
      const secs = Math.ceil((pausedUntil - Date.now()) / 1000);
      logWarn('series', `seasons skipped for ${item.name}: provider refused details recently, retry in ${secs}s`);
      return Alert.alert(tx('المزوّد رفض طلبات التفاصيل', 'The provider refused detail requests'), tx(`رفض المزوّد طلبات التفاصيل عدة مرات متتالية، فأوقفنا الطلب مؤقتًا لتجنب الحظر. جرّب بعد ${secs} ثانية.`, `The provider refused several detail requests in a row, so we paused to avoid being blocked. Try again in ${secs} s.`));
    }
    setActiveProvider(source);
    await AsyncStorage.setItem('streambox.activeProviderId', source.id);
    setBusy(true);
    try {
      const data = await xtream<any>(source, `action=get_series_info&series_id=${seriesId}`, {quick: true, timeoutMs: 20000});
      gov.success(source.id, 'info');
      const seasons = data?.episodes || {};
      if (!Object.keys(seasons).length) throw new Error('لا توجد مواسم متاحة لهذا المسلسل.');
      setSelectedSeries(item);
      setEpisodesBySeason(seasons);
      setSelectedSeason(Object.keys(seasons)[0] || '');
      setShowSeasons(true);
    } catch (e: any) {
      const detail = String(e?.detail || e?.message || '');
      if (e?.kind || /HTTP|timeout/i.test(detail)) gov.failure(source.id, 'info'); // a refusal/timeout counts; "no seasons" does not
      logWarn('series', `seasons unavailable for ${item.name}: ${e?.kind || ''} ${detail}`);
      const refused = /HTTP 4\d\d/.test(detail);
      Alert.alert(
        tx('تعذر تحميل المواسم', 'Could not load the seasons'),
        refused
          ? tx(`رفض السيرفر طلب تفاصيل هذا المسلسل (${detail.slice(0, 90)}). تغيير الشبكة لا يفيد عادةً: القيد من المزوّد أو الحساب. شارك السجل معه.`, `The server refused this series' details (${detail.slice(0, 90)}). Changing network usually does not help: the limit is on the provider/account side. Share the log with them.`)
          : tx('حاول مرة أخرى.', 'Please try again.'),
        [{text: tx('إغلاق', 'Close'), style: 'cancel'}, {text: tx('إعادة المحاولة', 'Retry'), onPress: () => openSeries(item)}]
      );
    } finally {
      setBusy(false);
    }
  }
  async function launchPlayer(p: any) {
    if (playerEngine !== 'builtin' && playerEngine !== 'media3') {
      const opt = PLAYER_OPTIONS.find(o => o.id === playerEngine);
      const headers: string[] = [];
      Object.entries(p.headers || {}).forEach(([k, v]) => { headers.push(k, String(v)); });
      try {
        const ok = await NativeModules.TurboPlayerModule?.openExternalPlayer(p.url, p.title || '', opt?.packages || '', headers);
        if (ok) return;
      } catch {/* fall back below */}
      Alert.alert(tx('المشغّل غير مثبت', 'Player not installed'), tx(`تعذر فتح ${opt?.ar}. سيتم استخدام المشغّل المدمج.`, `Could not open ${opt?.en}. Using the built-in player instead.`));
    }
    setPlayer(playerEngine === 'media3' ? {...p, native: true} : p);
  }
  async function saveAutomationSettings(next: Automation) {
    setAutomation(next);
    await saveAutomation(next);
  }
  async function updateNow() {
    setShowAutomation(false);
    if (!activeProvider) return;
    await cacheRemove(`streambox.epgCache.${activeProvider.id}`);
    await cacheRemove(`streambox.xmltv.${activeProvider.id}`);
    setEpgTick(t => t + 1);
    connect(activeProvider, true);
  }
  async function choosePlayerEngine(v: PlayerEngine) {
    setPlayerEngine(v);
    setShowPlayerPicker(false);
    await AsyncStorage.setItem('streambox.playerEngine', v);
  }
  async function playItem(item: Media, direct = false) {
    if (parentalPin && item.kind !== 'live') {
      setPendingAction(null);
      setPendingMedia(item);
      setVerifyDraft('');
      setShowVerify(true);
      return;
    }
    proceedItem(item, direct);
  }
  /** series → seasons screen, movie → details page (unless direct), everything else plays. */
  function proceedItem(item: Media, direct = false) {
    if (item.kind === 'series') return openSeries(item);
    const source = providerForItem(item);
    if (item.kind === 'movie' && !direct && source && !isM3uProvider(source)) return openMovie(item);
    startPlayback(item);
  }
  function startPlayback(item: Media) {
    recordRecent(channelKey(item));
    const urls = streamUrlCandidates(item);
    if (!urls.length) return Alert.alert(tx('لا يوجد رابط تشغيل', 'No stream link'), tx('لم يتم العثور على رابط لهذا العنصر.', 'No link was found for this item.'));
    launchPlayer({
      title: item.name,
      url: urls[0],
      fallbackUrls: urls.slice(1),
      allUrls: urls,
      headers: playbackHeaders(item),
      mediaKey: channelKey(item),
      live: item.kind === 'live'
    });
  }
  async function openMovie(item: Media) {
    setSelectedMovie(item);
    setMovieInfo(null);
    setShowMovie(true);
    const source = providerForItem(item);
    const id = mediaId(item);
    if (!source || isM3uProvider(source) || !id) return;
    const pausedUntil = gov.pausedUntil(source.id, 'info');
    if (pausedUntil) { logWarn('vod', `details skipped for ${item.name}: provider refused details recently, retry in ${Math.ceil((pausedUntil - Date.now()) / 1000)}s`); return; }
    setMovieLoading(true);
    try {
      setMovieInfo(await xtream<any>(source, `action=get_vod_info&vod_id=${encodeURIComponent(String(id))}`, {quick: true}));
      gov.success(source.id, 'info');
    } catch (e: any) {
      gov.failure(source.id, 'info');
      logWarn('vod', `details unavailable for ${item.name}: ${e?.kind || ''} ${e?.detail || e?.message || ''}`);
    } finally {
      setMovieLoading(false);
    }
  }
  function openTrailer() {
    const yt = String(movieInfo?.info?.youtube_trailer || '').trim();
    if (!yt) return;
    Linking.openURL(/^https?:/i.test(yt) ? yt : `https://www.youtube.com/watch?v=${yt}`).catch(() => undefined);
  }
  /** Xtream listing → Prog. Titles/descriptions are base64 on Xtream. */
  function toProg(p: any, archiveChannel: boolean): Prog | null {
    const t = decodeEpgText(p.title || p.name);
    const s = Number(p.start_timestamp || p.start_time || 0);
    const e = Number(p.stop_timestamp || p.end_timestamp || p.end_time || 0);
    if (!t || !s || !e) return null;
    const flag = p.has_archive;
    return {s, e, t, d: decodeEpgText(p.description) || undefined, start: typeof p.start === 'string' ? p.start : undefined, archive: archiveChannel && (flag === undefined ? true : String(flag) === '1')};
  }
  /** Guide of one channel (cached per profile). Catch-up channels use the full-day table so past programmes are included. */
  async function guideFor(ch: Media): Promise<Prog[]> {
    const k = channelKey(ch);
    if (guideCache.current[k]) return guideCache.current[k];
    let out: Prog[] = [];
    if (ch.url && !ch.stream_id) {
      out = (xmltvData.current[k] || []).map(x => ({s: x.s, e: x.e, t: x.t, d: x.d}));
    } else {
      const source = providerForItem(ch);
      const id = mediaId(ch);
      if (source && !isM3uProvider(source) && id) {
        const archive = Number((ch as any).tv_archive) === 1;
        if (Date.now() < Math.max(epgBackoff.current[source.id] || 0, gov.pausedUntil(source.id, 'epg'))) return []; // provider is refusing guide requests
        const load = async (action: string) => {
          const wait = gov.paceDelay(source.id, 'epg', 200);
          if (wait > 0) await sleepMs(wait);
          const res = await xtream<any>(source, `${action}&stream_id=${encodeURIComponent(String(id))}`, {quick: true});
          return Array.isArray(res?.epg_listings) ? res.epg_listings : [];
        };
        let list: any[] = [];
        let failed = false;
        try { list = await load(archive ? 'action=get_simple_data_table' : 'action=get_short_epg&limit=24'); } catch { failed = true; /* try the short guide */ }
        if (!list.length && archive) { try { list = await load('action=get_short_epg&limit=24'); failed = false; } catch { failed = true; /* no guide */ } }
        if (list.length) gov.success(source.id, 'epg');
        else if (failed) {
          const r = gov.failure(source.id, 'epg');
          if (r.tripped) { epgBackoff.current[source.id] = r.until; logWarn('epg', `${source.name}: guide requests keep failing, pausing for ${Math.round((r.until - Date.now()) / 60000)} min`); }
        }
        out = list.map(x => toProg(x, archive)).filter((x): x is Prog => !!x);
      }
    }
    out.sort((a, b) => a.s - b.s);
    if (out.length) guideCache.current[k] = out; // don't cache failures: retry on the next open
    return out;
  }
  function playCatchup(ch: Media, p: Prog) {
    const source = providerForItem(ch);
    const id = mediaId(ch);
    if (!source || isM3uProvider(source) || !id || !p.start) return;
    const days = Number((ch as any).tv_archive_duration) || 0;
    if (days && p.s < Date.now() / 1000 - days * 86400) {
      return Alert.alert(tx('خارج مدة الأرشيف', 'Outside the archive window'), tx(`هذه القناة تحفظ ${days} يومًا فقط.`, `This channel keeps ${days} day(s) only.`));
    }
    const base = streamUrl(ch).match(/^https?:\/\/[^/]+/i)?.[0] || '';
    const url = base ? timeshiftUrl(base, source.username, source.password, Math.ceil((p.e - p.s) / 60), p.start, id) : null;
    if (!url) return;
    logInfo('catchup', `${ch.name}: ${p.t}`);
    setShowTimeline(false);
    setShowEpg(false);
    launchPlayer({title: `${ch.name} · ${p.t}`, url, headers: playbackHeaders(ch), live: false});
  }
  function pickProgram(ch: Media, p: Prog) {
    const nowSec = Date.now() / 1000;
    if (p.s <= nowSec && nowSec < p.e) { setShowTimeline(false); setShowEpg(false); playItem(ch); return; }
    if (p.e <= nowSec && p.archive) { playCatchup(ch, p); return; }
    Alert.alert(p.t, `${hhmm(p.s)} – ${hhmm(p.e)}${p.d ? `\n\n${p.d}` : ''}`);
  }
  async function toggleKid(p: Provider) {
    const next = providers.map(x => x.id === p.id ? {...x, kid: !x.kid} : x);
    setProviders(next);
    await persistProviders(next);
    if (activeProvider?.id === p.id) setActiveProvider({...activeProvider, kid: !p.kid});
    if (!p.kid && !parentalPin) Alert.alert(tx('وضع الأطفال', 'Kids mode'), tx('تم التفعيل. لقفل الخروج منه، اضبط PIN من Parental Control.', 'Enabled. To lock leaving it, set a PIN in Parental Control.'));
  }
  async function chooseStartup(id: string) {
    const mode = parseStartup(id);
    setStartupMode(mode);
    setShowStartup(false);
    await AsyncStorage.setItem(STARTUP_KEY, mode);
  }
  async function openLogs() {
    setLogEntries([...(await getLogs())]);
    setShowLogs(true);
  }
  async function shareLogs() {
    const header = `TurboX | ${Platform.OS} ${Platform.Version} | ${deviceMode || ''} | profiles ${providers.length} | ${new Date().toISOString()}`;
    Share.share({message: formatLogs(logEntries, header)}).catch(() => undefined);
  }
  async function chooseLanguage(next: 'ar' | 'en') {
    setLanguage(next);
    setShowLanguage(false);
    await AsyncStorage.setItem('streambox.language', next);
  }
  async function saveParental() {
    if (pinDraft && pinDraft.length < 4) return Alert.alert(tx('PIN غير صالح', 'Invalid PIN'), tx('استخدم 4 أرقام على الأقل.', 'Use at least 4 digits.'));
    setParentalPin(pinDraft);
    await savePin(pinDraft);
    setShowParental(false);
    Alert.alert(tx('تم الحفظ', 'Saved'), pinDraft ? tx('تم تفعيل Parental Control.', 'Parental Control is on.') : tx('تم إيقاف Parental Control.', 'Parental Control is off.'));
  }
  function verifyAndPlay() {
    if (verifyDraft !== parentalPin) return Alert.alert(tx('PIN غير صحيح', 'Wrong PIN'), tx('أدخل رمز الرقابة الصحيح.', 'Enter the correct parental PIN.'));
    setShowVerify(false);
    if (pendingAction) { const run = pendingAction; setPendingAction(null); run(); return; }
    if (!pendingMedia) return;
    const item = pendingMedia;
    setPendingMedia(null);
    proceedItem(item);
  }
  function playEpisode(episode: any) {
    const source = selectedSeries ? providerForItem(selectedSeries) : null;
    if (!source || !selectedSeries) return;
    setShowSeasons(false);
    if (selectedSeries) recordRecent(channelKey(selectedSeries));
    launchPlayer({
      title: `${selectedSeries.name} · ${episode.title || `Episode ${episode.episode_num || ''}`}`,
      mediaKey: `${mediaId(selectedSeries)}-${episode.id}`,
      live: false,
      headers: {'User-Agent': uaFor(source), 'Accept': '*/*', 'Referer': `${normalizeServer(source.server)}/`, 'Origin': normalizeServer(source.server)},
      url: `${normalizeServer(source.server)}/series/${source.username}/${source.password}/${episode.id}.${episode.container_extension || 'mp4'}`
    });
  }
  async function testConnection() {
    if (!activeProvider) return Alert.alert(tx('اختبار الاتصال', 'Connection test'), tx('اختر Profile أولًا.', 'Pick a profile first.'));
    setDiagnosticBusy(true);
    setDiagnosticLabel(tx('جاري الاختبار…', 'Testing…'));
    const started = Date.now();
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);
    try {
      const response = await fetch(`${normalizeServer(activeProvider.server)}/player_api.php?username=${encodeURIComponent(activeProvider.username)}&password=${encodeURIComponent(activeProvider.password)}`, {
        signal: controller.signal
      });
      const latency = Date.now() - started;
      if (!response.ok) throw new IptvError(kindFromHttp(response.status), `HTTP ${response.status}`);
      const data = await response.json();
      const bad = kindFromPayload(data);
      if (bad) throw new IptvError(bad);
      setDiagnosticLabel(tx(`متصل · ${latency}ms`, `Connected · ${latency}ms`));
      Alert.alert(tx('اختبار الاتصال', 'Connection test'), tx(`المصدر متصل بنجاح.\nزمن الاستجابة: ${latency}ms`, `Connected.\nResponse time: ${latency}ms`));
    } catch (error: any) {
      const err = error instanceof IptvError ? error : new IptvError(error?.name === 'AbortError' ? 'timeout' : error instanceof SyntaxError ? 'badresponse' : 'unreachable', error?.name === 'AbortError' ? '8s' : '');
      const d = describeError(err, langRef.current, !onlineRef.current);
      logError('diagnostics', `${activeProvider.name}: ${d.kind}`);
      setDiagnosticLabel(`${tx('فشل', 'Failed')} · ${d.title}`);
      Alert.alert(tx('اختبار الاتصال', 'Connection test'), `${d.title}\n${d.text}`);
    } finally {
      clearTimeout(timeout);
      setDiagnosticBusy(false);
    }
  }
  /** No channel → the TV-guide timeline. With a channel → that channel's programme list (and catch-up). */
  async function openEpg(channel?: Media) {
    if (!channel) { setShowTimeline(true); return; }
    setEpgQuery('');
    setEpgChannel(channel);
    setEpgPrograms([]);
    setShowEpg(true);
    InteractionManager.runAfterInteractions(() => {
      (async () => {
        setEpgLoading(true);
        try {
          const list = await guideFor(channel);
          const nowSec = Date.now() / 1000;
          setEpgPrograms(list.filter(x => x.e > nowSec || x.archive).map(x => ({title: x.t, description: x.d || '', start: hhmm(x.s), start_timestamp: x.s, _prog: x})));
        } catch {
          setEpgPrograms([]);
        } finally {
          setEpgLoading(false);
        }
      })();
    });
  }
  // M3U sources: "now playing" + EPG from the XMLTV guide named in the playlist header (url-tvg).
  useEffect(() => {
    if (tab !== 'live' || !activeProvider || !isM3uProvider(activeProvider) || !channels.length) return;
    let cancelled = false;
    const provider = activeProvider;
    const task = InteractionManager.runAfterInteractions(() => {
      (async () => {
        const auto = await loadAutomation();
        const cacheKey = `streambox.xmltv.${provider.id}`;
        const nowMap = (data: Record<string, XmltvListing[]>) => {
          const now = Date.now() / 1000;
          const out: Record<string, string> = {};
          Object.keys(data).forEach(k => { const cur = data[k].find(p => now >= p.s && now < p.e); if (cur) out[k] = cur.t; });
          return out;
        };
        let cache: {savedAt: number; data: Record<string, XmltvListing[]>} | null = null;
        try { const raw = await cacheGet(cacheKey); if (raw) cache = JSON.parse(raw); } catch {/* ignore */}
        if (cache?.data) {
          const keys = Object.keys(cache.data);
          const covered = Object.keys(nowMap(cache.data)).length;
          const coversNow = keys.length > 0 && covered >= keys.length / 2;
          const due = auto.epgEnabled && (Date.now() - cache.savedAt > auto.epgDays * 86400000 || !coversNow);
          xmltvData.current = cache.data;
          if (!cancelled) setNowPlaying(nowMap(cache.data));
          if (!due) return;
        }
        const url = xmltvUrls.current[provider.id];
        if (!url) return; // playlist has no guide URL
        try {
          // which XMLTV ids / names belong to which channel of this playlist
          const wanted = new Map<string, string[]>();
          const add = (k: string, key: string) => { if (!k) return; const a = wanted.get(k); if (a) a.push(key); else wanted.set(k, [key]); };
          channels.forEach(ch => {
            const key = channelKey(ch);
            if (ch.tvgId) add(ch.tvgId.toLowerCase(), key);
            add(normName(ch.tvgName || ''), key);
            add(normName(ch.name || ''), key);
          });
          const xml = await fetchXmltv(url, undefined, undefined, provider.userAgent);
          const data = await parseXmltv(xml, wanted);
          if (cancelled) return;
          xmltvData.current = data;
          setNowPlaying(nowMap(data));
          cacheSet(cacheKey, JSON.stringify({savedAt: Date.now(), data})).catch(() => undefined);
        } catch {/* keep whatever cached guide we have */}
      })();
    });
    return () => { cancelled = true; task.cancel?.(); };
  }, [tab, activeProvider?.id, channels.length, epgTick]);
  useEffect(() => {
    if (tab !== 'live' || !activeProvider || isM3uProvider(activeProvider) || !channels.length) return;
    let cancelled = false;
    const provider = activeProvider;
    const task = InteractionManager.runAfterInteractions(() => {
      (async () => {
        type Listing = {t: string; s: number; e: number};
        const auto = await loadAutomation();
        const cacheKey = `streambox.epgCache.${provider.id}`;
        const current = (list: Listing[]) => {
          const now = Date.now() / 1000;
          const cur = list.find(p => p.s && p.e && now >= p.s && now < p.e);
          return cur ? decodeEpgText(cur.t) : null;
        };
        const toNow = (data: Record<string, Listing[]>) => {
          const out: Record<string, string> = {};
          Object.keys(data).forEach(k => { const t = current(data[k]); if (t) out[k] = t; });
          return out;
        };
        let cache: {savedAt: number; data: Record<string, Listing[]>} | null = null;
        try {
          const raw = await cacheGet(cacheKey);
          if (raw) cache = JSON.parse(raw);
        } catch {/* ignore */}
        if (cache && cache.data) {
          const keys = Object.keys(cache.data);
          const covered = Object.keys(toNow(cache.data)).length;
          const coversNow = keys.length > 0 && covered >= keys.length / 2;
          // Auto-update ON: refresh when older than N days (or the cache no longer covers "now").
          // Auto-update OFF: keep using the saved guide until "Update now".
          const due = auto.epgEnabled && (Date.now() - cache.savedAt > auto.epgDays * 86400000 || !coversNow);
          if (!due) {
            if (!cancelled) setNowPlaying(toNow(cache.data));
            return;
          }
        }
        // a provider whose guide endpoint is failing must not be hammered: back off for 10 minutes
        if (Date.now() < (epgBackoff.current[provider.id] || 0)) return;
        const data: Record<string, Listing[]> = {};
        let ok = 0;
        // 2 at a time, 250 ms apart; stops as soon as 3 requests in a row fail (the old rule only stopped when NONE had
        // succeeded, so a provider that accepted a few and then refused got ~50 more requests in one second)
        await mapLimit<Media>(channels.slice(0, 60), 2, async channel => {
          const id = mediaId(channel);
          if (!id) return;
          const wait = gov.paceDelay(provider.id, 'epg', 250);
          if (wait > 0) await sleepMs(wait);
          if (cancelled || gov.pausedUntil(provider.id, 'epg')) return;
          try {
            const res = await xtream<any>(provider, `action=get_short_epg&stream_id=${encodeURIComponent(String(id))}&limit=20`, {quick: true});
            const list = Array.isArray(res?.epg_listings) ? res.epg_listings : [];
            data[channelKey(channel)] = list.map((program: any) => ({
              t: decodeEpgText(program.title || program.name || ''),
              s: Number(program.start_timestamp || program.start_time || 0),
              e: Number(program.stop_timestamp || program.end_timestamp || program.end_time || 0)
            })).filter((p: Listing) => p.t);
            ok += 1;
            gov.success(provider.id, 'epg');
          } catch {
            const r = gov.failure(provider.id, 'epg'); // skip this channel
            if (r.tripped) {
              epgBackoff.current[provider.id] = r.until;
              logWarn('epg', `${provider.name}: guide requests keep failing, pausing for ${Math.round((r.until - Date.now()) / 60000)} min`);
            }
          }
        }, () => cancelled || gov.pausedUntil(provider.id, 'epg') > 0);
        if (cancelled) return;
        if (ok === 0) {
          epgBackoff.current[provider.id] = Math.max(epgBackoff.current[provider.id] || 0, Date.now() + 10 * 60 * 1000);
          return; // do not cache an empty guide: it made every visit to Live TV re-request everything
        }
        setNowPlaying(toNow(data));
        cacheSet(cacheKey, JSON.stringify({savedAt: Date.now(), data})).catch(() => undefined);
      })();
    });
    return () => { cancelled = true; task.cancel?.(); };
  }, [tab, activeProvider?.id, channels.length, epgTick]);

  const lastPlayError = useRef('');
  const retryRef = useRef({n: 0, at: 0});
  const startedRef = useRef(false); // has this stream produced picture/sound yet?
  useEffect(() => { retryRef.current = {n: 0, at: 0}; startedRef.current = false; }, [player?.mediaKey, player?.url]);
  /** One place for "playback failed/stalled": reconnect the same stream, then fallback URLs, then the other engine, then ask. */
  function handlePlayFailure(native: boolean, reason: string, detail = '') {
    if (!player) return;
    logWarn('player', `${native ? 'media3' : 'builtin'} ${reason}: ${player.title} ${player.url} | ${detail || '-'}`);
    lastPlayError.current = detail || reason;
    const limit = player.live ? 2 : 1;
    if (retryRef.current.n < limit) {
      retryRef.current = {n: retryRef.current.n + 1, at: Date.now()};
      setBuffering(true);
      setTimeout(() => setPlayer(cur => cur && cur.url === player.url ? {...cur, nonce: (cur.nonce || 0) + 1} : cur), 1200);
      return;
    }
    if (player.fallbackUrls?.length) {
      const [next, ...rest] = player.fallbackUrls;
      setPlayer({...player, url: next, fallbackUrls: rest});
    } else if (!native && !player.triedNative && player.allUrls?.length) {
      setPlayer({...player, native: true, triedNative: true, url: player.allUrls[0], fallbackUrls: player.allUrls.slice(1)});
    } else if (deviceMode === 'tv') {
      setBuffering(false);
      setPlayError({text: describePlaybackError(lastPlayError.current, langRef.current).text, cursor: 0});
    } else {
      Alert.alert(tx('تعذر تشغيل الفيديو', 'Playback failed'), describePlaybackError(lastPlayError.current, langRef.current).text, [
        {text: tx('إغلاق', 'Close'), style: 'cancel'},
        {text: tx('فتح عبر VLC', 'Open in VLC'), onPress: () => NativeModules.TurboPlayerModule?.openExternalVlc(player.url)}
      ]);
    }
  }
  // a live stream stuck buffering for 25 s is treated as a failure (reconnect instead of spinning forever)
  useEffect(() => {
    if (!player?.live || !buffering) return;
    const ms = startedRef.current ? 25000 : 60000; // a slow provider may take long to start; only a stall mid-stream is cut at 25 s
    const t = setTimeout(() => handlePlayFailure(!!player.native, `stalled ${ms / 1000}s`, `stalled: no data for ${ms / 1000}s`), ms);
    return () => clearTimeout(t);
  }, [buffering, player?.url, player?.nonce]);
  // reset per-stream UI, run the next-episode countdown, load now/next for the live channel
  useEffect(() => { setPlayError(null); setAutoNext(null); setResumeOffer(null); closePanel(); }, [player?.url, player?.nonce]);
  function commitResume() {
    const r = resumeRef.current;
    setResumeOffer(null);
    if (r) seekBy(r.pos - playStatus.current.pos, true);
  }
  useEffect(() => {
    if (!resumeOffer) return;
    if (resumeOffer.left <= 0) { commitResume(); return; }
    const t = setTimeout(() => setResumeOffer(r => r ? {...r, left: r.left - 1} : r), 1000);
    return () => clearTimeout(t);
  }, [resumeOffer?.left, !!resumeOffer]);
  useEffect(() => {
    if (!autoNext) return;
    if (autoNext.left <= 0) { const ep = autoNext.ep; setAutoNext(null); playEpisode(ep); return; }
    const t = setTimeout(() => setAutoNext(a => a ? {...a, left: a.left - 1} : a), 1000);
    return () => clearTimeout(t);
  }, [autoNext?.left, !!autoNext]);
  useEffect(() => {
    if (!player?.live || !player.mediaKey || deviceMode !== 'tv') { setLiveGuide(null); return; }
    const key = player.mediaKey;
    const ch = channels.find(c => channelKey(c) === key);
    if (!ch) { setLiveGuide(null); return; }
    let off = false;
    const t = setTimeout(async () => {
      const src = providerForItem(ch);
      if (src && Date.now() < (epgBackoff.current[src.id] || 0)) return;
      try {
        const list = await guideFor(ch);
        if (!off) setLiveGuide(list.length ? {key, list} : null);
      } catch { if (!off) setLiveGuide(null); }
    }, 1200); // debounced: zapping through channels must not fire a guide request per channel
    return () => { off = true; clearTimeout(t); };
  }, [player?.mediaKey, !!player?.live]);
  function onNativePlayerError(e?: any) {
    handlePlayFailure(true, 'error', String(e?.nativeEvent?.message || ''));
  }
  async function updatePlayback(status: any) {
    if (!status?.isLoaded) return;
    setBuffering(!!status.isBuffering);
    if (status.isPlaying) startedRef.current = true;
    if (status.isPlaying && retryRef.current.n > 0 && Date.now() - retryRef.current.at > 30000) retryRef.current = {n: 0, at: 0};
    playStatus.current = {pos: status.positionMillis || 0, dur: status.durationMillis || 0, playing: !!status.isPlaying || (!!status.shouldPlay && !!status.isBuffering)};
    if (deviceMode === 'tv' && player && !player.live && (status.durationMillis || 0) > 60000 && !status.isBuffering
      && (status.didJustFinish || (status.positionMillis || 0) >= (status.durationMillis || 0) - 1500)) {
      const tag = `${player.url}#${player.nonce || 0}`;
      if (endedFor.current !== tag) {
        endedFor.current = tag;
        const nx = getNextEpisode();
        if (nx) setAutoNext({ep: nx, title: episodeLabel(nx), left: 10});
      }
    }
    if (deviceMode === 'tv' && player && !player.live && player.mediaKey && (status.durationMillis || 0) > 120000) {
      const rtag = `${player.url}#${player.nonce || 0}`;
      if (resumeFor.current !== rtag) {
        resumeFor.current = rtag;
        const pct = watchProgress[player.mediaKey] || 0;
        if (pct >= 3 && pct <= 94 && (status.positionMillis || 0) < 15000) setResumeOffer({pos: Math.floor(pct / 100 * status.durationMillis), left: 8});
      }
    }
    if (deviceMode === 'tv') setPlayClock({...playStatus.current});
    if (player?.mediaKey && status.durationMillis) {
      const value = Math.min(100, Math.round(status.positionMillis / status.durationMillis * 100));
      const now = Date.now();
      if (value > 1 && (now - lastProgressSave.current > 8000 || value >= 99)) {
        lastProgressSave.current = now;
        const next = {
          ...watchProgress,
          [player.mediaKey]: value
        };
        setWatchProgress(next);
        AsyncStorage.setItem('streambox.watchProgress', JSON.stringify(next)).catch(() => undefined);
      }
    }
  }
  async function changeTheme(name: ThemeName) {
    setTheme(name);
    await AsyncStorage.setItem('streambox.theme', name);
  }
  saveDeviceModeRef.current = () => { saveDeviceMode(); };
  async function saveDeviceMode() {
    setDeviceMode(deviceDraft);
    await AsyncStorage.setItem('streambox.deviceMode', deviceDraft);
  }
  /** With a kids profile active and a PIN set, settings and profile management need the PIN. */
  function guard(action: () => void) {
    if (parentalPin && activeProvider?.kid) {
      setPendingAction(() => action);
      setPendingMedia(null);
      setVerifyDraft('');
      setShowVerify(true);
      return;
    }
    action();
  }
  function nav(id: string) {
    if (id === 'settings' && tab !== 'settings') { guard(() => navTo(id)); return; }
    navTo(id);
  }
  function navTo(id: string) {
    if (['live', 'movies', 'series'].includes(id) && !catalogReady) {
      const source = activeProvider || providers.find(p => !isM3uProvider(p)) || providers[0];
      if (!source) return Alert.alert(tx('المصدر غير جاهز', 'Source not ready'), tx('أضف Profile أو اختر واحدًا أولًا.', 'Add or pick a profile first.'));
      if (!catalogLoading) {
        connect(source);
      } else {
        Alert.alert(tx('جاري تحميل المصدر', 'Loading the source'), tx('سيتم فتح القسم تلقائيًا بعد اكتمال التحميل.', 'The section will open automatically when loading finishes.'));
      }
      return;
    }
    tvFocusIndex.current = 0;
    setTvFocusedIndex(0);
    setTab(id);
    setQuery('');
    if (id === 'live' && activeProvider && !channels.length && !catalogLoading) connect(activeProvider);
  }
  function toggleMulti(key: string) {
    setMultiSelected(current => current.includes(key) ? current.filter(item => item !== key) : current.length >= 4 ? current : [...current, key]);
  }
  function launchMultiView() {
    const selected = channels.filter(item => multiSelected.includes(channelKey(item)));
    if (!selected.length) return Alert.alert(tx('تعدد الشاشات', 'Multi-View'), tx('اختر قناة واحدة على الأقل.', 'Pick at least one channel.'));
    setShowMultiView(false);
    setMultiSelected(selected.map(channelKey));
    setShowMultiView(true);
  }
  const favoriteItems = useMemo(() => showFavorites ? [...channels, ...movies, ...series].filter(item => favorites.includes(channelKey(item))) : [] as Media[], [showFavorites, channels, movies, series, favorites]);
  const liveTV = tab === 'live' && deviceMode === 'tv';
  const vodTV = (tab === 'movies' || tab === 'series') && deviceMode === 'tv';
  const vodCats: LiveCat[] = useMemo(() => {
    if (!vodTV) return [];
    const list = tab === 'movies' ? movies : series;
    const favCount = list.reduce((n, i) => n + (favSet.has(channelKey(i)) ? 1 : 0), 0);
    const inProgress = Object.keys(watchProgress).filter(k => watchProgress[k] > 1 && watchProgress[k] < 99).length;
    return [
      {key: 'All', label: 'ALL | الكل', count: list.length},
      {key: '__continue__', label: 'Continue | متابعة المشاهدة', count: inProgress},
      {key: '__recent__', label: 'Recent | شوهد مؤخرًا', count: recentItems.length},
      {key: '__favorites__', label: 'Favorites | المفضلة', count: favCount},
      ...categories.filter(c => c !== 'All').map(c => ({key: c, label: c, count: categoryCounts.get(c) ?? 0})),
    ];
  }, [vodTV, tab, movies, series, favSet, categories, categoryCounts, recentItems.length, Object.keys(watchProgress).length]);
  const liveCats: LiveCat[] = useMemo(() => {
    if (!liveTV) return [];
    const favLive = channels.reduce((n, c) => n + (favSet.has(channelKey(c)) ? 1 : 0), 0);
    return [
      {key: 'All', label: 'ALL | الكل', count: channels.length},
      {key: '__favorites__', label: 'Favorites | المفضلة', count: favLive},
      ...categories.filter(c => c !== 'All').map(c => ({key: c, label: c, count: categoryCounts.get(c) ?? 0})),
    ];
  }, [liveTV, channels, categories, categoryCounts, favSet]);
  const liveStream = useCallback((item: Media) => {
    const urls = streamUrlCandidates(item);
    return urls.length ? {url: urls[0], headers: playbackHeaders(item)} : null;
  }, [activeProvider?.id, providers]);
  const liveGuide2 = useCallback(async (item: Media) => {
    const src = providerForItem(item);
    if (src && Date.now() < (epgBackoff.current[src.id] || 0)) return [] as Prog[];
    return guideFor(item);
  }, [activeProvider?.id, providers]);
  return <TVModeContext.Provider value={deviceMode === 'tv'}>
    {deviceMode === 'tv' && <Screensaver minutes={screensaverMin} suspended={!!player && playClock.playing} />}<StarFocusContext.Provider value={starFocus}><SafeAreaView style={styles.safe}><StatusBar hidden={!!player} barStyle="light-content" backgroundColor={bg} /><View style={[styles.app, {
      direction: isEnglish ? 'ltr' : 'rtl'
    }]}>{liveTV || vodTV ? null : tab === 'home' ? <HomeTopBar height={homeTopHeight} paddingHorizontal={homeHorizontalPad} onNotifications={() => Alert.alert(tx('الإشعارات', 'Notifications'), tx('لا توجد إشعارات جديدة.', 'No new notifications.'))} onSettings={() => nav('settings')} /> : <View style={styles.header}><Pressable style={styles.headerBack} onPress={() => nav('home')}><Ionicons name="arrow-back" size={28} color="#fff" /></Pressable><View style={styles.headerTitleBox}><Text style={styles.headerTitle}>{tab === 'live' ? 'LIVE TV' : tab === 'movies' ? 'MOVIES' : tab === 'series' ? 'SERIES' : 'SETTINGS'}</Text><Text style={styles.logoSub}>TURBOX IPTV</Text></View><Pressable style={styles.headerUser} onPress={() => setShowProfiles(true)}><Text style={styles.avatarText}>م</Text></Pressable></View>}<View style={[styles.content, deviceMode === 'tv' && styles.tvContent, ['live', 'movies', 'series'].includes(tab) && styles.catalogContent]}>{['live', 'movies', 'series'].includes(tab) ? <View style={styles.catalogHost}>{liveTV ? <View style={{flex: 1, marginHorizontal: -32}}><LiveTVScreen isEnglish={isEnglish} accent={accent} categories={liveCats} selectedCategory={selectedCategory} onSelectCategory={(k: string) => { setSelectedCategory(k); setQuery(''); }} channels={filtered} nowPlaying={nowPlaying} favSet={favSet} loading={busy || heavyPending} previewEnabled={livePreview} previewPaused={!!player || showSearch} getStream={liveStream} getGuide={liveGuide2} onOpen={(it: Media) => playItem(it)} onFavorite={onRowFavorite} onSearch={() => setShowSearch(true)} /></View> : vodTV ? <View style={{flex: 1, marginHorizontal: -32}}><VodScreen kind={tab === 'movies' ? 'movies' : 'series'} isEnglish={isEnglish} accent={accent} categories={vodCats} selectedCategory={selectedCategory} onSelectCategory={(k: string) => { setSelectedCategory(k); setQuery(''); }} items={filtered} favSet={favSet} progress={watchProgress} loading={busy || heavyPending} onOpen={(it: Media) => playItem(it)} onFavorite={onRowFavorite} onSearch={() => setShowSearch(true)} /></View> : (tab === 'live' || tab === 'movies' || tab === 'series') && <View style={[styles.catalogScreen, deviceMode === 'tv' && {
            marginHorizontal: -32
          }]}><TVScope scope={sideScroll.scope}><ScrollView ref={sideScroll.ref} onScroll={sideScroll.onScroll} scrollEventThrottle={16} style={[styles.catalogSide, {
              width: catalogSideWidth,
              maxWidth: catalogSideWidth,
              flexBasis: catalogSideWidth,
              flexGrow: 0,
              flexShrink: 0
            }]} contentContainerStyle={{paddingBottom:18}} nestedScrollEnabled showsVerticalScrollIndicator><View style={styles.catalogBrand}><Pressable onPress={() => nav('home')}><Ionicons name="arrow-back" size={28} color="#fff" /></Pressable><Text style={styles.catalogBrandText}>TurboX <Text style={{
                    color: '#ff3d62'
                  }}>IPTV</Text></Text><Pressable onPress={() => nav('home')}><Ionicons name="close" size={27} color="#fff" /></Pressable></View><View style={styles.catalogSideSearch}><Ionicons name="search" size={20} color="#cfd0da" />{deviceMode === 'tv' ? <Pressable style={{flex: 1, justifyContent: 'center', minHeight: 36}} onPress={() => setShowSearch(true)}><Text style={[styles.catalogSearchInput, {color: query.trim() ? '#fff' : '#918ea7'}]} numberOfLines={1}>{query.trim() || 'Search in categories'}</Text></Pressable> : <TextInput value={query} onChangeText={setQuery} placeholder="Search in categories" placeholderTextColor="#918ea7" style={styles.catalogSearchInput} />}</View>{[['FAVORITES', favorites.length, 'star'], ['CONTINUE WATCHING', continueItems.length, 'time'], ['RECENTLY ADDED', recentItems.length, 'flash']].map(([label, count, icon]) => <Pressable key={String(label)} style={[styles.catalogQuick, ((label === 'FAVORITES' && selectedCategory === '__favorites__') || (label === 'CONTINUE WATCHING' && selectedCategory === '__continue__') || (label === 'RECENTLY ADDED' && selectedCategory === '__recent__')) && {
                backgroundColor: `${accent}99`
              }]} onPress={() => { setSelectedCategory(label === 'FAVORITES' ? '__favorites__' : label === 'CONTINUE WATCHING' ? '__continue__' : label === 'RECENTLY ADDED' ? '__recent__' : 'All'); setQuery(''); }}><Ionicons name={icon as any} size={19} color="#f4f4f4" /><Text style={styles.catalogQuickText}>{label}</Text><Text style={styles.catalogQuickCount}>{String(count)}</Text></Pressable>)}<View style={styles.catalogCategories}>{categories.filter(c => c !== 'All').map(category => <CategoryRow key={category} name={category} count={categoryCounts.get(category) ?? 0} selected={selectedCategory === category} accent={accent} onSelect={setSelectedCategory} />)}</View></ScrollView></TVScope><View style={[styles.catalogMain, {
              paddingHorizontal: deviceMode === 'tv' ? 20 : 10
            }]}><View style={styles.catalogHeader}><Text style={styles.catalogTitle}>{selectedCategory === 'All' ? activeProvider?.name || (tab === 'live' ? 'LIVE TV' : tab === 'movies' ? 'MOVIES' : 'SERIES') : selectedCategory === '__favorites__' ? 'FAVORITES' : selectedCategory === '__continue__' ? 'CONTINUE WATCHING' : selectedCategory === '__recent__' ? 'RECENTLY ADDED · 7 DAYS' : selectedCategory}</Text><View style={styles.catalogHeaderActions}><Pressable onPress={() => deviceMode === 'tv' ? setShowSearch(true) : setQuery(query ? '' : ' ')}><Ionicons name="search" size={30} color="#fff" /></Pressable><Pressable onPress={() => Alert.alert('المزيد', 'استخدم التصنيفات الجانبية أو البحث للوصول إلى كل المحتوى.')}><Ionicons name="ellipsis-vertical" size={27} color="#fff" /></Pressable></View></View>{tab === 'live' && <Pressable style={styles.epgButton} onPress={() => openEpg()}><Ionicons name="calendar-outline" size={16} color={accent} /><Text style={{
                  color: accent,
                  fontSize: 11
                }}>Smart EPG · 7 days</Text></Pressable>}{busy || heavyPending ? <ActivityIndicator color={accent} style={{
                margin: 30
              }} /> : filtered.length ? tab === 'live' ? <TVScope scope={gridScroll.scope}><FlatList ref={gridScroll.ref} onScroll={gridScroll.onScroll} scrollEventThrottle={deviceMode === 'tv' ? 48 : 16} ListHeaderComponent={deviceMode === 'tv' && !favHintSeen ? <Text style={{color: '#9a9ab0', fontSize: 12, paddingHorizontal: 12, paddingBottom: 6}}>{tx('للمفضلة: اضغط MENU أو INFO أو الزر الأصفر وأنت على القناة', 'Favorites: press MENU, INFO or YELLOW while a channel is highlighted')}</Text> : null} data={filtered} initialNumToRender={deviceMode === 'tv' ? 10 : 14} maxToRenderPerBatch={deviceMode === 'tv' ? 6 : 8} windowSize={deviceMode === 'tv' ? 3 : 5} removeClippedSubviews={deviceMode !== 'tv'} nestedScrollEnabled scrollEnabled keyExtractor={(x, i) => `${x.sourceId || ''}-${x.stream_id || x.url || i}`} renderItem={({
                item, index
              }) => <MediaRow item={item} accent={accent} favorite={favSet.has(channelKey(item))} onFavorite={onRowFavorite} onPlay={onRowPlay} currentProgram={nowPlaying[channelKey(item)] || item.now_playing} hasTVPreferredFocus={index === 0} remoteFocused={false} />} /></TVScope> : <TVScope scope={gridScroll.scope}><FlatList ref={(r: any) => { (catalogListRef as any).current = r; (gridScroll.ref as any).current = r; }} onScroll={gridScroll.onScroll} scrollEventThrottle={deviceMode === 'tv' ? 48 : 16} data={filtered} key={`poster-grid-${deviceMode === 'tv' ? 'tv' : 'mobile'}`} numColumns={catalogColumns} keyExtractor={(item, index) => `${channelKey(item)}-${index}`} renderItem={({
                item, index
              }) => <MediaCard width={posterWidth} item={item} index={index} accent={accent} favorite={favSet.has(channelKey(item))} onFavorite={onRowFavorite} onPlay={onRowPlay} onFocusIndex={onRowFocusIndex} hasTVPreferredFocus={index === 0} remoteFocused={false} />} getItemLayout={(_, index) => ({length: Math.round(posterWidth * 1.75) + 12, offset: (Math.round(posterWidth * 1.75) + 12) * Math.floor(index / catalogColumns), index})} onScrollToIndexFailed={(info) => setTimeout(() => catalogListRef.current?.scrollToIndex({index: info.index, animated: false}), 100)} columnWrapperStyle={styles.posterRow} contentContainerStyle={styles.posterGrid} initialNumToRender={catalogColumns * 2} maxToRenderPerBatch={catalogColumns * 2} updateCellsBatchingPeriod={50} windowSize={deviceMode === 'tv' ? 3 : 4} removeClippedSubviews={deviceMode !== 'tv'} nestedScrollEnabled scrollEnabled /></TVScope> : <Empty onPress={() => openAdd()} label="No items in this category" accent={accent} />}</View></View>}</View> : <TVScope scope={outerScroll.scope}><ScrollView ref={outerScroll.ref} onScroll={outerScroll.onScroll} scrollEventThrottle={16} style={styles.outerScroll} showsVerticalScrollIndicator={false} contentContainerStyle={{
          paddingBottom: 20
        }}>{tab === 'home' && <HomeBody isEnglish={isEnglish} profileName={activeProvider?.name || profileName} providerName={activeProvider?.name} networkLabel={networkLabel} catalogReady={catalogReady} catalogProgress={catalogProgress} refreshing={refreshing} counts={{live: channels.length, movies: heavyLoaded ? movies.length : (catalogCounts?.movies ?? 0), series: heavyLoaded ? series.length : (catalogCounts?.series ?? 0)}} tileHeight={homeTileHeight} actionHeight={homeActionHeight} pad={homeHorizontalPad} onOpen={t => nav(t)} onEpg={() => openEpg()} onMulti={() => setShowMultiView(true)} onAccount={openAccount} alert={expiryAlert} onAlert={openAccount} rows={homeRows} onSearch={() => setShowSearch(true)} onSettings={() => nav('settings')} onAddSource={() => guard(() => openAdd())} continueItems={continueItems.map(item => ({key: channelKey(item), name: item.name, progress: watchProgress[channelKey(item)] || 0, onPress: () => playItem(item)}))} />}{tab === 'settings' && <><SectionTitle title={tx('الإعدادات', 'Settings')} accent={accent} /><Setting icon="color-palette-outline" title={tx('السمات (ألوان التطبيق)', 'Themes (app colours)')} sub={THEME_LABELS[theme][isEnglish ? 1 : 0]} onPress={() => setShowThemes(true)} accent={accent} /><Setting icon="eye-outline" title={tx('معاينة البث في قائمة القنوات', 'Live preview in the channel list')} sub={livePreview ? tx('مفعّلة (تستخدم اتصال بث واحد أثناء التصفح)', 'On (uses one stream connection while browsing)') : tx('متوقفة', 'Off')} onPress={toggleLivePreview} accent={accent} /><Setting icon="speedometer-outline" title={tx('وضع التحميل المؤقت (Buffer)', 'Buffer profile')} sub={bufferProfile === 'fast' ? tx('سريع (تنقّل فوري، أنسب لإنترنت مستقر)', 'Fast (instant zapping, needs a stable connection)') : tx('مستقر (أبطأ قليلًا، أقل تجمّد على إنترنت ضعيف)', 'Stable (a bit slower, fewer freezes on weak connections)')} onPress={toggleBufferProfile} accent={accent} /><Setting icon="flash-outline" title={tx('وضع النفق البرمجي (Tunneling)', 'Media tunneling')} sub={tunneling ? tx('مفعّل — تجريبي، يعتمد على دعم الجهاز', 'On — experimental, depends on device support') : tx('متوقف', 'Off')} onPress={toggleTunneling} accent={accent} /><Setting icon="moon-outline" title={tx('شاشة التوقف (حماية من حرق البكسلات)', 'Screensaver (burn-in protection)')} sub={SCREENSAVER_LABELS[screensaverMin][isEnglish ? 1 : 0]} onPress={() => setShowScreensaverPicker(true)} accent={accent} /><Setting icon="headset-outline" title={tx('لغة الصوت المفضلة', 'Preferred audio language')} sub={(LANG_PREF_OPTIONS.find(o => o.id === audioPref) || LANG_PREF_OPTIONS[0]).label[isEnglish ? 1 : 0]} onPress={() => setShowAudioPref(true)} accent={accent} /><Setting icon="chatbox-ellipses-outline" title={tx('الترجمة المفضلة', 'Preferred subtitles')} sub={(SUB_PREF_OPTIONS.find(o => o.id === subPref) || SUB_PREF_OPTIONS[0]).label[isEnglish ? 1 : 0]} onPress={() => setShowSubPref(true)} accent={accent} /><Setting icon="pulse-outline" title={tx('فحص المزوّد', 'Check this provider')} sub={activeProvider ? activeProvider.name : tx('لا يوجد مزوّد نشط', 'No active provider')} onPress={() => activeProvider && setShowProviderCheck(true)} accent={accent} /><Setting icon="cloud-download-outline" title={tx('التحديثات', 'Updates')} sub={checkingUpdate ? tx('جارٍ التحقق…', 'Checking…') : updateInfo ? tx(`يوجد تحديث جديد: v${updateInfo.version}`, `Update available: v${updateInfo.version}`) : tx(`محدّث (v${APP_VERSION})`, `Up to date (v${APP_VERSION})`)} onPress={() => updateInfo ? Linking.openURL(updateInfo.url) : checkUpdateNow()} accent={accent} /><Setting icon="swap-horizontal-outline" title={tx('نقل الإعدادات بين الأجهزة', 'Transfer settings between devices')} sub={tx('تصدير أو استيراد المزوّدين وإعدادات التطبيق', 'Export or import providers and app settings')} onPress={() => setShowBackup(true)} accent={accent} /><Setting icon="person-circle-outline" title={tx('حالة الحساب', 'Account Status')} sub={accountInfo?.kind === 'xtream' ? (accountInfo.expiresAt ? tx(`ينتهي ${accountInfo.expiresAt.toLocaleDateString('ar-EG')}`, `Expires ${accountInfo.expiresAt.toLocaleDateString()}`) : accountInfo.status) : tx('الحالة وتاريخ الانتهاء والاتصالات', 'Status, expiry and connections')} onPress={openAccount} accent={accent} /><Setting icon="people-outline" title={tx('الملفات (Profiles)', 'Profiles')} sub={`${activeProvider?.name || '—'} · ${providers.length} ${tx('اشتراك', 'subscription(s)')}`} onPress={() => guard(() => setShowProfiles(true))} accent={accent} /><Setting icon="calendar-outline" title={tx('دليل البرامج', 'TV Guide')} sub={tx('جدول زمني لكل القنوات', 'Timeline for all channels')} onPress={() => openEpg()} accent={accent} /><Setting icon="star-outline" title={tx('المفضلة', 'Favorites')} sub={tx(`${favorites.length} عنصر محفوظ`, `${favorites.length} saved item(s)`)} onPress={() => setShowFavorites(true)} accent={accent} /><Setting icon="grid-outline" title={tx('تعدد الشاشات', 'Multi-View')} sub={tx('حتى 4 قنوات Live', 'Up to 4 live channels')} onPress={() => setShowMultiView(true)} accent={accent} /><Setting icon="eye-off-outline" title={tx('إخفاء التصنيفات', 'Hidden Categories')} sub={(() => { const n = hiddenCats.live.length + hiddenCats.movies.length + hiddenCats.series.length; return n ? tx(`${n} تصنيف مخفي`, `${n} hidden`) : tx('إظهار كل التصنيفات', 'All categories visible'); })()} onPress={() => setShowHidden(true)} accent={accent} /><Setting icon="moon-outline" title={tx('مؤقت النوم', 'Sleep Timer')} sub={sleepEnd ? tx(`يتبقى ${sleepLeft}`, `${sleepLeft} left`) : tx('إيقاف', 'Off')} onPress={() => setShowSleep(true)} accent={accent} /><Setting icon="sync-outline" title={tx('الأتمتة', 'Automation')} sub={tx(`تحديث القنوات كل ${automation.catalogEnabled ? automation.catalogDays + ' يوم' : 'إيقاف'} · EPG كل ${automation.epgEnabled ? automation.epgDays + ' يوم' : 'إيقاف'}`, `Catalogue: ${automation.catalogEnabled ? 'every ' + automation.catalogDays + 'd' : 'off'} · EPG: ${automation.epgEnabled ? 'every ' + automation.epgDays + 'd' : 'off'}`)} onPress={() => setShowAutomation(true)} accent={accent} /><Setting icon="play-circle-outline" title={tx('المشغّل', 'Player')} sub={(() => { const o = PLAYER_OPTIONS.find(x => x.id === playerEngine); return o ? (isEnglish ? o.en : o.ar) : ''; })()} onPress={() => setShowPlayerPicker(true)} accent={accent} />{deviceMode === 'tv' && <Setting icon="star-outline" title={tx('نجمة المفضلة في قوائم التلفاز', 'Favorite star in TV lists')} sub={starFocus ? tx('تظهر كزر يمكن الوصول إليه بالأسهم', 'A button you can reach with the arrows') : tx('مخفية من التنقل: استخدم MENU أو INFO أو الأصفر على العنصر', 'Out of the way: press MENU, INFO or YELLOW on the item')} onPress={() => { const next = !starFocus; setStarFocus(next); AsyncStorage.setItem('streambox.tvStar', next ? '1' : '0').catch(() => undefined); }} accent={accent} />}<Setting icon="rocket-outline" title={tx('بدء التشغيل', 'Startup')} sub={startupMode === 'home' ? tx('الصفحة الرئيسية', 'Home') : startupMode === 'last' ? tx('آخر قناة شاهدتها', 'Resume last channel') : tx('البث المباشر', 'Live TV')} onPress={() => setShowStartup(true)} accent={accent} /><Setting icon="bug-outline" title={tx('سجل الأخطاء', 'Logs')} sub={tx('للمشاركة مع المطوّر عند حدوث مشكلة', 'Share with the developer when something goes wrong')} onPress={openLogs} accent={accent} /><Setting icon="speedometer-outline" title={tx('فحص الاتصال', 'Connection Diagnostics')} sub={diagnosticBusy ? tx('جارٍ فحص السيرفر…', 'Checking the server…') : diagnosticLabel} onPress={testConnection} accent={accent} /><Text style={styles.settingsLabel}>{tx('السمات', 'Themes')}</Text><View style={styles.themeRow}>{(Object.keys(themeAccents) as ThemeName[]).map(name => <Pressable key={name} onPress={() => changeTheme(name)} style={[styles.themeDot, {
                backgroundColor: themeAccents[name],
                borderColor: theme === name ? '#fff' : 'transparent'
              }]} />)}</View><Setting icon="language-outline" title="اللغة" sub={language === 'ar' ? 'Arabic (RTL) · Tap to change' : 'English (LTR) · Tap to change'} onPress={() => setShowLanguage(true)} accent={accent} /><Setting icon="shield-checkmark-outline" title="Parental Control" sub={parentalPin ? 'مفعلة · PIN محفوظ' : 'Disabled · Tap to enable'} onPress={() => {
              setPinDraft(parentalPin);
              setShowParental(true);
            }} accent={accent} /><Setting icon="game-controller-outline" title={tx('دليل الريموت', 'Remote guide')} sub={tx('ماذا يفعل كل زر في التطبيق', 'What each remote key does')} onPress={() => setShowRemoteGuide(true)} accent={accent} /><Setting icon="information-circle-outline" title="About TurboX IPTV" sub="الإصدار 1.0 · Independent IPTV player" onPress={() => setShowAbout(true)} accent={accent} /></>}</ScrollView></TVScope>}</View><Modal native visible={!splashDone} animationType="fade" statusBarTranslucent onRequestClose={() => setSplashDone(true)}><SplashScreen onDone={() => setSplashDone(true)} /></Modal><Modal native visible={splashDone && deviceMode === null} transparent animationType="fade"><View style={styles.choiceBg}><View style={styles.choiceCard}><View style={[styles.logo, {
              backgroundColor: accent
            }]}><Ionicons name="flash" size={20} color="#28191a" /></View><Text style={styles.choiceTitle}>How will you use TurboX IPTV?</Text><Text style={styles.choiceSub}>We will adjust the interface and player for your device.</Text><View style={styles.modeRow}><Pressable focusable={false} onPress={() => setDeviceDraft('tv')} style={[styles.modeCard, deviceDraft === 'tv' && {
                borderColor: accent,
                backgroundColor: `${accent}22`
              }]}><Ionicons name="tv-outline" size={32} color={accent} /><Text style={styles.modeText}>TV</Text><Text style={styles.modeSub}>Android TV / Google TV / Fire TV</Text></Pressable><Pressable focusable={false} onPress={() => setDeviceDraft('mobile')} style={[styles.modeCard, deviceDraft === 'mobile' && {
                borderColor: accent,
                backgroundColor: `${accent}22`
              }]}><Ionicons name="phone-portrait-outline" size={32} color={accent} /><Text style={styles.modeText}>Mobile</Text><Text style={styles.modeSub}>Phone or tablet</Text></Pressable></View><Pressable focusable={false} style={[styles.primary, {
              backgroundColor: accent,
              alignSelf: 'stretch',
              justifyContent: 'center'
            }, choiceOnContinue && {borderWidth: 2, borderColor: '#fff'}]} onPress={saveDeviceMode}><Text style={styles.primaryText}>Continue</Text></Pressable><Text style={{color: '#6b6b82', fontSize: 11, textAlign: 'center', marginTop: 12}}>◀ ▶ choose · ▼ Continue · OK confirm</Text></View></View></Modal><SearchOverlay visible={showSearch} isEnglish={isEnglish} accent={accent} channels={channels} movies={movies} series={series} onClose={() => setShowSearch(false)} onPick={it => { setShowSearch(false); playItem(it); }} /><Modal native visible={!!player} animationType="fade" statusBarTranslucent onRequestClose={onPlayerBack}><View style={styles.playerScreen}>{player && (player.native ? <NativeTurboPlayerView key={`${player.url}#${player.nonce || 0}`} style={styles.video} source={player.url} headers={player.headers} live={!!player.live} paused={nativePaused} seek={nativeSeek} audioTrack={audioSel} textTrack={textSel} resizeMode={aspectMode} onStatus={(e: any) => { const n = e.nativeEvent || {}; updatePlayback({isLoaded: true, isBuffering: !!n.buffering, isPlaying: !!n.playing, shouldPlay: !nativePaused, positionMillis: n.positionMs || 0, durationMillis: n.durationMs || 0}); }} onTracks={(e: any) => { const n = e.nativeEvent || {}; setNativeTracks({audio: n.audio || [], text: n.text || [], textOff: n.textOff !== false}); }} onError={onNativePlayerError} /> : <Video key={`${player.url}#${player.nonce || 0}`} style={styles.video} source={{
            uri: player.url,
            headers: player.headers
          }} ref={videoRef} useNativeControls={deviceMode !== 'tv'} resizeMode={aspectMode} shouldPlay progressUpdateIntervalMillis={deviceMode === 'tv' ? 1000 : 5000} onPlaybackStatusUpdate={updatePlayback} onError={(err: any) => handlePlayFailure(false, 'error', String(err || ''))} />)}<View style={[styles.playerTop, deviceMode === 'tv' && {opacity: 0}]} pointerEvents={deviceMode === 'tv' ? 'none' : 'auto'}><Pressable focusable={deviceMode !== 'tv'} onPress={() => setPlayer(null)}><Ionicons name="close-circle" size={32} color="#fff" /></Pressable><View style={styles.playerOverlayText}><Text style={styles.playerTitle}>{player?.title}</Text><Text style={styles.playerStatus}>{buffering ? 'Buffering…' : `TurboX · ${networkLabel}`}</Text></View>{player?.native && <Pressable focusable={deviceMode !== 'tv'} onPress={toggleTrackMenu}><Ionicons name="chatbox-ellipses-outline" size={24} color={showTracks ? '#ff5a66' : '#fff'} /></Pressable>}<Pressable focusable={deviceMode !== 'tv'} onPress={cycleSleep}><Ionicons name={sleepEnd ? 'moon' : 'moon-outline'} size={22} color={sleepEnd ? '#ff5a66' : '#fff'} /></Pressable>{sleepLeft && deviceMode !== 'tv' && <Text style={{color: '#ff5a66', fontSize: 12, fontWeight: '800'}}>{sleepLeft}</Text>}<Pressable focusable={deviceMode !== 'tv'} onPress={() => setAspectMode(aspectMode === ResizeMode.CONTAIN ? ResizeMode.COVER : aspectMode === ResizeMode.COVER ? ResizeMode.STRETCH : ResizeMode.CONTAIN)}><Ionicons name="resize" size={28} color="#fff" /></Pressable></View>{deviceMode === 'tv' && player && <PlayerControls visible={(overlayOn || !playClock.playing) && !chanPanel.open && !autoNext && !playError && !resumeOffer} title={player.title} live={!!player.live} playing={playClock.playing} buffering={buffering} position={playClock.pos} duration={playClock.dur} isEnglish={isEnglish} seekFlash={seekFlash} channelInput={channelInput} sleepLeft={sleepLeft} buttons={playerButtons()} focus={ctl.focus} scrubTo={ctl.scrubTo} guide={(() => {
              if (!player.live || !liveGuide || liveGuide.key !== player.mediaKey) return null;
              const t = Date.now() / 1000;
              const i = liveGuide.list.findIndex(x => x.s <= t && x.e > t);
              return i >= 0 ? {now: liveGuide.list[i], next: liveGuide.list[i + 1]} : null;
            })()} />}
          {deviceMode === 'tv' && player?.live && chanPanel.open && (() => {
            const list = chanRef.current.list;
            const start = Math.max(0, Math.min(chanPanel.cursor - 4, Math.max(0, list.length - 9)));
            const rows = list.slice(start, start + 9).map((it, i) => ({key: channelKey(it), num: start + i + 1, name: it.name, now: nowPlaying[channelKey(it)], current: channelKey(it) === player.mediaKey, selected: start + i === chanPanel.cursor}));
            return <ChannelPanel rows={rows} title={tx('القنوات', 'Channels')} hint={tx('▲ ▼ تصفح   ·   OK تشغيل   ·   ◀ ▶ إغلاق', '▲ ▼ Browse   ·   OK Play   ·   ◀ ▶ Close')} />;
          })()}
          {deviceMode === 'tv' && resumeOffer && (() => {
            const t = Math.floor(resumeOffer.pos / 1000), h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), sec = t % 60;
            const at = `${h ? h + ':' + String(m).padStart(2, '0') : m}:${String(sec).padStart(2, '0')}`;
            return <AutoNextCard label={tx('تكمل من مكان توقفت؟', 'Continue where you left off?')} title={tx(`استكمال من ${at}`, `Resume from ${at}`)} left={resumeOffer.left} total={8} hint={tx('OK استكمال   ·   أي سهم أو رجوع للبداية', 'OK Continue   ·   Any arrow / Back: start over')} />;
          })()}
          {deviceMode === 'tv' && autoNext && <AutoNextCard label={tx('الحلقة التالية', 'Next episode')} title={autoNext.title} left={autoNext.left} total={10} hint={tx('OK تشغيل الآن   ·   رجوع / أسهم للإلغاء', 'OK Play now   ·   Back / arrows to cancel')} />}
          {deviceMode === 'tv' && playError && <ErrorCard title={tx('تعذر تشغيل البث', 'Playback failed')} message={playError.text} actions={errorActions()} cursor={Math.min(playError.cursor, errorActions().length - 1)} />}{player?.native && showTracks && <TrackMenu rows={trackRows} cursor={deviceMode === 'tv' ? trackCursor : -1} isEnglish={isEnglish} onSelect={chooseTrack} onClose={() => setShowTracks(false)} />}</View></Modal><Modal visible={showMultiView} animationType="fade" onRequestClose={() => setShowMultiView(false)}><View style={styles.multiViewScreen}>{multiSelected.length > 0 && <View style={styles.multiGrid}>{channels.filter(item => multiSelected.includes(channelKey(item))).map(item => <View key={channelKey(item)} style={styles.multiCell}><Video style={styles.multiVideo} source={{
                uri: streamUrl(item),
                  headers: playbackHeaders(item)
              }} resizeMode={ResizeMode.CONTAIN} shouldPlay useNativeControls={false} /><Text style={styles.multiTitle} numberOfLines={1}>{item.name}</Text></View>)}</View>}<View style={styles.multiHeader}><Pressable onPress={() => {
              setMultiSelected([]);
              setShowMultiView(false);
            }}><Ionicons name="close-circle" size={32} color="#fff" /></Pressable><Text style={styles.modalTitle}>{multiSelected.length ? `Multi-View · ${multiSelected.length}/4` : 'اختيار قنوات Multi-View'}</Text></View>{multiSelected.length === 0 && <Text style={styles.multiNote}>قد يخفّض الجهاز الجودة أو يوقف بعض النوافذ إذا لم يدعم فك ترميز عدة بثوث في وقت واحد.</Text>}{multiSelected.length === 0 && <TVScrollView style={styles.multiPicker}>{channels.slice(0, 80).map(item => {
              const key = channelKey(item);
              const chosen = multiSelected.includes(key);
              return <Pressable key={key} style={[styles.multiPickerRow, chosen && {
                borderColor: accent,
                backgroundColor: `${accent}22`
              }]} onPress={() => toggleMulti(key)}><Ionicons name={chosen ? 'checkmark-circle' : 'radio-outline'} size={24} color={chosen ? accent : '#918ea7'} /><Text style={styles.channelName}>{item.name}</Text></Pressable>;
            })}</TVScrollView>}{multiSelected.length === 0 && <Pressable style={[styles.primary, {
            backgroundColor: accent,
            alignSelf: 'center',
            margin: 15
          }]} onPress={launchMultiView}><Text style={styles.primaryText}>تشغيل النوافذ المحددة</Text></Pressable>}</View></Modal><Modal visible={showFavorites} transparent animationType="slide" onRequestClose={() => setShowFavorites(false)}><View style={styles.modalBg}><View style={styles.modal}><Pressable onPress={() => setShowFavorites(false)} style={styles.close}><Ionicons name="close" size={20} color="#aaa" /></Pressable><Text style={styles.modalTitle}>Favorites</Text><Text style={styles.modalSub}>المفضلة الخاصة بالملف الحالي والمصدر الحالي</Text><FavListsBar lists={favLists} activeId={activeFavId} accent={accent} isEnglish={isEnglish} draft={listDraft} setDraft={setListDraft} onSelect={selectFavList} onAdd={addFavList} onDelete={deleteFavList} /><TVScrollView style={{
              maxHeight: 430
            }}>{favoriteItems.length ? favoriteItems.map((item, index) => <MediaRow key={`${channelKey(item)}-${index}`} item={item} accent={accent} favorite onFavorite={onRowFavorite} onPlay={it => {
                setShowFavorites(false);
                playItem(it);
              }} />) : <View style={styles.epgEmpty}><Ionicons name="star-outline" size={34} color={accent} /><Text style={styles.emptyText}>لا توجد عناصر محفوظة بعد.</Text></View>}</TVScrollView></View></View></Modal><Modal visible={showProfiles} transparent animationType="slide" onRequestClose={() => setShowProfiles(false)}><ProfilesModal providers={providers} activeId={activeProvider?.id} catalogReady={catalogReady} accent={accent} isEnglish={isEnglish} maxHeight={Math.round(screenHeight * 0.42)} ago={id => ago(updatedAt[id])} onSelect={p => { setShowProfiles(false); if (p.id !== activeProvider?.id || !catalogReady) connect(p); }} onRefresh={p => { setShowProfiles(false); connect(p, true); }} onEdit={p => { setShowProfiles(false); openEdit(p); }} onDelete={confirmDeleteProvider} onToggleKid={toggleKid} onAdd={() => { setShowProfiles(false); openAdd(); }} onClose={() => setShowProfiles(false)} /></Modal><Modal visible={!!deleteTarget} transparent animationType="fade" statusBarTranslucent onRequestClose={() => setDeleteTarget(null)}><ChoiceModal title={tx('حذف Profile', 'Delete profile')} sub={tx(`حذف "${deleteTarget?.name || ''}" واشتراكه من الجهاز؟`, `Remove "${deleteTarget?.name || ''}" and its subscription from this device?`)} value="no" closeLabel={tx('إلغاء', 'Cancel')} options={[{id: 'no', label: tx('لا، احتفظ به', 'No, keep it')}, {id: 'yes', label: tx('نعم، احذف', 'Yes, delete')}]} onSelect={id => { const t = deleteTarget; setDeleteTarget(null); if (id === 'yes' && t) deleteProvider(t); }} onClose={() => setDeleteTarget(null)} /></Modal><Modal visible={showMovie} transparent animationType="slide" statusBarTranslucent onRequestClose={() => setShowMovie(false)}>{selectedMovie && <MovieDetails item={selectedMovie} info={movieInfo} loading={movieLoading} accent={accent} isEnglish={isEnglish} favorite={favorites.includes(channelKey(selectedMovie))} progress={Math.round(watchProgress[channelKey(selectedMovie)] || 0)} maxHeight={Math.round(screenHeight * 0.3)} onPlay={() => { setShowMovie(false); startPlayback(selectedMovie); }} onFavorite={() => toggleFavorite(selectedMovie)} onTrailer={movieInfo?.info?.youtube_trailer ? openTrailer : undefined} onClose={() => setShowMovie(false)} />}</Modal><Modal visible={showTimeline} animationType="slide" statusBarTranslucent onRequestClose={() => setShowTimeline(false)}>{showTimeline && <EpgTimeline channels={timelineChannels} accent={accent} isEnglish={isEnglish} keyOf={channelKey} guide={guideFor} onPlayLive={ch => { setShowTimeline(false); playItem(ch); }} onPickProgram={pickProgram} onClose={() => setShowTimeline(false)} />}</Modal><Modal visible={showLogs} transparent animationType="slide" statusBarTranslucent onRequestClose={() => setShowLogs(false)}><LogsModal entries={logEntries} accent={accent} isEnglish={isEnglish} maxHeight={Math.round(screenHeight * 0.45)} onShare={shareLogs} onPhone={openLogsOnPhone} onClear={async () => { await clearLogs(); setLogEntries([]); }} onClose={() => setShowLogs(false)} /></Modal><Modal visible={showStartup} transparent animationType="fade" statusBarTranslucent onRequestClose={() => setShowStartup(false)}><ChoiceModal title={tx('عند فتح التطبيق', 'When the app opens')} sub={tx('اختر أين يبدأ التطبيق بعد تحميل القنوات.', 'Choose where the app starts once channels are loaded.')} value={startupMode} closeLabel={tx('إغلاق', 'Close')} options={[{id: 'home', label: tx('الصفحة الرئيسية', 'Home')}, {id: 'live', label: tx('البث المباشر', 'Live TV')}, {id: 'last', label: tx('آخر قناة شاهدتها', 'Resume last channel')}]} onSelect={chooseStartup} onClose={() => setShowStartup(false)} /></Modal><Modal visible={showEpg} transparent animationType="slide" onRequestClose={() => setShowEpg(false)}><View style={styles.modalBg}><View style={styles.modal}><Pressable onPress={() => setShowEpg(false)} style={styles.close}><Ionicons name="close" size={20} color="#aaa" /></Pressable><Text style={styles.modalTitle}>Smart EPG · مصدر القناة</Text><Text style={styles.modalSub}>{epgChannel?.name || 'اختر قناة'} · {activeProvider?.name || 'لا يوجد مصدر متصل'}</Text><View style={styles.epgSearch}><Ionicons name="search" size={16} color="#9592ac" /><TVTextInput wrapStyle={{flex: 1}} value={epgQuery} onChangeText={setEpgQuery} placeholder="ابحث عن برنامج" placeholderTextColor="#777985" style={styles.input} /></View>{epgLoading ? <ActivityIndicator color={accent} style={{
              margin: 25
            }} /> : epgPrograms.length ? <TVScrollView style={{
              maxHeight: 430
            }}>{epgPrograms.filter((program: any) => !epgQuery.trim() || String(program.title || program.name || '').toLowerCase().includes(epgQuery.toLowerCase())).map((program: any, index: number) => <Pressable key={program.id || index} style={styles.epgRow} onPress={() => program._prog && epgChannel && pickProgram(epgChannel, program._prog)}><Text style={styles.epgTime}>{program.start || program.start_timestamp || '--:--'}</Text><Text style={styles.epgProgram}>{program.title || program.name || 'برنامج بدون عنوان'}{program.description ? `\n${program.description}` : ''}</Text></Pressable>)}</TVScrollView> : <View style={styles.epgEmpty}><Ionicons name="calendar-outline" size={34} color={accent} /><Text style={styles.emptyText}>{activeProvider && !isM3uProvider(activeProvider) ? 'لا توجد بيانات EPG لهذه القناة من المصدر.' : 'لا يوجد دليل برامج لهذه القناة. قائمة M3U يجب أن تحتوي على رابط XMLTV (url-tvg) وأن تكون القناة مرتبطة بمعرّف tvg-id.'}</Text></View>}</View></View></Modal><Modal visible={showSeasons} animationType="fade" onRequestClose={() => setShowSeasons(false)}><View style={styles.seriesDetailScreen}><View style={styles.seriesDetailTop}><Pressable onPress={() => setShowSeasons(false)}><Ionicons name="arrow-back" size={30} color="#fff" /></Pressable><Text style={styles.seriesDetailTitle} numberOfLines={1}>{selectedSeries?.name || 'Series'}</Text><Pressable onPress={() => selectedSeries && toggleFavorite(selectedSeries)}><Ionicons name={selectedSeries && favorites.includes(channelKey(selectedSeries)) ? 'heart' : 'heart-outline'} size={30} color="#fff" /></Pressable></View><TVScrollView contentContainerStyle={styles.seriesDetailBody}><View style={styles.seriesInfoRow}>{selectedSeries?.cover || selectedSeries?.stream_icon ? <Image source={{
                uri: selectedSeries.cover || selectedSeries.stream_icon
              }} style={styles.seriesDetailPoster} /> : <View style={styles.seriesDetailPoster}><Ionicons name="videocam" size={50} color={accent} /></View>}<View style={styles.seriesMeta}><Text style={styles.seriesMetaLine}><Text style={styles.seriesMetaLabel}>Directed By: </Text>{(selectedSeries as any)?.director || 'N/A'}</Text><Text style={styles.seriesMetaLine}><Text style={styles.seriesMetaLabel}>Release Date: </Text>{(selectedSeries as any)?.releaseDate || selectedSeries?.year || 'N/A'}</Text><Text style={styles.seriesMetaLine}><Text style={styles.seriesMetaLabel}>Genre: </Text>{selectedSeries?.category_name || 'Series'}</Text><Text style={styles.seriesPlot} numberOfLines={4}>{selectedSeries?.plot || 'تفاصيل المسلسل والحلقات المتاحة من مصدر Xtream.'}</Text></View></View><View style={styles.seriesActionRow}><Pressable hasTVPreferredFocus style={[styles.seriesAction, {
                backgroundColor: accent
              }]} onPress={() => {
                const first = (episodesBySeason[selectedSeason] || [])[0];
                if (first) playEpisode(first);
              }}><Ionicons name="play" size={18} color="#ffffff" /><Text style={styles.seriesActionText}>Play S{selectedSeason}:E1</Text></Pressable><Pressable style={styles.seriesAction} onPress={() => Alert.alert('Trailer', 'لا يتوفر رابط Trailer من هذا المصدر.')}><Text style={styles.seriesActionText}>Watch Trailer</Text></Pressable></View><Text style={[styles.settingsLabel, {
              color: accent
            }]}>Seasons</Text><TVScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.seasonPicker}>{Object.keys(episodesBySeason).map(season => <Pressable key={season} onPress={() => setSelectedSeason(season)} style={[styles.seasonChip, selectedSeason === season && {
                backgroundColor: accent
              }]}><Text style={[styles.seasonChipText, selectedSeason === season && {
                  color: '#ffffff'
                }]}>Season {season}</Text></Pressable>)}</TVScrollView><Text style={styles.episodesTitle}>Episodes ({(episodesBySeason[selectedSeason] || []).length})</Text>{(episodesBySeason[selectedSeason] || []).map((episode: any, index: number) => <Pressable key={episode.id || index} style={styles.episodeRow} onPress={() => playEpisode(episode)}><Ionicons name="play-circle" size={24} color={accent} /><Text style={styles.episodeText}>{episode.episode_num || index + 1}. {episode.title || `Episode ${index + 1}`}</Text><Text style={styles.episodeDuration}>{episode.info?.duration || ''}</Text></Pressable>)}</TVScrollView></View></Modal><Modal visible={showLanguage} transparent animationType="fade" onRequestClose={() => setShowLanguage(false)}><View style={styles.modalBg}><View style={styles.modal}><Text style={styles.modalTitle}>اختيار اللغة</Text><Pressable style={styles.setting} onPress={() => chooseLanguage('ar')}><Text style={styles.channelName}>العربية (RTL)</Text><Ionicons name={language === 'ar' ? 'checkmark-circle' : 'ellipse-outline'} size={22} color={accent} /></Pressable><Pressable style={styles.setting} onPress={() => chooseLanguage('en')}><Text style={styles.channelName}>English (LTR)</Text><Ionicons name={language === 'en' ? 'checkmark-circle' : 'ellipse-outline'} size={22} color={accent} /></Pressable></View></View></Modal><Modal visible={showParental} transparent animationType="fade" onRequestClose={() => setShowParental(false)}><View style={styles.modalBg}><View style={styles.modal}><Text style={styles.modalTitle}>Parental Control</Text><Text style={styles.modalSub}>ضع PIN من 4 أرقام لمنع تشغيل Movies وSeries بدون إذن.</Text><TVTextInput value={pinDraft} onChangeText={setPinDraft} placeholder="PIN أو اتركه فارغًا للإيقاف" placeholderTextColor="#777985" keyboardType="number-pad" secureTextEntry style={styles.field} /><Pressable style={[styles.primary, {
              backgroundColor: accent
            }]} onPress={saveParental}><Text style={styles.primaryText}>حفظ</Text></Pressable></View></View></Modal><Modal visible={showVerify} transparent animationType="fade" onRequestClose={() => setShowVerify(false)}><View style={styles.modalBg}><View style={styles.modal}><Text style={styles.modalTitle}>محتوى محمي</Text><Text style={styles.modalSub}>أدخل PIN لتشغيل {pendingMedia?.name}.</Text><TVTextInput value={verifyDraft} onChangeText={setVerifyDraft} keyboardType="number-pad" secureTextEntry placeholder="PIN" placeholderTextColor="#777985" style={styles.field} /><Pressable style={[styles.primary, {
              backgroundColor: accent
            }]} onPress={verifyAndPlay}><Text style={styles.primaryText}>فتح وتشغيل</Text></Pressable></View></View></Modal><Modal visible={showAbout} transparent animationType="fade" onRequestClose={() => setShowAbout(false)}><View style={styles.modalBg}><View style={styles.modal}><Text style={styles.modalTitle}>About TurboX IPTV</Text><Text style={styles.aboutText}>TurboX IPTV Independent IPTV player لإدارة مصادر Xtream وM3U ومشاهدة القنوات وMovies وSeries.</Text><Text style={styles.aboutText}>الإصدار 1.0 · يدعم المشغل الأصلي، المواسم والحلقات، البحث، Themes والمفضلة لكل بروفايل.</Text><Pressable style={[styles.primary, {
              backgroundColor: accent
            }]} onPress={() => setShowAbout(false)}><Text style={styles.primaryText}>Close</Text></Pressable></View></View></Modal><Modal visible={splashDone && (showAdd || deviceMode !== null && providers.length === 0)} animationType="slide" statusBarTranslucent onRequestClose={() => { if (providers.length > 0) closeAdd(); else setShowExit(true); }}><LoginScreen form={form} setForm={setForm} onSubmit={saveProvider} onPickM3u={pickM3uFile} onClose={providers.length > 0 ? closeAdd : undefined} isEnglish={isEnglish} editing={!!editingId} error={loginError} /></Modal><Modal visible={showAccount} transparent animationType="fade" statusBarTranslucent onRequestClose={() => setShowAccount(false)}><AccountModal info={accountInfo} loading={accountLoading} error={accountError} providerName={activeProvider?.name || ''} isEnglish={isEnglish} onRefresh={refreshAccount} onProfiles={() => { setShowAccount(false); guard(() => setShowProfiles(true)); }} onClose={() => setShowAccount(false)} /></Modal><Modal visible={showPlayerPicker} transparent animationType="fade" statusBarTranslucent onRequestClose={() => setShowPlayerPicker(false)}><PlayerPicker value={playerEngine} isEnglish={isEnglish} onSelect={choosePlayerEngine} onClose={() => setShowPlayerPicker(false)} /></Modal><Modal visible={showAutomation} transparent animationType="fade" statusBarTranslucent onRequestClose={() => setShowAutomation(false)}><AutomationSettings value={automation} isEnglish={isEnglish} onSave={saveAutomationSettings} onBack={() => setShowAutomation(false)} onUpdateNow={updateNow} /></Modal><Modal visible={showHidden} transparent animationType="fade" statusBarTranslucent onRequestClose={() => setShowHidden(false)}><HiddenCategories categories={allCategoryNames} hidden={hiddenCats} isEnglish={isEnglish} onToggle={toggleHidden} onShowAll={t => saveHidden({...hiddenCats, [t]: []})} onClose={() => setShowHidden(false)} /></Modal><Modal visible={showExit} transparent animationType="fade" statusBarTranslucent onRequestClose={() => setShowExit(false)}><ChoiceModal title={tx('الخروج من التطبيق', 'Exit the app')} sub={tx('هل تريد الخروج من TurboX IPTV؟', 'Do you want to exit TurboX IPTV?')} value="no" closeLabel={tx('إلغاء', 'Cancel')} options={[{id: 'no', label: tx('لا، ابقَ في التطبيق', 'No, stay in the app')}, {id: 'yes', label: tx('نعم، اخرج', 'Yes, exit')}]} onSelect={id => { setShowExit(false); if (id === 'yes') BackHandler.exitApp(); }} onClose={() => setShowExit(false)} /></Modal><Modal visible={showRemoteGuide} transparent animationType="fade" statusBarTranslucent onRequestClose={() => setShowRemoteGuide(false)}><RemoteGuide isEnglish={isEnglish} onClose={() => setShowRemoteGuide(false)} /></Modal><Modal visible={showThemes} transparent animationType="fade" statusBarTranslucent onRequestClose={() => setShowThemes(false)}><ChoiceModal title={tx('السمات', 'Themes')} sub={tx('يتغير لون التطبيق فورًا.', 'The app colour changes immediately.')} value={theme} closeLabel={tx('إغلاق', 'Close')} options={(Object.keys(themeAccents) as ThemeName[]).map(id => ({id, label: THEME_LABELS[id][isEnglish ? 1 : 0], color: themeAccents[id]}))} onSelect={id => { changeTheme(id as ThemeName); setShowThemes(false); }} onClose={() => setShowThemes(false)} /></Modal><Modal visible={showScreensaverPicker} transparent animationType="fade" statusBarTranslucent onRequestClose={() => setShowScreensaverPicker(false)}><ChoiceModal title={tx('شاشة التوقف', 'Screensaver')} sub={tx('تعتيم الشاشة وتحريك الشعار بعد فترة من عدم الاستخدام، لحماية شاشات OLED من حرق البكسلات.', 'Dims the screen and moves the logo after a period of inactivity, to protect OLED screens from burn-in.')} value={String(screensaverMin)} closeLabel={tx('إغلاق', 'Close')} options={([0, 5, 10, 30] as ScreensaverMinutes[]).map(m => ({id: String(m), label: SCREENSAVER_LABELS[m][isEnglish ? 1 : 0]}))} onSelect={id => chooseScreensaver(Number(id) as ScreensaverMinutes)} onClose={() => setShowScreensaverPicker(false)} /></Modal><Modal visible={showAudioPref} transparent animationType="fade" statusBarTranslucent onRequestClose={() => setShowAudioPref(false)}><ChoiceModal title={tx('لغة الصوت المفضلة', 'Preferred audio language')} sub={tx('تُختار تلقائيًا عند توفّرها في الفيلم أو المسلسل، دون فتح قائمة المسارات.', 'Picked automatically when available in a movie or series, without opening the track menu.')} value={audioPref} closeLabel={tx('إغلاق', 'Close')} options={LANG_PREF_OPTIONS.map(o => ({id: o.id, label: o.label[isEnglish ? 1 : 0]}))} onSelect={chooseAudioPref} onClose={() => setShowAudioPref(false)} /></Modal><Modal visible={showSubPref} transparent animationType="fade" statusBarTranslucent onRequestClose={() => setShowSubPref(false)}><ChoiceModal title={tx('الترجمة المفضلة', 'Preferred subtitles')} sub={tx('تُختار تلقائيًا عند توفّرها، دون فتح قائمة المسارات.', 'Picked automatically when available, without opening the track menu.')} value={subPref} closeLabel={tx('إغلاق', 'Close')} options={SUB_PREF_OPTIONS.map(o => ({id: o.id, label: o.label[isEnglish ? 1 : 0]}))} onSelect={chooseSubPref} onClose={() => setShowSubPref(false)} /></Modal>{showProviderCheck && activeProvider && <ProviderCheckModal visible={showProviderCheck} provider={activeProvider} accent={accent} isEnglish={isEnglish} onPhone={text => setPhoneText({title: tx('فحص المزوّد', 'Provider check'), text})} onClose={() => setShowProviderCheck(false)} />}<TextServerModal visible={!!phoneText} isEnglish={isEnglish} title={phoneText?.title || ''} text={phoneText?.text || ''} onClose={() => setPhoneText(null)} /><BackupModal visible={showBackup} isEnglish={isEnglish} accent={accent} exportText={buildBackupJson()} onImport={applyBackup} onClose={() => setShowBackup(false)} />{deviceMode === 'tv' && player && showCast && <CastModal visible={showCast} isEnglish={isEnglish} accent={accent} streamUrl={player.url} title={player.title} onClose={() => setShowCast(false)} />}<Modal visible={showSleep} transparent animationType="fade" statusBarTranslucent onRequestClose={() => setShowSleep(false)}><ChoiceModal title={tx('مؤقت النوم', 'Sleep timer')} sub={tx('يوقف التشغيل ويغلق المشغّل بعد المدة المحددة.', 'Stops playback and closes the player after the chosen time.')} value={String(sleepMin)} closeLabel={tx('إغلاق', 'Close')} options={[{id: '0', label: tx('إيقاف', 'Off')}, ...[15, 30, 45, 60, 90, 120].map(m => ({id: String(m), label: tx(`${m} دقيقة`, `${m} minutes`)}))]} onSelect={id => { setSleepMinutes(Number(id)); setShowSleep(false); }} onClose={() => setShowSleep(false)} /></Modal>{catalogLoading && !catalogReady && <View style={styles.catalogLoadingOverlay}><View style={styles.catalogLoadingCard}><ActivityIndicator color={accent} size="large" /><Text style={styles.catalogLoadingTitle}>جاري تحميل المصدر بالكامل</Text><Text style={styles.catalogLoadingSub}>لن يتم فتح Live أو Movies أو Series قبل اكتمال التحميل.</Text></View></View>}</View></SafeAreaView></StarFocusContext.Provider></TVModeContext.Provider>;
}