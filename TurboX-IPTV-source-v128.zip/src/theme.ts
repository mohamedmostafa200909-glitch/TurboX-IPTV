import type { ThemeName } from './types';

export const bg = '#0b0b12';
export const card = '#1a1a1e';
export const themeAccents: Record<ThemeName, string> = {
  turbo: '#e11d2e',
  ember: '#ff3d62',
  ocean: '#27bde8',
  violet: '#b486ff',
  green: '#5de0b5'
};