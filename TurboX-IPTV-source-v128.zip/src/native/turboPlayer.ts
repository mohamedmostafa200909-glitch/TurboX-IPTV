import { requireNativeComponent } from 'react-native';

export const NativeTurboPlayerView = requireNativeComponent<any>('TurboPlayerView');