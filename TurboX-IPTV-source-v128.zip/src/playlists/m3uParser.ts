export type ParsedM3uItem = {
  name: string;
  url: string;
  group?: string;
  logo?: string;
  tvgId?: string;
  tvgName?: string;
};

function attr(line: string, key: string) {
  return line.match(new RegExp(`${key}="([^"]*)"`, 'i'))?.[1] || undefined;
}

export function parseM3uChunk(lines: string[], start = 0, end = lines.length): ParsedM3uItem[] {
  const result: ParsedM3uItem[] = [];
  let pending: Omit<ParsedM3uItem, 'url'> | null = null;
  for (let i = start; i < end; i += 1) {
    const line = lines[i].trim();
    if (!line) continue;
    if (line.toUpperCase().startsWith('#EXTINF')) {
      const comma = line.indexOf(',');
      pending = {
        name: comma >= 0 ? line.slice(comma + 1).trim() : 'قناة',
        group: attr(line, 'group-title') || 'عام',
        logo: attr(line, 'tvg-logo'),
        tvgId: attr(line, 'tvg-id'),
        tvgName: attr(line, 'tvg-name'),
      };
    } else if (pending && !line.startsWith('#')) {
      result.push({ ...pending, url: line });
      pending = null;
    }
  }
  return result;
}

export async function parseM3uText(
  text: string,
  onBatch?: (items: ParsedM3uItem[], parsed: number) => Promise<void> | void,
  batchSize = 500,
) {
  const lines = text.split(/\r?\n/);
  let total = 0;
  let start = 0;
  while (start < lines.length) {
    let end = Math.min(lines.length, start + batchSize * 2);
    // never cut between an #EXTINF line and its URL: that would silently drop one channel per batch
    while (end < lines.length && (!lines[end - 1].trim() || lines[end - 1].trim().startsWith('#'))) end += 1;
    const batch = parseM3uChunk(lines, start, end);
    total += batch.length;
    if (onBatch) await onBatch(batch, total);
    // Yield to React between batches so a 10,000+ item playlist does not lock the UI.
    await new Promise<void>(resolve => setTimeout(resolve, 0));
    start = end;
  }
  return total;
}
