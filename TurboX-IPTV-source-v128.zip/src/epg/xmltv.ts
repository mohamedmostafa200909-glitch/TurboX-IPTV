/**
 * XMLTV support for M3U sources.
 *
 *  - extractTvgUrl(): reads the guide URL from the playlist header (`url-tvg` / `x-tvg-url`).
 *  - fetchXmltv():   downloads the guide (plain XML; `.gz` files are not supported on-device).
 *  - parseXmltv():   parses <programme> entries in small batches (never freezes the UI), keeping only
 *                    channels we care about and a time window around "now".
 */
import { uaFor } from '../network/userAgent';

export type Listing = { t: string; d?: string; s: number; e: number };
export type XmltvData = Record<string, Listing[]>;

export function extractTvgUrl(m3uText: string): string | null {
  const head = m3uText.slice(0, 2000).split(/\r?\n/).find(l => l.trim().toUpperCase().startsWith('#EXTM3U'));
  if (!head) return null;
  const m = head.match(/(?:url-tvg|x-tvg-url|tvg-url)="([^"]+)"/i);
  const first = m?.[1]?.split(',')[0]?.trim();
  return first && /^https?:\/\//i.test(first) ? first : null;
}

function decodeEntities(v: string): string {
  return v
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)))
    .replace(/&amp;/g, '&')
    .trim();
}

/** "20260122183000 +0100" -> unix seconds. */
export function parseXmltvDate(raw: string | undefined): number {
  if (!raw) return 0;
  const m = raw.trim().match(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})?\s*([+-])?(\d{2})?(\d{2})?/);
  if (!m) return 0;
  const [, y, mo, d, h, mi, s = '0', sign, oh = '0', om = '0'] = m;
  const utc = Date.UTC(Number(y), Number(mo) - 1, Number(d), Number(h), Number(mi), Number(s)) / 1000;
  const offset = (Number(oh) * 3600 + Number(om) * 60) * (sign === '-' ? -1 : 1);
  return utc - offset;
}

export const normName = (v: string) => v.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '');

export async function fetchXmltv(url: string, timeoutMs = 60000, maxBytes = 90 * 1024 * 1024, userAgent?: string): Promise<string> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: ctrl.signal, headers: { 'User-Agent': uaFor({ userAgent }), Accept: '*/*' } });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const len = Number(res.headers.get('content-length') || 0);
    if (len > maxBytes) throw new Error('XMLTV file is too large for this device');
    const text = await res.text();
    if (!/<tv[\s>]/i.test(text.slice(0, 4000))) throw new Error('Not a plain XMLTV file (compressed .gz guides are not supported)');
    return text;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Parse the guide. `wanted` maps a lowercase XMLTV channel id (or normalised display name) to the
 * key(s) the app uses for that channel; programmes of other channels are skipped to save memory.
 */
export async function parseXmltv(
  xml: string,
  wanted: Map<string, string[]>,
  nowSec = Date.now() / 1000,
  keepPastSec = 3 * 3600,
  keepAheadSec = 36 * 3600,
  maxPerChannel = 24,
): Promise<XmltvData> {
  // XMLTV channel id -> app keys, using the <channel> display names as a fallback match.
  const idToKeys = new Map<string, string[]>();
  const chRe = /<channel\s+id="([^"]*)"[^>]*>([\s\S]*?)<\/channel>/gi;
  let cm: RegExpExecArray | null;
  while ((cm = chRe.exec(xml))) {
    const id = decodeEntities(cm[1]).toLowerCase();
    let keys = wanted.get(id);
    if (!keys) {
      const names = [...cm[2].matchAll(/<display-name[^>]*>([\s\S]*?)<\/display-name>/gi)].map(x => normName(decodeEntities(x[1])));
      for (const n of names) { keys = wanted.get(n); if (keys) break; }
    }
    if (keys) idToKeys.set(id, keys);
  }
  // channels the playlist referenced by id but that have no <channel> block still match directly
  wanted.forEach((keys, id) => { if (!idToKeys.has(id) && !/^\W|\s/.test(id)) idToKeys.set(id, keys); });

  const out: XmltvData = {};
  const progRe = /<programme\s+([^>]*)>([\s\S]*?)<\/programme>/gi;
  let pm: RegExpExecArray | null;
  let n = 0;
  while ((pm = progRe.exec(xml))) {
    if (++n % 4000 === 0) await new Promise<void>(r => setTimeout(r, 0)); // keep the UI responsive
    const attrs = pm[1];
    const ch = attrs.match(/channel="([^"]*)"/i)?.[1];
    if (!ch) continue;
    const keys = idToKeys.get(decodeEntities(ch).toLowerCase());
    if (!keys) continue;
    const s = parseXmltvDate(attrs.match(/start="([^"]*)"/i)?.[1]);
    const e = parseXmltvDate(attrs.match(/stop="([^"]*)"/i)?.[1]);
    if (!s || !e || e < nowSec - keepPastSec || s > nowSec + keepAheadSec) continue;
    const title = pm[2].match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1];
    if (!title) continue;
    const desc = pm[2].match(/<desc[^>]*>([\s\S]*?)<\/desc>/i)?.[1];
    const item: Listing = { t: decodeEntities(title), s, e };
    if (desc) item.d = decodeEntities(desc).slice(0, 400);
    for (const k of keys) {
      const list = (out[k] = out[k] || []);
      if (list.length < maxPerChannel) list.push(item);
    }
  }
  Object.values(out).forEach(l => l.sort((a, b) => a.s - b.s));
  return out;
}
