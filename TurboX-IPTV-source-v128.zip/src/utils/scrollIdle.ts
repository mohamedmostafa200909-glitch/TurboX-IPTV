/**
 * "Is the list still moving?" — used on TV so poster/logo images are only requested once scrolling calms down.
 * Decoding dozens of images while a held arrow key scrolls the list is a big part of the stutter on weak boxes.
 * Pure (no React Native): the clock and timers are injectable for tests.
 */
export const IDLE_MS = 220;

export function createScrollIdle(now: () => number = Date.now, setTimer: (fn: () => void, ms: number) => unknown = setTimeout) {
  let last = -Infinity;
  let pending = false;
  const waiting = new Set<() => void>();
  const isIdle = () => now() - last >= IDLE_MS;
  function check() {
    pending = false;
    if (!isIdle()) { schedule(); return; }
    const list = Array.from(waiting);
    waiting.clear();
    list.forEach(fn => fn());
  }
  function schedule() {
    if (pending) return;
    pending = true;
    setTimer(check, IDLE_MS + 20);
  }
  return {
    /** call on every scroll event */
    noteScroll() { last = now(); if (waiting.size) schedule(); },
    isIdle,
    /** run `fn` now if the list is calm, otherwise right after it calms down. Returns a cancel function. */
    onceIdle(fn: () => void) {
      if (isIdle()) { fn(); return () => undefined; }
      waiting.add(fn);
      schedule();
      return () => { waiting.delete(fn); };
    },
  };
}

export const scrollIdle = createScrollIdle();
