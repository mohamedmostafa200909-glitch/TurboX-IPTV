/**
 * Xtream returns programme titles/descriptions base64-encoded (UTF-8). Decoded here without atob/TextDecoder so it
 * works on every JS engine. Text that is not valid base64 (M3U/XMLTV guides, some panels) is returned unchanged.
 */
const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

function b64ToBytes(input: string): number[] | null {
  const s = input.replace(/\s+/g, '').replace(/=+$/, '');
  if (!s || s.length % 4 === 1 || /[^A-Za-z0-9+/]/.test(s)) return null;
  const bytes: number[] = [];
  let buf = 0, bits = 0;
  for (const ch of s) {
    buf = (buf << 6) | B64.indexOf(ch);
    bits += 6;
    if (bits >= 8) { bits -= 8; bytes.push((buf >> bits) & 0xff); buf &= (1 << bits) - 1; }
  }
  return bytes;
}

function utf8(bytes: number[]): string | null {
  let out = '';
  for (let i = 0; i < bytes.length;) {
    const b = bytes[i];
    let cp: number, n: number;
    if (b < 0x80) { cp = b; n = 1; }
    else if ((b & 0xe0) === 0xc0) { cp = b & 0x1f; n = 2; }
    else if ((b & 0xf0) === 0xe0) { cp = b & 0x0f; n = 3; }
    else if ((b & 0xf8) === 0xf0) { cp = b & 0x07; n = 4; }
    else return null;
    if (i + n > bytes.length) return null;
    for (let j = 1; j < n; j++) { if ((bytes[i + j] & 0xc0) !== 0x80) return null; cp = (cp << 6) | (bytes[i + j] & 0x3f); }
    out += String.fromCodePoint(cp);
    i += n;
  }
  return out;
}

export function decodeEpgText(value: unknown): string {
  const raw = String(value ?? '');
  // plain text normally contains spaces/punctuation; base64 never does
  if (!raw || /[^A-Za-z0-9+/=\s]/.test(raw) || raw.length < 4) return raw;
  const bytes = b64ToBytes(raw);
  const text = bytes ? utf8(bytes) : null;
  // reject results with control characters: it was a plain word that merely looked like base64
  if (!text || /[\u0000-\u0008\u000e-\u001f\ufffd]/.test(text)) return raw;
  return text;
}
