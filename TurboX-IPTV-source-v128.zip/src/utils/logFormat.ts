import { redact } from './sanitize';

export type LogEntry = { t: number; lvl: 'info' | 'warn' | 'error'; tag: string; msg: string };
export const MAX_LOGS = 150;

/** Appends an entry (credentials removed) and keeps only the newest MAX_LOGS. Pure. */
export function pushLog(list: LogEntry[], lvl: LogEntry['lvl'], tag: string, msg: unknown, now = Date.now()): LogEntry[] {
  const text = redact(typeof msg === 'string' ? msg : (msg as any)?.stack || (msg as any)?.message || String(msg)).slice(0, 600);
  const next = [...list, { t: now, lvl, tag, msg: text }];
  return next.length > MAX_LOGS ? next.slice(next.length - MAX_LOGS) : next;
}

const pad = (n: number) => String(n).padStart(2, '0');
export function formatLogs(list: LogEntry[], header = ''): string {
  const lines = list.map(e => {
    const d = new Date(e.t);
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())} [${e.lvl.toUpperCase()}] ${e.tag}: ${e.msg}`;
  });
  return (header ? `${header}\n` : '') + lines.join('\n');
}
