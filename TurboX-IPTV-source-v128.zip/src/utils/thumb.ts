/**
 * Poster thumbnails. Many Xtream panels send TMDB poster URLs at "original" (or w500/w780) size: several MB of pixels to
 * download and decode for a card that is ~300 px wide. TMDB serves fixed sizes from the same path, so asking for a
 * smaller one is just a different path segment. Other hosts are returned untouched (we cannot resize them).
 */
const TMDB = /(image\.tmdb\.org\/t\/p\/)(original|[wh]\d{2,4})(\/)/i;

export function thumbUrl(url: string, width: 154 | 185 | 342 | 500 = 342): string {
  if (!url) return url;
  const m = TMDB.exec(url);
  if (!m) return url;
  const cur = m[2].toLowerCase();
  if (cur.startsWith('w') && Number(cur.slice(1)) <= width) return url; // already small enough: never upscale
  return url.replace(TMDB, `$1w${width}$3`);
}
