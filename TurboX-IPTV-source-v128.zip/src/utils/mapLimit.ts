/** Runs `fn` over `items` with at most `limit` in flight; stops starting new work once `shouldStop()` is true. Pure. */
export async function mapLimit<T>(items: T[], limit: number, fn: (item: T, index: number) => Promise<void>, shouldStop: () => boolean = () => false): Promise<void> {
  let next = 0;
  const worker = async () => {
    while (next < items.length && !shouldStop()) {
      const i = next++;
      await fn(items[i], i);
    }
  };
  await Promise.all(Array.from({ length: Math.min(Math.max(1, limit), items.length) }, worker));
}
