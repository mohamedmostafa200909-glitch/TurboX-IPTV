import AsyncStorage from '@react-native-async-storage/async-storage';
import { LogEntry, pushLog } from './logFormat';

/**
 * Small persistent log (last 150 entries, credentials removed) so a user can send the developer what went wrong
 * from Settings → Logs without ADB.
 */
const KEY = 'streambox.logs';
let buffer: LogEntry[] = [];
let loaded: Promise<void> | null = null;
let timer: ReturnType<typeof setTimeout> | null = null;
const listeners = new Set<() => void>();

function load(): Promise<void> {
  if (!loaded) {
    loaded = AsyncStorage.getItem(KEY).then(raw => {
      if (!raw) return;
      try { const old = JSON.parse(raw) as LogEntry[]; buffer = [...old, ...buffer].slice(-150); } catch { /* ignore corrupt log */ }
    }).catch(() => undefined);
  }
  return loaded as Promise<void>;
}

function schedule() {
  if (timer) return;
  timer = setTimeout(() => {
    timer = null;
    AsyncStorage.setItem(KEY, JSON.stringify(buffer)).catch(() => undefined);
  }, 1500);
}

export function log(lvl: LogEntry['lvl'], tag: string, msg: unknown) {
  buffer = pushLog(buffer, lvl, tag, msg);
  load().then(schedule);
  listeners.forEach(l => l());
}
export const logInfo = (tag: string, msg: unknown) => log('info', tag, msg);
export const logWarn = (tag: string, msg: unknown) => log('warn', tag, msg);
export const logError = (tag: string, msg: unknown) => log('error', tag, msg);

export async function getLogs(): Promise<LogEntry[]> { await load(); return buffer; }
export async function clearLogs() { buffer = []; await AsyncStorage.removeItem(KEY).catch(() => undefined); listeners.forEach(l => l()); }

/** Also record uncaught JS errors; the app's default handler still runs afterwards. */
export function installGlobalErrorLogging() {
  const eu = (globalThis as any).ErrorUtils;
  if (!eu?.setGlobalHandler || (installGlobalErrorLogging as any).done) return;
  (installGlobalErrorLogging as any).done = true;
  const previous = eu.getGlobalHandler?.();
  eu.setGlobalHandler((error: any, isFatal?: boolean) => {
    logError(isFatal ? 'fatal' : 'uncaught', error);
    previous?.(error, isFatal);
  });
}
