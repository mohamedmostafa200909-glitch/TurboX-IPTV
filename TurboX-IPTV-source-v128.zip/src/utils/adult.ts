/** Kid-profile filter: true when a category name looks like adult content. Pure. */
const LATIN = /(^|[^a-z])(xxx|adults?|porno?|sex|sexy|erotic|hentai|nsfw)([^a-z]|$)/i;
const AGE = /\+\s?18|18\s?\+/;
const ARABIC = /(اباح|إباح|للكبار|بالغين|اغراء|إغراء)/;
export function isAdultCategory(name: string | undefined): boolean {
  const n = String(name || '');
  return LATIN.test(n) || AGE.test(n) || ARABIC.test(n);
}
