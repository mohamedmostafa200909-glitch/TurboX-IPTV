/** Accent/diacritic-insensitive search used by the global search screen. Pure and unit-tested. */

/** lower-case, no Arabic diacritics/tatweel, unified alef/yaa/taa-marbuta forms, punctuation → spaces */
export function normalizeText(input: string): string {
  return String(input || '')
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[\u0622\u0623\u0625\u0671]/g, '\u0627')
    .replace(/\u0649/g, '\u064A')
    .replace(/\u0629/g, '\u0647')
    .replace(/[\u0624]/g, '\u0648')
    .replace(/[\u0626]/g, '\u064A')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export type SearchIndex<T> = Array<{ item: T; n: string }>;

export function buildIndex<T>(items: T[], nameOf: (t: T) => string): SearchIndex<T> {
  const out: SearchIndex<T> = new Array(items.length);
  for (let i = 0; i < items.length; i++) out[i] = { item: items[i], n: normalizeText(nameOf(items[i])) };
  return out;
}

/** every query word must appear; best first: name starts with the query, then a word starts with it, then any match */
export function searchIndex<T>(index: SearchIndex<T>, query: string, limit = 12): T[] {
  const q = normalizeText(query);
  if (!q) return [];
  const tokens = q.split(' ');
  const b0: T[] = [];
  const b1: T[] = [];
  const b2: T[] = [];
  for (let i = 0; i < index.length; i++) {
    const { item, n } = index[i];
    let ok = true;
    for (let t = 0; t < tokens.length; t++) if (n.indexOf(tokens[t]) < 0) { ok = false; break; }
    if (!ok) continue;
    if (n.startsWith(q)) { if (b0.length < limit) b0.push(item); }
    else if (n.indexOf(' ' + tokens[0]) >= 0) { if (b1.length < limit) b1.push(item); }
    else if (b2.length < limit) b2.push(item);
    if (b0.length >= limit) break;
  }
  return b0.concat(b1, b2).slice(0, limit);
}
