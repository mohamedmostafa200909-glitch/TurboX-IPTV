import type { Media } from '../types';

export function mediaId(item: Media) {
  return item.stream_id ?? item.series_id ?? item.id;
}
export function channelKey(channel: Media) {
  return String(mediaId(channel) || channel.url || channel.name);
}
export function normalizeServer(value: string) {
  let server = value.trim().replace(/\s+/g, '');
  if (!/^https?:\/\//i.test(server)) server = `http://${server}`;
  server = server.replace(/\/(player_api|get)\.php.*$/i, '');
  return server.replace(/\/$/, '');
}
export function isM3u(value: string) {
  return /\.m3u8?(?:\?|$)/i.test(value) || /iptv-org\.github\.io/i.test(value) || /[?&]type=m3u/i.test(value);
}
export function isM3uProvider(p: {server: string; m3u?: boolean}) {
  return !!p.m3u || isM3u(p.server);
}
export function serverCandidates(value: string) {
  const server = normalizeServer(value);
  const candidates = [server];
  // Some Xtream panels expose the API on the opposite protocol from the stream.
  if (/^https:\/\//i.test(server)) candidates.push(server.replace(/^https:\/\//i, 'http://'));
  if (/^http:\/\//i.test(server)) candidates.push(server.replace(/^http:\/\//i, 'https://'));
  const https80 = server.match(/^https:\/\/([^/]+):80(\/.*)?$/i);
  const http443 = server.match(/^http:\/\/([^/]+):443(\/.*)?$/i);
  if (https80) candidates.push(`http://${https80[1]}:80${https80[2] || ''}`);
  if (http443) candidates.push(`https://${http443[1]}:443${http443[2] || ''}`);
  return [...new Set(candidates)];
}