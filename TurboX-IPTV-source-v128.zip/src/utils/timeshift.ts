/** Xtream catch-up ("timeshift") URL. `start` is the server-time string from the EPG ("YYYY-MM-DD HH:MM:SS"). */
export function timeshiftUrl(server: string, username: string, password: string, minutes: number, start: string, streamId: string | number, ext = 'ts'): string | null {
  const m = String(start || '').match(/^(\d{4}-\d{2}-\d{2})[ T](\d{2}):(\d{2})/);
  if (!m || !(minutes > 0)) return null;
  return `${server.replace(/\/$/, '')}/timeshift/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${Math.round(minutes)}/${m[1]}:${m[2]}-${m[3]}/${streamId}.${ext}`;
}
