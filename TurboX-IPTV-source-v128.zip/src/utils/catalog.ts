import type { Media } from '../types';

/** True while a saved catalogue is recent enough to skip downloading. `enabled=false` means "never auto-refresh". */
export function isCacheFresh(savedAt: number, now: number, enabled: boolean, days: number): boolean {
  if (!enabled) return true;
  return now - Number(savedAt || 0) < days * 86400000;
}

const USELESS = ['custom_sid', 'direct_source', 'thumbnail', 'stream_type', 'is_adult', 'backdrop_path', 'youtube_trailer', 'episode_run_time'];

/** Drops fields the app never reads and empty values: a 50k-item catalogue shrinks a lot in memory and in the cache. */
export function slimMedia<T extends Record<string, any>>(item: T): T {
  const out: Record<string, any> = {};
  for (const k of Object.keys(item)) {
    if (USELESS.includes(k)) continue;
    const v = item[k];
    if (v === '' || v === null || v === undefined) continue;
    out[k] = v;
  }
  return out as T;
}

export function slimList(items: Media[]): Media[] {
  return items.map(i => slimMedia(i as any) as Media);
}
