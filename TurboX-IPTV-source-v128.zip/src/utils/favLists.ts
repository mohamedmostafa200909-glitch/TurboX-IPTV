/** Several favourites lists per profile. The default list keeps the old storage key so existing favourites still load. */
export type FavList = { id: string; name: string };
export const DEFAULT_LIST_ID = 'default';

export function favListsKey(providerId: string) { return `streambox.favLists.${providerId}`; }
export function favItemsKey(providerId: string, listId: string, legacyProfileName: string) {
  return listId === DEFAULT_LIST_ID ? `streambox.favorites.${providerId}.${legacyProfileName}` : `streambox.favlist.${providerId}.${listId}`;
}
export function normalizeLists(raw: unknown, defaultName: string): FavList[] {
  const arr = Array.isArray(raw) ? raw.filter((x: any) => x && typeof x.id === 'string' && typeof x.name === 'string') as FavList[] : [];
  return arr.some(l => l.id === DEFAULT_LIST_ID) ? arr : [{ id: DEFAULT_LIST_ID, name: defaultName }, ...arr];
}
