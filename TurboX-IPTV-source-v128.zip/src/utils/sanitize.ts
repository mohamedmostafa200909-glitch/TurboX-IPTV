/** Removes credentials from any text that may be logged or shared. Pure: no React Native imports. */
export function redact(text: string): string {
  return String(text ?? '')
    .replace(/(\b(?:username|password|user|pass|token)=)[^&\s"']*/gi, '$1***')
    .replace(/(\/(?:live|movie|series|timeshift|vod)\/)[^/\s"']+\/[^/\s"']+(?=\/)/gi, '$1***/***')
    .replace(/(\/(?:live|movie|series|timeshift|vod)\/\*\*\*\/\*\*\*\/)\d+\/[\d:-]+/gi, '$1***');
}
