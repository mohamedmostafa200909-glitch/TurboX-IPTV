/** Where the app opens: the home screen, straight into Live TV, or resuming the last live channel. */
export type StartupMode = 'home' | 'live' | 'last';
export const STARTUP_KEY = 'streambox.startup';
export const LAST_LIVE_KEY = 'streambox.lastLive'; // `${providerId}|${channelKey}`
/** Default 'live' = the app's previous behaviour (it always opened Live TV after loading). */
export function parseStartup(v: unknown): StartupMode { return v === 'home' || v === 'last' ? v : 'live'; }
export function lastLiveValue(providerId: string, key: string) { return `${providerId}|${key}`; }
export function parseLastLive(v: string | null | undefined): { providerId: string; key: string } | null {
  if (!v) return null;
  const i = v.indexOf('|');
  return i > 0 ? { providerId: v.slice(0, i), key: v.slice(i + 1) } : null;
}
