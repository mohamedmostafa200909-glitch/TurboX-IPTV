import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';

/**
 * Parental-control PIN, kept in the platform keystore (Android Keystore via expo-secure-store).
 * The old plain-text AsyncStorage value (`streambox.parentalPin`) is migrated on first load and
 * removed. If the keystore is unavailable the PIN stays in AsyncStorage so the feature keeps working.
 */
const LEGACY_KEY = 'streambox.parentalPin';
const SECURE_KEY = 'streambox.secure.parentalPin';

export async function loadPin(legacyValue?: string | null): Promise<string> {
  try {
    const secure = await SecureStore.getItemAsync(SECURE_KEY);
    if (secure) return secure;
  } catch { /* keystore unavailable: use the legacy value below */ }

  const legacy = legacyValue ?? (await AsyncStorage.getItem(LEGACY_KEY).catch(() => null));
  if (!legacy) return '';
  try {
    await SecureStore.setItemAsync(SECURE_KEY, legacy);
    await AsyncStorage.removeItem(LEGACY_KEY); // migrated: no plain-text copy left
  } catch { /* keep the legacy copy if we could not migrate */ }
  return legacy;
}

/** An empty PIN turns parental control off. */
export async function savePin(pin: string): Promise<void> {
  try {
    if (pin) await SecureStore.setItemAsync(SECURE_KEY, pin);
    else await SecureStore.deleteItemAsync(SECURE_KEY);
    await AsyncStorage.removeItem(LEGACY_KEY);
  } catch {
    await AsyncStorage.setItem(LEGACY_KEY, pin); // keystore unavailable
  }
}
