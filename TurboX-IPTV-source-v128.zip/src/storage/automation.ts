import AsyncStorage from '@react-native-async-storage/async-storage';

/** Settings → Automation: when the catalogue (Live/Movies/Series) and the EPG refresh themselves. */
export type Automation = {
  catalogEnabled: boolean;
  catalogDays: number;
  epgEnabled: boolean;
  epgDays: number;
};

export const DAY_OPTIONS = [1, 2, 3, 5, 7, 14, 30];
export const DEFAULT_AUTOMATION: Automation = { catalogEnabled: true, catalogDays: 7, epgEnabled: true, epgDays: 7 };
const KEY = 'streambox.automation';

export async function loadAutomation(): Promise<Automation> {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    if (!raw) return DEFAULT_AUTOMATION;
    const v = JSON.parse(raw);
    return {
      catalogEnabled: v.catalogEnabled !== false,
      catalogDays: DAY_OPTIONS.includes(Number(v.catalogDays)) ? Number(v.catalogDays) : DEFAULT_AUTOMATION.catalogDays,
      epgEnabled: v.epgEnabled !== false,
      epgDays: DAY_OPTIONS.includes(Number(v.epgDays)) ? Number(v.epgDays) : DEFAULT_AUTOMATION.epgDays,
    };
  } catch {
    return DEFAULT_AUTOMATION;
  }
}

export async function saveAutomation(a: Automation) {
  await AsyncStorage.setItem(KEY, JSON.stringify(a));
}
