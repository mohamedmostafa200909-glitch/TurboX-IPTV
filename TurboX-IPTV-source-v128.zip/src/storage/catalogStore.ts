import type { Media } from '../types';

/**
 * Xtream catalogue snapshot (pure logic; the app binds it to the SQLite-backed cache in catalogCache.ts).
 *
 * - Each list is stored in CHUNKS of a few thousand items. Parsing/stringifying a 25 MB JSON string in one go froze the
 *   JS thread for seconds on weak TV boxes; chunks are processed one at a time with a yield in between, so the remote
 *   and the spinner keep working while a large catalogue is saved or loaded.
 * - The meta record is written LAST (and removed FIRST): an interrupted write leaves no meta, so the half-written
 *   snapshot is ignored and re-downloaded instead of mixing old and new chunks.
 * - The meta also holds item counts, so the app can start with only the live channels in memory and load movies/series
 *   the first time something needs them (readHeavy).
 * - Snapshots written by older versions (one record, or one key per list) are still read, fully loaded.
 */
export type Counts = { live: number; movies: number; series: number };
export type Snapshot = {
  savedAt: number;
  expiresAt?: string;
  channels: Media[];
  movies: Media[];
  series: Media[];
  /** false = movies/series were NOT loaded (light read); true/undefined = everything is in this object */
  heavy?: boolean;
  counts?: Counts;
};

/** Minimal key-value storage the snapshot needs (the app passes the SQLite-backed cache; tests pass a Map). */
export type KV = { get: (key: string) => Promise<string | null>; set: (key: string, value: string) => Promise<unknown>; remove: (key: string) => Promise<unknown> };
export type StoreOptions = { chunkSize?: number; yieldFn?: () => Promise<void>; /** optional timing sink (startup diagnostics) */ log?: (msg: string) => void };

const LISTS = ['live', 'movies', 'series'] as const;
type ListName = typeof LISTS[number];
const part = (key: string, name: string) => `${key}.${name}`;
const chunkKey = (key: string, name: string, i: number) => `${key}.${name}.${i}`;

export function createSnapshotStore(io: KV, { chunkSize = 4000, yieldFn = () => Promise.resolve(), log }: StoreOptions = {}) {
  /** `chunks` = number of chunk records (new format); undefined = the old single record `key.name`. */
  async function readList(key: string, name: ListName, chunks?: number): Promise<Media[] | null> {
    if (chunks === undefined) {
      const raw = await io.get(part(key, name));
      if (!raw) return null;
      const list = JSON.parse(raw);
      return Array.isArray(list) ? list : null;
    }
    const out: Media[] = [];
    const t0 = Date.now();
    let tGet = 0;
    let tParse = 0;
    for (let i = 0; i < chunks; i++) {
      const a = Date.now();
      const raw = await io.get(chunkKey(key, name, i));
      tGet += Date.now() - a;
      if (!raw) return null; // a missing chunk makes the whole list untrustworthy
      const b = Date.now();
      const piece = JSON.parse(raw);
      tParse += Date.now() - b;
      if (!Array.isArray(piece)) return null;
      for (const item of piece) out.push(item);
      await yieldFn();
    }
    log?.(`${name}: ${out.length} items / ${chunks} chunks - storage ${tGet}ms, parse ${tParse}ms, total ${Date.now() - t0}ms`);
    return out;
  }

  async function readMeta(key: string): Promise<any | null> {
    const raw = await io.get(key);
    return raw ? JSON.parse(raw) : null;
  }

  /** `light` = leave movies/series on disk when the snapshot knows its counts. */
  async function readSnapshot(key: string, light = false): Promise<Snapshot | null> {
    const meta = await readMeta(key);
    if (!meta) return null;
    if (!meta.split) {
      return Array.isArray(meta.channels) && Array.isArray(meta.movies) && Array.isArray(meta.series) ? { ...meta, heavy: true } : null;
    }
    const channels = await readList(key, 'live', meta.chunks?.live);
    if (!channels) return null;
    if (light && meta.counts) {
      return { savedAt: meta.savedAt, expiresAt: meta.expiresAt, channels, movies: [], series: [], heavy: false, counts: meta.counts };
    }
    const movies = await readList(key, 'movies', meta.chunks?.movies);
    const series = await readList(key, 'series', meta.chunks?.series);
    if (!movies || !series) return null;
    return { savedAt: meta.savedAt, expiresAt: meta.expiresAt, channels, movies, series, heavy: true, counts: meta.counts };
  }

  /** The part a light read left out. Chunks are parsed one at a time (yielding in between). */
  async function readHeavy(key: string): Promise<{ movies: Media[]; series: Media[] } | null> {
    const meta = await readMeta(key);
    if (!meta?.split) return null;
    const movies = await readList(key, 'movies', meta.chunks?.movies);
    if (!movies) return null;
    const series = await readList(key, 'series', meta.chunks?.series);
    return series ? { movies, series } : null;
  }

  async function removeParts(key: string, meta: any | null) {
    for (const name of LISTS) {
      await io.remove(part(key, name)); // old single-record format
      const n = meta?.chunks?.[name] ?? 0;
      for (let i = 0; i < n; i++) await io.remove(chunkKey(key, name, i));
    }
  }

  async function writeSnapshot(key: string, snap: Snapshot): Promise<void> {
    let previous: any = null;
    try { previous = await readMeta(key); } catch { /* unreadable old meta: nothing to clean precisely */ }
    await io.remove(key); // invalidate first: from here until the new meta is written there is no valid snapshot
    const lists: Record<ListName, Media[]> = { live: snap.channels, movies: snap.movies, series: snap.series };
    const chunks = { live: 0, movies: 0, series: 0 };
    for (const name of LISTS) {
      const list = lists[name];
      const n = Math.ceil(list.length / chunkSize);
      for (let i = 0; i < n; i++) {
        await io.set(chunkKey(key, name, i), JSON.stringify(list.slice(i * chunkSize, (i + 1) * chunkSize)));
        await yieldFn();
      }
      chunks[name] = n;
      // chunks of a previous, larger snapshot that are no longer part of this one
      for (let i = n; i < (previous?.chunks?.[name] ?? 0); i++) await io.remove(chunkKey(key, name, i));
      await io.remove(part(key, name)); // leftover single record of the old format
    }
    const counts: Counts = { live: snap.channels.length, movies: snap.movies.length, series: snap.series.length };
    await io.set(key, JSON.stringify({ split: true, savedAt: snap.savedAt, expiresAt: snap.expiresAt, counts, chunks }));
  }

  async function removeSnapshot(key: string): Promise<void> {
    let meta: any = null;
    try { meta = await readMeta(key); } catch { /* ignore */ }
    await io.remove(key);
    await removeParts(key, meta);
  }

  return { readSnapshot, readHeavy, writeSnapshot, removeSnapshot };
}
