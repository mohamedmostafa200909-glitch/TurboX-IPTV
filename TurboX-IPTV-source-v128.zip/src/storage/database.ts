import * as SQLite from 'expo-sqlite';

export type StoredProvider = {
  id: string;
  name: string;
  server: string;
  username?: string;
  password?: string;
  kind: 'xtream' | 'm3u-url' | 'm3u-file';
};

let dbPromise: Promise<SQLite.SQLiteDatabase> | null = null;

export function getDatabase() {
  if (!dbPromise) dbPromise = SQLite.openDatabaseAsync('streambox.db');
  return dbPromise;
}

export async function initializeDatabase() {
  const db = await getDatabase();
  await db.execAsync(`
    PRAGMA journal_mode = WAL;
    CREATE TABLE IF NOT EXISTS preferences (key TEXT PRIMARY KEY NOT NULL, value TEXT);
    CREATE TABLE IF NOT EXISTS providers (
      id TEXT PRIMARY KEY NOT NULL,
      name TEXT NOT NULL,
      server TEXT NOT NULL,
      username TEXT,
      password TEXT,
      kind TEXT NOT NULL,
      updated_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS favorites (
      profile_id TEXT NOT NULL,
      provider_id TEXT NOT NULL,
      item_key TEXT NOT NULL,
      item_kind TEXT NOT NULL,
      title TEXT NOT NULL,
      payload TEXT,
      PRIMARY KEY (profile_id, provider_id, item_key)
    );
    CREATE TABLE IF NOT EXISTS watch_progress (
      profile_id TEXT NOT NULL,
      item_key TEXT NOT NULL,
      position_ms INTEGER NOT NULL DEFAULT 0,
      duration_ms INTEGER NOT NULL DEFAULT 0,
      updated_at INTEGER NOT NULL,
      PRIMARY KEY (profile_id, item_key)
    );
    CREATE INDEX IF NOT EXISTS idx_favorites_provider ON favorites(provider_id, profile_id);
    CREATE INDEX IF NOT EXISTS idx_progress_profile ON watch_progress(profile_id, updated_at DESC);
  `);
}

export async function setPreference(key: string, value: string) {
  const db = await getDatabase();
  await db.runAsync('INSERT OR REPLACE INTO preferences (key, value) VALUES (?, ?)', key, value);
}

export async function getPreference(key: string) {
  const db = await getDatabase();
  const row = await db.getFirstAsync<{ value: string }>('SELECT value FROM preferences WHERE key = ?', key);
  return row?.value ?? null;
}

export async function saveProvider(provider: StoredProvider) {
  const db = await getDatabase();
  await db.runAsync(
    `INSERT OR REPLACE INTO providers (id, name, server, username, password, kind, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    provider.id, provider.name, provider.server, provider.username ?? null,
    provider.password ?? null, provider.kind, Date.now(),
  );
}

export async function listProviders() {
  const db = await getDatabase();
  return db.getAllAsync<StoredProvider>('SELECT id, name, server, username, password, kind FROM providers ORDER BY updated_at DESC');
}

export async function saveFavorite(input: {
  profileId: string; providerId: string; itemKey: string; itemKind: string; title: string; payload?: unknown;
}) {
  const db = await getDatabase();
  await db.runAsync(
    `INSERT OR REPLACE INTO favorites (profile_id, provider_id, item_key, item_kind, title, payload)
     VALUES (?, ?, ?, ?, ?, ?)`,
    input.profileId, input.providerId, input.itemKey, input.itemKind, input.title,
    input.payload ? JSON.stringify(input.payload) : null,
  );
}

export async function removeFavorite(profileId: string, providerId: string, itemKey: string) {
  const db = await getDatabase();
  await db.runAsync('DELETE FROM favorites WHERE profile_id = ? AND provider_id = ? AND item_key = ?', profileId, providerId, itemKey);
}

export async function saveWatchProgress(profileId: string, itemKey: string, positionMs: number, durationMs: number) {
  const db = await getDatabase();
  await db.runAsync(
    `INSERT OR REPLACE INTO watch_progress (profile_id, item_key, position_ms, duration_ms, updated_at)
     VALUES (?, ?, ?, ?, ?)`, profileId, itemKey, Math.round(positionMs), Math.round(durationMs), Date.now(),
  );
}
