import { cacheGet, cacheRemove, cacheSet } from './cacheStore';
import { createSnapshotStore } from './catalogStore';
import { logInfo } from '../utils/logger';

export type { Counts, Snapshot } from './catalogStore';

/** Catalogue snapshot store bound to the app's SQLite-backed cache (logic and format live in catalogStore.ts). */
export const { readSnapshot, readHeavy, writeSnapshot, removeSnapshot } = createSnapshotStore(
  { get: cacheGet, set: cacheSet, remove: cacheRemove },
  { yieldFn: () => new Promise<void>(resolve => setTimeout(resolve, 0)), log: msg => logInfo('startup', msg) } // yield: let the UI/remote run between chunks
);
