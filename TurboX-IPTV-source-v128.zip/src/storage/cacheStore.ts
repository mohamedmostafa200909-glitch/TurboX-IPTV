import AsyncStorage from '@react-native-async-storage/async-storage';
import { getDatabase } from './database';

/**
 * Large JSON caches (the Xtream catalog, EPG, XMLTV) live in SQLite.
 * AsyncStorage on Android is backed by a SQLite database with a ~2 MB per-row read window, so a big
 * catalog (tens of thousands of channels/movies) can fail to load from it. A plain SQLite table has
 * no such limit.
 *
 * If SQLite is unavailable for any reason, every call falls back to AsyncStorage so the app keeps
 * working. Values written by older versions to AsyncStorage are migrated on first read.
 */
let ready: Promise<boolean> | null = null;

function ensure(): Promise<boolean> {
  if (!ready) {
    ready = (async () => {
      try {
        const db = await getDatabase();
        await db.execAsync('CREATE TABLE IF NOT EXISTS kv_cache (key TEXT PRIMARY KEY NOT NULL, value TEXT NOT NULL, saved_at INTEGER NOT NULL);');
        return true;
      } catch {
        return false;
      }
    })();
  }
  return ready;
}

export async function cacheGet(key: string): Promise<string | null> {
  if (await ensure()) {
    try {
      const db = await getDatabase();
      const row = await db.getFirstAsync<{ value: string }>('SELECT value FROM kv_cache WHERE key = ?', key);
      if (row?.value != null) return row.value;
    } catch { /* fall through to AsyncStorage */ }
  }
  // legacy location (older versions) - migrate when found
  try {
    const legacy = await AsyncStorage.getItem(key);
    if (legacy) {
      cacheSet(key, legacy).then(ok => { if (ok) AsyncStorage.removeItem(key).catch(() => undefined); }).catch(() => undefined);
      return legacy;
    }
  } catch { /* ignore */ }
  return null;
}

/** Resolves true when the value was stored in SQLite, false when only AsyncStorage could take it. */
export async function cacheSet(key: string, value: string): Promise<boolean> {
  if (await ensure()) {
    try {
      const db = await getDatabase();
      await db.runAsync('INSERT OR REPLACE INTO kv_cache (key, value, saved_at) VALUES (?, ?, ?)', key, value, Date.now());
      return true;
    } catch { /* fall through */ }
  }
  try { await AsyncStorage.setItem(key, value); } catch { /* too large for AsyncStorage: skip caching */ }
  return false;
}

export async function cacheRemove(key: string): Promise<void> {
  if (await ensure()) {
    try {
      const db = await getDatabase();
      await db.runAsync('DELETE FROM kv_cache WHERE key = ?', key);
    } catch { /* ignore */ }
  }
  try { await AsyncStorage.removeItem(key); } catch { /* ignore */ }
}
