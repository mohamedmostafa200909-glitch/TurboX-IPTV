import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';

/**
 * IPTV credentials (server URL, username, password) are kept in the platform keystore
 * (Android Keystore via expo-secure-store). AsyncStorage only holds a stripped list
 * (id + name + `secure: true`), so no password sits in plain text on disk.
 *
 * If the keystore is unavailable on a device, we fall back to the old plain format for that
 * provider so the app keeps working, and try again on the next save.
 */
export type StoredProvider = {
  id: string;
  name: string;
  server: string;
  username: string;
  password: string;
  connected?: boolean;
  m3u?: boolean;
  kid?: boolean;
  secure?: boolean;
  /** request User-Agent for this provider (not a secret: kept in the plain list, not the keystore) */
  userAgent?: string;
};

const LIST_KEY = 'streambox.providers';
const secretKey = (id: string) => `streambox.secret.${id.replace(/[^A-Za-z0-9._-]/g, '_')}`;

type Bundle = { server: string; username: string; password: string };

async function putSecret(id: string, bundle: Bundle): Promise<boolean> {
  try {
    await SecureStore.setItemAsync(secretKey(id), JSON.stringify(bundle));
    return true;
  } catch {
    return false;
  }
}

async function getSecret(id: string): Promise<Bundle | null> {
  try {
    const raw = await SecureStore.getItemAsync(secretKey(id));
    return raw ? (JSON.parse(raw) as Bundle) : null;
  } catch {
    return null;
  }
}

export async function deleteSecret(id: string) {
  try {
    await SecureStore.deleteItemAsync(secretKey(id));
  } catch {
    /* ignore */
  }
}

/** Save the provider list: secrets go to the keystore, the rest to AsyncStorage. */
export async function persistProviders(list: StoredProvider[]): Promise<void> {
  const stripped: StoredProvider[] = [];
  for (const p of list) {
    const ok = await putSecret(p.id, { server: p.server, username: p.username, password: p.password });
    if (ok) stripped.push({ id: p.id, name: p.name, server: '', username: '', password: '', m3u: p.m3u, kid: p.kid, userAgent: p.userAgent, secure: true });
    else stripped.push({ ...p, secure: false }); // keystore unavailable: keep working
  }
  await AsyncStorage.setItem(LIST_KEY, JSON.stringify(stripped));
}

/**
 * Rebuild the full provider list from AsyncStorage + keystore.
 * Old installs stored passwords in plain text: those are migrated automatically.
 */
export async function restoreProviders(raw: string): Promise<StoredProvider[]> {
  let parsed: StoredProvider[] = [];
  try {
    parsed = JSON.parse(raw) as StoredProvider[];
  } catch {
    return [];
  }
  const full: StoredProvider[] = [];
  let needsMigration = false;
  for (const p of parsed) {
    if (p.secure) {
      const b = await getSecret(p.id);
      if (b) full.push({ ...p, ...b });
      // secret missing (e.g. restored backup without keystore): drop it, user can add again
    } else {
      full.push(p);
      needsMigration = true;
    }
  }
  if (needsMigration) {
    persistProviders(full).catch(() => undefined);
  }
  return full;
}
