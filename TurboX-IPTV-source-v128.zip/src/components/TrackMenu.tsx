import React, { useEffect, useRef } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export type TrackRow = { kind: 'audio' | 'text'; id: string; label: string; selected: boolean };

type Props = {
  rows: TrackRow[];
  cursor: number; // remote highlight (TV); -1 for touch only
  isEnglish: boolean;
  onSelect: (row: TrackRow) => void;
  onClose: () => void;
};

const ROW_H = 46;

/** Audio / subtitle picker shown over the Media3 player. Remote: ▲▼ move, OK select, MENU/BACK close. */
export default function TrackMenu({ rows, cursor, isEnglish, onSelect, onClose }: Props) {
  const tx = (ar: string, en: string) => (isEnglish ? en : ar);
  const scroll = useRef<ScrollView>(null);
  useEffect(() => {
    if (cursor >= 0) scroll.current?.scrollTo({ y: Math.max(0, (cursor - 3) * ROW_H), animated: true });
  }, [cursor]);

  const firstText = rows.findIndex(r => r.kind === 'text');
  const hasAudio = rows.some(r => r.kind === 'audio');

  const renderRow = (r: TrackRow, i: number) => (
    <Pressable key={`${r.kind}:${r.id}`} onPress={() => onSelect(r)} style={[styles.row, cursor === i && styles.rowFocus]}>
      <Ionicons name={r.selected ? 'radio-button-on' : 'radio-button-off'} size={18} color={r.selected ? '#ff5a66' : '#9a9ab0'} />
      <Text style={[styles.label, r.selected && { color: '#fff', fontWeight: '800' }]} numberOfLines={1}>{r.label}</Text>
    </Pressable>
  );

  return (
    <View style={styles.wrap} pointerEvents="box-none">
      <View style={styles.card}>
        <View style={styles.head}>
          <Text style={styles.title}>{tx('الصوت والترجمة', 'Audio & subtitles')}</Text>
          <Pressable onPress={onClose} hitSlop={10}><Ionicons name="close" size={22} color="#cfcfdc" /></Pressable>
        </View>
        <ScrollView ref={scroll} style={{ maxHeight: 300 }} showsVerticalScrollIndicator={false}>
          {hasAudio && <Text style={styles.section}>{tx('الصوت', 'AUDIO')}</Text>}
          {rows.map((r, i) => (
            <React.Fragment key={`${r.kind}:${r.id}`}>
              {i === firstText && <Text style={styles.section}>{tx('الترجمة', 'SUBTITLES')}</Text>}
              {renderRow(r, i)}
            </React.Fragment>
          ))}
        </ScrollView>
        <Text style={styles.hint}>{tx('▲▼ تنقل · OK اختيار · MENU إغلاق', '▲▼ move · OK select · MENU close')}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { ...StyleSheet.absoluteFillObject, alignItems: 'flex-end', justifyContent: 'center', padding: 18 },
  card: { width: 340, maxWidth: '90%', backgroundColor: 'rgba(14,14,22,0.96)', borderRadius: 18, borderWidth: 1, borderColor: '#2c2c3c', padding: 14 },
  head: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 },
  title: { color: '#f4f4f8', fontSize: 16, fontWeight: '800' },
  section: { color: '#ff5a66', fontSize: 11, fontWeight: '800', letterSpacing: 1, marginTop: 10, marginBottom: 4 },
  row: { height: ROW_H, flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 10, borderRadius: 12, borderWidth: 2, borderColor: 'transparent' },
  rowFocus: { borderColor: '#ff5a66', backgroundColor: 'rgba(225,29,46,0.18)' },
  label: { color: '#cfd0da', fontSize: 14, flexShrink: 1 },
  hint: { color: '#6b6b82', fontSize: 11, textAlign: 'center', marginTop: 10 },
});
