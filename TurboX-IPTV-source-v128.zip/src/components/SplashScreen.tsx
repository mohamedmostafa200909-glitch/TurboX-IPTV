import React, { useEffect, useRef, useState } from 'react';
import { Animated, DeviceEventEmitter, Easing, StyleSheet, Text, useWindowDimensions, View } from 'react-native';
import { Audio } from 'expo-av';
import TurboXLogo from './TurboXLogo';
import { TVPressable as Pressable } from '../tv/focus';

/**
 * Animated intro (≈5.4 s) with sound. Tap / OK on the remote skips it.
 * Timeline (ms): streaks 150 → word 350 → X 950/1200 → play pop 1600 →
 * tagline 2000 → loader 2300–4700 → READY 4950 → onDone ≈ 5700.
 */
const TOTAL = 5000;
const READY_AT = 4950;
const DONE_AT = 5700;

export default function SplashScreen({ onDone }: { onDone: () => void }) {
  const { width, height } = useWindowDimensions();
  const t = useRef(new Animated.Value(0)).current;
  const ring = useRef(new Animated.Value(0)).current;
  const ring2 = useRef(new Animated.Value(0)).current;
  const [ready, setReady] = useState(false);
  const finished = useRef(false);
  const soundRef = useRef<Audio.Sound | null>(null);

  const finish = () => {
    if (finished.current) return;
    finished.current = true;
    soundRef.current?.stopAsync().catch(() => undefined);
    onDone();
  };

  useEffect(() => {
    const openedAt = Date.now();
    const sub = DeviceEventEmitter.addListener('TurboXRemoteKey', (e: { action: number }) => {
      if (e.action === 1 && Date.now() - openedAt > 500) finish(); // any remote key skips the intro
    });
    return () => sub.remove();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    let cancelled = false;
    const timers: ReturnType<typeof setTimeout>[] = [];
    const anims: Animated.CompositeAnimation[] = [];

    const begin = () => {
      if (cancelled) return;
      const main = Animated.timing(t, { toValue: TOTAL, duration: TOTAL, easing: Easing.linear, useNativeDriver: true });
      anims.push(main);
      main.start();
      const loop = (v: Animated.Value, delay: number) =>
        timers.push(
          setTimeout(() => {
            if (cancelled) return;
            const a = Animated.loop(Animated.timing(v, { toValue: 1, duration: 2000, easing: Easing.out(Easing.quad), useNativeDriver: true }));
            anims.push(a);
            a.start();
          }, delay),
        );
      loop(ring, 2100);
      loop(ring2, 3100);
      timers.push(setTimeout(() => !cancelled && setReady(true), READY_AT));
      timers.push(setTimeout(() => !cancelled && finish(), DONE_AT));
    };

    (async () => {
      try {
        await Audio.setAudioModeAsync({ playsInSilentModeIOS: true });
        const { sound } = await Promise.race([
          Audio.Sound.createAsync(require('../../assets/sounds/turbox-intro.wav'), { shouldPlay: false, volume: 0.9 }),
          new Promise<never>((_, rej) => setTimeout(() => rej(new Error('audio timeout')), 1500)),
        ]);
        if (cancelled) {
          sound.unloadAsync().catch(() => undefined);
          return;
        }
        soundRef.current = sound;
        await sound.playAsync();
      } catch {
        /* no audio on this device: just play the animation */
      }
      begin();
    })();

    return () => {
      cancelled = true;
      timers.forEach(clearTimeout);
      anims.forEach(a => a.stop());
      soundRef.current?.unloadAsync().catch(() => undefined);
      soundRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const logoW = Math.min(width * 0.8, height * 1.1, 620);
  const trackW = Math.min(width * 0.5, 320);
  const glow = Math.min(width, height * 1.6) * 0.9;

  const ramp = (a: number, b: number, from: number, to: number) =>
    t.interpolate({ inputRange: [a, b], outputRange: [from, to], extrapolate: 'clamp' });

  return (
    <Pressable
      style={styles.root}
      onPress={finish}
      focusable
      isTVSelectable
      hasTVPreferredFocus
      accessibilityLabel="TurboX intro, press to skip"
    >
      <Animated.View
        pointerEvents="none"
        style={{
          position: 'absolute',
          width: glow,
          height: glow,
          borderRadius: glow / 2,
          backgroundColor: 'rgba(225,29,46,0.16)',
          opacity: ramp(200, 1400, 0, 1),
        }}
      />
      <TurboXLogo width={logoW} t={t} ring={ring} ring2={ring2} />

      <Animated.View style={[styles.loader, { width: trackW, opacity: ramp(2200, 2700, 0, 1) }]}>
        <View style={[styles.track, { width: trackW }]}>
          <Animated.View style={[styles.fill, { width: trackW, transform: [{ translateX: ramp(2300, 4700, -trackW, 0) }] }]} />
        </View>
        <Text style={[styles.msg, ready && styles.msgReady]}>{ready ? 'READY' : 'LOADING YOUR CHANNELS…'}</Text>
      </Animated.View>

      <Text style={styles.skip}>TAP TO SKIP</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0b0b12', alignItems: 'center', justifyContent: 'center' },
  loader: { marginTop: 22, alignItems: 'center' },
  track: { height: 5, borderRadius: 3, backgroundColor: '#23232f', overflow: 'hidden' },
  fill: { height: 5, borderRadius: 3, backgroundColor: '#e11d2e' },
  msg: { color: '#9a9ab0', fontSize: 12, letterSpacing: 2, marginTop: 12, fontWeight: '600' },
  msgReady: { color: '#f4f4f8' },
  skip: { position: 'absolute', bottom: 18, color: '#4b4b5e', fontSize: 10, letterSpacing: 2 },
});
