import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { TVPressable as Pressable, TVTextInput } from '../tv/focus';
import { DEFAULT_LIST_ID, FavList } from '../utils/favLists';

type Props = {
  lists: FavList[]; activeId: string; accent: string; isEnglish: boolean; draft: string;
  setDraft: (v: string) => void; onSelect: (id: string) => void; onAdd: () => void; onDelete: (id: string) => void;
};

/** Chips for the favourites lists of the current profile + "new list" field. */
export default function FavListsBar({ lists, activeId, accent, isEnglish, draft, setDraft, onSelect, onAdd, onDelete }: Props) {
  const tx = (ar: string, en: string) => (isEnglish ? en : ar);
  return (
    <View style={{ marginBottom: 10 }}>
      <View style={styles.chips}>
        {lists.map(l => {
          const on = l.id === activeId;
          return (
            <Pressable key={l.id} onPress={() => onSelect(l.id)} style={[styles.chip, on && { backgroundColor: accent }]}>
              <Text style={styles.chipText} numberOfLines={1}>{l.id === DEFAULT_LIST_ID ? tx('المفضلة', 'Favorites') : l.name}</Text>
            </Pressable>
          );
        })}
        {activeId !== DEFAULT_LIST_ID && (
          <Pressable onPress={() => onDelete(activeId)} hitSlop={8} accessibilityLabel={tx('حذف القائمة', 'Delete list')}>
            <Ionicons name="trash-outline" size={20} color="#f87171" />
          </Pressable>
        )}
      </View>
      <View style={styles.addRow}>
        <TVTextInput value={draft} onChangeText={setDraft} placeholder={tx('اسم قائمة جديدة (مثال: أخبار)', 'New list name (e.g. News)')} placeholderTextColor="#6b6b82" style={styles.input} maxLength={24} onSubmitEditing={onAdd} />
        <Pressable onPress={onAdd} style={[styles.add, { backgroundColor: draft.trim() ? accent : '#2a2b38' }]}><Ionicons name="add" size={22} color="#fff" /></Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, alignItems: 'center', marginBottom: 8 },
  chip: { backgroundColor: '#2a2b38', borderRadius: 999, paddingHorizontal: 14, paddingVertical: 8, maxWidth: 160 },
  chipText: { color: '#fff', fontWeight: '700', fontSize: 13 },
  addRow: { flexDirection: 'row', gap: 8, alignItems: 'center' },
  input: { flex: 1, backgroundColor: '#242532', color: '#fff', borderRadius: 12, paddingHorizontal: 12, paddingVertical: 9 },
  add: { borderRadius: 12, padding: 9 },
});
