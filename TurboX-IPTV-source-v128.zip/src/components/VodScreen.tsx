import React, { useCallback, useContext, useEffect, useMemo, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ActivityIndicator, Image, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { TVPressable as Pressable, TVFlatList } from '../tv/focus';
import { channelKey } from '../utils/media';
import { thumbUrl } from '../utils/thumb';
import type { Media } from '../types';
import {
  CAT_GAP, CAT_H, CategoryRow, FBtn, LiveCat, ScreenHeader, ThemeCtx, alpha, useEngineFocus, useScreenTheme,
} from './LiveTVScreen';

const GAP = 12;      // between cards in a row
const ROW_GAP = 14;  // between rows
const PAD_X = 6;     // list content padding (matches contentContainerStyle)
const PAD_TOP = 4;
const STRIP_H = 38;  // title strip: always two lines tall, so every card has the same size

type Props = {
  kind: 'movies' | 'series';
  isEnglish: boolean;
  accent?: string;
  categories: LiveCat[];
  selectedCategory: string;
  onSelectCategory: (key: string) => void;
  items: Media[];
  favSet: Set<string>;
  progress: Record<string, number>;
  loading: boolean;
  onOpen: (item: Media) => void;
  onFavorite: (item: Media) => void;
  onSearch: () => void;
};

/** Poster with fallbacks; no layout of its own (fills the card). */
function Poster({ item }: { item: Media }) {
  const [i, setI] = useState(0);
  const urls = [item.cover_big, item.cover, item.stream_icon].filter((u): u is string => !!u && u.trim().length > 0).map(u => thumbUrl(u.trim(), 342));
  if (!urls.length) return <View style={styles.noPoster}><Ionicons name="film-outline" size={34} color="#55555c" /></View>;
  return <Image source={{ uri: urls[Math.min(i, urls.length - 1)] }} style={StyleSheet.absoluteFill} resizeMode="cover" resizeMethod="resize" fadeDuration={0} onError={() => setI(c => (c + 1 < urls.length ? c + 1 : c))} />;
}

const PosterCard = React.memo(function PosterCard({ item, index, rowIndex, colIndex, cardW, cardH, favorite, pct, onFocusItem, onOpen, onFavorite }: {
  item: Media; index: number; rowIndex: number; colIndex: number; cardW: number; cardH: number; favorite: boolean; pct: number;
  onFocusItem: (i: Media) => void; onOpen: (i: Media) => void; onFavorite: (i: Media) => void;
}) {
  const { ring, accent } = useContext(ThemeCtx);
  const { focused: f, bind } = useEngineFocus();
  useEffect(() => { if (f) onFocusItem(item); }, [f]);
  return (
    <Pressable
      lite
      {...bind}
      hasTVPreferredFocus={index === 0}
      focusStyle={ring}
      // exact position inside the list content: the focus engine can place this card without measuring it
      tvLayout={{ x: PAD_X + colIndex * (cardW + GAP), y: PAD_TOP + rowIndex * (cardH + ROW_GAP), w: cardW, h: cardH }}
      onPress={() => onOpen(item)}
      onAltPress={() => onFavorite(item)}
      style={[styles.card, { width: cardW, height: cardH }]}
    >
      <Poster item={item} />
      {favorite && <View style={styles.fav}><Ionicons name="star" size={15} color="#fbbf24" /></View>}
      <View style={styles.strip}><Text style={styles.stripText} numberOfLines={2}>{item.name}</Text></View>
      {pct > 1 && pct < 99 && <View style={styles.pTrack}><View style={[styles.pFill, { width: `${pct}%`, backgroundColor: accent }]} /></View>}
    </Pressable>
  );
});

export default function VodScreen(p: Props) {
  const theme = useScreenTheme(p.accent);
  const { st, accent } = theme;
  const tx = useCallback((ar: string, en: string) => (p.isEnglish ? en : ar), [p.isEnglish]);
  const { width } = useWindowDimensions();
  const [focused, setFocused] = useState<Media | null>(null);
  const [density, setDensity] = useState<'cozy' | 'compact'>('cozy');
  useEffect(() => { AsyncStorage.getItem('streambox.gridDensity').then(v => { if (v === 'compact') setDensity('compact'); }).catch(() => undefined); }, []);
  function toggleDensity() {
    setDensity(v => { const next = v === 'cozy' ? 'compact' : 'cozy'; AsyncStorage.setItem('streambox.gridDensity', next).catch(() => undefined); return next; });
  }

  // column widths follow the flex ratios 24 / 46 / 30 of (screen - side padding - two gaps)
  const gridW = Math.floor((width - 88 - 52) * 0.46);
  const target = density === 'compact' ? 98 : 130;
  const colsMax = density === 'compact' ? 8 : 6;
  const cols = Math.max(2, Math.min(colsMax, Math.floor((gridW - 2 * PAD_X + GAP) / (target + GAP))));
  const cardW = Math.floor((gridW - 2 * PAD_X - (cols - 1) * GAP) / cols);
  const cardH = Math.round(cardW * 1.5);
  const rowH = cardH + ROW_GAP;

  const rows = useMemo(() => {
    const out: Media[][] = [];
    for (let i = 0; i < p.items.length; i += cols) out.push(p.items.slice(i, i + cols));
    return out;
  }, [p.items, cols]);

  useEffect(() => { setFocused(null); }, [p.items]);

  const renderCat = useCallback(({ item, index }: { item: LiveCat; index: number }) => <CategoryRow cat={item} index={index} active={p.selectedCategory === item.key} onSelect={p.onSelectCategory} />, [p.selectedCategory, p.onSelectCategory]);
  const renderRow = useCallback(({ item: row, index: ri }: { item: Media[]; index: number }) => (
    <View style={[styles.row, { height: rowH }]}>
      {row.map((it, ci) => {
        const key = channelKey(it);
        return <PosterCard key={`${key}-${ci}`} item={it} index={ri * cols + ci} rowIndex={ri} colIndex={ci} cardW={cardW} cardH={cardH}
          favorite={p.favSet.has(key)} pct={p.progress[key] || 0} onFocusItem={setFocused} onOpen={p.onOpen} onFavorite={p.onFavorite} />;
      })}
    </View>
  ), [cols, cardW, cardH, rowH, p.favSet, p.progress, p.onOpen, p.onFavorite]);

  const shown = focused;
  const ratingNum = shown ? parseFloat(String(shown.rating || '')) : NaN;
  const year = shown ? (shown.year || (shown.name.match(/\((\d{4})\)/)?.[1] ?? '')) : '';
  const title = tx(p.kind === 'movies' ? 'الأفلام' : 'المسلسلات', p.kind === 'movies' ? 'Movies' : 'Series');

  return (
    <ThemeCtx.Provider value={theme}>
      <View style={st.root}>
        <View pointerEvents="none" style={st.glow} />
        <ScreenHeader onSearch={p.onSearch} />

        <View style={st.cols}>
          <View style={{ flex: 24 }}>
            <Text style={st.colTitle}>{tx('الفئات', 'Categories')}</Text>
            <View style={st.panel}>
              <TVFlatList
                data={p.categories}
                keyExtractor={(c: LiveCat) => c.key}
                renderItem={renderCat}
                extraData={p.selectedCategory}
                getItemLayout={(_: any, i: number) => ({ length: CAT_H + CAT_GAP, offset: (CAT_H + CAT_GAP) * i, index: i })}
                initialNumToRender={12}
                windowSize={5}
                maxToRenderPerBatch={8}
                showsVerticalScrollIndicator={false}
              />
            </View>
          </View>

          <View style={{ flex: 46 }}>
            <View style={styles.gridHead}>
              <Text style={[st.colTitle, { marginBottom: 0 }]}>{title}</Text>
              <FBtn onPress={toggleDensity} style={styles.densityBtn} label={tx('كثافة الشبكة', 'Grid density')}>
                <Ionicons name={density === 'compact' ? 'apps' : 'grid-outline'} size={18} color="#fff" />
                <Text style={styles.densityText}>{density === 'compact' ? tx('مضغوط', 'Compact') : tx('كبير', 'Large')}</Text>
              </FBtn>
            </View>
            <View style={{ flex: 1 }}>
              {p.loading ? <ActivityIndicator color={accent} style={{ marginTop: 40 }} /> : rows.length ? (
                <TVFlatList
                  data={rows}
                  keyExtractor={(_: Media[], i: number) => String(i)}
                  renderItem={renderRow}
                  extraData={`${p.favSet.size}|${cols}`}
                  getItemLayout={(_: any, i: number) => ({ length: rowH, offset: rowH * i, index: i })}
                  initialNumToRender={4}
                  windowSize={5}
                  maxToRenderPerBatch={3}
                  contentContainerStyle={{ paddingHorizontal: PAD_X, paddingTop: PAD_TOP }}
                  showsVerticalScrollIndicator={false}
                />
              ) : <Text style={st.empty}>{tx('لا يوجد محتوى في هذه الفئة', 'Nothing in this category')}</Text>}
            </View>
          </View>

          <View style={{ flex: 30 }}>
            <Text style={st.colTitle}>{tx('التفاصيل', 'Details')}</Text>
            <View style={styles.details}>
              {shown ? (
                <>
                  <Text style={styles.dTitle} numberOfLines={3}>{shown.name}</Text>
                  <View style={styles.chips}>
                    {!!year && <View style={styles.chip}><Text style={styles.chipText}>{year}</Text></View>}
                    {ratingNum > 0 && <View style={[styles.chip, { borderColor: alpha(accent, 0.6), backgroundColor: alpha(accent, 0.15) }]}><Text style={[styles.chipText, { color: accent }]}>★ {ratingNum.toFixed(1)}</Text></View>}
                    {!!shown.category_name && <View style={styles.chip}><Text style={styles.chipText} numberOfLines={1}>{shown.category_name}</Text></View>}
                  </View>
                  <Text style={styles.dPlot} numberOfLines={9}>{shown.plot || tx('اضغط OK لعرض التفاصيل الكاملة.', 'Press OK for full details.')}</Text>
                </>
              ) : <Text style={styles.dHint}>{tx('اختر عنوانًا لعرض تفاصيله', 'Pick a title to see its details')}</Text>}
              <FBtn cta onPress={() => { if (shown) p.onOpen(shown); }} style={st.cta}>
                <Text style={st.ctaAr}>{p.kind === 'series' ? 'اضغط OK لعرض المواسم' : 'اضغط OK للتفاصيل والمشاهدة'}</Text>
                <Text style={st.ctaEn}>{p.kind === 'series' ? 'Press OK for seasons' : 'Press OK for details'}</Text>
              </FBtn>
            </View>
          </View>
        </View>
      </View>
    </ThemeCtx.Provider>
  );
}

const styles = StyleSheet.create({
  gridHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  densityBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, height: 34, borderRadius: 17, backgroundColor: 'rgba(255,255,255,0.08)' },
  densityText: { color: '#fff', fontSize: 13, fontWeight: '700' },
  row: { flexDirection: 'row', gap: GAP },
  card: { borderRadius: 12, borderWidth: 2, borderColor: 'rgba(255,255,255,0.06)', backgroundColor: '#16161A', overflow: 'hidden' },
  noPoster: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' },
  strip: { position: 'absolute', left: 0, right: 0, bottom: 0, height: STRIP_H, justifyContent: 'center', paddingHorizontal: 6, backgroundColor: 'rgba(0,0,0,0.74)' },
  stripText: { color: '#fff', fontSize: 12, lineHeight: 15, fontWeight: '700' },
  fav: { position: 'absolute', top: 6, right: 6, width: 26, height: 26, borderRadius: 13, backgroundColor: 'rgba(0,0,0,0.65)', alignItems: 'center', justifyContent: 'center' },
  pTrack: { position: 'absolute', left: 0, right: 0, bottom: STRIP_H, height: 4, backgroundColor: 'rgba(255,255,255,0.25)' },
  pFill: { height: 4 },
  details: { flex: 1 },
  dTitle: { color: '#fff', fontSize: 28, fontWeight: '800' },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 },
  chip: { borderRadius: 8, borderWidth: 1, borderColor: 'rgba(255,255,255,0.18)', backgroundColor: 'rgba(255,255,255,0.07)', paddingHorizontal: 12, paddingVertical: 5, maxWidth: 220 },
  chipText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  dPlot: { color: '#c7c7cf', fontSize: 18, lineHeight: 27, marginTop: 16 },
  dHint: { color: '#8E8E93', fontSize: 18, marginTop: 10 },
});
