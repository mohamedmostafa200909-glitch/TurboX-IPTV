import React from 'react';
import { Animated, View } from 'react-native';

/**
 * TurboX logo built only from core React Native views (no SVG dependency).
 * Design space: 910 x 440. Everything scales with `width`.
 *
 * - Pass `t` (Animated.Value in ms, driven natively) to play the intro animation.
 * - Omit `t` to render the final static logo (used on the login screen).
 */
const RED = '#e11d2e';
const PINK = '#ff5a66';

type Props = {
  width: number;
  t?: Animated.Value;
  ring?: Animated.Value;
  ring2?: Animated.Value;
};

export default function TurboXLogo({ width, t, ring, ring2 }: Props) {
  const s = width / 910;
  const height = 440 * s;

  const ramp = (a: number, b: number, from: number, to: number): any =>
    t ? t.interpolate({ inputRange: [a, b], outputRange: [from, to], extrapolate: 'clamp' }) : to;
  const step = (at: number): any =>
    t ? t.interpolate({ inputRange: [at, at + 1], outputRange: [0, 1], extrapolate: 'clamp' }) : 1;
  const pop: any = t
    ? t.interpolate({ inputRange: [1600, 1900, 2200], outputRange: [0, 1.2, 1], extrapolate: 'clamp' })
    : 1;

  // X: two rounded bars crossing at (740, 247). Each "draws" from one end.
  const L = 276 * s;           // bar length incl. round caps
  const BH = 46 * s;           // bar thickness
  const cx = 740 * s;
  const cy = 247 * s;
  const bar = (angle: string, start: number, key: string) => (
    <View
      key={key}
      style={{ position: 'absolute', left: cx - L / 2, top: cy - BH / 2, width: L, height: BH, transform: [{ rotate: angle }] }}
    >
      <Animated.View
        style={{
          width: L,
          height: BH,
          borderRadius: BH / 2,
          backgroundColor: RED,
          opacity: step(start),
          transform: [{ translateX: ramp(start, start + 550, -L / 2, 0) }, { scaleX: ramp(start, start + 550, 0.001, 1) }],
        }}
      />
    </View>
  );

  const streaks: Array<[number, number, number, number]> = [
    [20, 205, 110, 0.35],
    [10, 245, 95, 0.55],
    [30, 285, 100, 0.8],
  ];

  const fontSize = 132 * s;
  const lh = fontSize * 1.15;

  const ringView = (v: Animated.Value | undefined, key: string) =>
    v ? (
      <Animated.View
        key={key}
        pointerEvents="none"
        style={{
          position: 'absolute',
          left: cx - 36 * s,
          top: cy - 36 * s,
          width: 72 * s,
          height: 72 * s,
          borderRadius: 36 * s,
          borderWidth: Math.max(2, 4 * s),
          borderColor: RED,
          opacity: v.interpolate({ inputRange: [0, 1], outputRange: [0.7, 0] }),
          transform: [{ scale: v.interpolate({ inputRange: [0, 1], outputRange: [1, 2.3] }) }],
        }}
      />
    ) : null;

  return (
    <View style={{ width, height }}>
      {/* soft red glow behind the X */}
      <Animated.View
        pointerEvents="none"
        style={{
          position: 'absolute',
          left: cx - 150 * s,
          top: cy - 150 * s,
          width: 300 * s,
          height: 300 * s,
          borderRadius: 150 * s,
          backgroundColor: 'rgba(225,29,46,0.20)',
          opacity: ramp(900, 1700, 0, 1),
        }}
      />

      {/* speed streaks */}
      <Animated.View
        style={{ position: 'absolute', left: 0, top: 0, width, height, opacity: ramp(150, 850, 0, 1), transform: [{ translateX: ramp(150, 850, -140 * s, 0) }] }}
      >
        {streaks.map(([x1, y, x2, o], i) => (
          <View
            key={i}
            style={{ position: 'absolute', left: x1 * s, top: (y - 4) * s, width: (x2 - x1) * s, height: 8 * s, borderRadius: 4 * s, backgroundColor: RED, opacity: o }}
          />
        ))}
      </Animated.View>

      {/* TURBO wordmark */}
      <Animated.View
        style={{ position: 'absolute', left: 125 * s, top: 300 * s - lh * 0.8, opacity: ramp(350, 1150, 0, 1), transform: [{ translateX: ramp(350, 1150, -70 * s, 0) }] }}
      >
        <Animated.Text
          allowFontScaling={false}
          style={{ color: '#ffffff', fontSize, lineHeight: lh, fontWeight: '900', fontStyle: 'italic', letterSpacing: 3 * s, includeFontPadding: false }}
        >
          TURBO
        </Animated.Text>
      </Animated.View>

      {/* X */}
      {bar('45.9deg', 950, 'x1')}
      {bar('-45.9deg', 1200, 'x2')}

      {ringView(ring, 'r1')}
      {ringView(ring2, 'r2')}

      {/* play button in the middle of the X */}
      <Animated.View
        style={{ position: 'absolute', left: cx - 36 * s, top: cy - 36 * s, width: 72 * s, height: 72 * s, transform: [{ scale: pop }] }}
      >
        <View style={{ width: 72 * s, height: 72 * s, borderRadius: 36 * s, backgroundColor: '#ffffff' }} />
        <View
          style={{
            position: 'absolute',
            left: 29 * s,
            top: 17 * s,
            width: 0,
            height: 0,
            borderLeftWidth: 33 * s,
            borderTopWidth: 19 * s,
            borderBottomWidth: 19 * s,
            borderLeftColor: RED,
            borderTopColor: 'transparent',
            borderBottomColor: 'transparent',
          }}
        />
      </Animated.View>

      {/* tagline */}
      <Animated.View
        style={{ position: 'absolute', left: 60 * s, top: 358 * s, width: 760 * s, opacity: ramp(2000, 2700, 0, 1), transform: [{ translateY: ramp(2000, 2700, 14 * s, 0) }] }}
      >
        <Animated.Text
          allowFontScaling={false}
          style={{ color: PINK, fontSize: 30 * s, fontWeight: '700', letterSpacing: 50 * s, textAlign: 'center', paddingLeft: 50 * s, includeFontPadding: false }}
        >
          EVERYWHERE
        </Animated.Text>
      </Animated.View>
    </View>
  );
}
