import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Image, PixelRatio, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { TVPressable as Pressable, TVFlatList, tvEngine } from '../tv/focus';
import TurboXLogo from './TurboXLogo';
import { NativeTurboPlayerView } from '../native/turboPlayer';
import { channelKey } from '../utils/media';
import type { Media } from '../types';
import type { Prog } from './EpgTimeline';

const DEFAULT_ACCENT = '#FF1E27';
const BG = '#0A0A0C';
const MUTED = '#8E8E93';
export const CAT_H = 60;
export const CAT_GAP = 8;
const CH_H = 92;
const CH_GAP = 10;

export type LiveCat = { key: string; label: string; count: number };

/** accent colour with an alpha, from "#rrggbb" */
export function alpha(hex: string, a: number): string {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map(c => c + c).join('') : h, 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}
/** glow ring: TVPressable merges this over its own ring whenever the remote highlight is on the control */
export const makeRings = (c: string) => ({
  ring: { borderWidth: 2, borderColor: c, backgroundColor: alpha(c, 0.18), shadowColor: c, shadowOpacity: 0.5, shadowRadius: 16, elevation: 10, transform: [{ scale: 1.03 }] },
  ringCta: { borderWidth: 2, borderColor: '#fff', backgroundColor: c, shadowColor: c, shadowOpacity: 0.7, shadowRadius: 20, elevation: 12, transform: [{ scale: 1.03 }] },
});
type ThemeCtxValue = { accent: string; st: ReturnType<typeof makeStyles>; ring: any; ringCta: any };
export const ThemeCtx = createContext<ThemeCtxValue>(null as any);

/**
 * Focus state for content that changes with the highlight (LIVE pill, progress bar, colours).
 * On TV the JS focus engine drives the highlight (TVPressable never calls onFocus for it), so subscribe to the engine;
 * native focus (non-engine devices) is covered by onFocus/onBlur.
 */
export function useEngineFocus() {
  const [id, setId] = useState('');
  const [eng, setEng] = useState(false);
  const [nat, setNat] = useState(false);
  useEffect(() => (id ? tvEngine.subscribe(id, setEng) : undefined), [id]);
  const bind = useMemo(() => ({ __onId: setId, onFocus: () => setNat(true), onBlur: () => setNat(false) }), []);
  return { focused: eng || nat, bind };
}

type Props = {
  isEnglish: boolean;
  /** theme accent colour */
  accent?: string;
  categories: LiveCat[];
  selectedCategory: string;
  onSelectCategory: (key: string) => void;
  channels: Media[];
  nowPlaying: Record<string, string>;
  favSet: Set<string>;
  loading: boolean;
  /** show a muted live preview of the highlighted channel */
  previewEnabled: boolean;
  /** a full-screen player / dialog is open: release the preview so only one stream is active */
  previewPaused: boolean;
  getStream: (item: Media) => { url: string; headers?: any } | null;
  getGuide: (item: Media) => Promise<Prog[]>;
  onOpen: (item: Media) => void;
  onFavorite: (item: Media) => void;
  onSearch: () => void;
};

const pad2 = (n: number) => String(n).padStart(2, '0');
const hhmm = (sec: number) => { const d = new Date(sec * 1000); return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`; };
const clockNow = () => { const d = new Date(); return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`; };

function catIcon(label: string, key: string): any {
  const n = `${key} ${label}`.toLowerCase();
  if (key === '__favorites__') return 'star';
  if (key === 'All') return 'apps';
  if (key === '__continue__') return 'play-circle';
  if (key === '__recent__') return 'time';
  if (/sport|رياض|كور|bein|ssc/.test(n)) return 'football';
  if (/news|خبر|أخبار|اخبار/.test(n)) return 'newspaper';
  if (/movie|film|cinema|أفلام|افلام|سينما|فيلم/.test(n)) return 'film';
  if (/kid|cartoon|child|أطفال|اطفال|كرتون/.test(n)) return 'happy';
  if (/doc|وثائق|nature|animal|geograph/.test(n)) return 'earth';
  if (/music|موسيق|اغاني|أغاني|clip/.test(n)) return 'musical-notes';
  if (/relig|islam|quran|قرآن|قران|دين/.test(n)) return 'moon';
  if (/entertain|ترفيه|منوع|series|مسلسل|drama|دراما/.test(n)) return 'tv';
  return 'tv-outline';
}

/** quality/audio hints that can honestly be read from the channel name */
function specsFor(name: string): Array<{ label: string; hot?: boolean }> {
  const out: Array<{ label: string; hot?: boolean }> = [];
  if (/4k|uhd/i.test(name)) out.push({ label: '4K' });
  else if (/fhd|1080/i.test(name)) out.push({ label: 'FHD' });
  else if (/\bhd\b|720/i.test(name)) out.push({ label: 'HD' });
  else out.push({ label: 'SD' });
  const fps = name.match(/(\d{2})\s*fps/i);
  if (fps) out.push({ label: `${fps[1]}FPS`, hot: true });
  if (/dolby|atmos|ac3|dd\s?5\.1|5\.1/i.test(name)) out.push({ label: 'Dolby Audio' });
  return out;
}

/* ---------------------------- categories ---------------------------- */
export const CategoryRow = React.memo(function CategoryRow({ cat, index, active, onSelect }: { cat: LiveCat; index: number; active: boolean; onSelect: (k: string) => void }) {
  const { st, accent: RED, ring } = useContext(ThemeCtx);
  const { focused: f, bind } = useEngineFocus();
  return (
    <Pressable
      lite
      {...bind}
      focusStyle={ring}
      tvLayout={{ x: 0, y: index * (CAT_H + CAT_GAP), h: CAT_H }}
      onPress={() => onSelect(cat.key)}
      style={[st.cat, active && st.catActive]}
    >
      <Ionicons name={catIcon(cat.label, cat.key)} size={24} color={active || f ? RED : '#c9c9cf'} />
      <Text style={[st.catText, (active || f) && { color: '#fff' }]} numberOfLines={1}>{cat.label}</Text>
      <Text style={[st.catCount, active && { color: RED }]}>{cat.count}</Text>
    </Pressable>
  );
});

/* ------------------------------ channels ----------------------------- */
const ChannelCard = React.memo(function ChannelCard({ item, index, program, favorite, selected, pct, tx, onFocusItem, onOpen, onFavorite }: {
  item: Media; index: number; program?: string; favorite: boolean; selected: boolean; pct: number | null; tx: (a: string, e: string) => string;
  onFocusItem: (i: Media) => void; onOpen: (i: Media) => void; onFavorite: (i: Media) => void;
}) {
  const { st, ring } = useContext(ThemeCtx);
  const { focused: f, bind } = useEngineFocus();
  const [imgBad, setImgBad] = useState(false);
  const logo = item.stream_icon;
  useEffect(() => { if (f) onFocusItem(item); }, [f]);
  return (
    <Pressable
      lite
      {...bind}
      hasTVPreferredFocus={index === 0}
      focusStyle={ring}
      tvLayout={{ x: 6, y: 4 + index * (CH_H + CH_GAP), h: CH_H }}
      onPress={() => onOpen(item)}
      onAltPress={() => onFavorite(item)}
      style={st.ch}
    >
      <View style={st.logoBox}>
        {logo && !imgBad ? <Image source={{ uri: logo }} style={st.logo} resizeMode="contain" onError={() => setImgBad(true)} /> : <Ionicons name="tv-outline" size={30} color="#55555c" />}
      </View>
      <View style={st.chBody}>
        <View style={st.chRow}>
          <Text style={st.chName} numberOfLines={1}>{String(index + 1).padStart(3, '0')} {item.name}</Text>
          {favorite && <Ionicons name="star" size={15} color="#fbbf24" />}
          {f && <View style={st.livePill}><View style={st.liveDot} /><Text style={st.livePillText}>{tx('مباشر', 'LIVE')}</Text></View>}
        </View>
        <Text style={st.chProg} numberOfLines={1}>{program || tx('لا توجد بيانات البرنامج', 'No programme info')}</Text>
        {f && pct != null && (
          <View style={st.chBar}>
            <View style={st.track}><View style={[st.fill, { width: `${pct}%` }]} /></View>
            <Text style={st.chLive}>LIVE</Text>
          </View>
        )}
      </View>
    </Pressable>
  );
});

/** generic focusable button with the red glow focus state */
export function FBtn({ onPress, style, children, label, cta }: { onPress: () => void; style: any; children: React.ReactNode; label?: string; cta?: boolean }) {
  const { ring, ringCta } = useContext(ThemeCtx);
  return (
    <Pressable lite focusStyle={cta ? ringCta : ring} onPress={onPress} accessibilityLabel={label} style={style}>
      {children}
    </Pressable>
  );
}

/* ------------------------------ preview ------------------------------ */
function MiniPlayer({ width, height, item, source, enabled, tx }: { width: number; height: number; item: Media | null; source: { url: string; headers?: any } | null; enabled: boolean; tx: (a: string, e: string) => string }) {
  const { st } = useContext(ThemeCtx);
  const [buffering, setBuffering] = useState(true);
  const [failed, setFailed] = useState(false);
  useEffect(() => { setBuffering(true); setFailed(false); }, [source?.url]);
  const live = enabled && !!source && !failed;
  return (
    <View style={[st.video, { width, height }]}>
      {live && (
        <NativeTurboPlayerView
          style={StyleSheet.absoluteFill}
          source={source!.url}
          headers={source!.headers}
          live
          muted
          paused={false}
          resizeMode="contain"
          onStatus={(e: any) => { const n = e?.nativeEvent || {}; setBuffering(!n.playing); }}
          onError={() => setFailed(true)}
        />
      )}
      {(!live || buffering) && (
        <View style={st.videoCover} pointerEvents="none">
          {item?.stream_icon && !live ? <Image source={{ uri: item.stream_icon }} style={st.coverLogo} resizeMode="contain" /> : null}
          {live ? <ActivityIndicator color="#fff" /> : <Text style={st.coverText}>{failed ? tx('تعذّرت المعاينة', 'Preview unavailable') : enabled ? '' : tx('المعاينة متوقفة', 'Preview off')}</Text>}
        </View>
      )}
      <View style={[st.badge, { start: 12 }]}><Text style={st.badgeText}>16:9</Text></View>
      <View style={[st.badge, { end: 12 }]}><Text style={st.badgeText}>{tx('بث مباشر', 'LIVE')}</Text></View>
    </View>
  );
}


/* -------------------------------- screen ------------------------------- */
/** logo, search, wifi, clock, resolution badge: shared by the Live, Movies and Series screens */
export function ScreenHeader({ onSearch }: { onSearch: () => void }) {
  const { st } = useContext(ThemeCtx);
  const { width } = useWindowDimensions();
  const [clock, setClock] = useState(clockNow);
  useEffect(() => { const id = setInterval(() => setClock(clockNow()), 20000); return () => clearInterval(id); }, []);
  const res = width * PixelRatio.get() >= 3000 ? '4K' : 'FHD';
  return (
    <View style={st.header}>
      <TurboXLogo width={150} />
      <View style={st.hRight}>
        <FBtn onPress={onSearch} style={st.hBtn} label="Search"><Ionicons name="search" size={26} color="#fff" /></FBtn>
        <Ionicons name="wifi" size={26} color="#fff" />
        <Text style={st.clock}>{clock}</Text>
        <View style={st.res}><Text style={st.resText}>{res}</Text></View>
      </View>
    </View>
  );
}

export function useScreenTheme(accentIn?: string) {
  const accent = accentIn || DEFAULT_ACCENT;
  return useMemo(() => ({ accent, st: makeStyles(accent), ...makeRings(accent) }), [accent]);
}

export default function LiveTVScreen(p: Props) {
  const accent = p.accent || DEFAULT_ACCENT;
  const RED = accent;
  const theme = useMemo(() => ({ accent, st: makeStyles(accent), ...makeRings(accent) }), [accent]);
  const st = theme.st;
  const tx = useCallback((ar: string, en: string) => (p.isEnglish ? en : ar), [p.isEnglish]);
  const { width } = useWindowDimensions();
  const [focused, setFocused] = useState<Media | null>(null);
  const [guide, setGuide] = useState<{ key: string; list: Prog[] } | null>(null);
  const [previewItem, setPreviewItem] = useState<Media | null>(null);
  const [suspended, setSuspended] = useState(false);
  const opening = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => () => { if (opening.current) clearTimeout(opening.current); }, []);
  useEffect(() => { if (!p.previewPaused) setSuspended(false); }, [p.previewPaused]);

  // the list changed (category): forget the highlight until the user moves into it
  useEffect(() => { setFocused(null); setPreviewItem(null); }, [p.channels]);

  // programme details of the highlighted channel (cached by the app, debounced while scrolling)
  useEffect(() => {
    if (!focused) return;
    let off = false;
    const t = setTimeout(async () => {
      try {
        const list = await p.getGuide(focused);
        if (!off) setGuide({ key: channelKey(focused), list });
      } catch { /* no guide for this channel */ }
    }, 450);
    return () => { off = true; clearTimeout(t); };
  }, [focused]);

  // live preview: only after the highlight rests on a channel for a moment
  useEffect(() => {
    if (!focused) return;
    const t = setTimeout(() => setPreviewItem(focused), 900);
    return () => clearTimeout(t);
  }, [focused]);

  const open = useCallback((item: Media) => {
    setSuspended(true); // release the preview stream before the full-screen player opens (many accounts allow 1 connection)
    if (opening.current) clearTimeout(opening.current);
    opening.current = setTimeout(() => { p.onOpen(item); opening.current = setTimeout(() => setSuspended(false), 4000); }, 250);
  }, [p.onOpen]);

  const fKey = focused ? channelKey(focused) : '';
  const nowSec = Date.now() / 1000;
  const progs = guide && guide.key === fKey ? guide.list : [];
  const cur = progs.find(x => x.s <= nowSec && x.e > nowSec);
  const nxt = cur ? progs[progs.indexOf(cur) + 1] : undefined;
  const pct = cur ? Math.max(0, Math.min(100, Math.round(((nowSec - cur.s) / (cur.e - cur.s)) * 100))) : null;

  const previewSrc = useMemo(() => (previewItem ? p.getStream(previewItem) : null), [previewItem]);
  const shown = focused;
  const specs = shown ? specsFor(shown.name) : [];
  const vidW = Math.max(300, Math.floor(width * 0.40) - 56);
  const vidH = Math.round((vidW * 9) / 16);

  const renderCat = useCallback(({ item, index }: { item: LiveCat; index: number }) => <CategoryRow cat={item} index={index} active={p.selectedCategory === item.key} onSelect={p.onSelectCategory} />, [p.selectedCategory, p.onSelectCategory]);
  const renderCh = useCallback(({ item, index }: { item: Media; index: number }) => {
    const key = channelKey(item);
    return (
      <ChannelCard item={item} index={index} program={p.nowPlaying[key] || item.now_playing} favorite={p.favSet.has(key)} selected={key === fKey}
        pct={key === fKey ? pct : null} tx={tx} onFocusItem={setFocused} onOpen={open} onFavorite={p.onFavorite} />
    );
  }, [p.nowPlaying, p.favSet, fKey, pct, tx, open, p.onFavorite]);

  return (
    <ThemeCtx.Provider value={theme}>
    <View style={st.root}>
      <View pointerEvents="none" style={st.glow} />

      <ScreenHeader onSearch={p.onSearch} />

      <View style={st.cols}>
        {/* categories */}
        <View style={{ flex: 25 }}>
          <Text style={st.colTitle}>{tx('الفئات', 'Categories')}</Text>
          <View style={st.panel}>
            <TVFlatList
              data={p.categories}
              keyExtractor={(c: LiveCat) => c.key}
              renderItem={renderCat}
              extraData={p.selectedCategory}
              getItemLayout={(_: any, i: number) => ({ length: CAT_H + CAT_GAP, offset: (CAT_H + CAT_GAP) * i, index: i })}
              initialNumToRender={12}
              windowSize={5}
              maxToRenderPerBatch={8}
              showsVerticalScrollIndicator={false}
            />
          </View>
        </View>

        {/* channels */}
        <View style={{ flex: 35 }}>
          <Text style={st.colTitle}>{tx('قائمة القنوات', 'Channels')}</Text>
          <View style={{ flex: 1 }}>
            {p.loading ? <ActivityIndicator color={RED} style={{ marginTop: 40 }} /> : p.channels.length ? (
              <TVFlatList
                data={p.channels}
                keyExtractor={(c: Media, i: number) => `${channelKey(c)}-${i}`}
                renderItem={renderCh}
                extraData={`${fKey}|${pct}|${p.favSet.size}`}
                getItemLayout={(_: any, i: number) => ({ length: CH_H + CH_GAP, offset: (CH_H + CH_GAP) * i, index: i })}
                initialNumToRender={8}
                windowSize={5}
                maxToRenderPerBatch={6}
                contentContainerStyle={{ paddingHorizontal: 6, paddingTop: 4 }}
                showsVerticalScrollIndicator={false}
              />
            ) : <Text style={st.empty}>{tx('لا توجد قنوات في هذه الفئة', 'No channels in this category')}</Text>}
          </View>
        </View>

        {/* preview + info */}
        <View style={{ flex: 40 }}>
          <Text style={st.colTitle}>{tx('المعاينة والمعلومات', 'Preview & info')}</Text>
          <View style={st.previewPanel}>
            <MiniPlayer width={vidW} height={vidH} item={shown} source={previewSrc} enabled={p.previewEnabled && !p.previewPaused && !suspended && !!previewSrc} tx={tx} />
            <Text style={st.evTitle} numberOfLines={2}>{cur ? cur.t : shown ? shown.name : tx('اختر قناة', 'Pick a channel')}</Text>
            {cur ? (
              <>
                <Text style={st.evTime}>{hhmm(cur.s)} - {hhmm(cur.e)}</Text>
                <View style={st.evBarRow}>
                  <View style={[st.track, { flex: 1, height: 10, borderRadius: 5 }]}><View style={[st.fill, { width: `${pct}%`, borderRadius: 5 }]} /></View>
                  <Text style={st.evPct}>({pct}%)</Text>
                </View>
                {!!nxt && <Text style={st.evNext} numberOfLines={1}><Text style={{ color: RED }}>NEXT / {tx('التالي', 'Next')}: </Text>{nxt.t}</Text>}
              </>
            ) : <Text style={st.evTime}>{shown ? tx('لا توجد بيانات دليل البرامج لهذه القناة', 'No guide data for this channel') : ''}</Text>}
            <View style={st.specs}>
              {specs.map(s => <View key={s.label} style={[st.spec, s.hot && st.specHot]}><Text style={[st.specText, s.hot && { color: RED }]}>{s.label}</Text></View>)}
            </View>
            <FBtn cta onPress={() => { if (shown) open(shown); }} style={st.cta}>
              <Text style={st.ctaAr}>اضغط OK للمشاهدة الكاملة</Text>
              <Text style={st.ctaEn}>Press OK for Fullscreen</Text>
            </FBtn>
          </View>
        </View>
      </View>
    </View>
    </ThemeCtx.Provider>
  );
}

export const makeStyles = (RED: string) => StyleSheet.create({
  root: { flex: 1, backgroundColor: BG, direction: 'ltr', paddingHorizontal: 44, paddingTop: 22, paddingBottom: 18 },
  glow: { position: 'absolute', right: -200, bottom: -260, width: 760, height: 760, borderRadius: 380, backgroundColor: alpha(RED, 0.10) },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', height: 76, marginBottom: 10 },
  hRight: { flexDirection: 'row', alignItems: 'center', gap: 16 },
  hBtn: { width: 52, height: 52, borderRadius: 14, backgroundColor: 'rgba(255,255,255,0.08)', alignItems: 'center', justifyContent: 'center' },
  clock: { color: '#fff', fontSize: 30, fontWeight: '700' },
  res: { borderWidth: 2, borderColor: RED, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 2, backgroundColor: alpha(RED, 0.15) },
  resText: { color: RED, fontSize: 18, fontWeight: '900' },

  cols: { flex: 1, flexDirection: 'row', gap: 26 },
  colTitle: { color: '#fff', fontSize: 28, fontWeight: '800', textAlign: 'center', marginBottom: 12 },
  panel: { flex: 1, backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 20, borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)', padding: 10 },

  cat: { height: CAT_H, marginBottom: CAT_GAP, borderRadius: 14, borderWidth: 2, borderColor: 'transparent', backgroundColor: 'rgba(255,255,255,0.05)', flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 14 },
  catActive: { borderColor: alpha(RED, 0.7), backgroundColor: alpha(RED, 0.14) },
  catText: { flex: 1, color: '#c9c9cf', fontSize: 20, fontWeight: '700' },
  catCount: { color: '#a8a8b0', fontSize: 20, fontWeight: '700' },
  focus: { borderColor: RED, backgroundColor: alpha(RED, 0.18), shadowColor: RED, shadowOpacity: 0.5, shadowRadius: 16, elevation: 10, transform: [{ scale: 1.03 }] },

  ch: { height: CH_H, marginBottom: CH_GAP, borderRadius: 16, borderWidth: 2, borderColor: 'rgba(255,255,255,0.06)', backgroundColor: '#16161A', flexDirection: 'row', alignItems: 'center', gap: 14, paddingHorizontal: 10 },
  chFocus: { borderColor: RED, backgroundColor: alpha(RED, 0.12), shadowColor: RED, shadowOpacity: 0.5, shadowRadius: 16, elevation: 10, transform: [{ scale: 1.03 }] },
  logoBox: { width: 68, height: 68, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.07)', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  logo: { width: 58, height: 58 },
  chBody: { flex: 1, justifyContent: 'center' },
  chRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  chName: { flex: 1, color: '#fff', fontSize: 21, fontWeight: '700' },
  chProg: { color: MUTED, fontSize: 17, marginTop: 4 },
  livePill: { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: RED, borderRadius: 8, paddingHorizontal: 9, paddingVertical: 3 },
  liveDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: '#fff' },
  livePillText: { color: '#fff', fontSize: 13, fontWeight: '800' },
  chBar: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 6 },
  chLive: { color: RED, fontSize: 14, fontWeight: '800' },
  track: { height: 6, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.15)', overflow: 'hidden', flex: 1 },
  fill: { height: '100%', backgroundColor: RED },
  empty: { color: MUTED, fontSize: 18, textAlign: 'center', marginTop: 40 },

  previewPanel: { flex: 1 },
  video: { alignSelf: 'center', borderRadius: 14, overflow: 'hidden', backgroundColor: '#000', borderWidth: 2, borderColor: 'rgba(255,255,255,0.12)' },
  videoCover: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(10,10,12,0.72)' },
  coverLogo: { width: 120, height: 120, marginBottom: 6 },
  coverText: { color: MUTED, fontSize: 15, fontWeight: '600' },
  badge: { position: 'absolute', top: 12, backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  badgeText: { color: '#fff', fontSize: 15, fontWeight: '700' },
  evTitle: { color: '#fff', fontSize: 28, fontWeight: '800', marginTop: 14 },
  evTime: { color: MUTED, fontSize: 20, marginTop: 6 },
  evBarRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 10 },
  evPct: { color: MUTED, fontSize: 17, fontWeight: '600' },
  evNext: { color: '#e6e6ee', fontSize: 19, marginTop: 10 },
  specs: { flexDirection: 'row', gap: 10, marginTop: 14 },
  spec: { borderRadius: 8, borderWidth: 1, borderColor: 'rgba(255,255,255,0.18)', backgroundColor: 'rgba(255,255,255,0.07)', paddingHorizontal: 14, paddingVertical: 6 },
  specHot: { borderColor: alpha(RED, 0.6), backgroundColor: alpha(RED, 0.15) },
  specText: { color: '#fff', fontSize: 17, fontWeight: '700' },
  cta: { marginTop: 'auto', borderRadius: 16, backgroundColor: RED, paddingVertical: 14, alignItems: 'center', borderWidth: 2, borderColor: 'transparent' },
  ctaAr: { color: '#fff', fontSize: 22, fontWeight: '800' },
  ctaEn: { color: '#fff', fontSize: 17, fontWeight: '600', marginTop: 2 },
});
