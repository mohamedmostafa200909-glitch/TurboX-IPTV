import React, { useMemo } from 'react';
import { View } from 'react-native';
import { qrMatrix } from '../utils/qr';

/** QR drawn as run-length rows (a few hundred views instead of one per module). Always left-to-right, even in RTL. */
export default function QrView({ text, size }: { text: string; size: number }) {
  const rows = useMemo(() => {
    const m = qrMatrix(text);
    const q = 4;
    const n = m.length + q * 2;
    const cell = Math.max(2, Math.floor(size / n));
    const out: Array<Array<{ dark: boolean; len: number }>> = [];
    for (let y = -q; y < m.length + q; y++) {
      const runs: Array<{ dark: boolean; len: number }> = [];
      for (let x = -q; x < m.length + q; x++) {
        const dark = y >= 0 && y < m.length && x >= 0 && x < m.length ? m[y][x] : false;
        const last = runs[runs.length - 1];
        if (last && last.dark === dark) last.len++; else runs.push({ dark, len: 1 });
      }
      out.push(runs);
    }
    return { out, cell, px: cell * n };
  }, [text, size]);
  return (
    <View style={{ width: rows.px, height: rows.px, direction: 'ltr' }}>
      {rows.out.map((runs, y) => (
        <View key={y} style={{ flexDirection: 'row', height: rows.cell }}>
          {runs.map((r, i) => <View key={i} style={{ width: r.len * rows.cell, height: rows.cell, backgroundColor: r.dark ? '#000' : '#fff' }} />)}
        </View>
      ))}
    </View>
  );
}
