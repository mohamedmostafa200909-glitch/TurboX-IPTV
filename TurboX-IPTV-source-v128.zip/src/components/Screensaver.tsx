import React, { useEffect, useRef, useState } from 'react';
import { Animated, DeviceEventEmitter, Easing, StyleSheet, Text, View } from 'react-native';
import TurboXLogo from './TurboXLogo';

export type ScreensaverMinutes = 0 | 5 | 10 | 30; // 0 = off

const pad2 = (n: number) => String(n).padStart(2, '0');

/**
 * Idle-timeout screensaver for OLED/plasma TVs: dims the screen and slowly relocates a logo + clock every few
 * seconds (not a continuous animation — cheap on weak TV boxes, and the point is just to not leave any pixel lit
 * at one fixed brightness for a long time). Only engages away from active video playback: a still menu left open
 * for hours is the real burn-in risk, not a playing video.
 *
 * Wakes on any remote key (listens to the same 'TurboXRemoteKey' native event the focus engine uses) and on any
 * touch. The key that wakes it still reaches its normal target afterwards — this mirrors how most TVs behave
 * ("press to wake" doubles as the first real press) rather than silently swallowing it.
 */
export default function Screensaver({ minutes, suspended }: { minutes: ScreensaverMinutes; suspended: boolean }) {
  const [active, setActive] = useState(false);
  const [pos, setPos] = useState({ top: '40%', left: '40%' });
  const [clock, setClock] = useState('');
  const opacity = useRef(new Animated.Value(0)).current;
  const idleTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const moveTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const clockTimer = useRef<ReturnType<typeof setInterval> | null>(null);

  const arm = () => {
    if (idleTimer.current) clearTimeout(idleTimer.current);
    if (!minutes || suspended) return;
    idleTimer.current = setTimeout(() => setActive(true), minutes * 60_000);
  };

  // any remote key or touch resets the idle clock, and dismisses the screensaver if it's showing
  useEffect(() => {
    const onKey = () => { setActive(false); arm(); };
    const sub = DeviceEventEmitter.addListener('TurboXRemoteKey', onKey);
    return () => sub.remove();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [minutes, suspended]);

  useEffect(() => { arm(); return () => { if (idleTimer.current) clearTimeout(idleTimer.current); }; }, [minutes, suspended]);
  useEffect(() => { if (suspended) setActive(false); }, [suspended]);

  useEffect(() => {
    Animated.timing(opacity, { toValue: active ? 1 : 0, duration: 900, easing: Easing.out(Easing.quad), useNativeDriver: true }).start();
    if (active) {
      const jump = () => {
        const top = 10 + Math.random() * 60; // keep clear of screen edges
        const left = 10 + Math.random() * 60;
        setPos({ top: `${top}%`, left: `${left}%` });
      };
      jump();
      moveTimer.current = setInterval(jump, 15_000);
      const tick = () => { const d = new Date(); setClock(`${pad2(d.getHours())}:${pad2(d.getMinutes())}`); };
      tick();
      clockTimer.current = setInterval(tick, 20_000);
    } else {
      if (moveTimer.current) clearInterval(moveTimer.current);
      if (clockTimer.current) clearInterval(clockTimer.current);
    }
    return () => { if (moveTimer.current) clearInterval(moveTimer.current); if (clockTimer.current) clearInterval(clockTimer.current); };
  }, [active]);

  if (!active) return null;
  return (
    <Animated.View pointerEvents="none" style={[styles.root, { opacity }]}>
      <View style={[styles.group, pos as any]}>
        <TurboXLogo width={110} />
        <Text style={styles.clock}>{clock}</Text>
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  root: { ...StyleSheet.absoluteFillObject, backgroundColor: '#000', zIndex: 9999, elevation: 50 },
  group: { position: 'absolute', alignItems: 'center' },
  clock: { color: 'rgba(255,255,255,0.55)', fontSize: 20, fontWeight: '700', marginTop: 10 },
});
