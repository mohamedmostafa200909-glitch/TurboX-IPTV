import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { TVPressable as Pressable, TVScrollView } from '../tv/focus';

type Option = { id: string; label: string; desc?: string; color?: string };
type Props = { title: string; sub?: string; options: Option[]; value: string; closeLabel: string; onSelect: (id: string) => void; onClose: () => void };

/** Small remote-friendly "pick one" dialog (used by Sleep Timer). */
export default function ChoiceModal({ title, sub, options, value, closeLabel, onSelect, onClose }: Props) {
  return (
    <View style={styles.bg}>
      <View style={styles.card}>
        <Text style={styles.title}>{title}</Text>
        {!!sub && <Text style={styles.sub}>{sub}</Text>}
        <TVScrollView style={{ maxHeight: 320 }} showsVerticalScrollIndicator={false}>
          {options.map(o => {
            const on = o.id === value;
            return (
              <Pressable key={o.id} hasTVPreferredFocus={on} onPress={() => onSelect(o.id)} style={[styles.row, on && styles.rowOn]}>
                {!!o.color && <View style={[styles.swatch, { backgroundColor: o.color }]} />}
                <View style={{ flex: 1 }}>
                  <Text style={styles.name}>{o.label}</Text>
                  {!!o.desc && <Text style={styles.desc}>{o.desc}</Text>}
                </View>
                <Ionicons name={on ? 'radio-button-on' : 'radio-button-off'} size={22} color={on ? '#ff5a66' : '#4b4b5e'} />
              </Pressable>
            );
          })}
        </TVScrollView>
        <Pressable style={styles.close} onPress={onClose}><Text style={styles.closeText}>{closeLabel}</Text></Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bg: { flex: 1, backgroundColor: 'rgba(0,0,0,0.78)', justifyContent: 'center', alignItems: 'center', padding: 18 },
  card: { width: '100%', maxWidth: 460, backgroundColor: '#14141d', borderRadius: 22, borderWidth: 1, borderColor: '#2c2c3c', padding: 18 },
  title: { color: '#f4f4f8', fontSize: 18, fontWeight: '800' },
  sub: { color: '#9a9ab0', fontSize: 12, marginTop: 4, marginBottom: 6 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, borderRadius: 14, borderWidth: 1, borderColor: 'transparent', marginTop: 6, backgroundColor: '#1c1c28' },
  rowOn: { borderColor: '#e11d2e' },
  swatch: { width: 26, height: 26, borderRadius: 13, borderWidth: 2, borderColor: 'rgba(255,255,255,0.5)' },
  name: { color: '#f4f4f8', fontSize: 15, fontWeight: '800' },
  desc: { color: '#9a9ab0', fontSize: 11, marginTop: 2 },
  close: { marginTop: 12, height: 44, borderRadius: 12, backgroundColor: '#1c1c28', borderWidth: 1, borderColor: '#2c2c3c', alignItems: 'center', justifyContent: 'center' },
  closeText: { color: '#cfd0da', fontSize: 14, fontWeight: '800' },
});
