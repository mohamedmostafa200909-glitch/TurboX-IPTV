import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { TVPressable as Pressable, TVFlatList } from '../tv/focus';

export type CatTab = 'live' | 'movies' | 'series';
type Props = {
  categories: Record<CatTab, string[]>;
  hidden: Record<CatTab, string[]>;
  isEnglish: boolean;
  onToggle: (tab: CatTab, name: string) => void;
  onShowAll: (tab: CatTab) => void;
  onClose: () => void;
};

/** Settings → Hidden Categories: untick the categories you do not want to see. */
export default function HiddenCategories({ categories, hidden, isEnglish, onToggle, onShowAll, onClose }: Props) {
  const tx = (ar: string, en: string) => (isEnglish ? en : ar);
  const [tab, setTab] = useState<CatTab>('live');
  const list = categories[tab] || [];
  const hiddenSet = new Set(hidden[tab] || []);
  const tabs: Array<{ id: CatTab; label: string }> = [
    { id: 'live', label: 'LIVE' }, { id: 'movies', label: 'MOVIES' }, { id: 'series', label: 'SERIES' },
  ];
  return (
    <View style={styles.bg}>
      <View style={styles.card}>
        <Text style={styles.title}>{tx('إخفاء التصنيفات', 'Hidden categories')}</Text>
        <Text style={styles.sub}>{tx('ألغِ علامة التصنيف لإخفائه من القوائم.', 'Untick a category to hide it from the lists.')}</Text>

        <View style={styles.tabs}>
          {tabs.map(t => (
            <Pressable key={t.id} hasTVPreferredFocus={t.id === 'live'} onPress={() => setTab(t.id)} style={[styles.tab, tab === t.id && styles.tabOn]}>
              <Text style={[styles.tabText, tab === t.id && { color: '#fff' }]}>{t.label}</Text>
              {(hidden[t.id]?.length || 0) > 0 && <View style={styles.badge}><Text style={styles.badgeText}>{hidden[t.id].length}</Text></View>}
            </Pressable>
          ))}
        </View>

        <TVFlatList
          style={{ maxHeight: 250 }}
          data={list}
          keyExtractor={(n, i) => `${n}-${i}`}
          initialNumToRender={14}
          windowSize={5}
          ListEmptyComponent={<Text style={styles.empty}>{tx('لا توجد تصنيفات. اتصل بمصدر أولًا.', 'No categories yet. Connect to a source first.')}</Text>}
          renderItem={({ item }) => {
            const visible = !hiddenSet.has(item);
            return (
              <Pressable onPress={() => onToggle(tab, item)} style={styles.row}>
                <View style={[styles.box, visible && styles.boxOn]}>{visible && <Ionicons name="checkmark" size={16} color="#fff" />}</View>
                <Text style={[styles.name, !visible && { color: '#6b6b82', textDecorationLine: 'line-through' }]} numberOfLines={1}>{item}</Text>
              </Pressable>
            );
          }}
        />

        <View style={styles.actions}>
          <Pressable style={styles.btn} onPress={() => onShowAll(tab)}>
            <Ionicons name="eye-outline" size={16} color="#ff5a66" />
            <Text style={styles.btnText}>{tx('إظهار الكل', 'Show all')}</Text>
          </Pressable>
          <Pressable style={[styles.btn, styles.btnMain]} onPress={onClose}>
            <Ionicons name="checkmark" size={16} color="#fff" />
            <Text style={[styles.btnText, { color: '#fff' }]}>{tx('تم', 'Done')}</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bg: { flex: 1, backgroundColor: 'rgba(0,0,0,0.78)', justifyContent: 'center', alignItems: 'center', padding: 18 },
  card: { width: '100%', maxWidth: 560, backgroundColor: '#14141d', borderRadius: 22, borderWidth: 1, borderColor: '#2c2c3c', padding: 18 },
  title: { color: '#f4f4f8', fontSize: 18, fontWeight: '800' },
  sub: { color: '#9a9ab0', fontSize: 12, marginTop: 4, marginBottom: 10 },
  tabs: { flexDirection: 'row', gap: 8, marginBottom: 8 },
  tab: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, height: 38, borderRadius: 10, backgroundColor: '#1c1c28', borderWidth: 1, borderColor: '#2c2c3c' },
  tabOn: { backgroundColor: '#e11d2e', borderColor: '#e11d2e' },
  tabText: { color: '#9a9ab0', fontSize: 12, fontWeight: '900', letterSpacing: 1 },
  badge: { minWidth: 18, height: 18, borderRadius: 9, backgroundColor: '#0b0b12', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 4 },
  badgeText: { color: '#ff5a66', fontSize: 10, fontWeight: '900' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10, paddingHorizontal: 8, borderRadius: 10, marginBottom: 2 },
  box: { width: 24, height: 24, borderRadius: 7, borderWidth: 2, borderColor: '#6b6b82', alignItems: 'center', justifyContent: 'center' },
  boxOn: { backgroundColor: '#e11d2e', borderColor: '#e11d2e' },
  name: { flex: 1, color: '#f4f4f8', fontSize: 14, fontWeight: '700' },
  empty: { color: '#9a9ab0', fontSize: 13, textAlign: 'center', paddingVertical: 20 },
  actions: { flexDirection: 'row', gap: 10, marginTop: 12 },
  btn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, height: 46, borderRadius: 12, backgroundColor: '#1c1c28', borderWidth: 1, borderColor: '#2c2c3c' },
  btnMain: { backgroundColor: '#e11d2e', borderColor: '#e11d2e' },
  btnText: { color: '#cfd0da', fontSize: 14, fontWeight: '800' },
});
