import { Modal as RNModal } from 'react-native';
import { TVModalLayer, TVEngineLayer } from '../tv/focus';

// RN Modals live in their own window. By default the JS focus engine drives them on TV (D-Pad key-ups are
// forwarded by MainActivity.onKeyUp). Pass `native` for windows that handle remote keys themselves
// (splash, device choice, video player) so they keep using Android's native focus.
export const Modal = ({native, children, ...props}: any) => <RNModal {...props}>{native ? <TVModalLayer>{children}</TVModalLayer> : <TVEngineLayer>{children}</TVEngineLayer>}</RNModal>;