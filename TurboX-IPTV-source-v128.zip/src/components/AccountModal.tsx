import React from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { TVPressable as Pressable, TVScrollView } from '../tv/focus';
import type { AccountInfo } from '../network/accountInfo';

type Props = {
  info: AccountInfo | null;
  loading: boolean;
  error: string | null;
  providerName: string;
  isEnglish: boolean;
  onRefresh: () => void;
  onProfiles: () => void;
  onClose: () => void;
};

const RED = '#e11d2e';

/** Account status: state, expiry date, connections. Shown when "Account" is pressed. */
export default function AccountModal({ info, loading, error, providerName, isEnglish, onRefresh, onProfiles, onClose }: Props) {
  const tx = (ar: string, en: string) => (isEnglish ? en : ar);
  const fmt = (d: Date | null) => (d ? d.toLocaleDateString(isEnglish ? 'en-GB' : 'ar-EG', { year: 'numeric', month: 'long', day: 'numeric' }) : tx('غير محدد', 'Not set'));

  let chip = { text: tx('غير معروف', 'Unknown'), color: '#9a9ab0' };
  if (info) {
    if (info.kind === 'm3u') chip = { text: 'M3U', color: '#9a9ab0' };
    else if (info.expired) chip = { text: tx('منتهي', 'Expired'), color: '#f87171' };
    else if (!info.active) chip = { text: info.status, color: '#f87171' };
    else if (info.daysLeft !== null && info.daysLeft <= 7) chip = { text: tx('ينتهي قريبًا', 'Expiring soon'), color: '#fbbf24' };
    else chip = { text: tx('نشط', 'Active'), color: '#34d399' };
  }

  const used = info?.activeCons ?? 0;
  const max = info?.maxCons ?? 0;
  const free = max ? Math.max(0, max - used) : null;

  return (
    <View style={styles.bg}>
      <View style={styles.card}>
        <View style={styles.head}>
          <View style={styles.avatar}><Ionicons name="person" size={22} color="#fff" /></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.title} numberOfLines={1}>{providerName || tx('الحساب', 'Account')}</Text>
            <Text style={styles.sub} numberOfLines={1}>{info?.serverHost || ''}</Text>
          </View>
          <View style={[styles.chip, { borderColor: chip.color }]}>
            <View style={[styles.dot, { backgroundColor: chip.color }]} />
            <Text style={[styles.chipText, { color: chip.color }]}>{chip.text}</Text>
          </View>
        </View>

        <TVScrollView style={{ maxHeight: 260 }} showsVerticalScrollIndicator={false}>
          {loading && !info ? (
            <View style={styles.center}><ActivityIndicator color="#ff5a66" /><Text style={styles.muted}>{tx('جارٍ التحميل…', 'Loading…')}</Text></View>
          ) : !info ? (
            <View style={styles.center}><Ionicons name="alert-circle" size={26} color="#f87171" /><Text style={styles.muted}>{error || tx('تعذر تحميل بيانات الحساب', 'Could not load account details')}</Text></View>
          ) : info.kind === 'm3u' ? (
            <View style={styles.center}><Ionicons name="document-text-outline" size={26} color="#9a9ab0" /><Text style={styles.muted}>{tx('هذا المصدر قائمة M3U ولا يوفر بيانات اشتراك.', 'This source is an M3U playlist and has no subscription details.')}</Text></View>
          ) : (
            <>
              <Row icon="checkmark-circle-outline" label={tx('حالة الحساب', 'Status')} value={info.expired ? tx('منتهي', 'Expired') : info.status} color={chip.color} />
              <Row
                icon="calendar-outline"
                label={tx('تاريخ الانتهاء', 'Expiry date')}
                value={fmt(info.expiresAt)}
                extra={info.expiresAt ? (info.expired ? tx('انتهى', 'Expired') : tx(`باقي ${info.daysLeft} يوم`, `${info.daysLeft} days left`)) : undefined}
                color={info.expired ? '#f87171' : info.daysLeft !== null && info.daysLeft <= 7 ? '#fbbf24' : undefined}
              />
              <View style={styles.row}>
                <Ionicons name="people-outline" size={18} color="#ff5a66" />
                <View style={{ flex: 1 }}>
                  <Text style={styles.label}>{tx('الاتصالات', 'Connections')}</Text>
                  <Text style={styles.value}>
                    {max ? tx(`${used} مستخدم من ${max} · المتاح ${free}`, `${used} in use of ${max} · ${free} free`) : tx('غير محدد', 'Not set')}
                  </Text>
                  {!!max && (
                    <View style={styles.seg}>
                      {Array.from({ length: Math.min(max, 12) }).map((_, i) => (
                        <View key={i} style={[styles.segItem, i < used && { backgroundColor: RED }]} />
                      ))}
                    </View>
                  )}
                </View>
              </View>
              <Row icon="pricetag-outline" label={tx('نوع الحساب', 'Account type')} value={info.isTrial ? tx('تجريبي', 'Trial') : tx('مدفوع', 'Full')} />
              <Row icon="time-outline" label={tx('تاريخ الإنشاء', 'Created')} value={fmt(info.createdAt)} />
              <Row icon="person-outline" label={tx('اسم المستخدم', 'Username')} value={info.username || '—'} />
              {!!info.timezone && <Row icon="globe-outline" label={tx('المنطقة الزمنية', 'Time zone')} value={info.timezone} />}
            </>
          )}
        </TVScrollView>

        <View style={styles.actions}>
          <Pressable hasTVPreferredFocus style={[styles.btn, styles.btnMain]} onPress={onRefresh}>
            {loading ? <ActivityIndicator size="small" color="#fff" /> : <Ionicons name="refresh" size={16} color="#fff" />}
            <Text style={styles.btnText}>{tx('تحديث', 'Refresh')}</Text>
          </Pressable>
          <Pressable style={styles.btn} onPress={onProfiles}>
            <Ionicons name="people-circle-outline" size={16} color="#ff5a66" />
            <Text style={[styles.btnText, { color: '#cfd0da' }]}>{tx('الملفات الشخصية', 'Profiles')}</Text>
          </Pressable>
          <Pressable style={styles.btn} onPress={onClose}>
            <Ionicons name="close" size={16} color="#ff5a66" />
            <Text style={[styles.btnText, { color: '#cfd0da' }]}>{tx('إغلاق', 'Close')}</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}

function Row({ icon, label, value, extra, color }: { icon: any; label: string; value: string; extra?: string; color?: string }) {
  return (
    <View style={styles.row}>
      <Ionicons name={icon} size={18} color="#ff5a66" />
      <View style={{ flex: 1 }}>
        <Text style={styles.label}>{label}</Text>
        <Text style={[styles.value, color ? { color } : null]}>{value}</Text>
      </View>
      {!!extra && <View style={[styles.extra, color ? { borderColor: color } : null]}><Text style={[styles.extraText, color ? { color } : null]}>{extra}</Text></View>}
    </View>
  );
}

const styles = StyleSheet.create({
  bg: { flex: 1, backgroundColor: 'rgba(0,0,0,0.78)', justifyContent: 'center', alignItems: 'center', padding: 18 },
  card: { width: '100%', maxWidth: 520, backgroundColor: '#14141d', borderRadius: 22, borderWidth: 1, borderColor: '#2c2c3c', padding: 18 },
  head: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 10 },
  avatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: RED, alignItems: 'center', justifyContent: 'center' },
  title: { color: '#f4f4f8', fontSize: 18, fontWeight: '800' },
  sub: { color: '#9a9ab0', fontSize: 12, marginTop: 2 },
  chip: { flexDirection: 'row', alignItems: 'center', gap: 6, borderWidth: 1, borderRadius: 14, paddingHorizontal: 10, paddingVertical: 5 },
  dot: { width: 7, height: 7, borderRadius: 4 },
  chipText: { fontSize: 12, fontWeight: '800' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10, borderTopWidth: 1, borderTopColor: '#22222f' },
  label: { color: '#9a9ab0', fontSize: 11, fontWeight: '700', letterSpacing: 0.5 },
  value: { color: '#f4f4f8', fontSize: 15, fontWeight: '700', marginTop: 2 },
  extra: { borderWidth: 1, borderColor: '#34d399', borderRadius: 10, paddingHorizontal: 8, paddingVertical: 3 },
  extraText: { color: '#34d399', fontSize: 11, fontWeight: '800' },
  seg: { flexDirection: 'row', gap: 4, marginTop: 8 },
  segItem: { flex: 1, maxWidth: 28, height: 6, borderRadius: 3, backgroundColor: '#34d399' },
  center: { alignItems: 'center', gap: 10, paddingVertical: 24 },
  muted: { color: '#9a9ab0', fontSize: 13, textAlign: 'center' },
  actions: { flexDirection: 'row', gap: 8, marginTop: 14 },
  btn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, height: 44, borderRadius: 12, backgroundColor: '#1c1c28', borderWidth: 1, borderColor: '#2c2c3c' },
  btnMain: { backgroundColor: RED, borderColor: RED },
  btnText: { color: '#fff', fontSize: 13, fontWeight: '800' },
});
