import React, { useEffect, useMemo, useState } from 'react';
import { Dimensions, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { TVPressable as Pressable, TVFlatList } from '../tv/focus';
import type { Media } from '../types';

/** A programme. `start` is the server-time string Xtream needs for catch-up URLs. */
export type Prog = { s: number; e: number; t: string; d?: string; start?: string; archive?: boolean };

type Props = {
  channels: Media[];
  accent: string;
  isEnglish: boolean;
  keyOf: (c: Media) => string;
  guide: (c: Media) => Promise<Prog[]>;
  onPlayLive: (c: Media) => void;
  onPickProgram: (c: Media, p: Prog) => void;
  onClose: () => void;
};

const NAME_W = 118;
const SPAN = 3 * 3600; // 3 hours on screen; ◀ ▶ move the window (remote friendly, no horizontal scrolling)
const HALF_HOUR = 1800;
const hhmm = (sec: number) => { const d = new Date(sec * 1000); return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };

// at most 3 guide requests in flight so a long channel list does not hammer the server
const queue: Array<() => Promise<void>> = [];
let running = 0;
function enqueue(task: () => Promise<void>) {
  queue.push(task);
  pump();
}
function pump() {
  while (running < 3 && queue.length) {
    const next = queue.shift()!;
    running += 1;
    next().finally(() => { running -= 1; pump(); });
  }
}

type RowProps = { channel: Media; k: string; ws: number; stripW: number; now: number; accent: string; guide: Props['guide']; onPlayLive: Props['onPlayLive']; onPick: Props['onPickProgram'] };

const Row = React.memo(function Row({ channel, k, ws, stripW, now, accent, guide, onPlayLive, onPick }: RowProps) {
  const [progs, setProgs] = useState<Prog[] | null>(null);
  useEffect(() => {
    let alive = true;
    enqueue(async () => {
      if (!alive) return;
      try { const g = await guide(channel); if (alive) setProgs(g); } catch { if (alive) setProgs([]); }
    });
    return () => { alive = false; };
  }, [k]);
  const we = ws + SPAN;
  return (
    <View style={styles.row}>
      <Pressable style={styles.name} onPress={() => onPlayLive(channel)}>
        <Text style={styles.nameText} numberOfLines={2}>{channel.name}</Text>
      </Pressable>
      <View style={{ width: stripW, height: 52 }}>
        {(progs || []).filter(p => p.e > ws && p.s < we).map((p, i) => {
          const from = Math.max(p.s, ws);
          const to = Math.min(p.e, we);
          const left = ((from - ws) / SPAN) * stripW;
          const width = ((to - from) / SPAN) * stripW - 2;
          if (width < 6) return null;
          const live = p.s <= now && now < p.e;
          const past = p.e <= now;
          return (
            <Pressable key={`${p.s}-${i}`} onPress={() => onPick(channel, p)} style={[styles.block, { left, width }, live && { borderColor: accent, backgroundColor: '#2d2f45' }, past && { opacity: 0.6 }]}>
              <Text style={styles.blockText} numberOfLines={2}>{p.t}</Text>
              {past && p.archive ? <Ionicons name="play-back" size={11} color={accent} style={styles.archive} /> : null}
            </Pressable>
          );
        })}
        {progs === null && <Text style={styles.loading}>…</Text>}
        {progs !== null && !progs.some(p => p.e > ws && p.s < we) && <Text style={styles.loading}>—</Text>}
      </View>
    </View>
  );
});

/**
 * TV-guide style timeline: channels as rows, 3 hours across, ◀ ▶ to move in time. Press a programme: live → play,
 * past + catch-up available → watch it, otherwise details. Guides load lazily for the rows on screen only.
 */
export default function EpgTimeline({ channels, accent, isEnglish, keyOf, guide, onPlayLive, onPickProgram, onClose }: Props) {
  const tx = (ar: string, en: string) => (isEnglish ? en : ar);
  const [now, setNow] = useState(() => Math.floor(Date.now() / 1000));
  const [ws, setWs] = useState(() => Math.floor(Date.now() / 1000 / HALF_HOUR) * HALF_HOUR - HALF_HOUR);
  useEffect(() => { const t = setInterval(() => setNow(Math.floor(Date.now() / 1000)), 30000); return () => clearInterval(t); }, []);
  const stripW = Math.max(200, Dimensions.get('window').width - NAME_W - 32);
  const ticks = useMemo(() => Array.from({ length: SPAN / HALF_HOUR }, (_, i) => ws + i * HALF_HOUR), [ws]);
  const nowLeft = ((now - ws) / SPAN) * stripW;
  const goNow = () => setWs(Math.floor(Date.now() / 1000 / HALF_HOUR) * HALF_HOUR - HALF_HOUR);
  return (
    <View style={styles.screen}>
      <View style={styles.header}>
        <Pressable onPress={onClose} style={styles.hbtn}><Ionicons name="close" size={22} color="#fff" /></Pressable>
        <Text style={styles.title}>{tx('دليل البرامج', 'TV Guide')}</Text>
        <Pressable onPress={() => setWs(w => w - SPAN)} style={styles.hbtn} accessibilityLabel={tx('أبكر', 'Earlier')}><Ionicons name="chevron-back" size={22} color="#fff" /></Pressable>
        <Pressable onPress={goNow} style={[styles.hbtn, { backgroundColor: accent }]}><Text style={styles.nowText}>{tx('الآن', 'Now')}</Text></Pressable>
        <Pressable onPress={() => setWs(w => w + SPAN)} style={styles.hbtn} accessibilityLabel={tx('أحدث', 'Later')}><Ionicons name="chevron-forward" size={22} color="#fff" /></Pressable>
      </View>
      <View style={styles.ruler}>
        <View style={{ width: NAME_W }}><Text style={styles.day}>{new Date(ws * 1000).toLocaleDateString(isEnglish ? 'en' : 'ar', { weekday: 'short', day: 'numeric' })}</Text></View>
        <View style={{ width: stripW, height: 22 }}>
          {ticks.map((t, i) => <Text key={t} style={[styles.tick, { left: (i / ticks.length) * stripW }]}>{hhmm(t)}</Text>)}
        </View>
      </View>
      <View style={{ flex: 1 }}>
        <TVFlatList
          data={channels}
          keyExtractor={(c: Media, i: number) => `${keyOf(c)}-${i}`}
          initialNumToRender={8}
          windowSize={5}
          maxToRenderPerBatch={6}
          renderItem={({ item }: { item: Media }) => <Row channel={item} k={keyOf(item)} ws={ws} stripW={stripW} now={now} accent={accent} guide={guide} onPlayLive={onPlayLive} onPick={onPickProgram} />}
        />
        {nowLeft >= 0 && nowLeft <= stripW && <View pointerEvents="none" style={[styles.nowLine, { left: 16 + NAME_W + nowLeft, backgroundColor: accent }]} />}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#0f1017', paddingTop: 34, paddingHorizontal: 16 },
  header: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  title: { flex: 1, color: '#fff', fontSize: 20, fontWeight: '800' },
  hbtn: { backgroundColor: '#242532', borderRadius: 12, paddingHorizontal: 12, paddingVertical: 8, minWidth: 40, alignItems: 'center' },
  nowText: { color: '#fff', fontWeight: '800' },
  ruler: { flexDirection: 'row', marginBottom: 4 },
  day: { color: '#9a9ab0', fontSize: 12, fontWeight: '700' },
  tick: { position: 'absolute', top: 2, color: '#9a9ab0', fontSize: 11 },
  row: { flexDirection: 'row', alignItems: 'center', marginBottom: 6 },
  name: { width: NAME_W, height: 52, justifyContent: 'center', paddingRight: 8 },
  nameText: { color: '#fff', fontSize: 12, fontWeight: '700' },
  block: { position: 'absolute', top: 0, height: 52, backgroundColor: '#1f2030', borderRadius: 8, borderWidth: 1, borderColor: '#2f3146', paddingHorizontal: 6, paddingVertical: 4, justifyContent: 'center', overflow: 'hidden' },
  blockText: { color: '#e8e8f2', fontSize: 11 },
  archive: { position: 'absolute', right: 3, bottom: 3 },
  loading: { color: '#6b6b82', paddingTop: 16, paddingLeft: 6 },
  nowLine: { position: 'absolute', top: 0, bottom: 0, width: 2, opacity: 0.8 },
});
