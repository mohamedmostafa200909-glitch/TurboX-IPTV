import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { TVPressable as Pressable, TVScrollView } from '../tv/focus';
import { Automation, DAY_OPTIONS } from '../storage/automation';

type Props = {
  value: Automation;
  isEnglish: boolean;
  onSave: (a: Automation) => void;
  onBack: () => void;
  onUpdateNow: () => void;
};

/** Settings → Automation (auto-update Live/Movies/Series and EPG every N days). */
export default function AutomationSettings({ value, isEnglish, onSave, onBack, onUpdateNow }: Props) {
  const tx = (ar: string, en: string) => (isEnglish ? en : ar);
  const [draft, setDraft] = useState<Automation>(value);
  const [open, setOpen] = useState<'catalog' | 'epg' | null>(null);
  const [saved, setSaved] = useState(false);

  const set = (patch: Partial<Automation>) => { setDraft(d => ({ ...d, ...patch })); setSaved(false); };

  const renderRow = (kind: 'catalog' | 'epg', label: string) => {
    const enabled = kind === 'catalog' ? draft.catalogEnabled : draft.epgEnabled;
    const days = kind === 'catalog' ? draft.catalogDays : draft.epgDays;
    return (
      <View style={styles.block}>
        <View style={styles.row}>
          <Pressable
            hasTVPreferredFocus={kind === 'catalog'}
            style={styles.check}
            onPress={() => set(kind === 'catalog' ? { catalogEnabled: !enabled } : { epgEnabled: !enabled })}
            accessibilityLabel={label}
          >
            <View style={[styles.box, enabled && styles.boxOn]}>{enabled && <Ionicons name="checkmark" size={18} color="#fff" />}</View>
            <Text style={styles.label} numberOfLines={2}>{label}</Text>
          </Pressable>
          <Pressable
            style={[styles.drop, !enabled && { opacity: 0.45 }]}
            onPress={() => enabled && setOpen(open === kind ? null : kind)}
            accessibilityLabel={tx('عدد الأيام', 'Number of days')}
          >
            <Text style={styles.dropNum}>{days}</Text>
            <Ionicons name={open === kind ? 'chevron-up' : 'chevron-down'} size={16} color="#ff5a66" />
            <Text style={styles.dropUnit}>{tx('يوم', 'Day(s)')}</Text>
          </Pressable>
        </View>
        {open === kind && (
          <View style={styles.options}>
            {DAY_OPTIONS.map(d => (
              <Pressable
                key={d}
                style={[styles.opt, d === days && styles.optOn]}
                onPress={() => { set(kind === 'catalog' ? { catalogDays: d } : { epgDays: d }); setOpen(null); }}
              >
                <Text style={[styles.optText, d === days && { color: '#fff' }]}>{d}</Text>
              </Pressable>
            ))}
          </View>
        )}
      </View>
    );
  };

  return (
    <View style={styles.bg}>
      <View style={styles.card}>
        <Text style={styles.title}>{tx('الأتمتة', 'Automation')}</Text>
        <TVScrollView style={{ maxHeight: 280 }} showsVerticalScrollIndicator={false}>
          {renderRow('catalog', tx('تحديث تلقائي للقنوات والأفلام والمسلسلات كل', 'Auto-Update Live, Movies & Series after every'))}
          {renderRow('epg', tx('تحديث تلقائي لدليل البرامج (EPG) كل', 'Auto-Update EPG after every'))}
          <Text style={styles.note}>
            {tx('يتم التحديث عند فتح التطبيق إذا مرّت المدة المحددة. عند إيقاف الخيار تُستخدم البيانات المحفوظة حتى تضغط "تحديث الآن".',
                'Updates run when the app opens and the chosen time has passed. If an option is off, saved data is used until you press "Update now".')}
          </Text>
        </TVScrollView>

        {saved && <Text style={styles.saved}>{tx('تم الحفظ ✓', 'Saved ✓')}</Text>}

        <View style={styles.actions}>
          <Pressable style={[styles.btn, styles.btnMain]} onPress={() => { onSave(draft); setSaved(true); }}>
            <Ionicons name="save-outline" size={16} color="#fff" />
            <Text style={styles.btnText}>{tx('حفظ التغييرات', 'SAVE CHANGES')}</Text>
          </Pressable>
          <Pressable style={styles.btn} onPress={onBack}>
            <Ionicons name="arrow-back" size={16} color="#ff5a66" />
            <Text style={[styles.btnText, { color: '#cfd0da' }]}>{tx('رجوع', 'BACK')}</Text>
          </Pressable>
        </View>
        <Pressable style={styles.updateNow} onPress={onUpdateNow}>
          <Ionicons name="refresh" size={15} color="#ff5a66" />
          <Text style={styles.updateText}>{tx('تحديث الآن', 'Update now')}</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bg: { flex: 1, backgroundColor: 'rgba(0,0,0,0.78)', justifyContent: 'center', alignItems: 'center', padding: 18 },
  card: { width: '100%', maxWidth: 620, backgroundColor: '#14141d', borderRadius: 22, borderWidth: 1, borderColor: '#2c2c3c', padding: 20 },
  title: { color: '#f4f4f8', fontSize: 22, fontWeight: '800', textAlign: 'center', marginBottom: 14 },
  block: { marginBottom: 12 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  check: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10, borderRadius: 14, backgroundColor: '#1c1c28', borderWidth: 1, borderColor: '#2c2c3c' },
  box: { width: 26, height: 26, borderRadius: 7, borderWidth: 2, borderColor: '#6b6b82', alignItems: 'center', justifyContent: 'center' },
  boxOn: { backgroundColor: '#e11d2e', borderColor: '#e11d2e' },
  label: { flex: 1, color: '#f4f4f8', fontSize: 14, fontWeight: '700' },
  drop: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, height: 46, borderRadius: 14, backgroundColor: '#1c1c28', borderWidth: 1, borderColor: '#2c2c3c' },
  dropNum: { color: '#fff', fontSize: 17, fontWeight: '800', minWidth: 20, textAlign: 'center' },
  dropUnit: { color: '#cfd0da', fontSize: 13, fontWeight: '700' },
  options: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8, paddingHorizontal: 4 },
  opt: { minWidth: 48, height: 38, borderRadius: 10, backgroundColor: '#1c1c28', borderWidth: 1, borderColor: '#2c2c3c', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 10 },
  optOn: { backgroundColor: '#e11d2e', borderColor: '#e11d2e' },
  optText: { color: '#cfd0da', fontSize: 14, fontWeight: '800' },
  note: { color: '#6b6b82', fontSize: 11, lineHeight: 17, marginTop: 4 },
  saved: { color: '#34d399', fontSize: 13, fontWeight: '800', textAlign: 'center', marginTop: 10 },
  actions: { flexDirection: 'row', gap: 10, marginTop: 14 },
  btn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, height: 48, borderRadius: 12, backgroundColor: '#1c1c28', borderWidth: 1, borderColor: '#2c2c3c' },
  btnMain: { backgroundColor: '#e11d2e', borderColor: '#e11d2e' },
  btnText: { color: '#fff', fontSize: 14, fontWeight: '900', letterSpacing: 0.8 },
  updateNow: { marginTop: 10, height: 40, borderRadius: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  updateText: { color: '#ff5a66', fontSize: 13, fontWeight: '800' },
});
