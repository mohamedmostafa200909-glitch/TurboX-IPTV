import React, { useEffect, useState } from 'react';
import { ActivityIndicator, NativeModules, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Modal } from './TVModal';
import { TVPressable as Pressable } from '../tv/focus';
import QrView from './QrView';

type Props = { visible: boolean; isEnglish: boolean; title: string; text: string; onClose: () => void };

/**
 * "View on your phone": serves `text` read-only from a small page on the TV's local network and shows a QR code
 * for it, instead of asking the person to photograph the screen. Used for the error log and the provider-check
 * report. The page has its own Copy button; nothing is ever sent back to the TV.
 */
export default function TextServerModal({ visible, isEnglish, title, text, onClose }: Props) {
  const tx = (ar: string, en: string) => (isEnglish ? en : ar);
  const [url, setUrl] = useState<string | null>(null);
  const [state, setState] = useState<'starting' | 'ready' | 'nonet' | 'unsupported'>('starting');

  useEffect(() => {
    if (!visible) return;
    let alive = true;
    setUrl(null);
    setState('starting');
    const mod = NativeModules.TurboPlayerModule;
    if (!mod?.startTextServer) { setState('unsupported'); return; }
    Promise.resolve(mod.startTextServer(text, title))
      .then((u: string | null) => { if (!alive) return; if (u) { setUrl(u); setState('ready'); } else setState('nonet'); })
      .catch(() => { if (alive) setState('nonet'); });
    return () => { alive = false; mod?.stopTextServer?.(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- `text` is a snapshot taken when the modal opens
  }, [visible]);

  return (
    <Modal visible={visible} transparent animationType="fade" statusBarTranslucent onRequestClose={onClose}>
      <View style={styles.screen}>
        <View style={styles.card}>
          <View style={styles.left}>
            <Text style={styles.title}>{title}</Text>
            <Text style={styles.hint}>{tx('امسح الكود بكاميرا الهاتف لعرض النص ونسخه.', 'Scan with your phone\u2019s camera to view and copy the text.')}</Text>
            {state === 'nonet' && <Text style={styles.warn}>{tx('لا يوجد اتصال بشبكة محلية. وصّل التلفزيون بالواي فاي أو الكابل أولًا.', 'No local network found. Connect the TV to Wi-Fi or Ethernet first.')}</Text>}
            {state === 'unsupported' && <Text style={styles.warn}>{tx('هذه الميزة غير متاحة في هذه النسخة من التطبيق.', 'This feature is not available in this build.')}</Text>}
            <Text style={styles.note}>{tx('يعمل داخل شبكتك المنزلية فقط، ويتوقف تلقائيًا بعد 10 دقائق أو عند الإغلاق.', 'Works on your home network only; stops automatically after 10 minutes or when you close this.')}</Text>
            <Pressable hasTVPreferredFocus onPress={onClose} style={styles.cancel}><Text style={styles.cancelText}>{tx('إغلاق', 'Close')}</Text></Pressable>
          </View>
          <View style={styles.right}>
            {url ? (
              <>
                <View style={styles.qrBox}><QrView text={url} size={260} /></View>
                <Text style={styles.url} numberOfLines={2}>{url}</Text>
              </>
            ) : state === 'starting' ? <ActivityIndicator size="large" color="#ff5a66" /> : <Ionicons name="wifi-outline" size={56} color="#6b6b80" />}
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: 'rgba(0,0,0,0.88)', alignItems: 'center', justifyContent: 'center', padding: 24 },
  card: { flexDirection: 'row', gap: 28, maxWidth: 820, width: '100%', backgroundColor: '#14141d', borderRadius: 22, padding: 30 },
  left: { flex: 1 },
  right: { width: 300, alignItems: 'center', justifyContent: 'center' },
  title: { color: '#fff', fontSize: 22, fontWeight: '800', marginBottom: 10 },
  hint: { color: '#c7c7cf', fontSize: 15, lineHeight: 22 },
  warn: { color: '#fbbf24', fontSize: 14, lineHeight: 20, marginTop: 10 },
  note: { color: '#6b6b80', fontSize: 12, marginTop: 14, lineHeight: 18 },
  cancel: { marginTop: 18, alignSelf: 'flex-start', paddingHorizontal: 24, height: 44, borderRadius: 22, borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.35)', alignItems: 'center', justifyContent: 'center' },
  cancelText: { color: '#fff', fontSize: 15, fontWeight: '700' },
  qrBox: { backgroundColor: '#fff', borderRadius: 12, padding: 6 },
  url: { color: '#9a9ab0', fontSize: 12, marginTop: 10, textAlign: 'center' },
});
