import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { TVPressable as Pressable, TVScrollView } from '../tv/focus';
import type { LogEntry } from '../utils/logFormat';

type Props = { entries: LogEntry[]; accent: string; isEnglish: boolean; maxHeight: number; onShare: () => void; onPhone?: () => void; onClear: () => void; onClose: () => void };
const COLOR = { info: '#9a9ab0', warn: '#fbbf24', error: '#f87171' } as const;
const pad = (n: number) => String(n).padStart(2, '0');

/** Settings → Logs: last events (credentials removed) that the user can share with the developer. */
export default function LogsModal({ entries, accent, isEnglish, maxHeight, onShare, onPhone, onClear, onClose }: Props) {
  const tx = (ar: string, en: string) => (isEnglish ? en : ar);
  const list = [...entries].reverse();
  return (
    <View style={styles.bg}>
      <View style={styles.card}>
        <Pressable onPress={onClose} style={styles.close}><Ionicons name="close" size={20} color="#aaa" /></Pressable>
        <Text style={styles.title}>{tx('سجل الأخطاء', 'Logs')}</Text>
        <Text style={styles.sub}>{tx('يُخفى اسم المستخدم وكلمة المرور تلقائيًا. شارك السجل مع المطوّر عند حدوث مشكلة.', 'Username and password are removed automatically. Share this with the developer when something goes wrong.')}</Text>
        <TVScrollView style={{ maxHeight }}>
          {list.length ? list.map((e, i) => {
            const d = new Date(e.t);
            return (
              <Text key={`${e.t}-${i}`} style={[styles.line, { color: COLOR[e.lvl] }]}>
                {`${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())} ${e.tag}: ${e.msg}`}
              </Text>
            );
          }) : <Text style={styles.empty}>{tx('لا توجد أحداث مسجّلة.', 'No events recorded.')}</Text>}
        </TVScrollView>
        <View style={styles.actions}>
          <Pressable style={[styles.btn, { backgroundColor: accent }]} onPress={onShare}><Text style={styles.btnText}>{tx('مشاركة', 'Share')}</Text></Pressable>
          {!!onPhone && <Pressable style={[styles.btn, styles.ghost]} onPress={onPhone}><Text style={styles.btnText}>{tx('عرض على الهاتف', 'View on phone')}</Text></Pressable>}
          <Pressable style={[styles.btn, styles.ghost]} onPress={onClear}><Text style={styles.btnText}>{tx('مسح', 'Clear')}</Text></Pressable>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bg: { flex: 1, backgroundColor: '#000b', justifyContent: 'flex-end' },
  card: { backgroundColor: '#1a1b23', borderTopLeftRadius: 22, borderTopRightRadius: 22, padding: 24, paddingBottom: 34 },
  close: { position: 'absolute', right: 16, top: 16, zIndex: 2, padding: 6 },
  title: { color: '#fff', fontSize: 22, fontWeight: '800' },
  sub: { color: '#9a9ab0', marginTop: 4, marginBottom: 10, fontSize: 12 },
  line: { fontSize: 11, marginBottom: 4, fontFamily: 'monospace' },
  empty: { color: '#9a9ab0', paddingVertical: 20, textAlign: 'center' },
  actions: { flexDirection: 'row', gap: 10, marginTop: 14 },
  btn: { flex: 1, borderRadius: 14, paddingVertical: 13, alignItems: 'center' },
  ghost: { backgroundColor: '#2a2b38' },
  btnText: { color: '#fff', fontWeight: '800' },
});
