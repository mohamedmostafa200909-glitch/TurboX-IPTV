import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { TVPressable as Pressable, TVScrollView } from '../tv/focus';

type Props = { isEnglish: boolean; onClose: () => void };
type Row = { key: string; ar: string; en: string };
type Section = { icon: any; ar: string; en: string; rows: Row[] };

/** The single source of truth for what every remote key does. Keep in sync with TurboXApp / focus.tsx / MainActivity. */
const SECTIONS: Section[] = [
  {
    icon: 'apps-outline', ar: 'القوائم والشاشات', en: 'Menus & screens',
    rows: [
      { key: '▲ ▼ ◀ ▶', ar: 'التنقل بين العناصر', en: 'Move between items' },
      { key: 'OK', ar: 'فتح / تأكيد', en: 'Open / confirm' },
      { key: 'Back', ar: 'رجوع خطوة، ومن الرئيسية يظهر سؤال الخروج', en: 'Go back; on Home it asks to exit' },
    ],
  },
  {
    icon: 'keypad-outline', ar: 'الكتابة', en: 'Typing',
    rows: [
      { key: 'OK', ar: 'فتح الكيبورد على الحقل', en: 'Open the keyboard on a field' },
      { key: '▲ ▼ ◀ ▶', ar: 'التنقل بين حروف الكيبورد', en: 'Move over the keyboard keys' },
      { key: 'Next / Done', ar: 'الحقل التالي / تأكيد', en: 'Next field / confirm' },
      { key: 'Back', ar: 'إغلاق الكيبورد', en: 'Close the keyboard' },
    ],
  },
  {
    icon: 'play-circle-outline', ar: 'المشغّل', en: 'Player',
    rows: [
      { key: 'OK', ar: 'إيقاف مؤقت / تشغيل', en: 'Pause / play' },
      { key: '◀ ▶', ar: 'ترجيع / تقديم 10 ثوانٍ (الأفلام والمسلسلات)', en: 'Seek 10s back / forward (movies & series)' },
      { key: '▲ ▼', ar: 'القناة التالية / السابقة', en: 'Next / previous channel' },
      { key: '0 – 9', ar: 'كتابة رقم القناة', en: 'Type a channel number' },
      { key: 'Back', ar: 'إغلاق المشغّل', en: 'Close the player' },
    ],
  },
  {
    icon: 'tv-outline', ar: 'أزرار الريموت الإضافية', en: 'Extra remote keys',
    rows: [
      { key: 'Ch + / Ch −', ar: 'القناة التالية / السابقة', en: 'Next / previous channel' },
      { key: 'Last', ar: 'القناة السابقة التي شاهدتها', en: 'Previously watched channel' },
      { key: '⏪ ⏩', ar: 'ترجيع / تقديم', en: 'Rewind / fast-forward' },
      { key: '⏯ ▶ ⏸', ar: 'تشغيل / إيقاف مؤقت', en: 'Play / pause' },
      { key: '⏭ ⏮', ar: 'القناة التالية/السابقة، أو ±30 ثانية في الأفلام', en: 'Next/previous channel, or ±30s in movies' },
      { key: '⏹ Stop', ar: 'إغلاق المشغّل', en: 'Close the player' },
      { key: 'Menu / Info / Blue', ar: 'قائمة الصوت والترجمة', en: 'Audio & subtitles menu' },
      { key: 'Red', ar: 'مؤقت النوم', en: 'Sleep timer' },
      { key: 'Yellow', ar: 'تغيير حجم الصورة', en: 'Change picture size' },
    ],
  },
];

export default function RemoteGuide({ isEnglish, onClose }: Props) {
  const tx = (ar: string, en: string) => (isEnglish ? en : ar);
  return (
    <View style={styles.bg}>
      <View style={styles.card}>
        <Text style={styles.title}>{tx('دليل الريموت', 'Remote guide')}</Text>
        <Text style={styles.sub}>{tx('ماذا يفعل كل زر في التطبيق', 'What each remote key does in the app')}</Text>
        <TVScrollView style={{ maxHeight: 340 }} showsVerticalScrollIndicator={false}>
          {SECTIONS.map(sec => (
            <View key={sec.en} style={styles.section}>
              <View style={styles.secHead}>
                <Ionicons name={sec.icon} size={16} color="#ff5a66" />
                <Text style={styles.secTitle}>{tx(sec.ar, sec.en)}</Text>
              </View>
              {sec.rows.map(r => (
                <View key={r.key + r.en} style={styles.row}>
                  <View style={styles.keyBox}><Text style={styles.keyText}>{r.key}</Text></View>
                  <Text style={styles.desc}>{tx(r.ar, r.en)}</Text>
                </View>
              ))}
            </View>
          ))}
        </TVScrollView>
        <Pressable hasTVPreferredFocus style={styles.close} onPress={onClose}>
          <Text style={styles.closeText}>{tx('إغلاق', 'Close')}</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bg: { flex: 1, backgroundColor: 'rgba(0,0,0,0.78)', justifyContent: 'center', alignItems: 'center', padding: 18 },
  card: { width: '100%', maxWidth: 520, backgroundColor: '#14141d', borderRadius: 22, borderWidth: 1, borderColor: '#2c2c3c', padding: 18 },
  title: { color: '#f4f4f8', fontSize: 18, fontWeight: '800' },
  sub: { color: '#9a9ab0', fontSize: 12, marginTop: 4, marginBottom: 6 },
  section: { marginTop: 10 },
  secHead: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 },
  secTitle: { color: '#ff5a66', fontSize: 13, fontWeight: '800' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 5 },
  keyBox: { minWidth: 96, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, backgroundColor: '#1c1c28', borderWidth: 1, borderColor: '#2c2c3c', alignItems: 'center' },
  keyText: { color: '#f4f4f8', fontSize: 12, fontWeight: '800' },
  desc: { color: '#cfd0da', fontSize: 12, flex: 1 },
  close: { marginTop: 12, height: 44, borderRadius: 12, backgroundColor: '#1c1c28', borderWidth: 1, borderColor: '#2c2c3c', alignItems: 'center', justifyContent: 'center' },
  closeText: { color: '#cfd0da', fontSize: 14, fontWeight: '800' },
});
