import React, { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, NativeModules, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Modal } from './TVModal';
import { TVPressable as Pressable, TVTextInput } from '../tv/focus';
import QrView from './QrView';

export const BACKUP_VERSION = 1;

type Props = {
  visible: boolean;
  isEnglish: boolean;
  accent: string;
  /** JSON string built by the caller (providers + settings) — a snapshot taken when the modal opens */
  exportText: string;
  onImport: (data: any) => void;
  onClose: () => void;
};

/**
 * Settings transfer between two TVs on the same network (no camera needed on either end — a TV cannot scan a QR
 * from another TV): device A starts a tiny local server with its backup JSON and shows the address as both a QR
 * (handy if a phone is nearby to relay it) and plain text; on device B, the person types that short address with
 * the remote and imports it. Only providers and simple app settings travel this way — favourites and watch
 * history use a different, per-profile storage model and are not included yet.
 */
export default function BackupModal({ visible, isEnglish, accent, exportText, onImport, onClose }: Props) {
  const tx = (ar: string, en: string) => (isEnglish ? en : ar);
  const [mode, setMode] = useState<'menu' | 'export' | 'import'>('menu');
  const [url, setUrl] = useState<string | null>(null);
  const [state, setState] = useState<'starting' | 'ready' | 'nonet' | 'unsupported'>('starting');
  const [addr, setAddr] = useState('');
  const [importing, setImporting] = useState(false);

  useEffect(() => { if (visible) setMode('menu'); }, [visible]);

  useEffect(() => {
    if (mode !== 'export') return;
    let alive = true;
    setUrl(null);
    setState('starting');
    const mod = NativeModules.TurboPlayerModule;
    if (!mod?.startSettingsServer) { setState('unsupported'); return; }
    Promise.resolve(mod.startSettingsServer(exportText))
      .then((u: string | null) => { if (!alive) return; if (u) { setUrl(u); setState('ready'); } else setState('nonet'); })
      .catch(() => { if (alive) setState('nonet'); });
    return () => { alive = false; mod?.stopSettingsServer?.(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode]);

  async function doImport() {
    const addrTrim = addr.trim();
    if (!addrTrim) return;
    const full = /^https?:\/\//i.test(addrTrim) ? addrTrim : `http://${addrTrim}`;
    setImporting(true);
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 6000);
      const res = await fetch(full, { signal: controller.signal });
      clearTimeout(timer);
      if (!res.ok) throw new Error('bad response');
      const data = await res.json();
      if (!data || data.turboxBackup !== BACKUP_VERSION) throw new Error('not a backup');
      Alert.alert(
        tx('استيراد الإعدادات', 'Import settings'),
        tx(`سيتم استبدال المزوّدين والإعدادات الحالية بـ ${Array.isArray(data.providers) ? data.providers.length : 0} مزوّد من الجهاز الآخر. متابعة؟`, `This replaces your current providers and settings with ${Array.isArray(data.providers) ? data.providers.length : 0} provider(s) from the other device. Continue?`),
        [
          { text: tx('إلغاء', 'Cancel'), style: 'cancel' },
          { text: tx('استيراد', 'Import'), onPress: () => { onImport(data); onClose(); } },
        ],
      );
    } catch {
      Alert.alert(tx('تعذّر الاستيراد', 'Import failed'), tx('تأكد إن الجهازين على نفس الشبكة وإن العنوان صحيح، ثم حاول مرة أخرى.', 'Make sure both devices are on the same network and the address is correct, then try again.'));
    } finally {
      setImporting(false);
    }
  }

  return (
    <Modal visible={visible} transparent animationType="fade" statusBarTranslucent onRequestClose={onClose}>
      <View style={styles.screen}>
        <View style={styles.card}>
          {mode === 'menu' && (
            <>
              <Text style={styles.title}>{tx('نقل الإعدادات بين الأجهزة', 'Transfer settings between devices')}</Text>
              <Text style={styles.hint}>{tx('ينقل المزوّدين وإعدادات التطبيق إلى تلفزيون آخر على نفس الشبكة. لا ينقل المفضلة ولا سجل المشاهدة حاليًا.', 'Moves your providers and app settings to another TV on the same network. Favourites and watch history are not included yet.')}</Text>
              <Pressable hasTVPreferredFocus onPress={() => setMode('export')} style={[styles.bigBtn, { backgroundColor: accent }]}>
                <Ionicons name="cloud-upload-outline" size={20} color="#fff" />
                <Text style={styles.bigBtnText}>{tx('تصدير من هذا الجهاز', 'Export from this device')}</Text>
              </Pressable>
              <Pressable onPress={() => setMode('import')} style={[styles.bigBtn, styles.ghost]}>
                <Ionicons name="cloud-download-outline" size={20} color="#fff" />
                <Text style={styles.bigBtnText}>{tx('استيراد إلى هذا الجهاز', 'Import into this device')}</Text>
              </Pressable>
              <Pressable onPress={onClose} style={styles.cancel}><Text style={styles.cancelText}>{tx('إغلاق', 'Close')}</Text></Pressable>
            </>
          )}

          {mode === 'export' && (
            <>
              <Text style={styles.title}>{tx('تصدير', 'Export')}</Text>
              <Text style={styles.hint}>{tx('على الجهاز الآخر: افتح "نقل الإعدادات" ← "استيراد"، واكتب العنوان الظاهر هنا.', 'On the other device: open "Transfer settings" → "Import", and type the address shown here.')}</Text>
              <View style={styles.qrRow}>
                {url ? <View style={styles.qrBox}><QrView text={url} size={180} /></View>
                  : state === 'starting' ? <ActivityIndicator size="large" color={accent} />
                  : <Ionicons name="wifi-outline" size={48} color="#6b6b80" />}
                <View style={{ flex: 1 }}>
                  {url && <Text style={styles.url} selectable>{url}</Text>}
                  {state === 'nonet' && <Text style={styles.warn}>{tx('لا يوجد اتصال بشبكة محلية.', 'No local network found.')}</Text>}
                  {state === 'unsupported' && <Text style={styles.warn}>{tx('غير متاح في هذه النسخة.', 'Not available in this build.')}</Text>}
                </View>
              </View>
              <Text style={styles.note}>{tx('يتوقف تلقائيًا بعد 10 دقائق أو عند الإغلاق.', 'Stops automatically after 10 minutes or when you close this.')}</Text>
              <Pressable onPress={() => setMode('menu')} style={styles.cancel}><Text style={styles.cancelText}>{tx('رجوع', 'Back')}</Text></Pressable>
            </>
          )}

          {mode === 'import' && (
            <>
              <Text style={styles.title}>{tx('استيراد', 'Import')}</Text>
              <Text style={styles.hint}>{tx('اكتب العنوان الظاهر على الجهاز الآخر (شاشة التصدير).', 'Type the address shown on the other device\u2019s Export screen.')}</Text>
              <TVTextInput
                wrapStyle={styles.inputWrap}
                style={styles.input}
                value={addr}
                onChangeText={setAddr}
                placeholder="192.168.1.23:51234/ab12cd"
                placeholderTextColor="#6b6b82"
                autoCapitalize="none"
                autoCorrect={false}
              />
              <Pressable disabled={importing || !addr.trim()} onPress={doImport} style={[styles.bigBtn, { backgroundColor: accent }, (importing || !addr.trim()) && { opacity: 0.5 }]}>
                {importing ? <ActivityIndicator color="#fff" /> : <Text style={styles.bigBtnText}>{tx('استيراد', 'Import')}</Text>}
              </Pressable>
              <Pressable onPress={() => setMode('menu')} style={styles.cancel}><Text style={styles.cancelText}>{tx('رجوع', 'Back')}</Text></Pressable>
            </>
          )}
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: 'rgba(0,0,0,0.88)', alignItems: 'center', justifyContent: 'center', padding: 24 },
  card: { width: 640, maxWidth: '94%', backgroundColor: '#14141d', borderRadius: 22, padding: 28 },
  title: { color: '#fff', fontSize: 22, fontWeight: '800', marginBottom: 10 },
  hint: { color: '#c7c7cf', fontSize: 14, lineHeight: 21, marginBottom: 18 },
  warn: { color: '#fbbf24', fontSize: 13, lineHeight: 19 },
  note: { color: '#6b6b80', fontSize: 11, marginTop: 14 },
  bigBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, height: 52, borderRadius: 14, marginTop: 10 },
  ghost: { backgroundColor: 'rgba(255,255,255,0.1)' },
  bigBtnText: { color: '#fff', fontSize: 16, fontWeight: '800' },
  cancel: { alignSelf: 'center', marginTop: 16, paddingHorizontal: 22, height: 40, borderRadius: 20, borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.3)', alignItems: 'center', justifyContent: 'center' },
  cancelText: { color: '#fff', fontSize: 14, fontWeight: '700' },
  qrRow: { flexDirection: 'row', alignItems: 'center', gap: 16 },
  qrBox: { backgroundColor: '#fff', borderRadius: 10, padding: 6 },
  url: { color: '#fff', fontSize: 15, fontWeight: '700' },
  inputWrap: { marginBottom: 14 },
  input: { color: '#fff', fontSize: 16 },
});
