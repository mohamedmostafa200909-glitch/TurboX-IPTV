import React, { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { TVPressable as Pressable } from '../tv/focus';
import { runProviderCheck, formatReport, CheckItem } from '../network/providerCheck';
import type { Provider } from '../types';

type Props = { visible: boolean; provider: Provider | null; accent: string; isEnglish: boolean; onPhone: (text: string) => void; onClose: () => void };

/** Settings → "Check this provider": runs login/channels/movies/series/details/EPG/stream-open against the active
 *  provider and shows a green/red row per service, so it is obvious which part is the provider's problem. */
export default function ProviderCheckModal({ visible, provider, accent, isEnglish, onPhone, onClose }: Props) {
  const tx = (ar: string, en: string) => (isEnglish ? en : ar);
  const [items, setItems] = useState<CheckItem[]>([]);
  const [running, setRunning] = useState(false);
  const runId = useRef(0);

  const run = () => {
    if (!provider) return;
    const id = ++runId.current;
    setRunning(true);
    setItems([]);
    runProviderCheck(provider, snap => { if (runId.current === id) setItems(snap); })
      .finally(() => { if (runId.current === id) setRunning(false); });
  };
  useEffect(() => { if (visible) run(); else runId.current++; }, [visible, provider?.id]);

  const done = items.length > 0 && items.every(i => i.ok !== null);

  return (
    <View style={styles.bg}>
      <View style={styles.card}>
        <Pressable onPress={onClose} style={styles.close}><Ionicons name="close" size={20} color="#aaa" /></Pressable>
        <Text style={styles.title}>{tx('فحص المزوّد', 'Provider check')}</Text>
        <Text style={styles.sub} numberOfLines={1}>{provider?.name || ''}</Text>
        <View style={{ marginTop: 14, gap: 8 }}>
          {items.map(i => (
            <View key={i.id} style={styles.row}>
              <View style={[styles.dot, i.ok === null ? styles.dotWait : i.ok ? styles.dotOk : styles.dotBad]}>
                {i.ok === null ? <ActivityIndicator size="small" color="#fff" /> : <Ionicons name={i.ok ? 'checkmark' : 'close'} size={14} color="#fff" />}
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.rowLabel}>{i.label[isEnglish ? 1 : 0]}</Text>
                {!!i.detail && <Text style={styles.rowDetail} numberOfLines={1}>{i.detail}</Text>}
              </View>
              {i.ms > 0 && <Text style={styles.rowMs}>{i.ms}ms</Text>}
            </View>
          ))}
          {!items.length && <ActivityIndicator color={accent} style={{ marginTop: 10 }} />}
        </View>
        <Text style={styles.note}>{tx('"فتح بث مباشر" يتأكد فقط إن الرابط بيرد ببيانات، مش فحص تشغيل كامل.', '"Opening a live stream" only confirms the URL answers with data, not a full playback test.')}</Text>
        <View style={styles.actions}>
          <Pressable disabled={running} style={[styles.btn, { backgroundColor: accent }, running && { opacity: 0.5 }]} onPress={run}><Text style={styles.btnText}>{tx('إعادة الفحص', 'Run again')}</Text></Pressable>
          <Pressable disabled={!done} style={[styles.btn, styles.ghost, !done && { opacity: 0.5 }]} onPress={() => provider && onPhone(formatReport(provider, items, isEnglish))}>
            <Text style={styles.btnText}>{tx('عرض على الهاتف', 'View on phone')}</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bg: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.7)', alignItems: 'center', justifyContent: 'center' },
  card: { width: 560, maxWidth: '92%', maxHeight: '85%', backgroundColor: '#14141d', borderRadius: 18, padding: 22 },
  close: { position: 'absolute', top: 14, right: 14, zIndex: 1, padding: 6 },
  title: { color: '#fff', fontSize: 20, fontWeight: '800' },
  sub: { color: '#9a9ab0', fontSize: 14, marginTop: 4 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8 },
  dot: { width: 24, height: 24, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  dotWait: { backgroundColor: 'rgba(255,255,255,0.15)' },
  dotOk: { backgroundColor: '#1f9d55' },
  dotBad: { backgroundColor: '#d8323f' },
  rowLabel: { color: '#fff', fontSize: 14, fontWeight: '700' },
  rowDetail: { color: '#9a9ab0', fontSize: 11, marginTop: 1 },
  rowMs: { color: '#6b6b80', fontSize: 11 },
  note: { color: '#6b6b80', fontSize: 11, marginTop: 14, lineHeight: 16 },
  actions: { flexDirection: 'row', gap: 10, marginTop: 16 },
  btn: { flex: 1, borderRadius: 10, paddingVertical: 11, alignItems: 'center' },
  ghost: { backgroundColor: 'rgba(255,255,255,0.1)' },
  btnText: { color: '#fff', fontSize: 14, fontWeight: '800' },
});
