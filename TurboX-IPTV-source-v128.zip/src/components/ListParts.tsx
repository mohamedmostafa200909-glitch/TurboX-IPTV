import { thumbUrl } from '../utils/thumb';
import React, { createContext, useContext, useEffect, useState } from 'react';
import { Image, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { TVPressable as Pressable, TVModeContext } from '../tv/focus';
import { scrollIdle } from '../utils/scrollIdle';
import type { Provider, Media } from '../types';
import { styles } from '../styles';

export function SectionTitle({
  title,
  action,
  onAction,
  accent
}: {
  title: string;
  action?: string;
  onAction?: () => void;
  accent: string;
}) {
  return <View style={styles.sectionTitle}><Text style={styles.title}>{title}</Text>{action && <Pressable onPress={onAction}><Text style={[styles.action, {
        color: accent
      }]}>{action} ‹</Text></Pressable>}</View>;
}
export function ProviderRow({
  p,
  onPress,
  accent
}: {
  p: Provider;
  onPress: () => void;
  accent: string;
}) {
  return <Pressable style={styles.provider} onPress={onPress}><View style={[styles.providerIcon, {
      backgroundColor: `${accent}33`
    }]}><Ionicons name="tv-outline" size={19} color={accent} /></View><View style={{
      flex: 1
    }}><Text style={styles.channelName}>{p.name}</Text><Text style={styles.channelSub}>{p.server}</Text></View><View style={[styles.connected, {
      backgroundColor: p.connected ? '#275339' : '#3d3030'
    }]}><Text style={{
        fontSize: 9,
        color: p.connected ? '#83d79a' : '#e89078'
      }}>{p.connected ? 'متصل' : 'اتصال'}</Text></View></Pressable>;
}
/** Settings → "Favourite star on TV lists": true = the star is a normal focus target (for remotes without MENU/INFO/YELLOW). */
export const StarFocusContext = createContext(false);

/** On TV: false while a list is scrolling, so images are requested after the movement stops (always true elsewhere). */
function useImagesReady() {
  const tv = useContext(TVModeContext);
  const [ready, setReady] = useState(() => !tv || scrollIdle.isIdle());
  useEffect(() => {
    if (ready) return;
    return scrollIdle.onceIdle(() => setReady(true));
  }, [ready]);
  return ready;
}

export const MediaRow = React.memo(function MediaRow({
  item,
  accent,
  favorite,
  onFavorite,
  onPlay,
  currentProgram,
  hasTVPreferredFocus = false,
  remoteFocused = false
}: {
  item: Media;
  accent: string;
  favorite: boolean;
  /** receive the item, so the parent can pass ONE stable function for every row (keeps React.memo effective) */
  onFavorite: (item: Media) => void;
  onPlay: (item: Media) => void;
  currentProgram?: string;
  hasTVPreferredFocus?: boolean;
  remoteFocused?: boolean;
}) {
  const [isFocused, setIsFocused] = useState(false);
  const tvRaw = useContext(TVModeContext);
  const starFocus = useContext(StarFocusContext);
  const tv = tvRaw && !starFocus; // star stays out of D-pad navigation unless the user turned it on
  const imagesReady = useImagesReady();
  return <Pressable lite onAltPress={() => onFavorite(item)} focusable isTVSelectable={true} hasTVPreferredFocus={hasTVPreferredFocus} onFocus={() => setIsFocused(true)} onBlur={() => setIsFocused(false)} style={[styles.channel, (isFocused || remoteFocused) && {borderColor: '#ff5a66', borderWidth: 2, backgroundColor: 'rgba(225,29,46,0.18)', transform: [{scale: 1.02}]}]} onPress={() => onPlay(item)}><View style={[styles.channelLogo, {
      backgroundColor: accent
    }]}>{item.cover || item.stream_icon ? (imagesReady ? <Image source={{
        uri: item.cover || item.stream_icon
      }} style={styles.channelLogoImg} resizeMethod="resize" fadeDuration={0} /> : null) : <Text style={{
        fontWeight: '800',
        color: '#fff'
      }}>{(item.name || 'TV').slice(0, 2)}</Text>}</View><View style={{
      flex: 1
    }}><Text style={styles.channelName}>{item.name}</Text><Text style={styles.channelSub}>{currentProgram || (item.kind === 'live' ? 'لا توجد بيانات البرنامج الحالي' : item.category_name || item.year || (item.kind === 'movie' ? 'فيلم' : 'مسلسل'))}</Text></View>{tv ? <Ionicons name={favorite ? 'star' : 'star-outline'} size={21} color={favorite ? '#f0c55c' : '#777985'} /> : <Pressable onPress={() => onFavorite(item)} hitSlop={10}><Ionicons name={favorite ? 'star' : 'star-outline'} size={21} color={favorite ? '#f0c55c' : '#777985'} /></Pressable>}<Ionicons name="play-circle" size={25} color={accent} /></Pressable>;
});
/** One row of the category sidebar. Memoised: selecting a category re-renders only the two rows that changed. */
export const CategoryRow = React.memo(function CategoryRow({name, count, selected, accent, onSelect}: {name: string; count: number; selected: boolean; accent: string; onSelect: (name: string) => void}) {
  return <Pressable lite onPress={() => onSelect(name)} style={[styles.catalogCategory, selected && {backgroundColor: accent}]}><Text style={styles.catalogCategoryText} numberOfLines={1}>{name}</Text><Text style={styles.catalogCategoryCount}>{String(count)}</Text></Pressable>;
});

export function PosterImage({item, style}:{item: Media; style:any}) {
  const imagesReady = useImagesReady();
  const candidates = [item.cover_big, item.cover, item.stream_icon].filter((value): value is string => !!value && value.trim().length > 0).map(u => thumbUrl(u.trim(), 342));
  const [index, setIndex] = useState(0);
  if (!candidates.length || !imagesReady) return null;
  return <Image source={{uri:candidates[Math.min(index, candidates.length - 1)]}} style={style} resizeMode="contain" resizeMethod="resize" fadeDuration={0} onError={() => setIndex(current => current + 1 < candidates.length ? current + 1 : current)} />;
}
export const MediaCard = React.memo(function MediaCard({
  width,
  item,
  accent,
  favorite,
  onFavorite,
  onPlay,
  index = 0,
  onFocusIndex,
  hasTVPreferredFocus = false,
  remoteFocused = false
}: {
  width: number;
  item: Media;
  accent: string;
  favorite: boolean;
  onFavorite: (item: Media) => void;
  onPlay: (item: Media) => void;
  index?: number;
  onFocusIndex?: (index: number) => void;
  hasTVPreferredFocus?: boolean;
  remoteFocused?: boolean;
}) {
  const [isFocused, setIsFocused] = useState(false);
  const tvRaw = useContext(TVModeContext);
  const starFocus = useContext(StarFocusContext);
  const tv = tvRaw && !starFocus;
  return <Pressable lite onAltPress={() => onFavorite(item)} focusable isTVSelectable={true} hasTVPreferredFocus={hasTVPreferredFocus} onFocus={() => { setIsFocused(true); onFocusIndex?.(index); }} onBlur={() => setIsFocused(false)} style={[styles.mediaCard, (isFocused || remoteFocused) && {borderColor: '#ff5a66', borderWidth: 2, backgroundColor: 'rgba(225,29,46,0.18)', shadowColor: '#ff5a66', shadowOpacity: 0.65, shadowRadius: 8, elevation: 8, transform: [{scale: 1.05}]}, {
    width
  }]} onPress={() => onPlay(item)}><View style={[styles.mediaPoster, {
      height: Math.round(width * (item.kind === 'series' ? 1.5 : 1.38))
    }]}>{(item.cover_big || item.cover || item.stream_icon) ? <PosterImage item={item} style={styles.mediaPosterImage} /> : <Ionicons name={item.kind === 'series' ? 'videocam' : 'film'} size={42} color={accent} />}<View style={styles.mediaBadge}><Text style={styles.mediaBadgeText}>{item.kind === 'series' ? 'SERIES' : 'HD'}</Text></View>{tv ? <View style={styles.mediaStar}><Ionicons name={favorite ? 'star' : 'star-outline'} size={19} color={favorite ? '#ffd21c' : '#fff'} /></View> : <Pressable style={styles.mediaStar} onPress={() => onFavorite(item)}><Ionicons name={favorite ? 'star' : 'star-outline'} size={19} color={favorite ? '#ffd21c' : '#fff'} /></Pressable>}</View><Text style={styles.mediaCardTitle} numberOfLines={2}>{item.name}</Text><Text style={styles.mediaCardMeta} numberOfLines={1}>{item.year || item.category_name || (item.kind === 'series' ? 'مسلسل' : 'فيلم')}</Text></Pressable>;
});
export function Empty({
  onPress,
  label = 'ابدأ بAdd source IPTV',
  accent
}: {
  onPress: () => void;
  label?: string;
  accent: string;
}) {
  return <View style={styles.empty}><Ionicons name="radio-outline" size={32} color={accent} /><Text style={styles.emptyText}>لا توجد عناصر بعد</Text><Pressable onPress={onPress}><Text style={[styles.action, {
        color: accent
      }]}>{label}</Text></Pressable></View>;
}
export function Setting({
  icon,
  title,
  sub,
  onPress,
  accent
}: {
  icon: any;
  title: string;
  sub: string;
  onPress?: () => void;
  accent: string;
}) {
  return <Pressable style={styles.setting} onPress={onPress}><Ionicons name={icon} size={20} color={accent} /><View style={{
      flex: 1
    }}><Text style={styles.channelName}>{title}</Text><Text style={styles.channelSub}>{sub}</Text></View><Ionicons name="chevron-back" size={16} color="#777" /></Pressable>;
}