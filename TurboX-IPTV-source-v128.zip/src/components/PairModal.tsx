import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, DeviceEventEmitter, NativeModules, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Modal } from './TVModal';
import { TVPressable as Pressable } from '../tv/focus';
import QrView from './QrView';

export type PairData = { name: string; server: string; username: string; password: string };

type Props = { visible: boolean; isEnglish: boolean; onClose: () => void; onData: (d: PairData) => void };

/** "Sign in with your phone": shows a QR for a one-off page served by the TV on the local network. */
export default function PairModal({ visible, isEnglish, onClose, onData }: Props) {
  const tx = (ar: string, en: string) => (isEnglish ? en : ar);
  const [url, setUrl] = useState<string | null>(null);
  const [state, setState] = useState<'starting' | 'waiting' | 'nonet' | 'unsupported'>('starting');
  const onDataRef = useRef(onData);
  onDataRef.current = onData;

  useEffect(() => {
    if (!visible) return;
    let alive = true;
    setUrl(null);
    setState('starting');
    const mod = NativeModules.TurboPlayerModule;
    if (!mod?.startPairServer) { setState('unsupported'); return; }
    Promise.resolve(mod.startPairServer())
      .then((u: string | null) => { if (!alive) return; if (u) { setUrl(u); setState('waiting'); } else setState('nonet'); })
      .catch(() => { if (alive) setState('nonet'); });
    const sub = DeviceEventEmitter.addListener('TurboPairData', (d: any) => {
      if (!alive) return;
      alive = false;
      mod.stopPairServer?.();
      onDataRef.current({ name: String(d?.name || ''), server: String(d?.server || ''), username: String(d?.username || ''), password: String(d?.password || '') });
    });
    return () => { alive = false; sub.remove(); mod?.stopPairServer?.(); };
  }, [visible]);

  const steps = [
    tx('وصّل الهاتف بنفس شبكة الواي فاي', 'Connect your phone to the same Wi-Fi'),
    tx('افتح الكاميرا وامسح الكود', 'Open the camera and scan the code'),
    tx('اكتب بيانات الاشتراك واضغط إرسال', 'Enter the subscription details and tap Send'),
  ];

  return (
    <Modal visible={visible} transparent animationType="fade" statusBarTranslucent onRequestClose={onClose}>
      <View style={styles.screen}>
        <View style={styles.card}>
          <View style={styles.left}>
            <Text style={styles.title}>{tx('تسجيل الدخول بالهاتف', 'Sign in with your phone')}</Text>
            {steps.map((t, i) => (
              <View key={i} style={styles.step}><View style={styles.num}><Text style={styles.numText}>{i + 1}</Text></View><Text style={styles.stepText}>{t}</Text></View>
            ))}
            {state === 'waiting' && <View style={styles.wait}><ActivityIndicator size="small" color="#ff5a66" /><Text style={styles.waitText}>{tx('في انتظار الهاتف…', 'Waiting for your phone…')}</Text></View>}
            {state === 'nonet' && <Text style={styles.warn}>{tx('لا يوجد اتصال بشبكة محلية. وصّل التلفزيون بالواي فاي أو الكابل أولًا.', 'No local network found. Connect the TV to Wi-Fi or Ethernet first.')}</Text>}
            {state === 'unsupported' && <Text style={styles.warn}>{tx('هذه الميزة غير متاحة في هذه النسخة من التطبيق.', 'This feature is not available in this build.')}</Text>}
            <Text style={styles.note}>{tx('الاتصال داخل شبكتك المنزلية فقط، والصفحة تتوقف تلقائيًا بعد 10 دقائق أو عند الإغلاق.', 'Works on your home network only; the page stops after 10 minutes or when you close this screen.')}</Text>
            <Pressable hasTVPreferredFocus onPress={onClose} style={styles.cancel}><Text style={styles.cancelText}>{tx('إلغاء', 'Cancel')}</Text></Pressable>
          </View>
          <View style={styles.right}>
            {url ? (
              <>
                <View style={styles.qrBox}><QrView text={url} size={300} /></View>
                <Text style={styles.url} numberOfLines={2}>{url}</Text>
              </>
            ) : state === 'starting' ? <ActivityIndicator size="large" color="#ff5a66" /> : <Ionicons name="wifi-outline" size={64} color="#6b6b80" />}
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: 'rgba(0,0,0,0.88)', alignItems: 'center', justifyContent: 'center', padding: 24 },
  card: { flexDirection: 'row', gap: 32, maxWidth: 940, width: '100%', backgroundColor: '#14141d', borderRadius: 22, padding: 32 },
  left: { flex: 1 },
  right: { width: 340, alignItems: 'center', justifyContent: 'center' },
  title: { color: '#fff', fontSize: 26, fontWeight: '800', marginBottom: 18 },
  step: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 12 },
  num: { width: 30, height: 30, borderRadius: 15, backgroundColor: '#e11d2e', alignItems: 'center', justifyContent: 'center' },
  numText: { color: '#fff', fontWeight: '800' },
  stepText: { flex: 1, color: '#e6e6f0', fontSize: 17, fontWeight: '600' },
  wait: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 8 },
  waitText: { color: '#9a9ab0', fontSize: 15, fontWeight: '600' },
  warn: { color: '#fbbf24', fontSize: 15, lineHeight: 22, marginTop: 8 },
  note: { color: '#6b6b80', fontSize: 12, marginTop: 14, lineHeight: 18 },
  cancel: { marginTop: 18, alignSelf: 'flex-start', paddingHorizontal: 26, height: 46, borderRadius: 23, borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.35)', alignItems: 'center', justifyContent: 'center' },
  cancelText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  qrBox: { backgroundColor: '#fff', borderRadius: 12, padding: 6 },
  url: { color: '#9a9ab0', fontSize: 13, marginTop: 12, textAlign: 'center' },
});
