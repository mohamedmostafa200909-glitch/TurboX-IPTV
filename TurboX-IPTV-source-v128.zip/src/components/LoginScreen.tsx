import React, { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import TurboXLogo from './TurboXLogo';
import PairModal, { PairData } from './PairModal';
import { parseXtreamUrl, testIptvConnection, TestResult } from '../network/testConnection';
import { TVPressable as Pressable, TVTextInput, TVEngineLayer, TVScope, tvEngine, useTVScroller } from '../tv/focus';
import { UA_PRESETS } from '../network/userAgent';

type Form = { name: string; server: string; username: string; password: string; userAgent?: string };
type Props = {
  form: Form;
  setForm: (f: Form) => void;
  onSubmit: (m3u: boolean) => void;
  onPickM3u: () => void;
  onClose?: () => void;
  isEnglish: boolean;
  /** editing an existing profile (server screen re-opened to fix it) */
  editing?: boolean;
  /** why the last connection failed, shown at the top of the card */
  error?: string | null;
};

const RED = '#e11d2e';

/** TurboX IPTV login: Name / Server / Username / Password. Used after the Mobile-or-TV choice. */
export default function LoginScreen({ form, setForm, onSubmit, onPickM3u, onClose, isEnglish, editing, error }: Props) {
  const { width, height } = useWindowDimensions();
  const wide = width > height;
  const tx = (ar: string, en: string) => (isEnglish ? en : ar);
  const [focused, setFocused] = useState<string | null>(null);
  const [showPass, setShowPass] = useState(false);
  const [serverBad, setServerBad] = useState(false);
  const [testing, setTesting] = useState(false);
  const [mode, setMode] = useState<'xtream' | 'm3u'>(() => (/\.m3u|type=m3u|^file:/i.test(form.server) ? 'm3u' : 'xtream'));
  const [note, setNote] = useState<string | null>(null);
  const [showPair, setShowPair] = useState(false);
  const [showUa, setShowUa] = useState(false);
  const [result, setResult] = useState<TestResult | null>(null);
  const refs = useRef<Record<string, any>>({});
  const scroller = useTVScroller('y');

  const allFields: Array<{ key: keyof Form; icon: any; label: string; placeholder: string; keyboard?: any }> = [
    { key: 'name', icon: 'albums-outline', label: tx('اسم المصدر', 'NAME'), placeholder: tx('مثال: قائمتي', 'e.g. My Playlist') },
    mode === 'xtream'
      ? { key: 'server', icon: 'server-outline', label: tx('السيرفر (Xtream)', 'SERVER (XTREAM)'), placeholder: 'http://example.com:8080', keyboard: 'url' }
      : { key: 'server', icon: 'link-outline', label: tx('رابط قائمة M3U', 'M3U URL'), placeholder: 'http://example.com/list.m3u', keyboard: 'url' },
    { key: 'username', icon: 'person-outline', label: tx('اسم المستخدم', 'USERNAME'), placeholder: tx('اسم المستخدم', 'Username') },
    { key: 'password', icon: 'lock-closed-outline', label: tx('كلمة المرور', 'PASSWORD'), placeholder: tx('كلمة المرور', 'Password') },
  ];
  const fields = mode === 'xtream' ? allFields : allFields.slice(0, 2);

  // A pasted Xtream link (get.php?username=..&password=..) is split into the three fields.
  const convertLink = (value: string): boolean => {
    const parsed = parseXtreamUrl(value);
    if (!parsed) return false;
    setMode('xtream');
    setResult(null);
    setForm({ ...form, ...parsed });
    setNote(tx('تم استخراج بيانات Xtream من الرابط تلقائيًا.', 'Xtream details were extracted from the link.'));
    return true;
  };

  // details typed on the phone (QR pairing)
  const onPairData = (d: PairData) => {
    setShowPair(false);
    const merged = { ...form, name: d.name || form.name, server: d.server || form.server, username: d.username || form.username, password: d.password || form.password };
    const parsed = parseXtreamUrl(merged.server);
    if (parsed) { setMode('xtream'); setForm({ ...merged, ...parsed }); }
    else { if (/\.m3u|type=m3u/i.test(merged.server)) setMode('m3u'); setForm(merged); }
    setResult(null);
    setNote(tx('تم استلام البيانات من الهاتف.', 'Details received from your phone.'));
  };

  useEffect(() => { tvEngine.invalidate(); }, [mode, note, result, serverBad, showPass, wide]);
  const pending = useRef(false);
  useEffect(() => {
    if (pending.current) { pending.current = false; onSubmit(false); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form.username, form.password, form.server]);
  const submit = () => {
    const parsed = parseXtreamUrl(form.server);
    if (parsed) { // pasted link not converted yet: convert, then submit once the form state is updated
      pending.current = true;
      convertLink(form.server);
      return;
    }
    setServerBad(!form.server.trim());
    onSubmit(mode === 'm3u');
  };

  const runTest = async () => {
    if (testing) return;
    setTesting(true);
    setResult(null);
    try {
      setResult(await testIptvConnection({ server: form.server, username: form.username, password: form.password }, isEnglish));
    } catch {
      setResult({ ok: false, title: tx('تعذر إجراء الاختبار', 'Could not run the test'), lines: [] });
    } finally {
      setTesting(false);
    }
  };

  const logoW = wide ? Math.min(width * 0.38, height * 1.0, 440) : Math.min(width * 0.78, 320);

  const card = (
    <View style={styles.card}>
      <Text style={styles.title}>{editing ? tx('تعديل السيرفر', 'Edit server') : tx('إضافة حساب IPTV', 'Add your IPTV account')}</Text>
      <Text style={styles.sub}>{editing ? tx('عدّل بيانات السيرفر ثم اضغط حفظ وإعادة الاتصال', 'Fix the server details, then save and reconnect') : tx('أدخل بيانات الدخول من مزوّد الخدمة', 'Enter the login details from your provider')}</Text>
      {!!error && (
        <View style={[styles.result, styles.resultBad, { marginTop: 8 }]}>
          <View style={styles.resultHead}>
            <Ionicons name="alert-circle" size={20} color="#f87171" />
            <Text style={[styles.resultTitle, { color: '#f87171' }]}>{tx('تعذر تحميل المصدر', 'Could not load the source')}</Text>
          </View>
          <Text style={styles.resultLine}>{error}</Text>
        </View>
      )}

      <View style={styles.seg}>
        {(['xtream', 'm3u'] as const).map(m => (
          <Pressable key={m} onPress={() => { setMode(m); setResult(null); setNote(null); }} focusable isTVSelectable
            style={({ focused: f }: any) => [styles.segBtn, mode === m && styles.segOn, f && styles.btnFocus]}>
            <Ionicons name={m === 'xtream' ? 'key-outline' : 'list-outline'} size={16} color={mode === m ? '#fff' : '#9a9ab0'} />
            <Text style={[styles.segText, mode === m && { color: '#fff' }]}>{m === 'xtream' ? 'Xtream Codes' : tx('رابط / ملف M3U', 'M3U link / file')}</Text>
          </Pressable>
        ))}
      </View>
      {note && <Text style={styles.noteText}>{note}</Text>}

      {fields.map((f, i) => {
        const isPass = f.key === 'password';
        const isFocused = focused === f.key;
        const bad = f.key === 'server' && serverBad && !form.server.trim();
        return (
          <View key={f.key}>
            <Text style={styles.label}>{f.label}</Text>
            <View style={styles.fieldWrap}>
              <Ionicons name={f.icon} size={20} color={isFocused ? RED : '#9a9ab0'} style={styles.icon} />
              <TVTextInput
                ref={(r: any) => { refs.current[f.key] = r; }}
                hasTVPreferredFocus={i === 0}
                wrapStyle={styles.inputWrap}
                value={form[f.key]}
                onChangeText={v => { if (f.key === 'server') { setServerBad(false); if (v.length - form.server.length > 12 && convertLink(v)) return; } setNote(null); setResult(null); setForm({ ...form, [f.key]: v }); }}
                placeholder={f.placeholder}
                placeholderTextColor="#6b6b82"
                autoCapitalize="none"
                autoCorrect={false}
                keyboardType={f.keyboard}
                secureTextEntry={isPass && !showPass}
                returnKeyType={i === fields.length - 1 ? 'done' : 'next'}
                onSubmitEditing={() => (i === fields.length - 1 ? submit() : refs.current[fields[i + 1].key]?.focus())}
                onFocus={() => setFocused(f.key)}
                onBlur={() => { setFocused(null); if (f.key === 'server') convertLink(form.server); }}
                style={[styles.input, isFocused && styles.inputFocus, bad && styles.inputBad]}
              />
              {isPass && (
                <Pressable
                  onPress={() => setShowPass(v => !v)}
                  focusable
                  isTVSelectable
                  hitSlop={8}
                  style={styles.eye}
                  accessibilityLabel={tx('إظهار كلمة المرور', 'Show password')}
                >
                  <Ionicons name={showPass ? 'eye-off-outline' : 'eye-outline'} size={20} color="#9a9ab0" />
                </Pressable>
              )}
            </View>
            {bad && <Text style={styles.err}>{tx('أدخل رابط السيرفر', 'Enter the server URL')}</Text>}
          </View>
        );
      })}

      {mode === 'm3u' && <Pressable
        onPress={onPickM3u}
        focusable
        isTVSelectable
        style={({ focused: f }: any) => [styles.fileBtn, f && styles.btnFocus]}
      >
        <Ionicons name="document-attach-outline" size={18} color="#ff5a66" />
        <Text style={styles.fileText}>{tx('اختيار ملف M3U من الجهاز', 'Choose an M3U file from the device')}</Text>
      </Pressable>}
      <Text style={styles.hint}>{mode === 'm3u'
        ? tx('لروابط M3U يكفي إدخال الرابط فقط بدون اسم مستخدم أو كلمة مرور.', 'For M3U links, only the URL is needed.')
        : tx('يمكنك لصق رابط get.php كاملًا في خانة السيرفر وسيتم ملء الحقول تلقائيًا.', 'You can paste a full get.php link into Server and the fields fill in automatically.')}</Text>

      {/* Some panels block third-party players unless the request looks like a known client. Off by default: most
          subscriptions never need this. */}
      <Pressable onPress={() => setShowUa(v => !v)} focusable isTVSelectable style={styles.uaToggle}>
        <Ionicons name="options-outline" size={16} color="#9a9ab0" />
        <Text style={styles.uaToggleText}>{tx('إعداد متقدم: User-Agent', 'Advanced: User-Agent')}</Text>
        <Ionicons name={showUa ? 'chevron-up' : 'chevron-down'} size={16} color="#9a9ab0" />
      </Pressable>
      {showUa && (
        <View style={styles.uaBox}>
          <Text style={styles.uaHint}>{tx('غيّره لو السيرفر يرفض الاتصال (403) من المشغّلات الخارجية.', 'Change this if the server blocks third-party players (403).')}</Text>
          <View style={styles.uaRow}>
            {UA_PRESETS.map(preset => {
              const active = (form.userAgent || '').trim() === preset.ua || (!form.userAgent?.trim() && preset.id === 'vlc');
              return (
                <Pressable key={preset.id} onPress={() => setForm({ ...form, userAgent: preset.id === 'vlc' ? '' : preset.ua })} focusable isTVSelectable style={[styles.uaPill, active && styles.uaPillOn]}>
                  <Text style={[styles.uaPillText, active && styles.uaPillTextOn]}>{preset.label[isEnglish ? 1 : 0]}</Text>
                </Pressable>
              );
            })}
          </View>
          <TVTextInput
            wrapStyle={styles.inputWrap}
            value={form.userAgent || ''}
            onChangeText={v => setForm({ ...form, userAgent: v })}
            placeholder={tx('أو نص User-Agent مخصص', 'Or a custom User-Agent string')}
            placeholderTextColor="#6b6b82"
            autoCapitalize="none"
            autoCorrect={false}
            style={styles.input}
          />
        </View>
      )}

      <Pressable
        onPress={() => setShowPair(true)}
        focusable
        isTVSelectable
        style={({ focused: f }: any) => [styles.fileBtn, f && styles.btnFocus]}
      >
        <Ionicons name="qr-code-outline" size={18} color="#ff5a66" />
        <Text style={styles.fileText}>{tx('إدخال البيانات من الهاتف (QR)', 'ENTER DETAILS FROM YOUR PHONE (QR)')}</Text>
      </Pressable>
      <PairModal visible={showPair} isEnglish={isEnglish} onClose={() => setShowPair(false)} onData={onPairData} />

      <Pressable
        onPress={runTest}
        focusable
        isTVSelectable
        style={({ focused: f }: any) => [styles.testBtn, f && styles.btnFocus]}
      >
        {testing ? <ActivityIndicator size="small" color="#ff5a66" /> : <Ionicons name="pulse-outline" size={18} color="#ff5a66" />}
        <Text style={styles.fileText}>{testing ? tx('جارٍ الاختبار…', 'Testing…') : tx('اختبار الاتصال', 'TEST CONNECTION')}</Text>
      </Pressable>
      {result && (
        <View style={[styles.result, result.ok ? styles.resultOk : styles.resultBad]}>
          <View style={styles.resultHead}>
            <Ionicons name={result.ok ? 'checkmark-circle' : 'alert-circle'} size={20} color={result.ok ? '#34d399' : '#f87171'} />
            <Text style={[styles.resultTitle, { color: result.ok ? '#34d399' : '#f87171' }]}>{result.title}</Text>
          </View>
          {result.lines.map((l, i) => <Text key={i} style={styles.resultLine}>{l}</Text>)}
        </View>
      )}

      <Pressable
        onPress={submit}
        focusable
        isTVSelectable
        style={({ focused: f }: any) => [styles.go, f && styles.goFocus]}
      >
        <Ionicons name="play" size={18} color="#fff" />
        <Text style={styles.goText}>{editing ? tx('حفظ وإعادة الاتصال', 'SAVE & RECONNECT') : tx('تسجيل الدخول', 'SIGN IN')}</Text>
      </Pressable>
    </View>
  );

  return (
    <TVEngineLayer>
    <TVScope scope={scroller.scope}>
    <KeyboardAvoidingView style={styles.root} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={styles.glowA} pointerEvents="none" />
      <View style={styles.glowB} pointerEvents="none" />
      {onClose && (
        <Pressable onPress={onClose} focusable isTVSelectable style={styles.close} accessibilityLabel={tx('إغلاق', 'Close')}>
          <Ionicons name="close" size={22} color="#cfcfdc" />
        </Pressable>
      )}
      {wide ? (
        <View style={styles.row}>
          <View style={styles.left}><TurboXLogo width={logoW} /></View>
          <ScrollView ref={scroller.ref} onScroll={scroller.onScroll} scrollEventThrottle={16} style={styles.right} contentContainerStyle={styles.rightContent} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
            {card}
          </ScrollView>
        </View>
      ) : (
        <ScrollView ref={scroller.ref} onScroll={scroller.onScroll} scrollEventThrottle={16} contentContainerStyle={styles.col} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <TurboXLogo width={logoW} />
          {card}
        </ScrollView>
      )}
    </KeyboardAvoidingView>
    </TVScope>
    </TVEngineLayer>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0b0b12' },
  glowA: { position: 'absolute', top: -140, right: -120, width: 420, height: 420, borderRadius: 210, backgroundColor: 'rgba(225,29,46,0.18)' },
  glowB: { position: 'absolute', bottom: -160, left: -140, width: 420, height: 420, borderRadius: 210, backgroundColor: 'rgba(225,29,46,0.12)' },
  row: { flex: 1, flexDirection: 'row', alignItems: 'center' },
  left: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 16 },
  right: { flex: 1.05 },
  rightContent: { flexGrow: 1, justifyContent: 'center', paddingVertical: 18, paddingHorizontal: 22 },
  col: { alignItems: 'center', paddingTop: 36, paddingBottom: 28, paddingHorizontal: 18 },
  card: { width: '100%', maxWidth: 460, alignSelf: 'center', backgroundColor: '#14141d', borderWidth: 1, borderColor: '#2c2c3c', borderRadius: 22, padding: 20 },
  title: { color: '#f4f4f8', fontSize: 20, fontWeight: '800', textAlign: 'center' },
  sub: { color: '#9a9ab0', fontSize: 13, textAlign: 'center', marginTop: 4, marginBottom: 6 },
  label: { color: '#9a9ab0', fontSize: 12, fontWeight: '700', letterSpacing: 1, marginTop: 12, marginBottom: 6 },
  fieldWrap: { justifyContent: 'center' },
  inputWrap: { borderRadius: 14, borderWidth: 0 },
  icon: { position: 'absolute', start: 14, zIndex: 1 },
  input: { height: 50, borderRadius: 14, borderWidth: 1.5, borderColor: '#2c2c3c', backgroundColor: '#1c1c28', color: '#f4f4f8', fontSize: 15, paddingStart: 46, paddingEnd: 46 },
  inputFocus: { borderColor: RED },
  inputBad: { borderColor: '#f87171' },
  eye: { position: 'absolute', end: 4, width: 40, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 10 },
  err: { color: '#f87171', fontSize: 12, marginTop: 6 },
  fileBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 16, height: 44, borderRadius: 12, borderWidth: 1, borderColor: '#2c2c3c', backgroundColor: '#1c1c28' },
  fileText: { color: '#ff5a66', fontSize: 13, fontWeight: '700' },
  seg: { flexDirection: 'row', gap: 8, marginTop: 10, marginBottom: 2 },
  segBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, height: 40, borderRadius: 12, backgroundColor: '#1c1c28', borderWidth: 1, borderColor: '#2c2c3c' },
  segOn: { backgroundColor: '#e11d2e', borderColor: '#e11d2e' },
  segText: { color: '#9a9ab0', fontSize: 12, fontWeight: '800' },
  noteText: { color: '#34d399', fontSize: 12, textAlign: 'center', marginTop: 8 },
  testBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 12, height: 46, borderRadius: 12, borderWidth: 1.5, borderColor: '#e11d2e', backgroundColor: 'rgba(225,29,46,0.10)' },
  result: { marginTop: 12, borderRadius: 12, padding: 12, borderWidth: 1 },
  resultOk: { borderColor: 'rgba(52,211,153,0.5)', backgroundColor: 'rgba(52,211,153,0.08)' },
  resultBad: { borderColor: 'rgba(248,113,113,0.5)', backgroundColor: 'rgba(248,113,113,0.08)' },
  resultHead: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  resultTitle: { fontSize: 14, fontWeight: '800', flexShrink: 1 },
  resultLine: { color: '#cfd0da', fontSize: 12, marginTop: 6 },
  btnFocus: { borderColor: '#ffffff', borderWidth: 2 },
  hint: { color: '#6b6b82', fontSize: 11, textAlign: 'center', marginTop: 8 },
  go: { marginTop: 16, height: 54, borderRadius: 14, backgroundColor: RED, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, shadowColor: RED, shadowOpacity: 0.45, shadowRadius: 14, shadowOffset: { width: 0, height: 8 }, elevation: 8 },
  goFocus: { borderWidth: 2, borderColor: '#ffffff', transform: [{ scale: 1.02 }] },
  goText: { color: '#ffffff', fontSize: 16, fontWeight: '800', letterSpacing: 1 },
  close: { position: 'absolute', top: 14, end: 14, zIndex: 5, width: 42, height: 42, borderRadius: 21, backgroundColor: 'rgba(20,20,29,0.9)', borderWidth: 1, borderColor: '#2c2c3c', alignItems: 'center', justifyContent: 'center' },

  uaToggle: { flexDirection: 'row', alignItems: 'center', gap: 6, alignSelf: 'flex-start', marginTop: 6, paddingVertical: 6 },
  uaToggleText: { color: '#9a9ab0', fontSize: 13, fontWeight: '700' },
  uaBox: { marginTop: 4, marginBottom: 10, gap: 10 },
  uaHint: { color: '#8a8aa0', fontSize: 12, lineHeight: 18 },
  uaRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  uaPill: { paddingHorizontal: 14, height: 36, borderRadius: 18, borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center' },
  uaPillOn: { backgroundColor: RED, borderColor: RED },
  uaPillText: { color: '#c7c7cf', fontSize: 13, fontWeight: '700' },
  uaPillTextOn: { color: '#fff' },
});
