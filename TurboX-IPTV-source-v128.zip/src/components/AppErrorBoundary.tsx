import React from 'react';
import { SafeAreaView, Text } from 'react-native';
import { TVPressable as Pressable } from '../tv/focus';

export default class AppErrorBoundary extends React.Component<{
  children: React.ReactNode;
}, {
  error: Error | null;
}> {
  state = {
    error: null
  };
  static getDerivedStateFromError(error: Error) {
    return {
      error
    };
  }
  render() {
    if (this.state.error) return <SafeAreaView style={{
      flex: 1,
      backgroundColor: '#0b0b12',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 24
    }}><Text style={{
        color: '#fff',
        fontSize: 20,
        fontWeight: '800',
        textAlign: 'center'
      }}>حدث خطأ في عرض المحتوى</Text><Text style={{
        color: '#a8a9b8',
        fontSize: 12,
        marginTop: 10,
        textAlign: 'center'
      }}>{this.state.error.message}</Text><Pressable onPress={() => this.setState({
        error: null
      })} style={{
        marginTop: 20,
        padding: 14,
        borderRadius: 8,
        backgroundColor: '#ff5a66'
      }}><Text style={{
          color: '#ffffff',
          fontWeight: '800'
        }}>إعادة المحاولة</Text></Pressable></SafeAreaView>;
    return this.props.children;
  }
}