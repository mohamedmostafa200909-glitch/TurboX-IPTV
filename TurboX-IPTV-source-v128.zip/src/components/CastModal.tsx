import React, { useEffect, useState } from 'react';
import { ActivityIndicator, NativeModules, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Modal } from './TVModal';
import { TVPressable as Pressable } from '../tv/focus';

type Renderer = { name: string; location: string };
type Props = {
  visible: boolean;
  isEnglish: boolean;
  accent: string;
  streamUrl: string;
  title: string;
  onClose: () => void;
};

/**
 * DLNA "Play on another device" — experimental. Finds UPnP media renderers (smart TVs, some soundbars/speakers) on
 * the local network and casts the current stream to one. Unlike Google Cast this needs no Play Services, so it
 * works on Fire TV and budget Android TV boxes too, but most DLNA renderers can't be sent custom request headers,
 * so a provider that needs a special User-Agent may fail here even though it plays fine in this app.
 */
export default function CastModal({ visible, isEnglish, accent, streamUrl, title, onClose }: Props) {
  const tx = (ar: string, en: string) => (isEnglish ? en : ar);
  const [list, setList] = useState<Renderer[] | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [failed, setFailed] = useState<string | null>(null);
  const [unsupported, setUnsupported] = useState(false);

  useEffect(() => {
    if (!visible) return;
    setList(null);
    setFailed(null);
    const mod = NativeModules.TurboPlayerModule;
    if (!mod?.discoverDlnaRenderers) { setUnsupported(true); return; }
    setUnsupported(false);
    Promise.resolve(mod.discoverDlnaRenderers()).then((r: Renderer[]) => setList(Array.isArray(r) ? r : [])).catch(() => setList([]));
  }, [visible]);

  async function cast(r: Renderer) {
    setBusy(r.location);
    setFailed(null);
    try {
      const ok = await NativeModules.TurboPlayerModule?.castToDlna?.(r.location, streamUrl, title);
      if (ok) onClose(); else setFailed(r.location);
    } catch { setFailed(r.location); }
    finally { setBusy(null); }
  }

  return (
    <Modal visible={visible} transparent animationType="fade" statusBarTranslucent onRequestClose={onClose}>
      <View style={styles.screen}>
        <View style={styles.card}>
          <Text style={styles.title}>{tx('تشغيل على جهاز آخر (DLNA)', 'Play on another device (DLNA)')}</Text>
          <Text style={styles.hint}>{tx('تجريبية — تعمل مع بعض الشاشات الذكية والسماعات على شبكتك المحلية.', 'Experimental — works with some smart TVs and speakers on your local network.')}</Text>
          <View style={{ marginTop: 14, minHeight: 80 }}>
            {unsupported ? (
              <Text style={styles.warn}>{tx('غير متاحة في هذه النسخة.', 'Not available in this build.')}</Text>
            ) : list === null ? (
              <View style={styles.center}><ActivityIndicator color={accent} /><Text style={styles.searching}>{tx('جارٍ البحث عن أجهزة…', 'Searching for devices…')}</Text></View>
            ) : list.length === 0 ? (
              <Text style={styles.warn}>{tx('لم يتم العثور على أجهزة تدعم DLNA على الشبكة.', 'No DLNA-capable devices found on the network.')}</Text>
            ) : (
              list.map(r => (
                <Pressable key={r.location} disabled={!!busy} onPress={() => cast(r)} style={styles.row}>
                  <Ionicons name="tv-outline" size={20} color="#fff" />
                  <Text style={styles.rowText} numberOfLines={1}>{r.name}</Text>
                  {busy === r.location ? <ActivityIndicator color="#fff" size="small" /> : <Ionicons name="chevron-forward" size={18} color="#8a8a96" />}
                </Pressable>
              ))
            )}
            {!!failed && <Text style={styles.warn}>{tx('تعذّر التشغيل على هذا الجهاز.', 'Could not start playback on that device.')}</Text>}
          </View>
          <Pressable hasTVPreferredFocus onPress={onClose} style={styles.cancel}><Text style={styles.cancelText}>{tx('إغلاق', 'Close')}</Text></Pressable>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: 'rgba(0,0,0,0.88)', alignItems: 'center', justifyContent: 'center', padding: 24 },
  card: { width: 520, maxWidth: '92%', backgroundColor: '#14141d', borderRadius: 22, padding: 26 },
  title: { color: '#fff', fontSize: 20, fontWeight: '800' },
  hint: { color: '#9a9ab0', fontSize: 13, lineHeight: 19, marginTop: 6 },
  center: { alignItems: 'center', gap: 10, paddingVertical: 10 },
  searching: { color: '#9a9ab0', fontSize: 13 },
  warn: { color: '#fbbf24', fontSize: 13, lineHeight: 19 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12, marginBottom: 8 },
  rowText: { flex: 1, color: '#fff', fontSize: 15, fontWeight: '700' },
  cancel: { alignSelf: 'center', marginTop: 16, paddingHorizontal: 22, height: 40, borderRadius: 20, borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.3)', alignItems: 'center', justifyContent: 'center' },
  cancelText: { color: '#fff', fontSize: 14, fontWeight: '700' },
});
