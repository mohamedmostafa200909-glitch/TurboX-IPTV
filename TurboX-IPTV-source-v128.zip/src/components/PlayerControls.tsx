import React from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { Ionicons, MaterialIcons } from '@expo/vector-icons';

export type PlayerButtonId = 'back10' | 'play' | 'fwd10' | 'next' | 'tracks' | 'aspect' | 'cast' | 'sleep';
export type GuideProg = { t: string; s: number; e: number };

type Props = {
  visible: boolean;
  title: string;
  live: boolean;
  playing: boolean;
  buffering: boolean;
  position: number; // ms
  duration: number; // ms
  isEnglish: boolean;
  seekFlash: string | null; // e.g. "+10s"
  channelInput: string;
  sleepLeft?: string | null;
  /** YouTube-style row under the scrubber (VOD only). */
  buttons?: PlayerButtonId[];
  /** 0 = scrubber, 1..n = buttons[focus - 1] */
  focus?: number;
  /** pending scrub position (ms) while the viewer is dragging, before it is committed */
  scrubTo?: number | null;
  /** live channel: current and next programme (unix seconds) */
  guide?: { now?: GuideProg; next?: GuideProg } | null;
};

const RED = '#ff2e3d';

const hhmm = (sec: number) => new Date(sec * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

const fmt = (ms: number) => {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const mm = h ? String(m).padStart(2, '0') : String(m);
  return `${h ? h + ':' : ''}${mm}:${String(s).padStart(2, '0')}`;
};

/** Dark fade built from stacked bands (no gradient library in this project). Static, so it costs nothing per frame. */
const Fade = React.memo(function Fade({ edge, height }: { edge: 'top' | 'bottom'; height: number }) {
  const bands = 12;
  const items = [];
  for (let i = 0; i < bands; i++) {
    // alpha grows toward the screen edge with a smooth ease curve
    const t = edge === 'top' ? 1 - i / (bands - 1) : i / (bands - 1);
    items.push(<View key={i} style={{ height: height / bands, backgroundColor: `rgba(0,0,0,${(0.86 * t * t * (3 - 2 * t)).toFixed(3)})` }} />);
  }
  return <View pointerEvents="none" style={[styles.fade, edge === 'top' ? { top: 0 } : { bottom: 0 }, { height }]}>{items}</View>;
});

function IconBtn({ id, playing, focused }: { id: PlayerButtonId; playing: boolean; focused: boolean }) {
  const color = focused ? '#0b0b12' : '#fff';
  const big = id === 'play';
  const size = big ? 40 : 30;
  let icon: React.ReactNode;
  switch (id) {
    case 'back10': icon = <MaterialIcons name="replay-10" size={size} color={color} />; break;
    case 'fwd10': icon = <MaterialIcons name="forward-10" size={size} color={color} />; break;
    case 'next': icon = <MaterialIcons name="skip-next" size={size + 2} color={color} />; break;
    case 'cast': icon = <MaterialIcons name="cast" size={size - 4} color={color} />; break;
    case 'play': icon = <MaterialIcons name={playing ? 'pause' : 'play-arrow'} size={size} color={color} />; break;
    case 'tracks': icon = <MaterialIcons name="closed-caption" size={size} color={color} />; break;
    case 'aspect': icon = <MaterialIcons name="aspect-ratio" size={size - 4} color={color} />; break;
    default: icon = <MaterialIcons name="nights-stay" size={size - 4} color={color} />; break;
  }
  return (
    <View style={[styles.btn, big && styles.btnBig, focused && styles.btnFocus]}>{icon}</View>
  );
}

/** YouTube-style on-screen controls for TV: top title fade, centre feedback, scrubber with preview, button row. */
export default function PlayerControls({
  visible, title, live, playing, buffering, position, duration, isEnglish, seekFlash, channelInput, sleepLeft,
  buttons = [], focus = 0, scrubTo = null, guide = null,
}: Props) {
  const tx = (ar: string, en: string) => (isEnglish ? en : ar);
  const shown = scrubTo != null ? scrubTo : position;
  const pct = duration > 0 ? Math.min(100, Math.max(0, (shown / duration) * 100)) : 0;
  const curPct = duration > 0 ? Math.min(100, Math.max(0, (position / duration) * 100)) : 0;
  const barFocused = focus === 0;
  const scrubbing = scrubTo != null;
  const vod = !live && duration > 0;
  const nowSec = Date.now() / 1000;
  const gNow = live && guide?.now && guide.now.e > guide.now.s ? guide.now : null;
  const gPct = gNow ? Math.max(0, Math.min(100, ((nowSec - gNow.s) / (gNow.e - gNow.s)) * 100)) : 0;
  const split = buttons.indexOf('tracks') >= 0 ? buttons.indexOf('tracks') : buttons.indexOf('aspect');
  const left = split > 0 ? buttons.slice(0, split) : buttons;
  const right = split > 0 ? buttons.slice(split) : [];

  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      {!!sleepLeft && (
        <View style={styles.sleepChip}>
          <MaterialIcons name="nights-stay" size={14} color={RED} />
          <Text style={styles.sleepText}>{sleepLeft}</Text>
        </View>
      )}
      {!!channelInput && (
        <View style={styles.numBox}>
          <Text style={styles.numLabel}>{tx('القناة', 'CH')}</Text>
          <Text style={styles.numText}>{channelInput}</Text>
        </View>
      )}

      {/* centre feedback: seek flash / buffering spinner (play/pause lives in the button row) */}
      {(seekFlash || buffering) && (
        <View style={styles.center}>
          <View style={styles.centerBadge}>
            {seekFlash ? <Text style={styles.flash}>{seekFlash}</Text> : <ActivityIndicator size="large" color="#fff" />}
          </View>
        </View>
      )}

      {visible && (
        <>
          <Fade edge="top" height={150} />
          <View style={styles.top}>
            <Text style={styles.title} numberOfLines={1}>{title}</Text>
            {live && (
              <View style={styles.liveBadge}>
                <View style={styles.liveDot} />
                <Text style={styles.liveText}>LIVE</Text>
              </View>
            )}
          </View>

          <Fade edge="bottom" height={vod ? 250 : gNow ? 230 : 150} />
          <View style={styles.bottom}>
            {vod && (
              <>
                <View style={styles.scrubWrap}>
                  {scrubbing && (
                    <View style={[styles.bubble, { start: `${pct}%` }]}>
                      <Text style={styles.bubbleText}>{fmt(scrubTo as number)}</Text>
                    </View>
                  )}
                  <View style={[styles.track, barFocused && styles.trackFocus]}>
                    <View style={[styles.preview, { width: `${Math.max(pct, curPct)}%` }]} />
                    <View style={[styles.fill, { width: `${curPct}%` }]} />
                  </View>
                  {(barFocused || scrubbing) && <View style={[styles.knob, scrubbing && styles.knobBig, { start: `${pct}%` }]} />}
                </View>

                <View style={styles.row}>
                  <View style={styles.cluster}>
                    {left.map(id => <IconBtn key={id} id={id} playing={playing} focused={focus === buttons.indexOf(id) + 1} />)}
                    <Text style={styles.time}>{fmt(shown)} <Text style={styles.timeDim}>/ {fmt(duration)}</Text></Text>
                  </View>
                  <View style={styles.cluster}>
                    {right.map(id => <IconBtn key={id} id={id} playing={playing} focused={focus === buttons.indexOf(id) + 1} />)}
                  </View>
                </View>
              </>
            )}
            {!vod && !live && (
              <View style={styles.row}><Text style={styles.time}>{buffering ? tx('جارٍ التحميل…', 'Loading…') : ''}</Text></View>
            )}
            {live && (
              <View>
                {gNow && (
                  <View style={styles.epg}>
                    <View style={styles.epgRow}>
                      <Text style={styles.epgLabel}>{tx('الآن', 'NOW')}</Text>
                      <Text style={styles.epgTitle} numberOfLines={1}>{gNow.t}</Text>
                      <Text style={styles.epgTime}>{hhmm(gNow.s)} – {hhmm(gNow.e)}</Text>
                    </View>
                    <View style={styles.epgTrack}><View style={[styles.fill, { width: `${gPct}%` }]} /></View>
                    {!!guide?.next && (
                      <View style={styles.epgRow}>
                        <Text style={styles.epgLabelDim}>{tx('التالي', 'NEXT')}</Text>
                        <Text style={styles.epgNext} numberOfLines={1}>{guide.next.t}</Text>
                        <Text style={styles.epgTime}>{hhmm(guide.next.s)}</Text>
                      </View>
                    )}
                  </View>
                )}
                <View style={styles.liveRow}>
                  <Ionicons name="radio" size={18} color={RED} />
                  <Text style={styles.liveHint}>{tx('◀ ▶ قائمة القنوات   ·   ▲ ▼ تغيير القناة   ·   0-9 رقم القناة   ·   OK إيقاف', '◀ ▶ Channel list   ·   ▲ ▼ Change channel   ·   0-9 Number   ·   OK Pause')}</Text>
                </View>
              </View>
            )}
          </View>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  fade: { position: 'absolute', start: 0, end: 0 },
  center: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' },
  centerBadge: { minWidth: 88, height: 88, paddingHorizontal: 20, borderRadius: 44, backgroundColor: 'rgba(0,0,0,0.6)', alignItems: 'center', justifyContent: 'center' },
  flash: { color: '#fff', fontSize: 26, fontWeight: '800' },
  sleepChip: { position: 'absolute', top: 24, start: 48, flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: 16, paddingHorizontal: 12, paddingVertical: 6 },
  sleepText: { color: '#fff', fontSize: 13, fontWeight: '800' },
  numBox: { position: 'absolute', top: 24, end: 48, flexDirection: 'row', alignItems: 'baseline', gap: 8, backgroundColor: 'rgba(0,0,0,0.7)', borderRadius: 14, paddingHorizontal: 16, paddingVertical: 8 },
  numLabel: { color: RED, fontSize: 13, fontWeight: '800' },
  numText: { color: '#fff', fontSize: 38, fontWeight: '900', letterSpacing: 3 },

  top: { position: 'absolute', top: 0, start: 0, end: 0, paddingHorizontal: 48, paddingTop: 34, flexDirection: 'row', alignItems: 'center', gap: 14 },
  title: { flexShrink: 1, color: '#fff', fontSize: 26, fontWeight: '700' },
  liveBadge: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: RED, borderRadius: 5, paddingHorizontal: 9, paddingVertical: 3 },
  liveDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: '#fff' },
  liveText: { color: '#fff', fontSize: 12, fontWeight: '900', letterSpacing: 1 },

  bottom: { position: 'absolute', bottom: 0, start: 0, end: 0, paddingHorizontal: 48, paddingBottom: 26 },
  scrubWrap: { height: 26, justifyContent: 'center' },
  track: { height: 4, borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.3)', overflow: 'hidden' },
  trackFocus: { height: 8, borderRadius: 4 },
  preview: { position: 'absolute', top: 0, bottom: 0, start: 0, backgroundColor: 'rgba(255,255,255,0.55)' },
  fill: { position: 'absolute', top: 0, bottom: 0, start: 0, backgroundColor: RED },
  knob: { position: 'absolute', width: 18, height: 18, borderRadius: 9, marginStart: -9, backgroundColor: RED },
  knobBig: { width: 24, height: 24, borderRadius: 12, marginStart: -12, borderWidth: 2, borderColor: '#fff' },
  bubble: { position: 'absolute', bottom: 30, marginStart: -34, minWidth: 68, alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.78)', borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 },
  bubbleText: { color: '#fff', fontSize: 14, fontWeight: '800' },

  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 8 },
  cluster: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  btn: { width: 52, height: 52, borderRadius: 26, alignItems: 'center', justifyContent: 'center' },
  btnBig: { width: 62, height: 62, borderRadius: 31 },
  btnFocus: { backgroundColor: '#fff', transform: [{ scale: 1.12 }] },
  time: { color: '#fff', fontSize: 17, fontWeight: '700', marginStart: 8 },
  timeDim: { color: 'rgba(255,255,255,0.65)', fontWeight: '600' },
  epg: { marginBottom: 14 },
  epgRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginVertical: 5 },
  epgLabel: { minWidth: 62, color: '#fff', backgroundColor: RED, borderRadius: 5, textAlign: 'center', fontSize: 12, fontWeight: '900', letterSpacing: 1, paddingVertical: 3 },
  epgLabelDim: { minWidth: 62, color: '#fff', backgroundColor: 'rgba(255,255,255,0.22)', borderRadius: 5, textAlign: 'center', fontSize: 12, fontWeight: '900', letterSpacing: 1, paddingVertical: 3 },
  epgTitle: { flex: 1, color: '#fff', fontSize: 20, fontWeight: '700' },
  epgNext: { flex: 1, color: 'rgba(255,255,255,0.75)', fontSize: 16, fontWeight: '600' },
  epgTime: { color: 'rgba(255,255,255,0.7)', fontSize: 14, fontWeight: '600' },
  epgTrack: { height: 4, borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.3)', overflow: 'hidden', marginVertical: 4 },
  liveRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  liveHint: { color: 'rgba(255,255,255,0.75)', fontSize: 14, fontWeight: '600' },
});
