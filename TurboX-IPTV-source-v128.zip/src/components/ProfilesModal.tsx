import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { TVPressable as Pressable, TVScrollView } from '../tv/focus';
import type { Provider } from '../types';

type Props = {
  providers: Provider[];
  activeId?: string;
  catalogReady: boolean;
  accent: string;
  isEnglish: boolean;
  maxHeight: number;
  ago: (id: string) => string;
  onSelect: (p: Provider) => void;
  onRefresh: (p: Provider) => void;
  onEdit: (p: Provider) => void;
  onDelete: (p: Provider) => void;
  onToggleKid: (p: Provider) => void;
  onAdd: () => void;
  onClose: () => void;
};

const hostOf = (p: Provider) => (p.server.startsWith('file:') ? 'M3U file' : p.server.match(/^(?:https?:\/\/)?([^/:?#]+)/i)?.[1] || '');

/** Settings → Profiles: every profile is its own server subscription. */
export default function ProfilesModal(p: Props) {
  const tx = (ar: string, en: string) => (p.isEnglish ? en : ar);
  return (
    <View style={styles.bg}>
      <View style={styles.card}>
        <Pressable onPress={p.onClose} style={styles.close}><Ionicons name="close" size={20} color="#aaa" /></Pressable>
        <Text style={styles.title}>Profiles</Text>
        <Text style={styles.sub}>{tx('كل Profile له اشتراك وسيرفر منفصل. اختر واحدًا للتبديل.', 'Each profile has its own server subscription. Pick one to switch.')}</Text>
        <TVScrollView style={{ maxHeight: p.maxHeight }}>
          {p.providers.map(x => {
            const active = x.id === p.activeId;
            return (
              <View key={x.id} style={styles.row}>
                <Pressable style={styles.main} onPress={() => p.onSelect(x)}>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.name} numberOfLines={1}>{x.name}{x.kid ? '  🛡' : ''}</Text>
                    <Text style={styles.meta} numberOfLines={1}>{hostOf(x)} · {p.ago(x.id)}</Text>
                  </View>
                  <Ionicons name={active ? 'checkmark-circle' : 'person-circle-outline'} size={22} color={p.accent} />
                </Pressable>
                <Pressable onPress={() => p.onToggleKid(x)} hitSlop={8} accessibilityLabel={tx('وضع الأطفال', 'Kids mode')}>
                  <Ionicons name={x.kid ? 'shield-checkmark' : 'shield-outline'} size={22} color={x.kid ? '#34d399' : '#cfcfdc'} />
                </Pressable>
                <Pressable onPress={() => p.onRefresh(x)} hitSlop={8} accessibilityLabel={tx('تحديث الآن', 'Update now')}>
                  <Ionicons name="refresh-outline" size={22} color="#cfcfdc" />
                </Pressable>
                <Pressable onPress={() => p.onEdit(x)} hitSlop={8} accessibilityLabel={tx('تعديل', 'Edit')}>
                  <Ionicons name="create-outline" size={22} color="#cfcfdc" />
                </Pressable>
                <Pressable onPress={() => p.onDelete(x)} hitSlop={8} accessibilityLabel={tx('حذف', 'Delete')}>
                  <Ionicons name="trash-outline" size={21} color="#f87171" />
                </Pressable>
              </View>
            );
          })}
        </TVScrollView>
        <Text style={styles.hint}>{tx('🛡 وضع الأطفال: يخفي تصنيفات الكبار، ويحتاج PIN (من الرقابة الأبوية) للخروج منه.', '🛡 Kids mode hides adult categories and needs your Parental PIN to leave.')}</Text>
        <Pressable style={[styles.primary, { backgroundColor: p.accent }]} onPress={p.onAdd}>
          <Text style={styles.primaryText}>{tx('+ إضافة Profile جديد (سيرفر منفصل)', '+ Add new profile (separate server)')}</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bg: { flex: 1, backgroundColor: '#000b', justifyContent: 'flex-end' },
  card: { backgroundColor: '#1a1b23', borderTopLeftRadius: 22, borderTopRightRadius: 22, padding: 24, paddingBottom: 34 },
  close: { position: 'absolute', right: 16, top: 16, zIndex: 2, padding: 6 },
  title: { color: '#fff', fontSize: 22, fontWeight: '800' },
  sub: { color: '#9a9ab0', marginTop: 4, marginBottom: 12 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 8 },
  main: { flex: 1, flexDirection: 'row', alignItems: 'center', backgroundColor: '#242532', borderRadius: 14, padding: 12, gap: 10 },
  name: { color: '#fff', fontSize: 16, fontWeight: '700' },
  meta: { color: '#8a8aa0', fontSize: 12, marginTop: 2 },
  hint: { color: '#6b6b82', fontSize: 11, marginTop: 6 },
  primary: { marginTop: 14, borderRadius: 14, paddingVertical: 14, alignItems: 'center' },
  primaryText: { color: '#fff', fontWeight: '800', fontSize: 15 },
});
