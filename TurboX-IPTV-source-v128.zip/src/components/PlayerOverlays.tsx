import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

const RED = '#ff2e3d';

/* ---------------- channel side panel (live) ---------------- */
export type PanelRow = { key: string; num: number; name: string; now?: string; current: boolean; selected: boolean };

/** Remote-driven channel list shown over the live stream. Pure view: the key handler owns the cursor. */
export function ChannelPanel({ rows, title, hint }: { rows: PanelRow[]; title: string; hint: string }) {
  return (
    <View pointerEvents="none" style={styles.panel}>
      <Text style={styles.panelTitle}>{title}</Text>
      {rows.map(r => (
        <View key={r.key} style={[styles.pRow, r.selected && styles.pRowSel]}>
          <Text style={[styles.pNum, r.selected && styles.dark]}>{r.num}</Text>
          <View style={styles.pMid}>
            <Text style={[styles.pName, r.selected && styles.dark]} numberOfLines={1}>{r.name}</Text>
            {!!r.now && <Text style={[styles.pNow, r.selected && styles.darkDim]} numberOfLines={1}>{r.now}</Text>}
          </View>
          {r.current && <View style={styles.pDot} />}
        </View>
      ))}
      <Text style={styles.pHint}>{hint}</Text>
    </View>
  );
}

/* ---------------- next episode countdown ---------------- */
export function AutoNextCard({ label, title, left, total, hint }: { label: string; title: string; left: number; total: number; hint: string }) {
  const pct = Math.max(0, Math.min(100, (left / total) * 100));
  return (
    <View pointerEvents="none" style={styles.next}>
      <View style={styles.nextHead}>
        <MaterialIcons name="skip-next" size={22} color="#fff" />
        <Text style={styles.nextLabel}>{label}</Text>
        <Text style={styles.nextLeft}>{Math.max(0, left)}</Text>
      </View>
      <Text style={styles.nextTitle} numberOfLines={2}>{title}</Text>
      <View style={styles.nextTrack}><View style={[styles.nextFill, { width: `${pct}%` }]} /></View>
      <Text style={styles.nextHint}>{hint}</Text>
    </View>
  );
}

/* ---------------- playback error ---------------- */
export function ErrorCard({ title, message, actions, cursor }: { title: string; message: string; actions: Array<{ id: string; label: string }>; cursor: number }) {
  return (
    <View pointerEvents="none" style={styles.errWrap}>
      <View style={styles.errCard}>
        <MaterialIcons name="error-outline" size={44} color={RED} />
        <Text style={styles.errTitle}>{title}</Text>
        <Text style={styles.errMsg} numberOfLines={6}>{message}</Text>
        <View style={styles.errRow}>
          {actions.map((a, i) => (
            <View key={a.id} style={[styles.errBtn, i === cursor && styles.errBtnOn]}>
              <Text style={[styles.errBtnText, i === cursor && styles.dark]} numberOfLines={1}>{a.label}</Text>
            </View>
          ))}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  dark: { color: '#0b0b12' },
  darkDim: { color: 'rgba(11,11,18,0.65)' },

  panel: { position: 'absolute', top: 0, bottom: 0, end: 0, width: 400, backgroundColor: 'rgba(0,0,0,0.86)', paddingTop: 28, paddingHorizontal: 14 },
  panelTitle: { color: '#fff', fontSize: 22, fontWeight: '700', marginBottom: 12, paddingHorizontal: 8 },
  pRow: { flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 62, paddingHorizontal: 12, borderRadius: 12, marginBottom: 4 },
  pRowSel: { backgroundColor: '#fff' },
  pNum: { width: 40, color: 'rgba(255,255,255,0.6)', fontSize: 16, fontWeight: '700', textAlign: 'center' },
  pMid: { flex: 1 },
  pName: { color: '#fff', fontSize: 17, fontWeight: '700' },
  pNow: { color: 'rgba(255,255,255,0.6)', fontSize: 13, marginTop: 2 },
  pDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: RED },
  pHint: { position: 'absolute', bottom: 18, start: 22, end: 22, color: 'rgba(255,255,255,0.55)', fontSize: 12, fontWeight: '600', textAlign: 'center' },

  next: { position: 'absolute', end: 48, bottom: 44, width: 440, backgroundColor: 'rgba(18,18,26,0.95)', borderRadius: 16, padding: 18 },
  nextHead: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  nextLabel: { flex: 1, color: 'rgba(255,255,255,0.75)', fontSize: 14, fontWeight: '700' },
  nextLeft: { color: '#fff', fontSize: 26, fontWeight: '800' },
  nextTitle: { color: '#fff', fontSize: 20, fontWeight: '700', marginTop: 8 },
  nextTrack: { height: 4, borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.25)', marginTop: 14, overflow: 'hidden' },
  nextFill: { height: 4, backgroundColor: RED },
  nextHint: { color: 'rgba(255,255,255,0.6)', fontSize: 12, fontWeight: '600', marginTop: 10 },

  errWrap: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.78)', alignItems: 'center', justifyContent: 'center' },
  errCard: { width: 680, maxWidth: '90%', backgroundColor: 'rgba(24,24,34,0.98)', borderRadius: 20, paddingVertical: 28, paddingHorizontal: 32, alignItems: 'center' },
  errTitle: { color: '#fff', fontSize: 24, fontWeight: '800', marginTop: 10 },
  errMsg: { color: 'rgba(255,255,255,0.75)', fontSize: 15, lineHeight: 22, textAlign: 'center', marginTop: 10 },
  errRow: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 10, marginTop: 22 },
  errBtn: { minWidth: 130, paddingHorizontal: 18, height: 46, borderRadius: 23, borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.35)', alignItems: 'center', justifyContent: 'center' },
  errBtnOn: { backgroundColor: '#fff', borderColor: '#fff' },
  errBtnText: { color: '#fff', fontSize: 15, fontWeight: '700' },
});
