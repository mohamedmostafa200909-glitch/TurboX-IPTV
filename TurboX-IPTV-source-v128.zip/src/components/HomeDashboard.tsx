import React, { useEffect, useRef, useState } from 'react';
import { Animated, Easing, Image, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import TurboXLogo from './TurboXLogo';
import { TVPressable, TVScope, tvEngine, useTVScroller } from '../tv/focus';

const RED = '#e11d2e';
const PINK = '#ff5a66';
const CARD = '#14141d';
const LINE = '#2c2c3c';
const TEXT = '#f4f4f8';
const MUTED = '#9a9ab0';

/** Remote-aware button: focus ring + press come from the TV focus engine (src/tv/focus.tsx). */
function Focusable({ children, style, focusStyle, onPress, preferred, label }: any) {
  return (
    <TVPressable
      hasTVPreferredFocus={!!preferred}
      onPress={onPress}
      accessibilityLabel={label}
      focusStyle={focusStyle}
      style={({ pressed }: any) => [style, pressed && { opacity: 0.78 }]}
    >
      {children}
    </TVPressable>
  );
}

/* ------------------------------------------------------------------ */
/* Top bar: TurboX logo + clock / network / notifications / settings   */
/* ------------------------------------------------------------------ */
export function HomeTopBar({
  height,
  paddingHorizontal,
  onNotifications,
  onSettings,
}: {
  height: number;
  paddingHorizontal: number;
  onNotifications: () => void;
  onSettings: () => void;
}) {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(id);
  }, []);
  const logoH = height - 8;
  const logoW = Math.round(logoH * 2.0);
  return (
    <View style={[styles.top, { height, paddingHorizontal }]}>
      <TurboXLogo width={logoW} />
      <View style={styles.topRight}>
        <Text style={styles.clock}>{now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</Text>
        <View style={styles.roundBtn}><Ionicons name="wifi" size={20} color={MUTED} /></View>
        <Focusable style={styles.roundBtn} onPress={onNotifications} label="Notifications">
          <Ionicons name="notifications-outline" size={21} color={TEXT} />
        </Focusable>
        <Focusable style={styles.roundBtn} onPress={onSettings} label="Settings">
          <Ionicons name="settings-outline" size={21} color={TEXT} />
        </Focusable>
      </View>
    </View>
  );
}

/* ------------------------------------------------------------------ */
/* Body: status, 3 hero tiles, quick actions, continue watching        */
/* ------------------------------------------------------------------ */
export type HomeRowItem = { key: string; name: string; icon?: string; onPress: () => void };
export type HomeRowData = { id: string; title: string; icon: any; items: HomeRowItem[] };
type Cont = { key: string; name: string; progress: number; onPress: () => void };
type BodyProps = {
  isEnglish: boolean;
  profileName: string;
  providerName?: string;
  networkLabel: string;
  catalogReady: boolean;
  catalogProgress: number;
  /** the saved catalogue is on screen while a newer one downloads in the background */
  refreshing?: boolean;
  counts: { live: number; movies: number; series: number };
  tileHeight: number;
  actionHeight: number;
  pad: number;
  onOpen: (tab: 'live' | 'movies' | 'series') => void;
  onEpg: () => void;
  onSearch?: () => void;
  onMulti: () => void;
  onAccount: () => void;
  onSettings: () => void;
  onAddSource: () => void;
  alert?: { level: 'warn' | 'bad'; text: string } | null;
  rows?: HomeRowData[];
  onAlert?: () => void;
  continueItems: Cont[];
};

/* ------------------------------------------------------------------ */
/* Hero tile: artwork icon + spring-scale / neon-glow focus animation   */
/* ------------------------------------------------------------------ */
const TILE_ART = {
  live: { icon: require('../../assets/tiles/live.webp'), glow: require('../../assets/tiles/live-glow.webp') },
  movies: { icon: require('../../assets/tiles/movies.webp'), glow: require('../../assets/tiles/movies-glow.webp') },
  series: { icon: require('../../assets/tiles/series.webp'), glow: require('../../assets/tiles/series-glow.webp') },
};
/** Neutralise the engine's default focus ring (border / tint / scale): the tile animates itself, with no layout change. */
const NO_RING = { borderWidth: 0, borderColor: 'transparent', backgroundColor: 'transparent', shadowOpacity: 0, elevation: 0, transform: [{ scale: 1 }] };

function HeroTile({ art, color, sub, pct, progress, height, preferred, label, onPress }: {
  art: { icon: any; glow: any }; color: string; sub: string; pct: string; progress: number;
  height: number; preferred: boolean; label: string; onPress: () => void;
}) {
  // "active" = remote highlight (JS focus engine) OR native focus OR mouse hover
  const [nodeId, setNodeId] = useState('');
  const [engineOn, setEngineOn] = useState(false);
  const [nativeOn, setNativeOn] = useState(false);
  const [hoverOn, setHoverOn] = useState(false);
  const active = engineOn || nativeOn || hoverOn;

  const scale = useRef(new Animated.Value(1)).current;
  const glow = useRef(new Animated.Value(0)).current;
  const pulse = useRef(new Animated.Value(0)).current;

  useEffect(() => (nodeId ? tvEngine.subscribe(nodeId, setEngineOn) : undefined), [nodeId]);

  // Everything below runs on the native UI thread (useNativeDriver): transform + opacity only, so no layout pass.
  useEffect(() => {
    const run = Animated.parallel([
      Animated.spring(scale, { toValue: active ? 1.09 : 1, friction: 6, tension: 140, useNativeDriver: true }),
      Animated.timing(glow, { toValue: active ? 1 : 0, duration: active ? 180 : 260, easing: Easing.out(Easing.quad), useNativeDriver: true }),
    ]);
    run.start();
    let loop: Animated.CompositeAnimation | null = null;
    if (active) {
      // "animated state": the neon breathes slowly while the tile is focused
      loop = Animated.loop(Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 900, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 0, duration: 900, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      ]));
      loop.start();
    }
    return () => { run.stop(); loop?.stop(); };
  }, [active, scale, glow, pulse]);

  const glowOpacity = Animated.multiply(glow, pulse.interpolate({ inputRange: [0, 1], outputRange: [0.72, 1] }));

  return (
    <TVPressable
      hasTVPreferredFocus={preferred}
      onPress={onPress}
      accessibilityLabel={label}
      focusStyle={NO_RING}
      __onId={setNodeId}
      onFocus={() => setNativeOn(true)}
      onBlur={() => setNativeOn(false)}
      onHoverIn={() => setHoverOn(true)}
      onHoverOut={() => setHoverOn(false)}
      style={({ pressed }: any) => [styles.hero, { height, zIndex: active ? 5 : 0 }, pressed && { opacity: 0.88 }]}
    >
      <Animated.View style={[styles.heroInner, { transform: [{ scale }] }]}>
        <View style={styles.heroArt}>
          <Animated.Image source={art.glow} resizeMode="contain" fadeDuration={0} style={[styles.heroFill, { opacity: glowOpacity, transform: [{ scale: 1.2 }] }]} />
          <Image source={art.icon} resizeMode="contain" fadeDuration={0} style={styles.heroFill} />
        </View>
        <View style={styles.heroInfo}>
          <View style={styles.heroInfoRow}>
            <Text style={styles.tileSub} numberOfLines={1}>{sub}</Text>
            <Text style={[styles.tilePct, { marginTop: 0, color }]}>{pct}</Text>
          </View>
          <View style={styles.track}>
            <View style={[styles.fill, { width: `${Math.max(4, Math.min(100, progress))}%`, backgroundColor: color }]} />
          </View>
        </View>
      </Animated.View>
    </TVPressable>
  );
}

function HomeRow({ row }: { row: HomeRowData }) {
  const scroller = useTVScroller('x');
  return (
    <View style={styles.contWrap}>
      <View style={styles.rowHead}>
        <Ionicons name={row.icon} size={16} color={PINK} />
        <Text style={styles.contTitle}>{row.title}</Text>
      </View>
      <TVScope scope={scroller.scope}>
        <ScrollView ref={scroller.ref} onScroll={scroller.onScroll} scrollEventThrottle={16} horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10 }}>
          {row.items.map(it => (
            <Focusable key={it.key} style={styles.chCard} onPress={it.onPress} label={it.name}>
              <View style={styles.chLogo}>
                {it.icon ? <Image source={{ uri: it.icon }} style={styles.chImg} resizeMode="contain" /> : <Ionicons name="tv-outline" size={20} color="#6b6b82" />}
              </View>
              <Text style={styles.chName} numberOfLines={2}>{it.name}</Text>
            </Focusable>
          ))}
        </ScrollView>
      </TVScope>
    </View>
  );
}

export function HomeBody(p: BodyProps) {
  const contScroll = useTVScroller('x');
  const tx = (ar: string, en: string) => (p.isEnglish ? en : ar);
  const progress = p.catalogReady ? 100 : p.catalogProgress;
  const hasSource = !!p.providerName;

  const tiles: Array<{ tab: 'live' | 'movies' | 'series'; icon: any; label: string; sub: string; color: string }> = [
    { tab: 'live', icon: 'radio', label: 'LIVE TV', sub: p.counts.live ? tx(`${p.counts.live} قناة`, `${p.counts.live} channels`) : tx('البث المباشر', 'Live broadcast'), color: '#ff4d5a' },
    { tab: 'movies', icon: 'film', label: 'MOVIES', sub: p.counts.movies ? tx(`${p.counts.movies} فيلم`, `${p.counts.movies} movies`) : tx('مكتبة الأفلام', 'Movie library'), color: '#ff8a3d' },
    { tab: 'series', icon: 'videocam', label: 'SERIES', sub: p.counts.series ? tx(`${p.counts.series} مسلسل`, `${p.counts.series} series`) : tx('المسلسلات والمواسم', 'Shows & seasons'), color: '#ff5aa5' },
  ];
  const actions: Array<{ icon: any; label: string; onPress: () => void }> = [
    { icon: 'search', label: tx('بحث', 'SEARCH'), onPress: p.onSearch || (() => undefined) },
    { icon: 'book-outline', label: 'EPG', onPress: p.onEpg },
    { icon: 'grid-outline', label: 'MULTI-VIEW', onPress: p.onMulti },
    { icon: 'person-circle-outline', label: tx('الحساب', 'ACCOUNT'), onPress: p.onAccount },
    { icon: 'settings-outline', label: tx('الإعدادات', 'SETTINGS'), onPress: p.onSettings },
  ];

  return (
    <View style={[styles.body, { paddingHorizontal: p.pad }]}>
      <View pointerEvents="none" style={styles.glowA} />
      <View pointerEvents="none" style={styles.glowB} />

      {/* status row */}
      <View style={styles.statusRow}>
        <View style={{ flex: 1 }}>
          <Text style={styles.hello} numberOfLines={1}>{tx(`مرحباً، ${p.profileName}`, `Welcome, ${p.profileName}`)}</Text>
          <Text style={styles.helloSub} numberOfLines={1}>{tx('اختر ما تريد مشاهدته', 'Pick what you want to watch')}</Text>
        </View>
        {hasSource ? (
          <View style={styles.pill}>
            <View style={[styles.dot, { backgroundColor: p.catalogReady && !p.refreshing ? '#34d399' : '#fbbf24' }]} />
            <Text style={styles.pillText} numberOfLines={1}>{p.providerName} · {p.networkLabel}{p.refreshing ? tx(' · جارٍ التحديث…', ' · updating…') : ''}</Text>
          </View>
        ) : (
          <Focusable style={[styles.pill, { borderColor: RED }]} onPress={p.onAddSource} label="Add source">
            <Ionicons name="add-circle" size={16} color={PINK} />
            <Text style={[styles.pillText, { color: PINK }]}>{tx('أضف مصدر Xtream أو M3U', 'Add an Xtream or M3U source')}</Text>
          </Focusable>
        )}
      </View>

      {p.alert && (
        <Focusable
          style={[styles.alert, p.alert.level === 'bad' ? styles.alertBad : styles.alertWarn]}
          onPress={p.onAlert}
          label={p.alert.text}
        >
          <Ionicons name={p.alert.level === 'bad' ? 'alert-circle' : 'time'} size={20} color={p.alert.level === 'bad' ? '#f87171' : '#fbbf24'} />
          <Text style={[styles.alertText, { color: p.alert.level === 'bad' ? '#fca5a5' : '#fde68a' }]} numberOfLines={1}>{p.alert.text}</Text>
          <Ionicons name="chevron-forward" size={16} color="#9a9ab0" />
        </Focusable>
      )}

      {/* hero tiles */}
      <View style={styles.tiles}>
        {tiles.map((t, i) => (
          <HeroTile
            key={t.tab}
            art={TILE_ART[t.tab]}
            color={t.color}
            label={t.label}
            sub={t.sub}
            pct={p.catalogReady ? tx('جاهز ✓', 'Ready ✓') : `${Math.round(progress)}%`}
            progress={progress}
            height={p.tileHeight}
            preferred={i === 0}
            onPress={() => p.onOpen(t.tab)}
          />
        ))}
      </View>

      {/* quick actions */}
      <View style={[styles.actions, { height: p.actionHeight }]}>
        {actions.map(a => (
          <Focusable key={a.label} style={styles.action} onPress={a.onPress} label={a.label}>
            <View style={styles.actionIcon}><Ionicons name={a.icon} size={20} color={PINK} /></View>
            <Text style={styles.actionText} numberOfLines={1}>{a.label}</Text>
          </Focusable>
        ))}
      </View>

      {(p.rows || []).filter(r => r.items.length > 0).map(r => <HomeRow key={r.id} row={r} />)}

      {/* continue watching */}
      {p.continueItems.length > 0 && (
        <View style={styles.contWrap}>
          <View style={styles.rowHead}><Ionicons name="play-circle" size={16} color={PINK} /><Text style={styles.contTitle}>{tx('متابعة المشاهدة', 'Continue Watching')}</Text></View>
          <TVScope scope={contScroll.scope}><ScrollView ref={contScroll.ref} onScroll={contScroll.onScroll} scrollEventThrottle={16} horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10 }}>
            {p.continueItems.map(c => (
              <Focusable key={c.key} style={styles.contCard} onPress={c.onPress} label={c.name}>
                <Ionicons name="play-circle" size={26} color={PINK} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.contName} numberOfLines={1}>{c.name}</Text>
                  <View style={[styles.track, { marginTop: 6 }]}>
                    <View style={[styles.fill, { width: `${Math.max(3, Math.min(100, c.progress || 0))}%`, backgroundColor: RED }]} />
                  </View>
                </View>
              </Focusable>
            ))}
          </ScrollView></TVScope>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  top: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#0b0b12', borderBottomWidth: 1, borderBottomColor: '#1b1b27' },
  topRight: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  clock: { color: TEXT, fontSize: 18, fontWeight: '700', marginEnd: 4 },
  roundBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: CARD, borderWidth: 1, borderColor: LINE, alignItems: 'center', justifyContent: 'center' },

  body: { backgroundColor: '#0b0b12', paddingTop: 12, paddingBottom: 18, overflow: 'hidden' },
  glowA: { position: 'absolute', top: -120, end: -100, width: 380, height: 380, borderRadius: 190, backgroundColor: 'rgba(225,29,46,0.16)' },
  glowB: { position: 'absolute', bottom: -140, start: -120, width: 380, height: 380, borderRadius: 190, backgroundColor: 'rgba(225,29,46,0.10)' },

  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 12 },
  hello: { color: TEXT, fontSize: 20, fontWeight: '800' },
  helloSub: { color: MUTED, fontSize: 12, marginTop: 2 },
  pill: { flexDirection: 'row', alignItems: 'center', gap: 8, maxWidth: '55%', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 18, backgroundColor: CARD, borderWidth: 1, borderColor: LINE },
  dot: { width: 8, height: 8, borderRadius: 4 },
  pillText: { color: '#cfcfdc', fontSize: 12, fontWeight: '600', flexShrink: 1 },

  alert: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 14, borderWidth: 1, marginBottom: 10 },
  alertWarn: { backgroundColor: 'rgba(251,191,36,0.10)', borderColor: 'rgba(251,191,36,0.5)' },
  alertBad: { backgroundColor: 'rgba(248,113,113,0.10)', borderColor: 'rgba(248,113,113,0.5)' },
  alertText: { flex: 1, fontSize: 13, fontWeight: '700' },
  tiles: { flexDirection: 'row', gap: 12, overflow: 'visible' },
  hero: { flex: 1, overflow: 'visible' },
  heroInner: { flex: 1 },
  heroArt: { flex: 1 },
  heroFill: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, width: '100%', height: '100%' },
  heroInfo: { paddingHorizontal: 10, paddingTop: 4 },
  heroInfoRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
  tile: { flex: 1, borderRadius: 20, borderWidth: 1.5, backgroundColor: CARD, padding: 14, overflow: 'hidden' },
  tileGlow: { position: 'absolute', top: -50, end: -50, width: 150, height: 150, borderRadius: 75 },
  badge: { width: 58, height: 58, borderRadius: 29, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  tileLabel: { fontSize: 20, fontWeight: '900', letterSpacing: 1.5 },
  tileSub: { color: MUTED, fontSize: 12, marginTop: 2 },
  track: { height: 4, borderRadius: 2, backgroundColor: '#272736', overflow: 'hidden', marginTop: 10 },
  fill: { height: 4, borderRadius: 2 },
  tilePct: { color: MUTED, fontSize: 11, marginTop: 5, fontWeight: '600' },

  actions: { flexDirection: 'row', gap: 10, marginTop: 12 },
  action: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderRadius: 16, backgroundColor: CARD, borderWidth: 1, borderColor: LINE, paddingHorizontal: 8 },
  actionIcon: { width: 32, height: 32, borderRadius: 16, backgroundColor: 'rgba(225,29,46,0.16)', alignItems: 'center', justifyContent: 'center' },
  actionText: { color: TEXT, fontSize: 12, fontWeight: '800', letterSpacing: 0.8, flexShrink: 1 },

  contWrap: { marginTop: 14 },
  rowHead: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  chCard: { width: 112, alignItems: 'center', gap: 6, padding: 8, borderRadius: 14, backgroundColor: CARD, borderWidth: 1, borderColor: LINE },
  chLogo: { width: 64, height: 48, borderRadius: 10, backgroundColor: '#1c1c28', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  chImg: { width: 60, height: 44 },
  chName: { color: TEXT, fontSize: 11, fontWeight: '700', textAlign: 'center', minHeight: 28 },
  contTitle: { color: TEXT, fontSize: 15, fontWeight: '800' },
  contCard: { width: 220, flexDirection: 'row', alignItems: 'center', gap: 10, padding: 12, borderRadius: 14, backgroundColor: CARD, borderWidth: 1, borderColor: LINE },
  contName: { color: TEXT, fontSize: 13, fontWeight: '700' },
});
