import React from 'react';
import { ActivityIndicator, Image, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { TVPressable as Pressable, TVScrollView } from '../tv/focus';
import type { Media } from '../types';

type Props = {
  item: Media;
  /** response of player_api.php?action=get_vod_info (null while loading / unavailable) */
  info: any | null;
  loading: boolean;
  accent: string;
  isEnglish: boolean;
  favorite: boolean;
  progress?: number; // 0-100
  maxHeight: number;
  onPlay: () => void;
  onFavorite: () => void;
  onTrailer?: () => void;
  onClose: () => void;
};

const clean = (v: unknown) => (v === undefined || v === null || v === '' ? '' : String(v));

/** Movie page: poster, story, rating, cast, then Play / Favorite / Trailer. */
export default function MovieDetails({ item, info, loading, accent, isEnglish, favorite, progress, maxHeight, onPlay, onFavorite, onTrailer, onClose }: Props) {
  const tx = (ar: string, en: string) => (isEnglish ? en : ar);
  const i = info?.info || {};
  const poster = clean(i.movie_image || i.cover_big) || clean((item as any).cover || item.stream_icon);
  const meta = [clean(i.releasedate || (item as any).year).slice(0, 4), clean(i.duration), clean(i.genre), clean(i.rating || (item as any).rating) ? `★ ${clean(i.rating || (item as any).rating)}` : ''].filter(Boolean).join(' · ');
  const plot = clean(i.plot || i.description || (item as any).plot);
  const cast = clean(i.cast || i.actors);
  const director = clean(i.director);
  return (
    <View style={styles.bg}>
      <View style={styles.card}>
        <Pressable onPress={onClose} style={styles.close}><Ionicons name="close" size={20} color="#aaa" /></Pressable>
        <View style={styles.top}>
          {poster ? <Image source={{ uri: poster }} style={styles.poster} resizeMode="cover" /> : <View style={[styles.poster, styles.noPoster]}><Ionicons name="film-outline" size={34} color="#6b6b82" /></View>}
          <View style={{ flex: 1 }}>
            <Text style={styles.title} numberOfLines={3}>{item.name}</Text>
            {!!meta && <Text style={styles.meta}>{meta}</Text>}
            {!!progress && progress > 1 && progress < 98 && <Text style={[styles.meta, { color: accent }]}>{tx(`تمت مشاهدة ${progress}%`, `${progress}% watched`)}</Text>}
          </View>
        </View>
        <TVScrollView style={{ maxHeight }}>
          {loading ? <ActivityIndicator color={accent} style={{ marginVertical: 16 }} /> : (
            <>
              {!!plot && <Text style={styles.plot}>{plot}</Text>}
              {!!director && <Text style={styles.line}><Text style={styles.label}>{tx('المخرج: ', 'Director: ')}</Text>{director}</Text>}
              {!!cast && <Text style={styles.line}><Text style={styles.label}>{tx('البطولة: ', 'Cast: ')}</Text>{cast}</Text>}
              {!plot && !cast && !director && <Text style={styles.line}>{tx('لا توجد تفاصيل إضافية من المزوّد.', 'The provider has no extra details.')}</Text>}
            </>
          )}
        </TVScrollView>
        <View style={styles.actions}>
          <Pressable hasTVPreferredFocus style={[styles.play, { backgroundColor: accent }]} onPress={onPlay}>
            <Ionicons name="play" size={20} color="#fff" />
            <Text style={styles.playText}>{progress && progress > 1 && progress < 98 ? tx('متابعة', 'Resume') : tx('تشغيل', 'Play')}</Text>
          </Pressable>
          <Pressable style={styles.icon} onPress={onFavorite} accessibilityLabel={tx('المفضلة', 'Favorite')}>
            <Ionicons name={favorite ? 'star' : 'star-outline'} size={22} color={favorite ? '#fbbf24' : '#fff'} />
          </Pressable>
          {onTrailer && (
            <Pressable style={styles.icon} onPress={onTrailer} accessibilityLabel={tx('الإعلان', 'Trailer')}>
              <Ionicons name="logo-youtube" size={22} color="#fff" />
            </Pressable>
          )}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bg: { flex: 1, backgroundColor: '#000b', justifyContent: 'flex-end' },
  card: { backgroundColor: '#1a1b23', borderTopLeftRadius: 22, borderTopRightRadius: 22, padding: 22, paddingBottom: 30 },
  close: { position: 'absolute', right: 14, top: 14, zIndex: 2, padding: 6 },
  top: { flexDirection: 'row', gap: 14, marginBottom: 12, paddingRight: 28 },
  poster: { width: 96, height: 140, borderRadius: 12, backgroundColor: '#242532' },
  noPoster: { alignItems: 'center', justifyContent: 'center' },
  title: { color: '#fff', fontSize: 20, fontWeight: '800' },
  meta: { color: '#9a9ab0', marginTop: 6, fontSize: 13 },
  plot: { color: '#d8d8e6', lineHeight: 21, marginBottom: 10 },
  line: { color: '#b8b8cc', marginBottom: 6, fontSize: 13, lineHeight: 19 },
  label: { color: '#fff', fontWeight: '700' },
  actions: { flexDirection: 'row', gap: 10, marginTop: 14, alignItems: 'center' },
  play: { flex: 1, flexDirection: 'row', gap: 8, alignItems: 'center', justifyContent: 'center', borderRadius: 14, paddingVertical: 13 },
  playText: { color: '#fff', fontWeight: '800', fontSize: 16 },
  icon: { backgroundColor: '#2a2b38', borderRadius: 14, padding: 12 },
});
