import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { TVPressable as Pressable, TVScrollView } from '../tv/focus';

export type PlayerEngine = 'builtin' | 'media3' | 'vlc' | 'mx' | 'just' | 'ask';

export const PLAYER_OPTIONS: Array<{
  id: PlayerEngine;
  icon: any;
  ar: string;
  en: string;
  descAr: string;
  descEn: string;
  packages: string;
}> = [
  { id: 'builtin', icon: 'tv-outline', ar: 'المشغّل المدمج', en: 'Built-in player', descAr: 'داخل التطبيق: تحكم كامل بالريموت وتغيير القنوات بالأرقام', descEn: 'Inside the app: full remote control and channel zapping', packages: '' },
  { id: 'media3', icon: 'musical-notes-outline', ar: 'Media3 (صوت وترجمة)', en: 'Media3 (audio & subtitles)', descAr: 'مشغّل أصلي داخل التطبيق: اختيار مسار الصوت والترجمة بزر MENU/INFO', descEn: 'Native in-app player: pick audio & subtitle tracks with MENU/INFO', packages: '' },
  { id: 'vlc', icon: 'play-circle-outline', ar: 'VLC', en: 'VLC', descAr: 'يفتح VLC (يجب تثبيته): أفضل لاختيار الصوت والترجمة', descEn: 'Opens VLC (must be installed): best for audio & subtitle tracks', packages: 'org.videolan.vlc' },
  { id: 'mx', icon: 'film-outline', ar: 'MX Player', en: 'MX Player', descAr: 'يفتح MX Player (يجب تثبيته)', descEn: 'Opens MX Player (must be installed)', packages: 'com.mxtech.videoplayer.pro,com.mxtech.videoplayer.ad' },
  { id: 'just', icon: 'videocam-outline', ar: 'Just Player', en: 'Just Player', descAr: 'يفتح Just Player (يجب تثبيته)', descEn: 'Opens Just Player (must be installed)', packages: 'com.brouken.player' },
  { id: 'ask', icon: 'apps-outline', ar: 'اختيار في كل مرة', en: 'Ask every time', descAr: 'يعرض قائمة بكل المشغلات المثبتة على الجهاز', descEn: 'Shows every video player installed on the device', packages: '' },
];

type Props = { value: PlayerEngine; isEnglish: boolean; onSelect: (v: PlayerEngine) => void; onClose: () => void };

/** Settings → Player: choose where videos open. */
export default function PlayerPicker({ value, isEnglish, onSelect, onClose }: Props) {
  const tx = (ar: string, en: string) => (isEnglish ? en : ar);
  return (
    <View style={styles.bg}>
      <View style={styles.card}>
        <Text style={styles.title}>{tx('اختيار المشغّل', 'Choose player')}</Text>
        <Text style={styles.sub}>{tx('حدد المشغّل الذي يفتح به التطبيق القنوات والأفلام.', 'Pick the player used for channels and movies.')}</Text>
        <TVScrollView style={{ maxHeight: 300 }} showsVerticalScrollIndicator={false}>
          {PLAYER_OPTIONS.map((o, i) => {
            const on = o.id === value;
            return (
              <Pressable key={o.id} hasTVPreferredFocus={on || (i === 0 && !PLAYER_OPTIONS.some(x => x.id === value))} onPress={() => onSelect(o.id)} style={[styles.row, on && styles.rowOn]}>
                <View style={[styles.icon, on && { backgroundColor: '#e11d2e' }]}>
                  <Ionicons name={o.icon} size={20} color={on ? '#fff' : '#ff5a66'} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.name}>{isEnglish ? o.en : o.ar}</Text>
                  <Text style={styles.desc}>{isEnglish ? o.descEn : o.descAr}</Text>
                </View>
                <Ionicons name={on ? 'radio-button-on' : 'radio-button-off'} size={22} color={on ? '#ff5a66' : '#4b4b5e'} />
              </Pressable>
            );
          })}
        </TVScrollView>
        <Pressable style={styles.close} onPress={onClose}>
          <Text style={styles.closeText}>{tx('إغلاق', 'Close')}</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bg: { flex: 1, backgroundColor: 'rgba(0,0,0,0.78)', justifyContent: 'center', alignItems: 'center', padding: 18 },
  card: { width: '100%', maxWidth: 520, backgroundColor: '#14141d', borderRadius: 22, borderWidth: 1, borderColor: '#2c2c3c', padding: 18 },
  title: { color: '#f4f4f8', fontSize: 18, fontWeight: '800' },
  sub: { color: '#9a9ab0', fontSize: 12, marginTop: 4, marginBottom: 10 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10, borderRadius: 14, borderWidth: 1, borderColor: 'transparent', marginBottom: 6, backgroundColor: '#1c1c28' },
  rowOn: { borderColor: '#e11d2e' },
  icon: { width: 38, height: 38, borderRadius: 19, backgroundColor: 'rgba(225,29,46,0.14)', alignItems: 'center', justifyContent: 'center' },
  name: { color: '#f4f4f8', fontSize: 15, fontWeight: '800' },
  desc: { color: '#9a9ab0', fontSize: 11, marginTop: 2 },
  close: { marginTop: 8, height: 44, borderRadius: 12, backgroundColor: '#1c1c28', borderWidth: 1, borderColor: '#2c2c3c', alignItems: 'center', justifyContent: 'center' },
  closeText: { color: '#cfd0da', fontSize: 14, fontWeight: '800' },
});
