import React, { useDeferredValue, useMemo, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Modal } from './TVModal';
import { TVPressable as Pressable, TVScrollView, TVTextInput } from '../tv/focus';
import { buildIndex, searchIndex } from '../utils/search';
import type { Media } from '../types';

type Props = {
  visible: boolean;
  isEnglish: boolean;
  accent: string;
  channels: Media[];
  movies: Media[];
  series: Media[];
  onClose: () => void;
  onPick: (item: Media) => void;
};

/**
 * Typing uses the device's own on-screen keyboard (Android TV's system IME — via TVTextInput, the same real
 * TextInput used for server/username/password in LoginScreen) instead of a hand-built key grid: it already has
 * Arabic/English layouts, a mic button where the box supports voice typing, and whatever layout the box ships with,
 * so there is nothing to duplicate or keep in sync here.
 */
export default function SearchOverlay({ visible, isEnglish, accent, channels, movies, series, onClose, onPick }: Props) {
  const tx = (ar: string, en: string) => (isEnglish ? en : ar);
  const [text, setText] = useState('');
  const deferred = useDeferredValue(text);

  // the index is built once per open (≈60k names) and dropped when the screen closes
  const idx = useMemo(() => {
    if (!visible) return null;
    return {
      live: buildIndex(channels, x => x.name),
      movie: buildIndex(movies, x => x.name),
      series: buildIndex(series, x => x.name),
    };
  }, [visible, channels, movies, series]);

  const results = useMemo(() => {
    if (!idx || !deferred.trim()) return { live: [] as Media[], movie: [] as Media[], series: [] as Media[] };
    return { live: searchIndex(idx.live, deferred, 10), movie: searchIndex(idx.movie, deferred, 10), series: searchIndex(idx.series, deferred, 10) };
  }, [idx, deferred]);

  const total = results.live.length + results.movie.length + results.series.length;
  const pick = (item: Media) => { setText(''); onPick(item); };
  const close = () => { setText(''); onClose(); };

  const section = (title: string, icon: any, list: Media[]) => list.length ? (
    <View key={title} style={{ marginBottom: 10 }}>
      <View style={styles.secHead}><Ionicons name={icon} size={16} color={accent} /><Text style={styles.secTitle}>{title} · {list.length}</Text></View>
      {list.map((item, i) => (
        <Pressable key={`${title}-${i}`} lite onPress={() => pick(item)} style={styles.result}>
          <Text style={styles.resName} numberOfLines={1}>{item.name}</Text>
          {!!(item.category_name || item.year) && <Text style={styles.resSub} numberOfLines={1}>{item.category_name || item.year}</Text>}
        </Pressable>
      ))}
    </View>
  ) : null;

  return (
    <Modal visible={visible} transparent animationType="fade" statusBarTranslucent onRequestClose={close}>
      <View style={styles.screen}>
        <View style={styles.left}>
          <Text style={styles.title}>{tx('بحث', 'Search')}</Text>
          <View style={styles.box}>
            <Ionicons name="search" size={20} color="#9a9ab0" />
            <TVTextInput
              hasTVPreferredFocus
              wrapStyle={styles.inputWrap}
              style={styles.input}
              value={text}
              onChangeText={setText}
              placeholder={tx('اكتب اسم قناة أو فيلم أو مسلسل', 'Type a channel, movie or series')}
              placeholderTextColor="#6b6b80"
              autoCapitalize="none"
              autoCorrect={false}
              returnKeyType="search"
            />
            {!!text && (
              <Pressable lite onPress={() => setText('')} style={styles.clearBtn} accessibilityLabel={tx('مسح', 'Clear')}>
                <Ionicons name="close-circle" size={20} color="#8a8a96" />
              </Pressable>
            )}
          </View>
          <Text style={styles.hint}>{tx('استخدم لوحة مفاتيح الجهاز، وتقدر تستخدم الميكروفون فيها للكتابة بالصوت إن وُجد.', 'Uses your device\u2019s own keyboard — if it has a mic button, you can type by voice with it.')}</Text>
        </View>

        <View style={styles.right}>
          <Text style={styles.count}>{text.trim() ? tx(`${total} نتيجة`, `${total} results`) : tx('النتائج تظهر هنا', 'Results appear here')}</Text>
          <TVScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
            {section(tx('القنوات', 'Channels'), 'tv-outline', results.live)}
            {section(tx('الأفلام', 'Movies'), 'film-outline', results.movie)}
            {section(tx('المسلسلات', 'Series'), 'albums-outline', results.series)}
            {!!text.trim() && total === 0 && <Text style={styles.none}>{tx('لا توجد نتائج', 'No results')}</Text>}
          </TVScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, flexDirection: 'row', backgroundColor: '#0b0b12', paddingHorizontal: 36, paddingVertical: 28, gap: 28 },
  left: { width: 560 },
  right: { flex: 1 },
  title: { color: '#fff', fontSize: 28, fontWeight: '800', marginBottom: 14 },
  box: { flexDirection: 'row', alignItems: 'center', gap: 10, height: 56, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.08)', paddingHorizontal: 14 },
  inputWrap: { flex: 1 },
  input: { color: '#fff', fontSize: 20, fontWeight: '600' },
  clearBtn: { padding: 4 },
  hint: { color: '#6b6b80', fontSize: 12, lineHeight: 18, marginTop: 10 },
  count: { color: '#9a9ab0', fontSize: 14, fontWeight: '700', marginTop: 6, marginBottom: 10 },
  secHead: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 6 },
  secTitle: { color: '#fff', fontSize: 16, fontWeight: '800' },
  result: { minHeight: 52, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.06)', paddingHorizontal: 14, paddingVertical: 8, marginBottom: 6, justifyContent: 'center' },
  resName: { color: '#fff', fontSize: 17, fontWeight: '700' },
  resSub: { color: '#9a9ab0', fontSize: 12, marginTop: 2 },
  none: { color: '#9a9ab0', fontSize: 16, marginTop: 20 },
});
