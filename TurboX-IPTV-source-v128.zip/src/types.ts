

export type Provider = {
  id: string;
  name: string;
  server: string;
  username: string;
  password: string;
  connected?: boolean;
  m3u?: boolean;
  /** kids profile: hides adult categories; leaving it needs the Parental PIN */
  kid?: boolean;
  /** request User-Agent for this provider's API and stream requests; empty = the app default (VLC) */
  userAgent?: string;
};
export type Media = {
  name: string;
  tvgId?: string;
  tvgName?: string;
  sourceId?: string;
  series_id?: number | string;
  id?: number | string;
  sourceServer?: string;
  sourceUsername?: string;
  sourcePassword?: string;
  stream_id?: number | string;
  stream_icon?: string;
  category_name?: string;
  url?: string;
  container_extension?: string;
  cover?: string;
  cover_big?: string;
  plot?: string;
  year?: string;
  rating?: string;
  added?: number | string;
  added_at?: number | string;
  created_at?: number | string;
  last_modified?: number | string;
  epg_channel_id?: string;
  now_playing?: string;
  kind?: 'live' | 'movie' | 'series';
};
export type ThemeName = 'turbo' | 'ember' | 'ocean' | 'violet' | 'green';
export type Profile = {
  id: string;
  name: string;
  kid?: boolean;
};