import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { scrollIdle } from '../utils/scrollIdle';
import { DeviceEventEmitter, FlatList, Keyboard, Pressable as RNPressable, ScrollView, TextInput } from 'react-native';

/**
 * TurboX TV focus engine
 * ----------------------
 * AOSP TV boxes handle Android's native focus search very differently from each other,
 * and core React Native does not turn the remote's OK button into onPress. So on TV the
 * main screens are driven by a small JS engine instead:
 *
 *  - Every <TVPressable> on a main screen registers itself.
 *  - The native bridge already emits `TurboXRemoteKey` (D-Pad / OK) to JS.
 *  - On a D-Pad key the engine measures all registered controls, picks the nearest one in
 *    that direction (spatial navigation), highlights it and scrolls it into view.
 *  - OK calls the focused control's onPress directly.
 *
 * Controls inside <Modal>s keep using Android's native focus (a modal is its own window), and
 * their OK press is forwarded by MainActivity.onKeyUp (action = 1).
 *
 * Touch / mouse behaviour is unchanged. On phones (device mode "mobile") the engine is off.
 */

export type Rect = { x: number; y: number; w: number; h: number };
type Dir = 'left' | 'right' | 'up' | 'down';

export const TVModeContext = createContext<boolean>(false);
// 'main'  : normal screen, driven by the JS engine
// 'modal' : native RN <Modal>, driven by Android's native focus (legacy behaviour)
// 'engine': native RN <Modal> that is ALSO driven by the JS engine (see <TVEngineLayer>)
export const TVLayerContext = createContext<'main' | 'modal' | 'engine'>('main');
export const TVModalIdContext = createContext<string | null>(null);
export const TVScrollerChain = createContext<string[]>([]);

/** Where a control sits inside its scroll container's content (known without measuring: fixed-size list rows/cells). */
export type TVLayoutHint = { x: number; y: number; h: number; /** default: viewport width minus 2*x */ w?: number };
type NodeEntry = {
  id: string;
  ref: React.RefObject<any>;
  chain: string[];
  preferred: boolean;
  press: () => void;
  /** secondary action (MENU / INFO / YELLOW on the remote), e.g. add to favourites */
  alt?: () => void;
  modal: string | null;
  hint?: React.MutableRefObject<TVLayoutHint | undefined>;
};
type Scroller = { axis: 'x' | 'y'; ref: React.RefObject<any>; offset: React.MutableRefObject<number>; actual: React.MutableRefObject<number> };

const KEY: Record<number, Dir> = { 19: 'up', 20: 'down', 21: 'left', 22: 'right' };
const OK_KEYS = [23, 66, 160, 96]; // DPAD_CENTER, ENTER, NUMPAD_ENTER, BUTTON_A
const ALT_KEYS = [82, 165, 185]; // MENU, INFO, PROG_YELLOW

function measure(ref: React.RefObject<any> | undefined): Promise<Rect | null> {
  return new Promise(resolve => {
    const node = ref?.current;
    if (!node || typeof node.measureInWindow !== 'function') return resolve(null);
    let done = false;
    const timer = setTimeout(() => { if (!done) { done = true; resolve(null); } }, 80);
    try {
      node.measureInWindow((x: number, y: number, w: number, h: number) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        resolve(w > 0 && h > 0 && isFinite(x) && isFinite(y) ? { x, y, w, h } : null);
      });
    } catch {
      clearTimeout(timer);
      resolve(null);
    }
  });
}

function overlap(a0: number, a1: number, b0: number, b1: number) {
  return Math.min(a1, b1) - Math.max(a0, b0);
}

/** Rank the neighbours of `cur` in direction `dir` (best first). */
export function rankNeighbors(cur: Rect, cands: Array<{ id: string; r: Rect }>, dir: Dir): Array<{ id: string; score: number }> {
  const cx = cur.x + cur.w / 2;
  const cy = cur.y + cur.h / 2;
  const out: Array<{ id: string; score: number; aligned: boolean }> = [];
  for (const c of cands) {
    const ccx = c.r.x + c.r.w / 2;
    const ccy = c.r.y + c.r.h / 2;
    let primary = 0;
    let secondary = 0;
    let aligned = false;
    if (dir === 'right') {
      if (ccx <= cx + 2) continue;
      primary = Math.max(0, c.r.x - (cur.x + cur.w));
      secondary = Math.abs(ccy - cy);
      aligned = overlap(cur.y, cur.y + cur.h, c.r.y, c.r.y + c.r.h) > 0;
    } else if (dir === 'left') {
      if (ccx >= cx - 2) continue;
      primary = Math.max(0, cur.x - (c.r.x + c.r.w));
      secondary = Math.abs(ccy - cy);
      aligned = overlap(cur.y, cur.y + cur.h, c.r.y, c.r.y + c.r.h) > 0;
    } else if (dir === 'down') {
      if (ccy <= cy + 2) continue;
      primary = Math.max(0, c.r.y - (cur.y + cur.h));
      secondary = Math.abs(ccx - cx);
      aligned = overlap(cur.x, cur.x + cur.w, c.r.x, c.r.x + c.r.w) > 0;
    } else {
      if (ccy >= cy - 2) continue;
      primary = Math.max(0, cur.y - (c.r.y + c.r.h));
      secondary = Math.abs(ccx - cx);
      aligned = overlap(cur.x, cur.x + cur.w, c.r.x, c.r.x + c.r.w) > 0;
    }
    // A control with no real overlap on the cross axis is not actually "below/above/left/right" of this one, just
    // nearer in raw distance than something that is — without this, reaching the end of a column makes Down/Up jump
    // sideways into an unrelated column (e.g. from the last row of a grid into the categories panel) instead of
    // stopping. So an unaligned candidate is only kept as a last-resort fallback, heavily penalised.
    out.push({ id: c.id, score: primary + secondary * (aligned ? 0.6 : 4), aligned });
  }
  const alignedOut = out.filter(o => o.aligned);
  (alignedOut.length ? alignedOut : out).sort((a, b) => a.score - b.score);
  return (alignedOut.length ? alignedOut : out).map(({ id, score }) => ({ id, score }));
}

/** Pick the best neighbour of `cur` in direction `dir`. */
export function pickNeighbor(cur: Rect, cands: Array<{ id: string; r: Rect }>, dir: Dir): string | null {
  return rankNeighbors(cur, cands, dir)[0]?.id ?? null;
}

class TVFocusEngine {
  enabled = false;
  current: string | null = null;
  private nodes = new Map<string, NodeEntry>();
  private scrollers = new Map<string, Scroller>();
  // several components can watch the same node (e.g. TVPressable + TVTextInput): keep a set per node
  private listeners = new Map<string, Set<(focused: boolean) => void>>();
  private busy = false;
  private pendingDir: Dir | null = null;
  private started = false;
  /**
   * Last measured window rect of every control + the scroll offsets at that moment. While nothing
   * re-lays out, a control only moves by the scroll delta, so its position can be *estimated* with no
   * bridge call. A key press then measures only the few best-looking candidates (not every control).
   */
  private rectCache = new Map<string, { r: Rect; ox: number; oy: number }>();
  private lastScrollAt = 0;
  bump() { this.lastScrollAt = Date.now(); }
  /** Forget every remembered position (screen layout changed). */
  invalidate() { this.rectCache.clear(); this.vpCache.clear(); this.vpHint.clear(); this.scheduleWarm(); }
  /** Window rect of each scroll container's viewport (it does not move while scrolling; cleared with the rect cache). */
  private vpCache = new Map<string, Rect>();
  /** viewport (window) rect of scrollers that hold hinted controls, with the outer scroll offsets it was measured at */
  private vpHint = new Map<string, { r: Rect; ox: number; oy: number }>();
  /** scrollers whose hints turned out wrong: measured normally from then on */
  private badHints = new Set<string>();
  /** Optional sink for timing summaries (the app writes them to Settings → Logs). */
  perfSink: ((msg: string) => void) | null = null;
  private perf = { moves: 0, ms: 0, max: 0, measures: 0, fast: 0 };
  private measureCount = 0;
  private warmTimer: ReturnType<typeof setTimeout> | null = null;
  /**
   * After a layout change / new rows, measure the unknown controls a few at a time WHILE IDLE, so the next key press
   * finds every position already cached instead of paying ~one bridge call per control (a big stall on TV boxes).
   */
  private scheduleWarm() {
    if (!this.enabled) return;
    if (this.warmTimer) clearTimeout(this.warmTimer);
    this.warmTimer = setTimeout(() => { this.warmTimer = null; this.warm(); }, 350);
  }
  private async warm() {
    const todo = Array.from(this.nodes.values()).filter(n => n.modal === this.activeModal && !this.rectCache.has(n.id));
    for (let i = 0; i < todo.length; i += 16) {
      if (!this.enabled || this.busy || Date.now() - this.lastScrollAt < 250) { this.scheduleWarm(); return; }
      await Promise.all(todo.slice(i, i + 16).map(n => (this.nodes.has(n.id) ? this.freshMeasure(n) : null)));
      await new Promise<void>(resolve => setTimeout(resolve, 8));
    }
  }
  private chainOffsets(chain: string[]) {
    let x = 0, y = 0;
    for (const sid of chain) {
      const sc = this.scrollers.get(sid);
      if (!sc) continue;
      if (sc.axis === 'y') y += sc.actual.current; else x += sc.actual.current;
    }
    return { x, y };
  }
  /** position from the layout hint (no native measure): viewport origin + hinted offset - scroll offsets */
  private hintRect(n: NodeEntry): Rect | null {
    const hint = n.hint?.current;
    const sid = n.chain[0];
    if (!hint || !sid || this.badHints.has(sid)) return null;
    const sc = this.scrollers.get(sid);
    const vp = this.vpHint.get(sid);
    if (!sc || !vp) return null;
    const outer = this.chainOffsets(n.chain.slice(1));
    const inner = sc.actual.current;
    return {
      x: vp.r.x + hint.x - (sc.axis === 'x' ? inner : 0) - (outer.x - vp.ox),
      y: vp.r.y + hint.y - (sc.axis === 'y' ? inner : 0) - (outer.y - vp.oy),
      w: hint.w ?? Math.max(0, vp.r.w - 2 * hint.x),
      h: hint.h,
    };
  }
  /** measure (once per scroller) the viewports of containers that hold hinted controls */
  private async ensureViewports() {
    const need = new Map<string, string[]>();
    for (const n of this.nodes.values()) {
      const sid = n.chain[0];
      if (n.modal !== this.activeModal || !sid || !n.hint?.current || this.vpHint.has(sid) || this.badHints.has(sid) || !this.scrollers.has(sid)) continue;
      need.set(sid, n.chain.slice(1));
    }
    for (const [sid, tail] of need) {
      const view = this.scrollers.get(sid)?.ref.current;
      if (!view) continue;
      const o = this.chainOffsets(tail);
      const r = await measure({ current: typeof view.getNativeScrollRef === 'function' ? view.getNativeScrollRef() : view } as any);
      if (r) this.vpHint.set(sid, { r, ox: o.x, oy: o.y });
    }
  }
  private approxRect(n: NodeEntry): Rect | null {
    const hr = this.hintRect(n);
    if (hr) return hr;
    const c = this.rectCache.get(n.id);
    if (!c) return null;
    const o = this.chainOffsets(n.chain);
    return { x: c.r.x - (o.x - c.ox), y: c.r.y - (o.y - c.oy), w: c.r.w, h: c.r.h };
  }
  private async freshMeasure(n: NodeEntry): Promise<Rect | null> {
    const o = this.chainOffsets(n.chain);
    this.measureCount += 1;
    const r = await measure(n.ref);
    // do not remember positions measured while a scroll animation is running
    if (r && Date.now() - this.lastScrollAt > 150) this.rectCache.set(n.id, { r, ox: o.x, oy: o.y });
    return r;
  }
  private autoTimer: ReturnType<typeof setTimeout> | null = null;
  /** Controls inside modals that currently hold *native* focus (for OK-key forwarding). */
  nativeFocus: { id: string; press: () => void } | null = null;
  /** Stack of open dialogs that are driven by this engine (top = active). */
  private modalStack: Array<{ id: string; prevCurrent: string | null }> = [];
  private pushedAt = 0;
  /** true while a TVTextInput is being edited: left/right belong to the caret, not to focus movement. */
  textEditing = false;
  /** true while the on-screen keyboard is open: all 4 arrows belong to the keyboard keys, not to focus movement. */
  kbVisible = false;
  /** set while focus moves away from a field that was being edited: a text field that receives it keeps typing. */
  autoEdit = false;
  get activeModal(): string | null {
    return this.modalStack.length ? this.modalStack[this.modalStack.length - 1].id : null;
  }
  private isValid(id: string | null): boolean {
    if (!id) return false;
    const n = this.nodes.get(id);
    return !!n && n.modal === this.activeModal;
  }

  pushModal(id: string) {
    this.invalidate();
    this.modalStack.push({ id, prevCurrent: this.current });
    this.pushedAt = Date.now();
    this.setCurrent(null);
    this.scheduleAutoPick();
  }
  popModal(id: string) {
    const idx = this.modalStack.findIndex(m => m.id === id);
    if (idx < 0) return;
    this.invalidate();
    const [entry] = this.modalStack.splice(idx, 1);
    this.setCurrent(null);
    if (entry.prevCurrent && this.isValid(entry.prevCurrent)) this.setCurrent(entry.prevCurrent);
    else this.scheduleAutoPick();
  }
  /** Programmatic focus (e.g. "next" on the keyboard): highlight the control and scroll to it. */
  async focusNode(id: string) {
    const n = this.nodes.get(id);
    if (!n) return;
    this.setCurrent(id);
    const r = await measure(n.ref);
    if (r) await this.scrollIntoView({ ...r }, n.chain);
  }

  start() {
    if (this.started) return;
    this.started = true;
    DeviceEventEmitter.addListener('TurboXRemoteKey', (e: { keyCode: number; action: number }) => this.onKey(e.keyCode, e.action));
    Keyboard.addListener('keyboardDidShow', () => { this.kbVisible = true; this.invalidate(); });
    Keyboard.addListener('keyboardDidHide', () => { this.kbVisible = false; this.invalidate(); });
  }
  setEnabled(v: boolean) {
    this.enabled = v;
    if (!v) this.setCurrent(null);
    else this.scheduleAutoPick();
  }

  register(n: NodeEntry) {
    this.nodes.set(n.id, n);
    if (this.enabled && !this.isValid(this.current)) this.scheduleAutoPick();
    this.scheduleWarm();
  }
  unregister(id: string) {
    this.nodes.delete(id);
    this.rectCache.delete(id);
    if (this.nativeFocus?.id === id) this.nativeFocus = null;
    if (this.current === id) {
      this.current = null;
      this.notify(id, false);
      this.scheduleAutoPick();
    }
  }
  registerScroller(id: string, s: Scroller) { this.scrollers.set(id, s); }
  unregisterScroller(id: string) { this.scrollers.delete(id); }

  subscribe(id: string, fn: (focused: boolean) => void) {
    let set = this.listeners.get(id);
    if (!set) { set = new Set(); this.listeners.set(id, set); }
    set.add(fn);
    fn(this.current === id);
    return () => { const cur = this.listeners.get(id); if (cur) { cur.delete(fn); if (!cur.size) this.listeners.delete(id); } };
  }
  private notify(id: string | null, v: boolean) {
    if (id) this.listeners.get(id)?.forEach(fn => fn(v));
  }
  setCurrent(id: string | null) {
    if (this.current === id) return;
    const prev = this.current;
    this.current = id;
    this.notify(prev, false);
    this.notify(id, true);
  }

  /** Called when a node was touched / clicked: keep the highlight in sync. */
  touched(id: string) {
    if (this.enabled && this.nodes.has(id)) this.setCurrent(id);
  }

  private scheduleAutoPick() {
    if (this.autoTimer) clearTimeout(this.autoTimer);
    this.autoTimer = setTimeout(() => { this.autoTimer = null; this.autoPick(); }, 180);
  }
  /** Choose a starting control: a preferred one, otherwise the top-left-most visible one. */
  private async autoPick() {
    if (!this.enabled || this.isValid(this.current)) return;
    const all = Array.from(this.nodes.values()).filter(n => n.modal === this.activeModal);
    const pref = all.filter(n => n.preferred);
    const pool = pref.length ? pref : all;
    const rects = await Promise.all(pool.map(async n => ({ n, r: await measure(n.ref) })));
    const vis = rects.filter(x => x.r && x.r.y >= -2 && x.r.x >= -2) as Array<{ n: NodeEntry; r: Rect }>;
    vis.sort((a, b) => a.r.y - b.r.y || a.r.x - b.r.x);
    const first = vis[0]?.n || pool[0];
    if (first && this.enabled && !this.isValid(this.current)) this.setCurrent(first.id);
  }

  private onKey(keyCode: number, action: number) {
    const inModal = this.activeModal !== null;
    // Dialog controls: the dialog window only forwards key-UP events to the activity.
    if (action === 1) {
      if (inModal) {
        if (!this.enabled) return;
        // ignore the key-up that belongs to the press which opened this dialog
        if (Date.now() - this.pushedAt < 450) return;
        if (OK_KEYS.includes(keyCode)) {
          const n = this.current ? this.nodes.get(this.current) : null;
          if (n && this.isValid(this.current)) n.press(); else this.autoPick();
          return;
        }
        if (ALT_KEYS.includes(keyCode)) {
          const an = this.current ? this.nodes.get(this.current) : null;
          if (an?.alt && this.isValid(this.current)) an.alt();
          return;
        }
        const d = KEY[keyCode];
        if (d && this.textEditing && (d === 'left' || d === 'right' || this.kbVisible)) return;
        if (d) this.move(d);
        return;
      }
      if (OK_KEYS.includes(keyCode)) {
        const nf = this.nativeFocus;
        if (nf) nf.press();
      }
      return;
    }
    if (!this.enabled || action !== 0 || inModal) return;
    if (OK_KEYS.includes(keyCode)) {
      const n = this.current ? this.nodes.get(this.current) : null;
      if (n) n.press(); else this.autoPick();
      return;
    }
    if (ALT_KEYS.includes(keyCode)) {
      const an = this.current ? this.nodes.get(this.current) : null;
      if (an?.alt) an.alt();
      return;
    }
    const dir = KEY[keyCode];
    if (dir && this.textEditing && (dir === 'left' || dir === 'right' || this.kbVisible)) return;
    if (dir) this.move(dir);
  }

  private async move(dir: Dir) {
    if (this.busy) { this.pendingDir = dir; return; } // keep only the latest key while busy (held arrow)
    this.busy = true;
    const t0 = Date.now();
    const m0 = this.measureCount;
    try {
      if (!this.isValid(this.current)) {
        await this.autoPick();
        return;
      }
      const curNode = this.nodes.get(this.current!)!;
      await this.ensureViewports();
      if (await this.fastMove(dir, curNode)) { this.perf.fast += 1; return; }
      const curRect = await this.freshMeasure(curNode);
      if (!curRect) { await this.autoPick(); return; }
      const others = Array.from(this.nodes.values()).filter(n => n.id !== curNode.id && n.modal === this.activeModal);
      // 1) estimate every control's position from memory (measure only controls never seen before)
      // PERF: never fire one bridge call per unknown control at once (363 controls = bridge jam = multi-second stalls).
      // Measure only the unknown controls closest to the current one (registration order ~ layout order), in small
      // batches; warm() measures the rest while idle.
      const order = new Map<string, number>();
      let oi = 0;
      for (const k of this.nodes.keys()) order.set(k, oi++);
      const ci = order.get(curNode.id) ?? 0;
      const unknownNodes = others
        .filter(n => !this.rectCache.has(n.id))
        .sort((a, b) => Math.abs((order.get(a.id) ?? 0) - ci) - Math.abs((order.get(b.id) ?? 0) - ci))
        .slice(0, 48);
      for (let i = 0; i < unknownNodes.length; i += 12) {
        await Promise.all(unknownNodes.slice(i, i + 12).map(n => this.freshMeasure(n)));
      }
      const known = others
        .map(n => ({ n, r: this.approxRect(n) }))
        .filter(a => a.r) as Array<{ n: NodeEntry; r: Rect }>;
      // 2) take the best few by estimate and measure just those for real
      const top = rankNeighbors(curRect, known.map(k => ({ id: k.n.id, r: k.r })), dir)
        .slice(0, 6); // the estimate is accurate while the cache is valid: the best match is virtually always in the top few
      const fresh = (await Promise.all(top.map(async t => ({ id: t.id, r: await this.freshMeasure(this.nodes.get(t.id)!) })))).filter(f => f.r) as Array<{ id: string; r: Rect }>;
      const targetId = pickNeighbor(curRect, fresh, dir);
      if (!targetId) return;
      this.autoEdit = this.textEditing; // typing in a field + ▼/▲ -> continue typing in the next field
      this.setCurrent(targetId);
      this.autoEdit = false;
      const tr = fresh.find(c => c.id === targetId)!.r;
      await this.scrollIntoView({ ...tr }, this.nodes.get(targetId)!.chain);
    } finally {
      this.busy = false;
      const p = this.perf;
      const took = Date.now() - t0;
      p.moves += 1; p.ms += took; p.max = Math.max(p.max, took); p.measures += this.measureCount - m0;
      if (p.moves >= 25 && this.perfSink) {
        this.perfSink(`D-pad: ${p.moves} moves (${p.fast} fast), avg ${Math.round(p.ms / p.moves)}ms, max ${p.max}ms, ${(p.measures / p.moves).toFixed(1)} measures/move, ${this.nodes.size} controls`);
        this.perf = { moves: 0, ms: 0, max: 0, measures: 0, fast: 0 };
      }
      const next = this.pendingDir;
      this.pendingDir = null;
      if (next) this.move(next);
    }
  }

  /**
   * Fast path: when EVERY control's position is already remembered, pick the neighbour from memory and (when the
   * screen is still) confirm just that one control with a single measure. While scrolling (a held arrow) no bridge
   * call is made at all. Returns false when anything is unknown or inconsistent → the caller uses the full path.
   */
  private async fastMove(dir: Dir, curNode: NodeEntry): Promise<boolean> {
    const curRect = this.approxRect(curNode);
    if (!curRect) return false;
    const known: Array<{ id: string; r: Rect }> = [];
    const unknown: NodeEntry[] = [];
    for (const n of this.nodes.values()) {
      if (n.id === curNode.id || n.modal !== this.activeModal) continue;
      const r = this.approxRect(n);
      if (r) known.push({ id: n.id, r });
      else unknown.push(n);
    }
    if (unknown.length) {
      // a control we have never measured could be the right answer, so measure it — but only when there are a few
      // (right after rows were added); with many unknowns the full path / warm-up handles it
      if (unknown.length > 12) return false;
      await Promise.all(unknown.map(n => this.freshMeasure(n)));
      for (const n of unknown) {
        const r = this.approxRect(n);
        if (r) known.push({ id: n.id, r });
      }
    }
    const best = rankNeighbors(curRect, known, dir)[0];
    if (!best) return false; // edge of the screen: let the full path make sure
    const target = this.nodes.get(best.id);
    const expected = this.approxRect(target!);
    if (!target || !expected) return false;
    let rect = expected;
    if (Date.now() - this.lastScrollAt > 150) {
      const fresh = await this.freshMeasure(target);
      if (!fresh) return false;
      // compare centres: the focus ring scales a control around its centre, so edges differ by a few px
      const dx = Math.abs(fresh.x + fresh.w / 2 - (expected.x + expected.w / 2));
      const dy = Math.abs(fresh.y + fresh.h / 2 - (expected.y + expected.h / 2));
      if (dx > 3 || dy > 3) {
        if (target.hint?.current) this.badHints.add(target.chain[0]); // our arithmetic was off: stop trusting hints for this list
        this.rectCache.clear();
        return false; // layout moved since we measured
      }
      rect = fresh;
    }
    this.autoEdit = this.textEditing;
    this.setCurrent(best.id);
    this.autoEdit = false;
    await this.scrollIntoView({ ...rect }, target.chain);
    return true;
  }

  /** Scroll every scroll container (inner → outer) so the focused control is fully visible. */
  private async scrollIntoView(t: Rect, chain: string[]): Promise<boolean> {
    let scrolled = false;
    for (const sid of chain) {
      const sc = this.scrollers.get(sid);
      const view = sc?.ref.current;
      if (!sc || !view) continue;
      const hostRef = { current: typeof view.getNativeScrollRef === 'function' ? view.getNativeScrollRef() : view };
      let vr = this.vpCache.get(sid) || null;
      if (!vr) { vr = await measure(hostRef); if (vr) this.vpCache.set(sid, vr); }
      if (!vr) continue;
      const margin = 28;
      let delta = 0;
      if (sc.axis === 'y') {
        if (t.y < vr.y + margin) delta = t.y - (vr.y + margin);
        else if (t.y + t.h > vr.y + vr.h - margin) delta = t.y + t.h - (vr.y + vr.h - margin);
      } else {
        if (t.x < vr.x + margin) delta = t.x - (vr.x + margin);
        else if (t.x + t.w > vr.x + vr.w - margin) delta = t.x + t.w - (vr.x + vr.w - margin);
      }
      if (!delta) continue;
      const next = Math.max(0, sc.offset.current + delta);
      try {
        if (typeof view.scrollToOffset === 'function') view.scrollToOffset({ offset: next, animated: true });
        else if (typeof view.scrollTo === 'function') view.scrollTo(sc.axis === 'y' ? { y: next, animated: true } : { x: next, animated: true });
      } catch { /* ignore */ }
      sc.offset.current = next;
      scrolled = true;
      if (sc.axis === 'y') t = { ...t, y: t.y - delta }; else t = { ...t, x: t.x - delta };
    }
    return scrolled;
  }
}

export const tvEngine = new TVFocusEngine();

let nodeCounter = 0;
let scrollerCounter = 0;

/* ------------------------------------------------------------------ */
/* Scrollers                                                           */
/* ------------------------------------------------------------------ */
export function useTVScroller(axis: 'x' | 'y' = 'y') {
  const id = useRef(`s${++scrollerCounter}`).current;
  const ref = useRef<any>(null);
  const offset = useRef(0);
  const actual = useRef(0);
  const parent = useContext(TVScrollerChain);
  const scope = useMemo(() => [id, ...parent], [id, parent]);
  useEffect(() => {
    tvEngine.registerScroller(id, { axis, ref, offset, actual });
    return () => tvEngine.unregisterScroller(id);
  }, [id, axis]);
  const onScroll = useCallback((e: any) => {
    const o = e?.nativeEvent?.contentOffset;
    if (o) { offset.current = axis === 'y' ? o.y : o.x; actual.current = offset.current; }
    tvEngine.bump();
    scrollIdle.noteScroll();
  }, [axis]);
  return { ref, onScroll, scope };
}

export function TVScope({ scope, children }: { scope: string[]; children: React.ReactNode }) {
  return <TVScrollerChain.Provider value={scope}>{children}</TVScrollerChain.Provider>;
}

/** Wrap an RN <Modal>: its content lives in its own window, so it uses native focus. */
export function TVModalLayer({ children }: { children: React.ReactNode }) {
  return <TVLayerContext.Provider value="modal">{children}</TVLayerContext.Provider>;
}

let modalCounter = 0;
/**
 * Use INSIDE a <Modal> whose content must be remote-controllable on TV boxes where Android's
 * native focus does not work inside dialog windows. While mounted, the JS engine drives this
 * dialog (D-Pad key-ups are forwarded by MainActivity.onKeyUp). Off TV it changes nothing.
 */
export function TVEngineLayer({ children }: { children: React.ReactNode }) {
  const tvMode = useContext(TVModeContext);
  const parentLayer = useContext(TVLayerContext);
  const nested = parentLayer === 'engine'; // an outer <TVEngineLayer> already drives this dialog
  const id = useRef(`m${++modalCounter}`).current;
  useEffect(() => {
    if (!tvMode || nested) return;
    tvEngine.pushModal(id);
    return () => tvEngine.popModal(id);
  }, [tvMode, nested, id]);
  if (nested) return <>{children}</>;
  return (
    <TVLayerContext.Provider value={tvMode ? 'engine' : 'modal'}>
      <TVModalIdContext.Provider value={tvMode ? id : null}>{children}</TVModalIdContext.Provider>
    </TVLayerContext.Provider>
  );
}

/* ------------------------------------------------------------------ */
/* TVPressable: drop-in replacement for Pressable                      */
/* ------------------------------------------------------------------ */
const FOCUS_STYLE = {
  borderColor: '#ff5a66',
  borderWidth: 2,
  backgroundColor: 'rgba(225,29,46,0.18)',
  shadowColor: '#e11d2e',
  shadowOpacity: 0.7,
  shadowRadius: 10,
  elevation: 8,
  transform: [{ scale: 1.04 }],
};

/** Cheap focus ring for long lists: border + tint only (no shadow/elevation/scale, which are expensive on weak TV GPUs). */
const LITE_FOCUS_STYLE = {
  borderColor: '#ff5a66',
  borderWidth: 2,
  backgroundColor: 'rgba(225,29,46,0.22)',
};

export const TVPressable = React.forwardRef<any, any>((props, fwd) => {
  const { style, onFocus, onBlur, onPress, onAltPress, lite, focusStyle: customFocus, __onId, tvLayout, ...rest } = props;
  const tvMode = useContext(TVModeContext);
  const layer = useContext(TVLayerContext);
  const chain = useContext(TVScrollerChain);
  const modalId = useContext(TVModalIdContext);
  const engineMode = tvMode && (layer === 'main' || layer === 'engine');
  const entryModal = layer === 'engine' ? modalId : null;

  const idRef = useRef<string>('');
  if (!idRef.current) idRef.current = `n${++nodeCounter}`;
  const id = idRef.current;
  const inner = useRef<any>(null);
  useEffect(() => { __onId?.(id); }, [__onId, id]);
  const live = useRef<{ onPress: any; onAlt: any; nativeAt: number; keyAt: number }>({ onPress, onAlt: onAltPress, nativeAt: 0, keyAt: 0 });
  live.current.onPress = onPress;
  live.current.onAlt = onAltPress;
  const hasAlt = !!onAltPress;
  const hintRef = useRef<TVLayoutHint | undefined>(tvLayout);
  hintRef.current = tvLayout;

  const [nativeFocused, setNativeFocused] = useState(false);
  const [engineFocused, setEngineFocused] = useState(false);

  const press = useCallback(() => {
    const now = Date.now();
    if (now - live.current.nativeAt < 350) return; // already handled by a native click
    live.current.keyAt = now;
    live.current.onPress?.({ nativeEvent: {} });
  }, []);

  useEffect(() => {
    if (!engineMode || props.disabled) return;
    tvEngine.register({ id, ref: inner, chain, preferred: !!props.hasTVPreferredFocus, press, alt: hasAlt ? () => live.current.onAlt?.() : undefined, modal: entryModal, hint: hintRef });
    const unsub = tvEngine.subscribe(id, setEngineFocused);
    return () => { unsub(); tvEngine.unregister(id); setEngineFocused(false); };
  }, [engineMode, props.disabled, props.hasTVPreferredFocus, chain, id, press, entryModal, hasAlt]);

  useEffect(() => () => { if (tvEngine.nativeFocus?.id === id) tvEngine.nativeFocus = null; }, [id]);

  const setRefs = useCallback((node: any) => {
    inner.current = node;
    if (typeof fwd === 'function') fwd(node);
    else if (fwd) (fwd as any).current = node;
  }, [fwd]);

  const focused = engineFocused || nativeFocused;
  const ring = focused ? [lite ? LITE_FOCUS_STYLE : FOCUS_STYLE, customFocus] : null;
  const resolvedStyle = typeof style === 'function'
    ? (state: any) => [style({ ...state, focused }), ring]
    : [style, ring];

  return (
    <RNPressable
      ref={setRefs}
      {...rest}
      accessible={props.accessible !== false}
      accessibilityRole={props.accessibilityRole || 'button'}
      importantForAccessibility="yes"
      focusable={engineMode ? false : props.focusable !== false}
      style={resolvedStyle}
      onPress={(e: any) => {
        const now = Date.now();
        if (now - live.current.keyAt < 350) return; // already handled by the remote's OK key
        live.current.nativeAt = now;
        if (engineMode) tvEngine.touched(id);
        onPress?.(e);
      }}
      onFocus={(e: any) => {
        setNativeFocused(true);
        if (layer === 'modal') tvEngine.nativeFocus = { id, press };
        onFocus?.(e);
      }}
      onBlur={(e: any) => {
        setNativeFocused(false);
        if (tvEngine.nativeFocus?.id === id) tvEngine.nativeFocus = null;
        onBlur?.(e);
      }}
    />
  );
});
TVPressable.displayName = 'TVPressable';

/* ------------------------------------------------------------------ */
/* TVTextInput: TextInput that the remote can select with OK           */
/* ------------------------------------------------------------------ */
/**
 * In engine mode (TV) the input is wrapped in a TVPressable: D-Pad moves the highlight onto it,
 * OK makes it editable + focused (opens the on-screen keyboard), and moving away blurs it.
 * Outside engine mode it is a plain TextInput. Exposes focus() so "next" on the keyboard works.
 */
const TEXT_FOCUS = { borderColor: '#ff5a66', borderWidth: 2, backgroundColor: '#2a1c26' };
export const TVTextInput = React.forwardRef<any, any>((props, fwd) => {
  const { wrapStyle, onFocus, onBlur, hasTVPreferredFocus, autoFocus, ...rest } = props;
  const tvMode = useContext(TVModeContext);
  const layer = useContext(TVLayerContext);
  const engineMode = tvMode && (layer === 'main' || layer === 'engine');
  const input = useRef<any>(null);
  const wrapRef = useRef<any>(null);
  const [editing, setEditing] = useState(!!autoFocus && engineMode);
  const [nodeId, setNodeId] = useState<string>('');
  const wasFocused = useRef(false);
  const [engineFocused, setEngineFocused] = useState(false);

  const begin = useCallback(() => setEditing(true), []);

  React.useImperativeHandle(fwd, () => ({
    focus: () => {
      if (!engineMode) { input.current?.focus(); return; }
      if (nodeId) tvEngine.focusNode(nodeId);
      setEditing(true);
    },
    blur: () => input.current?.blur(),
  }), [engineMode, nodeId]);

  useEffect(() => {
    if (editing) {
      const t = setTimeout(() => input.current?.focus(), 30);
      return () => clearTimeout(t);
    }
  }, [editing]);
  // while typing, ◀ ▶ move the caret instead of leaving the field
  useEffect(() => {
    if (!engineMode) return;
    tvEngine.textEditing = editing;
    return () => { tvEngine.textEditing = false; };
  }, [editing, engineMode]);

  // keyboard closed (Back): leave edit mode but keep the highlight, so ▲ ▼ move between fields again
  useEffect(() => {
    if (!engineMode || !editing) return;
    const sub = Keyboard.addListener('keyboardDidHide', () => { setEditing(false); input.current?.blur(); });
    return () => sub.remove();
  }, [engineMode, editing]);

  // keep editing only while the highlight stays on this control
  useEffect(() => {
    if (!engineMode || !nodeId) return;
    return tvEngine.subscribe(nodeId, f => {
      setEngineFocused(f);
      if (f) { wasFocused.current = true; if (tvEngine.autoEdit) setEditing(true); }
      else if (wasFocused.current) { wasFocused.current = false; setEditing(false); input.current?.blur(); }
    });
  }, [engineMode, nodeId]);

  if (!engineMode) {
    return <TextInput ref={input} autoFocus={autoFocus} {...rest} onFocus={onFocus} onBlur={onBlur} />;
  }
  return (
    <TVPressable
      ref={wrapRef}
      onPress={begin}
      hasTVPreferredFocus={hasTVPreferredFocus || !!autoFocus}
      style={wrapStyle}
      focusStyle={{ transform: [{ scale: 1 }], borderRadius: 14, borderWidth: 0, backgroundColor: 'transparent', shadowOpacity: 0, elevation: 0 }}
      __onId={setNodeId}
    >
      <TextInput
        ref={input}
        {...rest}
        style={[rest.style, engineFocused && TEXT_FOCUS]}
        editable={editing && rest.editable !== false}
        pointerEvents={editing ? 'auto' : 'none'}
        onFocus={onFocus}
        onBlur={(e: any) => { setEditing(false); onBlur?.(e); }}
      />
    </TVPressable>
  );
});
TVTextInput.displayName = 'TVTextInput';

/* ------------------------------------------------------------------ */
/* Scrollable lists that auto-scroll to the remote-focused control      */
/* ------------------------------------------------------------------ */
function makeTVScrollable(Base: any, name: string) {
  const C = React.forwardRef<any, any>((props, fwd) => {
    const { onScroll: userScroll, ...rest } = props;
    const { ref, onScroll, scope } = useTVScroller(props.horizontal ? 'x' : 'y');
    const setRef = useCallback((node: any) => {
      (ref as any).current = node;
      if (typeof fwd === 'function') fwd(node);
      else if (fwd) (fwd as any).current = node;
    }, [fwd, ref]);
    return (
      <TVScope scope={scope}>
        <Base
          {...rest}
          ref={setRef}
          scrollEventThrottle={16}
          onScroll={(e: any) => { onScroll(e); userScroll?.(e); }}
        />
      </TVScope>
    );
  });
  C.displayName = name;
  return C;
}
export const TVScrollView = makeTVScrollable(ScrollView, 'TVScrollView');
export const TVFlatList = makeTVScrollable(FlatList, 'TVFlatList');
