/**
 * Provider health check: runs a small battery of real requests against one provider and reports pass/fail per
 * service, so the person can tell at a glance whether a problem is in the app or on the provider's side — and paste
 * the result when asking the provider for help.
 */
import type { Provider } from '../types';
import { xtream } from './sources';
import { serverCandidates } from '../utils/media';
import { uaFor } from './userAgent';

export type CheckItem = { id: string; label: [string, string]; ok: boolean | null; ms: number; detail: string };

async function timeIt<T>(fn: () => Promise<T>): Promise<{ ok: boolean; ms: number; detail: string; value?: T }> {
  const t0 = Date.now();
  try {
    const value = await fn();
    return { ok: true, ms: Date.now() - t0, detail: '', value };
  } catch (e: any) {
    return { ok: false, ms: Date.now() - t0, detail: String(e?.detail || e?.message || e || '').slice(0, 140) };
  }
}

/** Runs the checks in order (later ones reuse data from earlier ones, e.g. a real channel/movie id), 4s each by default. */
export async function runProviderCheck(provider: Provider, onStep?: (items: CheckItem[]) => void): Promise<CheckItem[]> {
  const items: CheckItem[] = [
    { id: 'auth', label: ['تسجيل الدخول', 'Login'], ok: null, ms: 0, detail: '' },
    { id: 'live', label: ['قائمة القنوات', 'Channel list'], ok: null, ms: 0, detail: '' },
    { id: 'movies', label: ['قائمة الأفلام', 'Movie list'], ok: null, ms: 0, detail: '' },
    { id: 'series', label: ['قائمة المسلسلات', 'Series list'], ok: null, ms: 0, detail: '' },
    { id: 'vodinfo', label: ['تفاصيل فيلم', 'Movie details'], ok: null, ms: 0, detail: '' },
    { id: 'seriesinfo', label: ['تفاصيل مسلسل', 'Series details'], ok: null, ms: 0, detail: '' },
    { id: 'epg', label: ['دليل البرامج (EPG)', 'Programme guide (EPG)'], ok: null, ms: 0, detail: '' },
    { id: 'stream', label: ['فتح بث مباشر', 'Opening a live stream'], ok: null, ms: 0, detail: '' },
  ];
  const push = () => onStep?.(items.map(i => ({ ...i })));
  push();

  const auth = await timeIt(() => xtream<any>(provider, '', { timeoutMs: 15000 }));
  Object.assign(items[0], { ok: auth.ok, ms: auth.ms, detail: auth.ok ? (auth.value?.user_info?.status || 'OK') : auth.detail });
  push();
  if (!auth.ok) { for (let i = 1; i < items.length; i++) items[i].detail = ''; return items; } // nothing else will work without this

  const live = await timeIt(() => xtream<any[]>(provider, 'action=get_live_streams', { quick: true, timeoutMs: 15000 }));
  const liveList = Array.isArray(live.value) ? live.value : [];
  Object.assign(items[1], { ok: live.ok && liveList.length > 0, ms: live.ms, detail: live.ok ? `${liveList.length}` : live.detail });
  push();

  const movies = await timeIt(() => xtream<any[]>(provider, 'action=get_vod_streams', { quick: true, timeoutMs: 15000 }));
  const movieList = Array.isArray(movies.value) ? movies.value : [];
  Object.assign(items[2], { ok: movies.ok && movieList.length > 0, ms: movies.ms, detail: movies.ok ? `${movieList.length}` : movies.detail });
  push();

  const series = await timeIt(() => xtream<any[]>(provider, 'action=get_series', { quick: true, timeoutMs: 15000 }));
  const seriesList = Array.isArray(series.value) ? series.value : [];
  Object.assign(items[3], { ok: series.ok && seriesList.length > 0, ms: series.ms, detail: series.ok ? `${seriesList.length}` : series.detail });
  push();

  if (movieList[0]?.stream_id) {
    const vi = await timeIt(() => xtream<any>(provider, `action=get_vod_info&vod_id=${movieList[0].stream_id}`, { quick: true, timeoutMs: 15000 }));
    Object.assign(items[4], { ok: vi.ok, ms: vi.ms, detail: vi.ok ? 'OK' : vi.detail });
  } else { items[4].detail = 'no movie to test'; }
  push();

  if (seriesList[0]?.series_id) {
    const si = await timeIt(() => xtream<any>(provider, `action=get_series_info&series_id=${seriesList[0].series_id}`, { quick: true, timeoutMs: 20000 }));
    Object.assign(items[5], { ok: si.ok, ms: si.ms, detail: si.ok ? 'OK' : si.detail });
  } else { items[5].detail = 'no series to test'; }
  push();

  if (liveList[0]?.stream_id) {
    const eg = await timeIt(() => xtream<any>(provider, `action=get_short_epg&stream_id=${liveList[0].stream_id}&limit=5`, { quick: true, timeoutMs: 12000 }));
    const n = Array.isArray(eg.value?.epg_listings) ? eg.value.epg_listings.length : 0;
    Object.assign(items[6], { ok: eg.ok && n > 0, ms: eg.ms, detail: eg.ok ? `${n}` : eg.detail });
  } else { items[6].detail = 'no channel to test'; }
  push();

  if (liveList[0]?.stream_id) {
    const base = serverCandidates(provider.server)[0];
    const url = `${base}/live/${provider.username}/${provider.password}/${liveList[0].stream_id}.ts`;
    const st = await timeIt(async () => {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 8000);
      try {
        const res = await fetch(url, { method: 'GET', headers: { Range: 'bytes=0-4095', 'User-Agent': uaFor(provider) }, signal: controller.signal });
        if (!res.ok && res.status !== 206) throw new Error(`HTTP ${res.status}`);
        return res.status;
      } finally { clearTimeout(timer); }
    });
    // this only checks that the stream URL answers with data, not full playback (codecs, continued delivery, etc.)
    Object.assign(items[7], { ok: st.ok, ms: st.ms, detail: st.ok ? `HTTP ${st.value}` : st.detail });
  } else { items[7].detail = 'no channel to test'; }
  push();

  return items;
}

export function formatReport(provider: Provider, items: CheckItem[], isEnglish: boolean): string {
  const lines = [
    `TurboX — ${isEnglish ? 'Provider check' : 'فحص المزوّد'}: ${provider.name}`,
    new Date().toString(),
    '',
    ...items.map(i => {
      const mark = i.ok === null ? '?' : i.ok ? 'OK' : 'FAIL';
      const label = i.label[isEnglish ? 1 : 0];
      return `[${mark}] ${label} — ${i.ms}ms${i.detail ? `  (${i.detail})` : ''}`;
    }),
  ];
  return lines.join('\n');
}
