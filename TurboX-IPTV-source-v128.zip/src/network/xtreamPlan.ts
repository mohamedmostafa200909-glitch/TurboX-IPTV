/**
 * How hard to try one Xtream request. Pure.
 * - login / catalogue downloads are worth waiting for: both address variants (http/https), two attempts each.
 * - "quick" requests (movie details, programme guide, season list) are optional extras: ONE attempt on the address that
 *   already worked, short timeout. A provider whose guide endpoint hangs must not pin dozens of sockets for minutes.
 */
export type AttemptPlan = { server: string; timeouts: number[] };

export function planAttempts(candidates: string[], preferred: string | undefined, quick: boolean, quickTimeoutMs = 10000): AttemptPlan[] {
  const ordered = preferred && candidates.includes(preferred) ? [preferred, ...candidates.filter(c => c !== preferred)] : candidates;
  if (quick) return ordered.slice(0, 1).map(server => ({ server, timeouts: [quickTimeoutMs] }));
  return ordered.map(server => ({ server, timeouts: [30000, 45000] }));
}
