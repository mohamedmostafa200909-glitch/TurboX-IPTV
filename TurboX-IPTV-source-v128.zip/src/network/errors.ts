/**
 * Splits "could not load the source" into causes the user can act on.
 * Pure (no React Native imports) so it can be unit-tested.
 */
export type IptvErrorKind = 'offline' | 'timeout' | 'unreachable' | 'auth' | 'expired' | 'disabled' | 'notfound' | 'blocked' | 'server' | 'badresponse' | 'unknown';

export class IptvError extends Error {
  kind: IptvErrorKind;
  detail: string;
  constructor(kind: IptvErrorKind, detail = '') {
    super(`${kind}${detail ? `: ${detail}` : ''}`);
    this.name = 'IptvError';
    this.kind = kind;
    this.detail = detail;
  }
}

export function kindFromHttp(status: number): IptvErrorKind {
  if (status === 401) return 'auth';
  if (status === 403 || status === 458 || status === 884) return 'blocked';
  if (status === 404) return 'notfound';
  if (status >= 500) return 'server';
  return 'unknown';
}

/** Xtream answers 200 with a user_info block even for bad accounts: read the account state from it. */
export function kindFromPayload(payload: any): IptvErrorKind | null {
  if (!payload || typeof payload !== 'object') return null;
  const status = String(payload.user_info?.status || '').toLowerCase();
  if (payload.user_info?.auth === 0 || payload.user_info?.auth === '0') {
    if (status === 'expired') return 'expired';
    if (status === 'banned' || status === 'disabled') return 'disabled';
    return 'auth';
  }
  if (payload.error) return 'auth';
  return null;
}

export function kindFromFetchError(error: any, timedOut: boolean): IptvErrorKind {
  if (timedOut || error?.name === 'AbortError') return 'timeout';
  if (error instanceof SyntaxError) return 'badresponse'; // reply was not JSON (wrong URL / a web page)
  return 'unreachable';
}

const TEXT: Record<IptvErrorKind, { ar: [string, string]; en: [string, string] }> = {
  offline: { ar: ['لا يوجد اتصال بالإنترنت', 'تأكد من الواي فاي أو الشبكة ثم أعد المحاولة.'], en: ['No internet connection', 'Check your Wi‑Fi or network and try again.'] },
  timeout: { ar: ['السيرفر لا يرد', 'السيرفر بطيء أو متوقف مؤقتًا. جرّب بعد قليل، وإن استمر فاسأل مزوّد الخدمة.'], en: ['The server is not responding', 'It is slow or temporarily down. Try again shortly; if it persists, ask your provider.'] },
  unreachable: { ar: ['تعذر الوصول إلى السيرفر', 'راجع رابط السيرفر والمنفذ (مثال: http://example.com:8080) وتأكد أن السيرفر يعمل.'], en: ['Could not reach the server', 'Check the server address and port (e.g. http://example.com:8080) and that the server is up.'] },
  auth: { ar: ['اسم المستخدم أو كلمة المرور غير صحيحة', 'راجع بيانات الدخول بدقة (الحروف الكبيرة والصغيرة).'], en: ['Wrong username or password', 'Re-check the login details (upper/lower case matters).'] },
  expired: { ar: ['انتهى الاشتراك', 'جدّد الاشتراك لدى المزوّد ثم أعد المحاولة.'], en: ['Subscription expired', 'Renew it with your provider, then try again.'] },
  disabled: { ar: ['الحساب موقوف أو محظور', 'تواصل مع مزوّد الخدمة لتفعيله.'], en: ['Account disabled or banned', 'Contact your provider to re-enable it.'] },
  notfound: { ar: ['الرابط غير صحيح (404)', 'السيرفر موجود لكن المسار غير صحيح. تأكد من الرابط والمنفذ.'], en: ['Wrong address (404)', 'The server answers but this path does not exist. Check the address and port.'] },
  blocked: { ar: ['السيرفر رفض الاتصال', 'قد يحجب المزوّد هذا الجهاز أو الشبكة. جرّب شبكة أخرى أو اسأل المزوّد.'], en: ['The server refused the connection', 'The provider may block this device or network. Try another network or ask the provider.'] },
  server: { ar: ['خطأ داخل السيرفر', 'عطل مؤقت عند المزوّد. أعد المحاولة لاحقًا.'], en: ['Server error', 'A temporary fault at the provider. Try again later.'] },
  badresponse: { ar: ['رد غير متوقع من السيرفر', 'الرابط لا يشير إلى سيرفر Xtream. تأكد أنه رابط السيرفر وليس موقعًا آخر.'], en: ['Unexpected reply', 'The address does not look like an Xtream server. Make sure it is the server address.'] },
  unknown: { ar: ['تعذر تحميل المصدر', 'تأكد من الرابط وبيانات الاشتراك ثم أعد المحاولة.'], en: ['Could not load the source', 'Check the address and subscription details, then try again.'] },
};

export function describeError(error: any, isEnglish: boolean, offline = false): { kind: IptvErrorKind; title: string; text: string } {
  let kind: IptvErrorKind = error instanceof IptvError ? error.kind : 'unknown';
  // a network failure while the device itself is offline is not the server's fault
  if (offline && (kind === 'unreachable' || kind === 'timeout')) kind = 'offline';
  const [title, fix] = TEXT[kind][isEnglish ? 'en' : 'ar'];
  const detail = error instanceof IptvError ? error.detail : String(error?.message || '');
  return { kind, title, text: detail && kind !== 'offline' ? `${fix}\n(${detail})` : fix };
}
