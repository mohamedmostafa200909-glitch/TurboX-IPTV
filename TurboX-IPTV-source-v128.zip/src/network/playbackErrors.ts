/**
 * Turns the raw player error (ExoPlayer text from expo-av / the native Media3 view) into a cause the user can act on.
 * Pure: unit-tested. `detail` may contain stream URLs — callers log it through the redacting logger.
 */
export type PlaybackErrorKind = 'http-auth' | 'http-notfound' | 'http-server' | 'network' | 'codec' | 'format' | 'stalled' | 'unknown';

const T: Record<PlaybackErrorKind, { ar: string; en: string }> = {
  'http-auth': { ar: 'السيرفر رفض البث (غالبًا الاشتراك منتهٍ، أو الحساب يُستخدم على جهاز آخر بحدّ الاتصالات، أو الجهاز/الشبكة محظور).', en: 'The server refused the stream (subscription expired, the account is in use on another device (connection limit), or this device/network is blocked).' },
  'http-notfound': { ar: 'هذا العنصر غير موجود على السيرفر (404). جرّب عنصرًا آخر أو حدّث القوائم.', en: 'This item does not exist on the server (404). Try another one or refresh the lists.' },
  'http-server': { ar: 'عطل داخل سيرفر البث. أعد المحاولة لاحقًا.', en: 'A fault inside the streaming server. Try again later.' },
  network: { ar: 'تعذر الاتصال بسيرفر البث من هذا الجهاز (الشبكة بطيئة أو محجوبة، أو العنوان/المنفذ لا يعمل).', en: 'This device could not reach the streaming server (slow or blocked network, or the address/port is down).' },
  codec: { ar: 'هذا الجهاز لا يدعم ترميز الفيديو أو الصوت لهذا البث (مثل HEVC أو AC3). جرّب مشغّلًا آخر من الإعدادات.', en: 'This device cannot decode the video/audio format of this stream (e.g. HEVC or AC3). Try another player in Settings.' },
  format: { ar: 'صيغة البث غير مدعومة أو الرد ليس فيديو. جرّب مشغّلًا آخر من الإعدادات.', en: 'Unsupported stream format, or the reply is not video. Try another player in Settings.' },
  stalled: { ar: 'السيرفر بطيء جدًا في بدء البث (لا بيانات).', en: 'The server is too slow to start the stream (no data).' },
  unknown: { ar: 'تعذر تشغيل البث. جرّب مشغّلًا آخر من الإعدادات.', en: 'Could not play the stream. Try another player in Settings.' },
};

export function classifyPlaybackError(detail: string): PlaybackErrorKind {
  const d = String(detail || '');
  const code = d.match(/Response code:?\s*(\d{3})/i)?.[1] || d.match(/HTTP\s*(?:status|error)?\s*[: ]\s*(\d{3})/i)?.[1];
  if (code) {
    const n = Number(code);
    if (n === 401 || n === 403 || n === 458 || n === 884 || n === 429) return 'http-auth';
    if (n === 404 || n === 410) return 'http-notfound';
    if (n >= 500) return 'http-server';
  }
  if (/stalled|no data/i.test(d)) return 'stalled';
  if (/decoder init failed|MediaCodecRenderer|exceeds[_ ]capabilities|NO_EXCEEDS|audio\/(e?ac3|dts|true-?hd)|video\/hevc|Decoding failed|ERROR_CODE_DECOD/i.test(d)) return 'codec';
  if (/Unable to connect|UnknownHost|UnresolvedAddress|SocketTimeout|ConnectException|timed? ?out|ERROR_CODE_IO_NETWORK|Connection (reset|refused)|SSLHandshake|Cleartext/i.test(d)) return 'network';
  if (/UnrecognizedInputFormat|ParserException|Malformed|ERROR_CODE_PARSING|Source error|content-type/i.test(d)) return 'format';
  return 'unknown';
}

export function describePlaybackError(detail: string, isEnglish: boolean): { kind: PlaybackErrorKind; text: string } {
  const kind = classifyPlaybackError(detail);
  const short = String(detail || '').replace(/https?:\/\/\S+/g, '').replace(/\s+/g, ' ').trim().slice(0, 140);
  const text = T[kind][isEnglish ? 'en' : 'ar'];
  return { kind, text: short ? `${text}\n\n(${short})` : text };
}
