/**
 * Per-provider User-Agent. Some panels block third-party players with a 403 unless the request looks like a known
 * client (VLC, Apple TV, a browser…). The value is stored verbatim on the provider (empty/undefined = the app's
 * default, VLC, which is what every existing provider already used — this is purely additive).
 */
export const UA_DEFAULT = 'VLC/3.0.21 LibVLC/3.0.21';

export const UA_PRESETS: Array<{ id: string; ua: string; label: [string, string] }> = [
  { id: 'vlc', ua: UA_DEFAULT, label: ['VLC (افتراضي)', 'VLC (default)'] },
  { id: 'appletv', ua: 'AppleCoreMedia/1.0.0.21G93 (Apple TV; U; CPU OS 17_5 like Mac OS X; en_us)', label: ['Apple TV', 'Apple TV'] },
  { id: 'safari', ua: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15', label: ['Safari', 'Safari'] },
  { id: 'android', ua: 'Mozilla/5.0 (Linux; Android 13; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36', label: ['Android', 'Android'] },
];

export function uaFor(source?: { userAgent?: string } | null): string {
  const v = source?.userAgent?.trim();
  return v || UA_DEFAULT;
}
