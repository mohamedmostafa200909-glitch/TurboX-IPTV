/**
 * Checks GitHub Releases for a newer version than the one currently installed. Pure comparison logic is exported
 * separately so it can be unit-tested without touching the network.
 *
 * IMPORTANT: this only works once REPO below is set to this project's real "owner/name" on GitHub (the app has no
 * way to know that on its own). Until then checkForUpdate() always resolves to null — no network call, no UI, the
 * feature is simply inert, not broken.
 */
export const REPO = ''; // e.g. 'yourname/turbox-iptv' — set this to enable update checks

/** Compares two "vX.Y.Z"-style versions (the 'v' prefix, if any, and any trailing text like "-beta" are ignored
 *  for the numeric comparison). Returns >0 if a is newer, <0 if b is newer, 0 if equal. */
export function compareVersions(a: string, b: string): number {
  const parts = (v: string) => v.trim().replace(/^v/i, '').split(/[.+-]/).map(n => parseInt(n, 10) || 0);
  const pa = parts(a);
  const pb = parts(b);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

export type UpdateInfo = { version: string; url: string; notes: string };

/** Resolves to the newer release's info, or null when there is none, REPO is unset, or the check failed for any
 *  reason (network, rate limit, no releases yet) — always fails silently, this must never interrupt the person. */
export async function checkForUpdate(currentVersion: string, timeoutMs = 8000): Promise<UpdateInfo | null> {
  if (!REPO) return null;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(`https://api.github.com/repos/${REPO}/releases/latest`, {
      signal: controller.signal,
      headers: { Accept: 'application/vnd.github+json' },
    });
    if (!res.ok) return null;
    const data = await res.json();
    const tag = String(data?.tag_name || '');
    if (!tag || data?.draft) return null;
    if (compareVersions(tag, currentVersion) <= 0) return null;
    return { version: tag.replace(/^v/i, ''), url: String(data?.html_url || `https://github.com/${REPO}/releases/latest`), notes: String(data?.body || '').slice(0, 500) };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}
