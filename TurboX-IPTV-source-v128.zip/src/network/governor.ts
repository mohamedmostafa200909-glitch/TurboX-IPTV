/**
 * Request governor: stops hammering a provider that keeps refusing us.
 *
 * Some panels answer bursts of detail requests (guide, movie/series info) with custom nginx codes (460/469) or time out.
 * After a few failures in a row for one provider and one kind of request we pause that kind for a while (growing
 * exponentially if it keeps failing); a success clears everything. Also spaces out requests of the same kind.
 * Pure (time is injectable) so it can be unit-tested.
 */
export type GovClass = 'epg' | 'info';

type Entry = { fails: number; trips: number; until: number; nextStart: number };

const DEFAULTS: Record<GovClass, { threshold: number; basePauseMs: number }> = {
  epg: { threshold: 3, basePauseMs: 10 * 60_000 }, // background guide requests: back off for a long time
  info: { threshold: 2, basePauseMs: 45_000 },     // user-opened details: short pause, then one probe
};
const MAX_PAUSE_MS = 30 * 60_000;

export function createGovernor(now: () => number = () => Date.now()) {
  const map = new Map<string, Entry>();
  const get = (provider: string, cls: GovClass): Entry => {
    const k = `${provider}|${cls}`;
    let e = map.get(k);
    if (!e) { e = { fails: 0, trips: 0, until: 0, nextStart: 0 }; map.set(k, e); }
    return e;
  };
  return {
    /** epoch ms until which this kind of request is paused (0 when it may go out) */
    pausedUntil(provider: string, cls: GovClass): number {
      const e = get(provider, cls);
      return e.until > now() ? e.until : 0;
    },
    success(provider: string, cls: GovClass) {
      const e = get(provider, cls);
      e.fails = 0; e.trips = 0; e.until = 0;
    },
    /** returns tripped=true when this failure started a pause */
    failure(provider: string, cls: GovClass): { tripped: boolean; until: number } {
      const e = get(provider, cls);
      e.fails += 1;
      if (e.fails < DEFAULTS[cls].threshold) return { tripped: false, until: 0 };
      e.fails = 0;
      e.trips += 1;
      e.until = now() + Math.min(MAX_PAUSE_MS, DEFAULTS[cls].basePauseMs * 2 ** (e.trips - 1));
      return { tripped: true, until: e.until };
    },
    /** how long to wait before starting a request of this kind so starts are at least gapMs apart (reserves the slot) */
    paceDelay(provider: string, cls: GovClass, gapMs: number): number {
      const e = get(provider, cls);
      const t = now();
      const start = Math.max(t, e.nextStart);
      e.nextStart = start + gapMs;
      return start - t;
    },
    reset(provider?: string) {
      for (const k of Array.from(map.keys())) if (!provider || k.startsWith(`${provider}|`)) map.delete(k);
    },
  };
}

export type Governor = ReturnType<typeof createGovernor>;
