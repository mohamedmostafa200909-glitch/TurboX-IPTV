/**
 * Connection test for the login screen: checks the server, the credentials and the
 * subscription without loading the whole catalogue. Supports Xtream Codes and M3U links.
 */
export type TestForm = { server: string; username: string; password: string; userAgent?: string };
export type TestResult = { ok: boolean; title: string; lines: string[] };

import { uaFor } from './userAgent';

const M3U_RE = /\.m3u8?(?:\?|$)/i;

export function normalizeServer(value: string) {
  let server = value.trim().replace(/\s+/g, '');
  if (!/^https?:\/\//i.test(server)) server = `http://${server}`;
  server = server.replace(/\/(player_api|get)\.php.*$/i, '');
  return server.replace(/\/$/, '');
}

export function candidates(value: string) {
  const server = normalizeServer(value);
  const list = [server];
  if (/^https:\/\//i.test(server)) list.push(server.replace(/^https:\/\//i, 'http://'));
  else list.push(server.replace(/^http:\/\//i, 'https://'));
  return [...new Set(list)];
}

export async function timedFetch(url: string, ms: number, headers: Record<string, string> = {}, userAgent?: string) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  try {
    return await fetch(url, { signal: controller.signal, headers: { 'User-Agent': uaFor({ userAgent }), 'Cache-Control': 'no-cache', ...headers } });
  } finally {
    clearTimeout(timer);
  }
}

const dateOf = (sec: any) => {
  const n = Number(sec);
  if (!n) return null;
  return new Date(n * 1000);
};

export async function testIptvConnection(form: TestForm, isEnglish: boolean): Promise<TestResult> {
  const tx = (ar: string, en: string) => (isEnglish ? en : ar);
  const server = form.server.trim();
  if (!server) return { ok: false, title: tx('أدخل رابط السيرفر', 'Enter the server URL'), lines: [] };

  // Local file picked from the device
  if (server.startsWith('file://')) {
    return { ok: true, title: tx('ملف M3U محلي', 'Local M3U file'), lines: [tx('تم اختيار الملف من الجهاز.', 'File selected from the device.')] };
  }

  const started = Date.now();

  /* ---------------- M3U link ---------------- */
  if (M3U_RE.test(server) || /iptv-org\.github\.io/i.test(server)) {
    try {
      const res = await timedFetch(server, 25000, {}, form.userAgent);
      if (!res.ok) return { ok: false, title: tx(`رد السيرفر: HTTP ${res.status}`, `Server replied: HTTP ${res.status}`), lines: [tx('تأكد من الرابط وصلاحيته.', 'Check the link and that it is still valid.')] };
      const text = await res.text();
      if (!/^\s*#EXTM3U/i.test(text)) return { ok: false, title: tx('الرابط لا يحتوي على قائمة M3U صالحة', 'The link is not a valid M3U playlist'), lines: [] };
      const count = (text.match(/#EXTINF/gi) || []).length;
      return {
        ok: true,
        title: tx('قائمة M3U صالحة', 'Valid M3U playlist'),
        lines: [tx(`عدد العناصر: ${count}`, `Items: ${count}`), tx(`زمن الاستجابة: ${Date.now() - started} ms`, `Response time: ${Date.now() - started} ms`)],
      };
    } catch (e: any) {
      return failNetwork(e, tx);
    }
  }

  /* ---------------- Xtream Codes ---------------- */
  if (!form.username || !form.password) {
    return { ok: false, title: tx('أدخل اسم المستخدم وكلمة المرور', 'Enter username and password'), lines: [] };
  }
  const query = `?username=${encodeURIComponent(form.username)}&password=${encodeURIComponent(form.password)}`;
  let lastHttp: number | null = null;
  let lastErr: any = null;
  let notJson = false;

  for (const base of candidates(server)) {
    try {
      const res = await timedFetch(`${base}/player_api.php${query}`, 12000, { Accept: 'application/json, text/plain, */*', Referer: `${base}/` }, form.userAgent);
      if (!res.ok) { lastHttp = res.status; continue; }
      let data: any;
      try { data = await res.json(); } catch { notJson = true; continue; }
      const info = data?.user_info;
      if (!info) { notJson = true; continue; }

      const ms = Date.now() - started;
      if (info.auth === 0 || data?.error) {
        return { ok: false, title: tx('اسم المستخدم أو كلمة المرور غير صحيحة', 'Wrong username or password'), lines: [tx('السيرفر يعمل لكن بيانات الدخول مرفوضة.', 'The server is reachable but rejected the login.')] };
      }
      const status = String(info.status || '');
      const exp = dateOf(info.exp_date);
      const lines: string[] = [];
      if (exp) {
        const days = Math.ceil((exp.getTime() - Date.now()) / 86400000);
        lines.push(tx(`ينتهي الاشتراك: ${exp.toLocaleDateString()} (${days > 0 ? `باقي ${days} يوم` : 'منتهي'})`, `Expires: ${exp.toLocaleDateString()} (${days > 0 ? `${days} days left` : 'expired'})`));
      } else {
        lines.push(tx('الاشتراك: غير محدد المدة', 'Subscription: no expiry'));
      }
      if (info.max_connections) lines.push(tx(`الاتصالات: ${info.active_cons || 0} / ${info.max_connections}`, `Connections: ${info.active_cons || 0} / ${info.max_connections}`));
      if (String(info.is_trial) === '1') lines.push(tx('نوع الحساب: تجريبي', 'Account type: trial'));
      lines.push(tx(`زمن الاستجابة: ${ms} ms`, `Response time: ${ms} ms`));

      if (status && status.toLowerCase() !== 'active') {
        return { ok: false, title: tx(`الحساب غير نشط (${status})`, `Account is not active (${status})`), lines };
      }
      if (exp && exp.getTime() < Date.now()) {
        return { ok: false, title: tx('انتهى الاشتراك', 'Subscription expired'), lines };
      }
      return { ok: true, title: tx('الاتصال ناجح ✓', 'Connection successful ✓'), lines };
    } catch (e: any) {
      lastErr = e;
    }
  }

  if (notJson) return { ok: false, title: tx('الرد غير متوقع: هل هذا سيرفر Xtream؟', 'Unexpected reply: is this an Xtream server?'), lines: [tx('إن كان لديك رابط قائمة M3U فالصقه في خانة السيرفر.', 'If you have an M3U link, paste it in the Server field.')] };
  if (lastHttp) {
    const hint = lastHttp === 401 || lastHttp === 403 ? tx('السيرفر رفض الطلب (قد يكون الحساب محظورًا).', 'The server refused the request (the account may be blocked).')
      : lastHttp === 404 ? tx('تأكد من عنوان السيرفر والبورت.', 'Check the server address and port.')
      : tx('تأكد من الرابط أو حاول لاحقًا.', 'Check the URL or try again later.');
    return { ok: false, title: tx(`رد السيرفر: HTTP ${lastHttp}`, `Server replied: HTTP ${lastHttp}`), lines: [hint] };
  }
  return failNetwork(lastErr, tx);
}

function failNetwork(e: any, tx: (ar: string, en: string) => string): TestResult {
  const timeout = e?.name === 'AbortError';
  return {
    ok: false,
    title: timeout ? tx('انتهت المهلة: السيرفر لا يرد', 'Timed out: the server is not responding') : tx('تعذر الوصول إلى السيرفر', 'Cannot reach the server'),
    lines: [tx('تأكد من الإنترنت ومن عنوان السيرفر والبورت.', 'Check your internet connection and the server address and port.')],
  };
}

/**
 * Accepts a pasted Xtream "get.php" / "player_api.php" link and splits it into
 * server + username + password. Returns null for anything else.
 */
export function parseXtreamUrl(value: string): { server: string; username: string; password: string } | null {
  const m = value.trim().match(/^(https?:\/\/[^?\s]+?)\/(?:get|player_api|panel_api)\.php\?(.+)$/i);
  if (!m) return null;
  const params: Record<string, string> = {};
  m[2].split('&').forEach(pair => {
    const [k, ...rest] = pair.split('=');
    if (k) params[decodeURIComponent(k).toLowerCase()] = decodeURIComponent(rest.join('=') || '');
  });
  if (!params.username || !params.password) return null;
  return { server: m[1].replace(/\/$/, ''), username: params.username, password: params.password };
}
