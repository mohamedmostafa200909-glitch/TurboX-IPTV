import * as FileSystem from 'expo-file-system';
import { parseM3uText } from '../playlists/m3uParser';
import { extractTvgUrl } from '../epg/xmltv';
import type { Provider, Media } from '../types';
import { serverCandidates } from '../utils/media';
import { IptvError, kindFromFetchError, kindFromHttp, kindFromPayload } from './errors';
import { planAttempts } from './xtreamPlan';
import { logWarn } from '../utils/logger';
import { uaFor } from './userAgent';

/** Which address variant (http/https) last worked for a provider: tried first next time, and the only one used for quick calls. */
const workingServer = new Map<string, string>();

export async function xtream<T>(provider: Provider, action = '', opts: { quick?: boolean; timeoutMs?: number } = {}) {
  const query = `?username=${encodeURIComponent(provider.username)}&password=${encodeURIComponent(provider.password)}${action ? `&${action}` : ''}`;
  const memoKey = `${provider.id}|${provider.server}`;
  const plan = planAttempts(serverCandidates(provider.server), workingServer.get(memoKey), !!opts.quick, opts.timeoutMs);
  let last: IptvError = new IptvError('unreachable');
  for (const { server, timeouts } of plan) {
    for (const timeoutMs of timeouts) {
      const controller = new AbortController();
      let timedOut = false;
      const timeout = setTimeout(() => { timedOut = true; controller.abort(); }, timeoutMs);
      try {
        const response = await fetch(`${server}/player_api.php${query}`, {
          signal: controller.signal,
          headers: {
            'User-Agent': uaFor(provider),
            'Accept': 'application/json, text/plain, */*',
            'Cache-Control': 'no-cache',
            'Referer': `${server}/`,
            'Origin': server
          }
        });
        if (!response.ok) {
          // keep a short, tag-free snippet of the reply: providers often explain a refusal in the body (shown in the logs)
          let snippet = '';
          try { snippet = (await response.text()).replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 120); } catch { /* no body */ }
          // which hop refused? (origin panel vs. CDN/WAF/proxy) — a few harmless response headers tell
          const hdr = ['server', 'via', 'cf-ray', 'x-powered-by', 'retry-after', 'content-type', 'content-length']
            .map(h => { const v = response.headers.get(h); return v ? `${h}=${String(v).slice(0, 40)}` : ''; }).filter(Boolean).join(' ');
          last = new IptvError(kindFromHttp(response.status), `HTTP ${response.status}${snippet ? ` | ${snippet}` : ' | (empty body)'}${hdr ? ` | ${hdr}` : ''}`);
          if (response.status >= 400 && response.status < 500) break; // wrong credentials/path: retrying will not help
          continue;
        }
        const payload = await response.json();
        const bad = kindFromPayload(payload);
        if (bad) {
          last = new IptvError(bad, typeof payload?.error === 'string' ? payload.error : '');
          break;
        }
        workingServer.set(memoKey, server);
        return payload as T;
      } catch (error: any) {
        const kind = kindFromFetchError(error, timedOut);
        last = new IptvError(kind, kind === 'timeout' ? `${timeoutMs / 1000}s` : kind === 'unreachable' ? String(error?.message || '') : '');
      } finally {
        clearTimeout(timeout);
      }
    }
  }
  logWarn('xtream', `${action || 'login'} failed: ${last.kind} ${last.detail}`);
  throw last;
}

export async function loadM3u(url: string): Promise<{items: Media[]; epgUrl: string | null}> {
  const source = url.trim();
  const text = source.startsWith('file://') ? await FileSystem.readAsStringAsync(source) : await (async () => {
    let response: Response;
    try {
      response = await fetch(source);
    } catch (error: any) {
      throw new IptvError('unreachable', String(error?.message || ''));
    }
    if (!response.ok) throw new IptvError(kindFromHttp(response.status), `HTTP ${response.status}`);
    return response.text();
  })();
  const epgUrl = extractTvgUrl(text);
  const items: Media[] = [];
  await parseM3uText(text, batch => {
    items.push(...batch.map(x => ({
      name: x.name,
      category_name: x.group || 'عام',
      stream_icon: x.logo,
      tvgId: x.tvgId,
      tvgName: x.tvgName,
      url: x.url,
      kind: 'live' as const
    })));
  });
  return {items, epgUrl};
}