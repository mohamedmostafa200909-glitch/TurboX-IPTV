import { candidates, timedFetch } from './testConnection';

export type AccountInfo = {
  kind: 'xtream' | 'm3u';
  status: string;            // Active / Expired / Disabled / Banned ...
  active: boolean;
  expiresAt: Date | null;
  daysLeft: number | null;
  expired: boolean;
  activeCons: number | null;
  maxCons: number | null;
  isTrial: boolean;
  createdAt: Date | null;
  username: string;
  serverHost: string;
  timezone: string;
  fetchedAt: number;
};

const dateOf = (sec: any) => {
  const n = Number(sec);
  return n > 0 ? new Date(n * 1000) : null;
};
const num = (v: any) => {
  const n = Number(v);
  return Number.isFinite(n) && v !== null && v !== undefined && v !== '' ? n : null;
};
const hostOf = (server: string) => server.replace(/^https?:\/\//i, '').replace(/\/.*$/, '');

/** Build the account summary from a player_api.php payload (no extra request needed). */
export function accountInfoFromPayload(payload: any, provider: { server: string; username: string }): AccountInfo {
  const u = payload?.user_info || {};
  const exp = dateOf(u.exp_date);
  const daysLeft = exp ? Math.ceil((exp.getTime() - Date.now()) / 86400000) : null;
  const status = String(u.status || (u.auth === 0 ? 'Disabled' : 'Active'));
  const expired = !!exp && exp.getTime() < Date.now();
  return {
    kind: 'xtream',
    status,
    active: status.toLowerCase() === 'active' && !expired,
    expiresAt: exp,
    daysLeft,
    expired,
    activeCons: num(u.active_cons),
    maxCons: num(u.max_connections),
    isTrial: String(u.is_trial) === '1',
    createdAt: dateOf(u.created_at),
    username: String(u.username || provider.username || ''),
    serverHost: hostOf(provider.server),
    timezone: String(payload?.server_info?.timezone || ''),
    fetchedAt: Date.now(),
  };
}

export function m3uAccountInfo(provider: { server: string }): AccountInfo {
  return {
    kind: 'm3u', status: 'M3U', active: true, expiresAt: null, daysLeft: null, expired: false,
    activeCons: null, maxCons: null, isTrial: false, createdAt: null, username: '',
    serverHost: hostOf(provider.server.startsWith('file://') ? 'local-file' : provider.server), timezone: '', fetchedAt: Date.now(),
  };
}

/** Fresh request (used by the Refresh button). Throws on network / auth failure. */
export async function fetchAccountInfo(provider: { server: string; username: string; password: string }): Promise<AccountInfo> {
  const query = `?username=${encodeURIComponent(provider.username)}&password=${encodeURIComponent(provider.password)}`;
  let lastError = 'network';
  for (const base of candidates(provider.server)) {
    try {
      const res = await timedFetch(`${base}/player_api.php${query}`, 15000, { Accept: 'application/json, text/plain, */*', Referer: `${base}/` });
      if (!res.ok) { lastError = `HTTP ${res.status}`; continue; }
      const data = await res.json();
      if (!data?.user_info) { lastError = 'bad-response'; continue; }
      return accountInfoFromPayload(data, provider);
    } catch (e: any) {
      lastError = e?.name === 'AbortError' ? 'timeout' : e?.message || 'network';
    }
  }
  throw new Error(lastError);
}
