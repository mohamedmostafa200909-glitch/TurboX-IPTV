# بناء ملف APK لتطبيق TurboX

اختر طريقة واحدة:

## 1) GitHub Actions (الأسهل، بدون أي برامج على جهازك)
1. أنشئ مستودعًا خاصًا (Private) على GitHub وارفع محتويات هذا المجلد.
2. افتح تبويب **Actions** ← **Build TurboX APK** ← **Run workflow**.
3. بعد 10 إلى 20 دقيقة افتح التشغيل المكتمل ونزّل **TurboX-APK** من قسم Artifacts. بداخله `app-release.apk`.
4. انقل الملف إلى جهاز Android أو TV Box (فلاشة أو Send Files to TV) وثبّته. فعّل "مصادر غير معروفة" إن طُلب.

## 2) على جهازك (يتطلب Android SDK)
```bash
./build-apk.sh
```
الملف يظهر في `android/app/build/outputs/apk/release/app-release.apk`.

## 3) Expo EAS Build (سيرفرات Expo)
```bash
npm install -g eas-cli
eas login
eas build -p android --profile preview
```

## بعد التثبيت: اختبار الريموت
- أول تشغيل: شاشة الافتتاح ← اختيار TV ← إضافة الحساب.
- جرّب: الأسهم في الرئيسية، OK على البطاقات، فتح قناة، أرقام القنوات، الزر الأحمر لمؤقت النوم.
- لو حصل خطأ على TV Box: `adb connect <IP>` ثم `adb logcat -s TV_REMOTE_DEBUG ReactNativeJS` وأرسل لي الناتج.
