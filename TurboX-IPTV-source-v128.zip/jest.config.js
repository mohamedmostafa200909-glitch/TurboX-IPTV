// Unit tests cover only pure logic (parsers, error classification, cache rules, favourite lists…).
// They never import React Native, so plain ts-jest in a Node environment is enough: `npm test`.
module.exports = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  testMatch: ['<rootDir>/__tests__/**/*.test.ts'],
  transform: { '^.+\\.tsx?$': ['ts-jest', { tsconfig: { module: 'commonjs', target: 'es2020', esModuleInterop: true, jsx: 'react', strict: false, skipLibCheck: true }, diagnostics: false }] },
};
