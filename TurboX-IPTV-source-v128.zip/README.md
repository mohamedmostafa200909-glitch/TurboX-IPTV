# StreamBox IPTV — Expo Android

نسخة React Native / Expo من واجهة StreamBox، مع إضافة مزود Xtream Codes وجلب Live وMovies وSeries وEPG.

## التشغيل

```bash
npm install
npx expo start
```

لإنشاء APK لاحقًا على جهاز يملك Android SDK أو عبر EAS:

```bash
npx expo install
npx eas build -p android --profile preview
```

لا توجد بيانات مزود حقيقية داخل المشروع. تُحفظ بيانات المصادر محليًا على الجهاز، ويجب إدخالها من شاشة إضافة المصدر.
