// Same simulation with a layout shift the app never reported (stale cache): fast path vs original vs ground truth.
// Run after the tsc command in tv-sim-equivalence.js:  node tools/tv-sim-stale.js
// Simulation of the TV focus engine: does the fast path pick the same control as the full path, and how many measure calls?
const Module = require('module');
const origResolve = Module._resolveFilename;
const stubs = {
  react: { createContext: () => ({ Provider: () => null }), forwardRef: f => f, useCallback: f => f, useContext: () => null, useEffect() {}, useMemo: f => f(), useRef: v => ({ current: v }), useState: v => [v, () => {}], default: null },
  'react-native': { DeviceEventEmitter: { addListener() {} }, Keyboard: { addListener() {} }, FlatList: () => null, Pressable: () => null, ScrollView: () => null, TextInput: () => null },
};
stubs.react.default = stubs.react;
Module._resolveFilename = function (req, ...a) { return stubs[req] ? req : origResolve.call(this, req, ...a); };
const origLoad = Module._load;
Module._load = function (req, ...a) { return stubs[req] ? stubs[req] : origLoad.call(this, req, ...a); };
const { tvEngine } = require('/tmp/tvbuild/tv/focus.js');

const sleep = ms => new Promise(r => setTimeout(r, ms));
let measureCalls = 0;
const W = 700, VH = 600;
let scrollY = 0;
const scroller = { axis: 'y', ref: { current: { scrollToOffset: ({ offset }) => { scrollY = offset; scroller.actual.current = offset; tvEngine.bump(); }, measureInWindow: cb => { measureCalls++; cb(0, 0, W, VH); } } }, offset: { current: 0 }, actual: { current: 0 } };
const layout = []; // {id,x,y,w,h} in content coordinates
// left: 30 channel rows; right: 3-column poster grid with 12 rows (focus order mixes both on purpose)
for (let i = 0; i < 30; i++) layout.push({ id: 'r' + i, x: 0, y: i * 60, w: 330, h: 52 });
for (let i = 0; i < 36; i++) layout.push({ id: 'g' + i, x: 350 + (i % 3) * 120, y: Math.floor(i / 3) * 170, w: 110, h: 160 });
function setup() {
  tvEngine.invalidate();
  for (const n of [...layout]) tvEngine.unregister(n.id);
  tvEngine.registerScroller('s1', scroller);
  scrollY = 0; scroller.offset.current = 0; scroller.actual.current = 0;
  for (const n of layout) {
    tvEngine.register({ id: n.id, chain: ['s1'], preferred: false, modal: null, press() {},
      ref: { current: { measureInWindow: cb => { measureCalls++; setTimeout(() => cb(n.x, n.y - scrollY, n.w, n.h), 0); } } } });
  }
}
async function run(useFast, seq, waitMs, shift = 0, truth = false) {
  setup();
  tvEngine.enabled = true;
  if (!useFast) tvEngine.fastMove = async () => false; else delete tvEngine.fastMove;
  await sleep(2500); // let warm() fill the cache while idle
  if (shift) { for (const n of layout) if (n.id[0] === 'g') n.y += shift; if (truth) tvEngine.invalidate(); }
  tvEngine.setCurrent('g4');
  const path = []; measureCalls = 0;
  for (const dir of seq) {
    tvEngine.move(dir); // fire like a key press (async)
    await sleep(waitMs);
    path.push(tvEngine.current);
  }
  return { path, calls: measureCalls, perf: tvEngine.perf };
}
(async () => {
  const dirs = ['down', 'down', 'down', 'right', 'down', 'down', 'left', 'up', 'down', 'down', 'down', 'down', 'right', 'right', 'down', 'down', 'down', 'up', 'left', 'left', 'down', 'down', 'down', 'down', 'down', 'down', 'up', 'up', 'right', 'down'];
  // seed a deterministic pseudo random tail for extra coverage
  let seed = 7; const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
  for (let i = 0; i < 40; i++) dirs.push(['up', 'down', 'left', 'right'][Math.floor(rnd() * 4)]);
  for (const wait of []) {
    const slow = await run(false, dirs, wait);
    const fast = await run(true, dirs, wait);
    const same = JSON.stringify(slow.path) === JSON.stringify(fast.path);
    let firstDiff = -1; for (let i = 0; i < dirs.length; i++) if (slow.path[i] !== fast.path[i]) { firstDiff = i; break; }
    console.log(`key spacing ${String(wait).padStart(3)}ms | same targets: ${same}${same ? '' : ' (first diff at move ' + firstDiff + ': ' + slow.path[firstDiff] + ' vs ' + fast.path[firstDiff] + ')'} | measure calls full-path: ${slow.calls}  fast-path: ${fast.calls}  (${dirs.length} moves)`);
  }
  // restore layout between runs
  const reset = () => { for (const n of layout) if (n.id[0] === 'g') n.y = Math.floor(Number(n.id.slice(1)) / 3) * 170; };
  const seq2 = dirs.slice(0, 40);
  reset(); const truth = await run(false, seq2, 200, 40, true);
  reset(); const slow = await run(false, seq2, 200, 40, false);
  reset(); const fast = await run(true, seq2, 200, 40, false);
  const diff = (a, b) => a.path.reduce((n, x, i) => n + (x !== b.path[i] ? 1 : 0), 0);
  console.log('layout shifted by 40px without invalidate (40 moves, compared with ground truth after a proper invalidate):');
  console.log('  original full path differs from truth in', diff(slow, truth), 'moves | fast path differs in', diff(fast, truth), 'moves');
  console.log('  measure calls: full', slow.calls, ' fast', fast.calls);
  process.exit(0);
})();
